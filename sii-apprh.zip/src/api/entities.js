import { base44 } from './base44Client';


export const Department = base44.entities.Department;

export const Employee = base44.entities.Employee;

export const LeaveRequest = base44.entities.LeaveRequest;

export const Attendance = base44.entities.Attendance;

export const PerformanceReview = base44.entities.PerformanceReview;

export const Document = base44.entities.Document;

export const DocumentRequest = base44.entities.DocumentRequest;

export const OnboardingTask = base44.entities.OnboardingTask;

export const JobPosting = base44.entities.JobPosting;

export const Candidate = base44.entities.Candidate;

export const Training = base44.entities.Training;

export const Skill = base44.entities.Skill;

export const Asset = base44.entities.Asset;

export const PerformanceGoal = base44.entities.PerformanceGoal;

export const Interview = base44.entities.Interview;

export const WorkflowTemplate = base44.entities.WorkflowTemplate;

export const Workflow = base44.entities.Workflow;

export const DocumentVersion = base44.entities.DocumentVersion;

export const DocumentShare = base44.entities.DocumentShare;

export const JobHistory = base44.entities.JobHistory;

export const SocialWorkerCase = base44.entities.SocialWorkerCase;

export const UserRole = base44.entities.UserRole;

export const ChatChannel = base44.entities.ChatChannel;

export const ChatMessage = base44.entities.ChatMessage;

export const Notification = base44.entities.Notification;

export const TrainingEnrollment = base44.entities.TrainingEnrollment;

export const SelfAssessment = base44.entities.SelfAssessment;

export const PeerFeedback = base44.entities.PeerFeedback;

export const CareerPath = base44.entities.CareerPath;

export const SuccessionPlan = base44.entities.SuccessionPlan;

export const TalentPool = base44.entities.TalentPool;

export const SkillGap = base44.entities.SkillGap;

export const DocumentSignature = base44.entities.DocumentSignature;

export const TrainingCertificate = base44.entities.TrainingCertificate;

export const ContinuousFeedback = base44.entities.ContinuousFeedback;

export const DocumentAuditLog = base44.entities.DocumentAuditLog;

export const DocumentPermission = base44.entities.DocumentPermission;



// auth sdk:
export const User = base44.auth;