import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, Upload } from "lucide-react";
import EmployeeCard from "../components/employees/EmployeeCard";
import EmployeeForm from "../components/employees/EmployeeForm";
import EmployeeDetails from "../components/employees/EmployeeDetails";
import EmployeeImport from "../components/employees/EmployeeImport";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { generateWorkflow } from "../components/workflow/WorkflowAutomation";
import { notifyNewEmployee } from "../components/notifications/NotificationTriggers";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Employees() {
  const [showForm, setShowForm] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [employeeToDelete, setEmployeeToDelete] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: employees = [], isLoading } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list('-created_date'),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const createMutation = useMutation({
    mutationFn: async ({ data, generateWorkflow: shouldGenerateWorkflow }) => {
      try {
        console.log("Creating employee with data:", data);
        const employee = await base44.entities.Employee.create(data);
        console.log("Employee created:", employee);
        
        if (shouldGenerateWorkflow && data.hire_date) {
          try {
            await generateWorkflow(employee, 'onboarding', data.hire_date);
          } catch (error) {
            console.error('Erreur lors de la génération du workflow:', error);
          }
        }
        
        return employee;
      } catch (error) {
        console.error("Error creating employee:", error);
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      queryClient.invalidateQueries({ queryKey: ['onboardingTasks'] });
      setShowForm(false);
      setSelectedEmployee(null);
      toast({
        title: "Employé créé",
        description: "L'employé a été ajouté avec succès.",
        duration: 5000,
      });
    },
    onError: (error) => {
      console.error("Mutation error:", error);
      toast({
        title: "Erreur",
        description: `Impossible de créer l'employé: ${error.message || 'Erreur inconnue'}`,
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => {
      console.log("Updating employee:", id, data);
      return base44.entities.Employee.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setSelectedEmployee(null);
      setShowForm(false);
      toast({
        title: "Employé mis à jour",
        description: "Les informations ont été modifiées avec succès.",
        duration: 5000,
      });
    },
    onError: (error) => {
      console.error("Update error:", error);
      toast({
        title: "Erreur",
        description: `Impossible de mettre à jour l'employé: ${error.message || 'Erreur inconnue'}`,
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Employee.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setSelectedEmployee(null);
      setEmployeeToDelete(null);
      toast({
        title: "✅ Employé supprimé",
        description: "Le profil de l'employé a été supprimé définitivement.",
        duration: 5000,
      });
    },
    onError: (error) => {
      console.error("Delete error:", error);
      toast({
        title: "Erreur",
        description: `Impossible de supprimer l'employé: ${error.message || 'Erreur inconnue'}`,
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  const handleSubmit = (data, shouldGenerateWorkflow = false) => {
    console.log("handleSubmit called with:", data, shouldGenerateWorkflow);
    
    if (selectedEmployee) {
      updateMutation.mutate({ id: selectedEmployee.id, data });
    } else {
      createMutation.mutate({ data, generateWorkflow: shouldGenerateWorkflow });
    }
  };

  const handleDeleteClick = (employee) => {
    setEmployeeToDelete(employee);
  };

  const handleDeleteConfirm = () => {
    if (employeeToDelete) {
      deleteMutation.mutate(employeeToDelete.id);
    }
  };

  const filteredEmployees = employees.filter(emp => {
    const matchesSearch = emp.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.position?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = filterDepartment === "all" || emp.department === filterDepartment;
    const matchesStatus = filterStatus === "all" || emp.status === filterStatus;
    return matchesSearch && matchesDepartment && matchesStatus;
  });

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Employés</h1>
          <p className="text-slate-600 mt-1">{employees.length} employés au total</p>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={() => setShowImport(true)}
            variant="outline"
            className="shadow-md"
          >
            <Upload className="w-4 h-4 mr-2" />
            Importer
          </Button>
          <Button
            onClick={() => {
              setSelectedEmployee(null);
              setShowForm(true);
            }}
            className="bg-blue-600 hover:bg-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter un employé
          </Button>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
          <Input
            placeholder="Rechercher des employés..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterDepartment} onValueChange={setFilterDepartment}>
          <SelectTrigger className="w-full md:w-48">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Département" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les départements</SelectItem>
            {departments.map(dept => (
              <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-full md:w-40">
            <SelectValue placeholder="Statut" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les statuts</SelectItem>
            <SelectItem value="active">Actif</SelectItem>
            <SelectItem value="on_leave">En congé</SelectItem>
            <SelectItem value="terminated">Terminé</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Chargement des employés...</p>
        </div>
      ) : filteredEmployees.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          <p className="text-lg font-medium">Aucun employé trouvé</p>
          <p className="text-sm mt-1">Ajustez vos filtres ou ajoutez un nouvel employé</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredEmployees.map((employee) => (
            <EmployeeCard
              key={employee.id}
              employee={employee}
              onEdit={() => {
                setSelectedEmployee(employee);
                setShowForm(true);
              }}
              onView={() => setSelectedEmployee(employee)}
              onDelete={handleDeleteClick}
            />
          ))}
        </div>
      )}

      {showForm && (
        <EmployeeForm
          employee={selectedEmployee}
          departments={departments}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setSelectedEmployee(null);
          }}
          isSubmitting={createMutation.isPending || updateMutation.isPending}
        />
      )}

      {selectedEmployee && !showForm && (
        <EmployeeDetails
          employee={selectedEmployee}
          onClose={() => setSelectedEmployee(null)}
          onEdit={() => setShowForm(true)}
          onDelete={handleDeleteClick}
        />
      )}

      {showImport && (
        <EmployeeImport
          onClose={() => setShowImport(false)}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['employees'] });
            setShowImport(false);
          }}
        />
      )}

      <AlertDialog open={!!employeeToDelete} onOpenChange={() => setEmployeeToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              🗑️ Supprimer définitivement cet employé ?
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <div className="p-4 bg-red-50 rounded-lg border border-red-200">
                <p className="font-semibold text-red-900 text-base">
                  {employeeToDelete?.full_name}
                </p>
                <p className="text-sm text-red-700">{employeeToDelete?.position}</p>
                <p className="text-xs text-red-600">{employeeToDelete?.email}</p>
              </div>
              
              <div className="p-3 bg-orange-50 rounded border border-orange-200">
                <p className="text-sm font-medium text-orange-900 mb-1">⚠️ Attention :</p>
                <ul className="text-xs text-orange-800 space-y-1 list-disc list-inside">
                  <li>Cette action est <strong>irréversible</strong></li>
                  <li>Toutes les données de cet employé seront supprimées</li>
                  <li>Les évaluations, formations et historiques seront perdus</li>
                </ul>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700 text-white"
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? "Suppression..." : "🗑️ Supprimer définitivement"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}