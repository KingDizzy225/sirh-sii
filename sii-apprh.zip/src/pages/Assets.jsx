import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Package } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AssetCard from "../components/assets/AssetCard";
import AssetForm from "../components/assets/AssetForm";

export default function Assets() {
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("all");

  const queryClient = useQueryClient();

  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['assets'],
    queryFn: () => base44.entities.Asset.list('-created_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Asset.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      setShowForm(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Asset.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
    },
  });

  const handleAssign = (id, employeeEmail, employeeName) => {
    updateMutation.mutate({
      id,
      data: {
        assigned_to: employeeEmail,
        assigned_to_name: employeeName,
        status: 'assigned',
        assignment_date: new Date().toISOString().split('T')[0]
      }
    });
  };

  const handleUnassign = (id) => {
    updateMutation.mutate({
      id,
      data: {
        assigned_to: "",
        assigned_to_name: "",
        status: 'available',
        assignment_date: ""
      }
    });
  };

  const filteredAssets = filter === "all" ? assets : assets.filter(a => a.status === filter);

  const availableCount = assets.filter(a => a.status === 'available').length;
  const assignedCount = assets.filter(a => a.status === 'assigned').length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestion des actifs</h1>
          <p className="text-slate-600 mt-1">
            {availableCount} disponibles • {assignedCount} assignés
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouvel actif
        </Button>
      </div>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="all">Tous ({assets.length})</TabsTrigger>
          <TabsTrigger value="available">Disponibles ({availableCount})</TabsTrigger>
          <TabsTrigger value="assigned">Assignés ({assignedCount})</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
          <TabsTrigger value="retired">Retirés</TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <div className="text-center py-12">Chargement...</div>
      ) : filteredAssets.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          <Package className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p>Aucun actif trouvé</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAssets.map((asset) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              employees={employees}
              onAssign={handleAssign}
              onUnassign={handleUnassign}
            />
          ))}
        </div>
      )}

      {showForm && (
        <AssetForm
          employees={employees}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}
    </div>
  );
}