import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import DepartmentCard from "../components/departments/DepartmentCard";
import DepartmentForm from "../components/departments/DepartmentForm";

export default function Departments() {
  const [showForm, setShowForm] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState(null);

  const queryClient = useQueryClient();

  const { data: departments = [], isLoading } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Department.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments'] });
      setShowForm(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Department.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['departments'] });
      setSelectedDepartment(null);
      setShowForm(false);
    },
  });

  const handleSubmit = (data) => {
    if (selectedDepartment) {
      updateMutation.mutate({ id: selectedDepartment.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Departments</h1>
          <p className="text-slate-600 mt-1">{departments.length} departments</p>
        </div>
        <Button
          onClick={() => {
            setSelectedDepartment(null);
            setShowForm(true);
          }}
          className="bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Department
        </Button>
      </div>

      {/* Departments Grid */}
      {isLoading ? (
        <div className="text-center py-12">Loading...</div>
      ) : departments.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          <p>No departments found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {departments.map((department) => (
            <DepartmentCard
              key={department.id}
              department={department}
              employees={employees.filter(e => e.department === department.name && e.status === 'active')}
              onEdit={() => {
                setSelectedDepartment(department);
                setShowForm(true);
              }}
            />
          ))}
        </div>
      )}

      {/* Department Form */}
      {showForm && (
        <DepartmentForm
          department={selectedDepartment}
          employees={employees.filter(e => e.status === 'active')}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setSelectedDepartment(null);
          }}
          isSubmitting={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}