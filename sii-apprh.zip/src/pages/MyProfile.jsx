
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  User, Mail, Phone, MapPin, Calendar, Briefcase, Award,
  GraduationCap, FileText, AlertTriangle, Edit, Save, X,
  Home, Globe, Heart, Building2, History, Download, MessageSquare
} from "lucide-react";
import { format, differenceInYears, differenceInMonths } from "date-fns";
import { fr } from "date-fns/locale";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";

// Profile components
import SkillsEditor from "../components/profile/SkillsEditor";
import CertificationsViewer from "../components/profile/CertificationsViewer";
import TrainingHistoryViewer from "../components/profile/TrainingHistoryViewer";
import ManagerFeedbackSection from "../components/profile/ManagerFeedbackSection";

const statusColors = {
  active: "bg-green-100 text-green-800",
  on_leave: "bg-yellow-100 text-yellow-800",
  terminated: "bg-red-100 text-red-800",
};

const statusLabels = {
  active: "Actif",
  on_leave: "En congé",
  terminated: "Terminé",
};

const maritalStatusLabels = {
  single: "Célibataire",
  married: "Marié(e)",
  divorced: "Divorcé(e)",
  widowed: "Veuf/Veuve"
};

export default function MyProfile() {
  const [user, setUser] = useState(null);
  const [employee, setEmployee] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({});
  const [activeTab, setActiveTab] = useState("personal");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: !!user,
  });

  useEffect(() => {
    if (user && employees.length > 0) {
      const emp = employees.find(e => e.email === user.email);
      setEmployee(emp);
      if (emp) {
        setFormData(emp);
      }
    }
  }, [user, employees]);

  const { data: jobHistory = [] } = useQuery({
    queryKey: ['myJobHistory', employee?.id],
    queryFn: () => base44.entities.JobHistory.filter({ employee_id: employee.id }),
    enabled: !!employee,
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['myReviews', employee?.email],
    queryFn: () => base44.entities.PerformanceReview.filter({ employee_email: employee.email }),
    enabled: !!employee,
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['mySkills', employee?.email],
    queryFn: () => base44.entities.Skill.filter({ employee_email: employee.email }),
    enabled: !!employee,
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['myDocuments', employee?.id],
    queryFn: () => base44.entities.Document.filter({ employee_id: employee.id }),
    enabled: !!employee,
  });

  const { data: allTrainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
    enabled: !!employee,
  });

  const { data: certificates = [] } = useQuery({
    queryKey: ['myCertificates', employee?.email],
    queryFn: () => base44.entities.TrainingCertificate.filter({ employee_email: employee.email }),
    enabled: !!employee,
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Employee.update(employee.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setEditMode(false);
      toast({
        title: "Profil mis à jour",
        description: "Vos informations ont été mises à jour avec succès.",
        duration: 5000,
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour le profil.",
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  if (!employee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Chargement de votre profil...</p>
        </div>
      </div>
    );
  }

  const employeeTrainings = allTrainings.filter(training =>
    training.enrolled_employees?.includes(employee.email) ||
    training.completed_employees?.includes(employee.email)
  );

  const yearsOfService = employee.hire_date
    ? differenceInYears(new Date(), new Date(employee.hire_date))
    : 0;
  const monthsOfService = employee.hire_date
    ? differenceInMonths(new Date(), new Date(employee.hire_date)) % 12
    : 0;

  const sortedJobHistory = [...jobHistory].sort((a, b) =>
    new Date(b.start_date) - new Date(a.start_date)
  );

  const sortedReviews = [...reviews].sort((a, b) =>
    new Date(b.review_date) - new Date(a.review_date)
  );

  const handleSave = () => {
    // Ne permettre la modification que des champs personnels
    const allowedFields = {
      personal_phone: formData.personal_phone,
      address: formData.address,
      city: formData.city,
      postal_code: formData.postal_code,
      country: formData.country,
      emergency_contact_name: formData.emergency_contact_name,
      emergency_contact_relationship: formData.emergency_contact_relationship,
      emergency_contact_phone: formData.emergency_contact_phone,
      emergency_contact_email: formData.emergency_contact_email,
      secondary_emergency_contact_name: formData.secondary_emergency_contact_name,
      secondary_emergency_contact_phone: formData.secondary_emergency_contact_phone,
    };

    updateMutation.mutate(allowedFields);
  };

  const handleCancel = () => {
    setFormData(employee);
    setEditMode(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-none shadow-xl bg-gradient-to-r from-blue-600 to-blue-700">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
              <div className="flex items-center gap-6">
                <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center shadow-lg">
                  <span className="text-4xl font-bold text-blue-600">
                    {employee.full_name?.charAt(0) || 'E'}
                  </span>
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">{employee.full_name}</h1>
                  <p className="text-blue-100 text-lg font-medium mb-2">{employee.position}</p>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge className={statusColors[employee.status]}>
                      {statusLabels[employee.status]}
                    </Badge>
                    {employee.employee_id && (
                      <Badge variant="secondary">ID: {employee.employee_id}</Badge>
                    )}
                    <Badge variant="secondary" className="bg-white/20 text-white">
                      {employee.department}
                    </Badge>
                  </div>
                </div>
              </div>

              {!editMode ? (
                <Button
                  onClick={() => setEditMode(true)}
                  className="bg-white text-blue-600 hover:bg-blue-50"
                >
                  <Edit className="w-4 h-4 mr-2" />
                  Modifier mes informations
                </Button>
              ) : (
                <div className="flex gap-3">
                  <Button
                    onClick={handleCancel}
                    variant="outline"
                    className="bg-white/20 text-white hover:bg-white/30"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Annuler
                  </Button>
                  <Button
                    onClick={handleSave}
                    disabled={updateMutation.isPending}
                    className="bg-white text-blue-600 hover:bg-blue-50"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {updateMutation.isPending ? "Enregistrement..." : "Enregistrer"}
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Ancienneté</p>
                  <p className="text-xl font-bold text-slate-900">
                    {yearsOfService > 0 ? `${yearsOfService}a` : `${monthsOfService}m`}
                  </p>
                </div>
                <Calendar className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Compétences</p>
                  <p className="text-xl font-bold text-slate-900">{skills.length}</p>
                </div>
                <Award className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Certifications</p>
                  <p className="text-xl font-bold text-slate-900">{certificates.length}</p>
                </div>
                <Award className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Formations</p>
                  <p className="text-xl font-bold text-slate-900">{employeeTrainings.length}</p>
                </div>
                <GraduationCap className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Évaluations</p>
                  <p className="text-xl font-bold text-slate-900">{reviews.length}</p>
                </div>
                <MessageSquare className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-slate-600 mb-1">Documents</p>
                  <p className="text-xl font-bold text-slate-900">{documents.length}</p>
                </div>
                <FileText className="w-8 h-8 text-teal-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contenu principal */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-white shadow-md grid w-full grid-cols-3 md:grid-cols-7">
            <TabsTrigger value="personal">Infos</TabsTrigger>
            <TabsTrigger value="job">Poste</TabsTrigger>
            <TabsTrigger value="skills">Compétences</TabsTrigger>
            <TabsTrigger value="training">Formations</TabsTrigger>
            <TabsTrigger value="history">Historique</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          {/* Informations personnelles */}
          <TabsContent value="personal" className="mt-6 space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Coordonnées
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                    <Mail className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-xs text-slate-500 mb-1">Email professionnel</p>
                      <p className="text-sm font-medium text-slate-900">{employee.email}</p>
                    </div>
                  </div>

                  {employee.phone && (
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                      <Phone className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-xs text-slate-500 mb-1">Téléphone professionnel</p>
                        <p className="text-sm font-medium text-slate-900">{employee.phone}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                    <Phone className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-xs text-slate-500 mb-1">Téléphone personnel</p>
                      {editMode ? (
                        <Input
                          value={formData.personal_phone || ""}
                          onChange={(e) => setFormData({...formData, personal_phone: e.target.value})}
                          className="text-sm"
                        />
                      ) : (
                        <p className="text-sm font-medium text-slate-900">
                          {employee.personal_phone || "Non renseigné"}
                        </p>
                      )}
                    </div>
                  </div>

                  {employee.date_of_birth && (
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                      <Calendar className="w-5 h-5 text-orange-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-xs text-slate-500 mb-1">Date de naissance</p>
                        <p className="text-sm font-medium text-slate-900">
                          {format(new Date(employee.date_of_birth), 'dd MMMM yyyy', { locale: fr })}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Home className="w-5 h-5" />
                  Adresse
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {editMode ? (
                    <>
                      <div className="space-y-2">
                        <Label>Adresse complète</Label>
                        <Textarea
                          value={formData.address || ""}
                          onChange={(e) => setFormData({...formData, address: e.target.value})}
                          rows={2}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Ville</Label>
                          <Input
                            value={formData.city || ""}
                            onChange={(e) => setFormData({...formData, city: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Code postal</Label>
                          <Input
                            value={formData.postal_code || ""}
                            onChange={(e) => setFormData({...formData, postal_code: e.target.value})}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Pays</Label>
                          <Input
                            value={formData.country || ""}
                            onChange={(e) => setFormData({...formData, country: e.target.value})}
                          />
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                      <MapPin className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-xs text-slate-500 mb-1">Adresse complète</p>
                        <p className="text-sm font-medium text-slate-900">
                          {employee.address || "Non renseignée"}
                        </p>
                        {(employee.city || employee.postal_code) && (
                          <p className="text-sm text-slate-600 mt-1">
                            {employee.postal_code} {employee.city}
                            {employee.country && `, ${employee.country}`}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {employee.nationality && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Globe className="w-5 h-5 text-indigo-600 mt-0.5 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-xs text-slate-500 mb-1">Nationalité</p>
                          <p className="text-sm font-medium text-slate-900">{employee.nationality}</p>
                        </div>
                      </div>
                    )}

                    {employee.marital_status && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Heart className="w-5 h-5 text-pink-600 mt-0.5 flex-shrink-0" />
                        <div className="flex-1">
                          <p className="text-xs text-slate-500 mb-1">Situation familiale</p>
                          <p className="text-sm font-medium text-slate-900">
                            {maritalStatusLabels[employee.marital_status] || employee.marital_status}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5" />
                  Contacts d'urgence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {editMode ? (
                    <>
                      <div className="p-4 rounded-lg bg-orange-50 border border-orange-200 space-y-4">
                        <p className="font-semibold text-slate-900">Contact d'urgence principal</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Nom complet</Label>
                            <Input
                              value={formData.emergency_contact_name || ""}
                              onChange={(e) => setFormData({...formData, emergency_contact_name: e.target.value})}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Relation</Label>
                            <Input
                              value={formData.emergency_contact_relationship || ""}
                              onChange={(e) => setFormData({...formData, emergency_contact_relationship: e.target.value})}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Téléphone</Label>
                            <Input
                              value={formData.emergency_contact_phone || ""}
                              onChange={(e) => setFormData({...formData, emergency_contact_phone: e.target.value})}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Email</Label>
                            <Input
                              type="email"
                              value={formData.emergency_contact_email || ""}
                              onChange={(e) => setFormData({...formData, emergency_contact_email: e.target.value})}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-4">
                        <p className="font-semibold text-slate-900">Contact d'urgence secondaire</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Nom complet</Label>
                            <Input
                              value={formData.secondary_emergency_contact_name || ""}
                              onChange={(e) => setFormData({...formData, secondary_emergency_contact_name: e.target.value})}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Téléphone</Label>
                            <Input
                              value={formData.secondary_emergency_contact_phone || ""}
                              onChange={(e) => setFormData({...formData, secondary_emergency_contact_phone: e.target.value})}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    <>
                      {employee.emergency_contact_name && (
                        <div className="p-4 rounded-lg bg-orange-50 border border-orange-200">
                          <p className="font-semibold text-slate-900 mb-3">Contact d'urgence principal</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <p className="text-xs text-slate-600">Nom</p>
                              <p className="font-medium">{employee.emergency_contact_name}</p>
                            </div>
                            {employee.emergency_contact_relationship && (
                              <div>
                                <p className="text-xs text-slate-600">Relation</p>
                                <p className="font-medium">{employee.emergency_contact_relationship}</p>
                              </div>
                            )}
                            {employee.emergency_contact_phone && (
                              <div>
                                <p className="text-xs text-slate-600">Téléphone</p>
                                <p className="font-medium">{employee.emergency_contact_phone}</p>
                              </div>
                            )}
                            {employee.emergency_contact_email && (
                              <div>
                                <p className="text-xs text-slate-600">Email</p>
                                <p className="font-medium">{employee.emergency_contact_email}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {employee.secondary_emergency_contact_name && (
                        <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                          <p className="font-semibold text-slate-900 mb-3">Contact d'urgence secondaire</p>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <p className="text-xs text-slate-600">Nom</p>
                              <p className="font-medium">{employee.secondary_emergency_contact_name}</p>
                            </div>
                            {employee.secondary_emergency_contact_phone && (
                              <div>
                                <p className="text-xs text-slate-600">Téléphone</p>
                                <p className="font-medium">{employee.secondary_emergency_contact_phone}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {!employee.emergency_contact_name && (
                        <p className="text-sm text-slate-500 italic">Aucun contact d'urgence enregistré</p>
                      )}
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mon poste */}
          <TabsContent value="job" className="mt-6 space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Mon poste actuel
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg bg-slate-50">
                    <p className="text-xs text-slate-600 mb-1">Poste</p>
                    <p className="font-semibold text-lg">{employee.position}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50">
                    <p className="text-xs text-slate-600 mb-1">Département</p>
                    <p className="font-semibold text-lg">{employee.department}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50">
                    <p className="text-xs text-slate-600 mb-1">Date d'embauche</p>
                    <p className="font-medium">{format(new Date(employee.hire_date), 'dd/MM/yyyy')}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {yearsOfService > 0 && `${yearsOfService} an${yearsOfService > 1 ? 's' : ''} `}
                      {monthsOfService > 0 && `${monthsOfService} mois`}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-50">
                    <p className="text-xs text-slate-600 mb-1">Type d'emploi</p>
                    <p className="font-medium capitalize">{employee.employment_type?.replace('_', ' ')}</p>
                  </div>

                  {employee.work_location && (
                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Lieu de travail</p>
                      <p className="font-medium">{employee.work_location}</p>
                    </div>
                  )}

                  {employee.office_number && (
                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Bureau</p>
                      <p className="font-medium">{employee.office_number}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {employee.manager_name && (
              <Card className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Mon manager
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                    <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-lg">
                        {employee.manager_name?.charAt(0) || 'M'}
                      </span>
                    </div>
                    <div>
                      <p className="font-semibold text-slate-900">{employee.manager_name}</p>
                      {employee.manager_email && (
                        <p className="text-sm text-slate-600">{employee.manager_email}</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Compétences */}
          <TabsContent value="skills" className="mt-6 space-y-6">
            <SkillsEditor skills={skills} employee={employee} editable={true} />
            <CertificationsViewer certificates={certificates} />
          </TabsContent>

          {/* Formations */}
          <TabsContent value="training" className="mt-6">
            <TrainingHistoryViewer trainings={employeeTrainings} employeeEmail={employee.email} />
          </TabsContent>

          {/* Historique */}
          <TabsContent value="history" className="mt-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Mon historique dans l'entreprise
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sortedJobHistory.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Aucun historique disponible</p>
                ) : (
                  <div className="space-y-4">
                    {sortedJobHistory.map((job) => (
                      <div
                        key={job.id}
                        className={`p-4 rounded-lg border-2 ${
                          job.is_current ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-slate-50'
                        }`}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="font-semibold text-lg text-slate-900">{job.position}</p>
                            <p className="text-sm text-slate-600">{job.department}</p>
                          </div>
                          {job.is_current && (
                            <Badge className="bg-blue-600">Actuel</Badge>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3 mt-3">
                          <div>
                            <p className="text-xs text-slate-500">Début</p>
                            <p className="text-sm font-medium">
                              {format(new Date(job.start_date), 'MMMM yyyy', { locale: fr })}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-slate-500">Fin</p>
                            <p className="text-sm font-medium">
                              {job.end_date
                                ? format(new Date(job.end_date), 'MMMM yyyy', { locale: fr })
                                : "Aujourd'hui"
                              }
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Performance */}
          <TabsContent value="performance" className="mt-6 space-y-6">
            {/* Feedback du manager */}
            <ManagerFeedbackSection
              employee={employee}
              isManager={false}
              currentUserEmail={user?.email}
            />

            {/* Évaluations formelles */}
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Mes évaluations formelles ({sortedReviews.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {sortedReviews.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Aucune évaluation disponible</p>
                ) : (
                  <div className="space-y-4">
                    {sortedReviews.map((review) => (
                      <div key={review.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <p className="font-semibold text-slate-900">{review.review_period}</p>
                            <p className="text-sm text-slate-600">
                              {format(new Date(review.review_date), 'dd MMMM yyyy', { locale: fr })}
                            </p>
                          </div>
                          <Badge className="bg-blue-600 text-lg">
                            {review.overall_rating.toFixed(1)} ⭐
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                          <div className="p-2 bg-white rounded">
                            <p className="text-xs text-slate-600">Technique</p>
                            <p className="font-semibold">{review.technical_skills}/5</p>
                          </div>
                          <div className="p-2 bg-white rounded">
                            <p className="text-xs text-slate-600">Communication</p>
                            <p className="font-semibold">{review.communication}/5</p>
                          </div>
                          <div className="p-2 bg-white rounded">
                            <p className="text-xs text-slate-600">Équipe</p>
                            <p className="font-semibold">{review.teamwork}/5</p>
                          </div>
                          <div className="p-2 bg-white rounded">
                            <p className="text-xs text-slate-600">Leadership</p>
                            <p className="font-semibold">{review.leadership}/5</p>
                          </div>
                        </div>

                        {review.strengths && (
                          <div className="mb-2">
                            <p className="text-xs font-medium text-green-700 mb-1">Points forts</p>
                            <p className="text-sm text-slate-700 bg-white p-2 rounded">{review.strengths}</p>
                          </div>
                        )}

                        {review.areas_for_improvement && (
                          <div>
                            <p className="text-xs font-medium text-orange-700 mb-1">À améliorer</p>
                            <p className="text-sm text-slate-700 bg-white p-2 rounded">{review.areas_for_improvement}</p>
                          </div>
                        )}

                        {review.goals && (
                          <div className="mt-2">
                            <p className="text-xs font-medium text-blue-700 mb-1">Objectifs</p>
                            <p className="text-sm text-slate-700 bg-white p-2 rounded">{review.goals}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents */}
          <TabsContent value="documents" className="mt-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Mes documents ({documents.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {documents.length === 0 ? (
                  <p className="text-sm text-slate-500 italic">Aucun document disponible</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {documents.map((doc) => (
                      <div key={doc.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50 hover:border-blue-300 transition-colors">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1">
                            <p className="font-semibold text-slate-900">{doc.title}</p>
                            <Badge variant="outline" className="mt-1">
                              {doc.document_type}
                            </Badge>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => window.open(doc.file_url, '_blank')}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                        {doc.description && (
                          <p className="text-xs text-slate-600 mt-2">{doc.description}</p>
                        )}
                        <p className="text-xs text-slate-500 mt-2">
                          Ajouté le {format(new Date(doc.upload_date), 'dd/MM/yyyy')}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
