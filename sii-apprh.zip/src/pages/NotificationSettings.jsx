import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import NotificationSettings from "../components/notifications/NotificationSettings";

export default function NotificationSettingsPage() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 md:p-8">
      <div className="max-w-4xl mx-auto">
        <NotificationSettings user={user} />
      </div>
    </div>
  );
}