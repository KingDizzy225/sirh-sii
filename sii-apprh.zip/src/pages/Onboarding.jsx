
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, CheckCircle, Clock, Users, Calendar, AlertCircle, TrendingUp } from "lucide-react";
import OnboardingTaskCard from "../components/onboarding/TaskCard";
import OnboardingTaskForm from "../components/onboarding/TaskForm";
import { Card, CardContent } from "@/components/ui/card";
import { updateWorkflowProgress } from "../components/workflow/WorkflowAutomation";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function Onboarding() {
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [activeTab, setActiveTab] = useState("tasks");
  const [user, setUser] = useState(null);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ['onboardingTasks'],
    queryFn: () => base44.entities.OnboardingTask.list('-created_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const { data: workflows = [] } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.Workflow.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.OnboardingTask.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['onboardingTasks'] });
      setShowForm(false);
      toast({
        title: "Tâche créée",
        description: "La tâche a été ajoutée avec succès.",
        duration: 5000,
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, status }) => {
      const task = await base44.entities.OnboardingTask.update(id, { status });
      
      // Mettre à jour la progression du workflow
      const relatedWorkflows = workflows.filter(w => 
        w.employee_email === task.employee_email && 
        w.workflow_type === task.task_type
      );
      
      if (relatedWorkflows.length > 0) {
        await updateWorkflowProgress(
          relatedWorkflows[0].id,
          task.employee_email,
          task.task_type
        );
      }

      // Créer notification si tâche complétée
      if (status === 'completed') {
        try {
          await base44.entities.Notification.create({
            user_email: task.employee_email,
            user_name: task.employee_name,
            notification_type: "system",
            title: "Tâche terminée ✅",
            message: `La tâche "${task.title}" a été marquée comme terminée.`,
            priority: "low",
            icon: "check-circle"
          });
        } catch (error) {
          console.error("Erreur lors de la création de la notification:", error);
        }
      }

      return task;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['onboardingTasks'] });
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      
      const statusMessages = {
        in_progress: "La tâche a été démarrée",
        completed: "Tâche marquée comme terminée ✅",
        pending: "Tâche remise en attente"
      };

      toast({
        title: "Statut mis à jour",
        description: statusMessages[variables.status] || "Le statut a été modifié",
        duration: 5000,
      });
    },
  });

  const handleUpdateStatus = (taskId, status) => {
    updateMutation.mutate({ id: taskId, status });
  };

  // Filtrage des tâches
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = 
      task.employee_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.title?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || task.status === filterStatus;
    const matchesType = filterType === "all" || task.task_type === filterType;
    const matchesPriority = filterPriority === "all" || task.priority === filterPriority;
    
    return matchesSearch && matchesStatus && matchesType && matchesPriority;
  });

  // Statistiques
  const totalTasks = tasks.length;
  const pendingTasks = tasks.filter(t => t.status === 'pending').length;
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress').length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const overdueTasks = tasks.filter(t => {
    if (t.status === 'completed') return false;
    const dueDate = new Date(t.due_date);
    return dueDate < new Date();
  }).length;

  // Grouper les tâches par employé
  const tasksByEmployee = filteredTasks.reduce((acc, task) => {
    if (!acc[task.employee_email]) {
      acc[task.employee_email] = {
        employee: task.employee_name,
        email: task.employee_email,
        tasks: [],
        total: 0,
        completed: 0,
        pending: 0,
        in_progress: 0
      };
    }
    
    acc[task.employee_email].tasks.push(task);
    acc[task.employee_email].total++;
    acc[task.employee_email][task.status]++;
    
    return acc;
  }, {});

  const employeeGroups = Object.values(tasksByEmployee);

  // Vue des workflows
  const activeWorkflows = workflows.filter(w => 
    w.status === 'in_progress' || w.status === 'not_started'
  );

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Intégration & Départ</h1>
          <p className="text-slate-600 mt-1">
            {totalTasks} tâches • {completionRate}% terminées • {overdueTasks} en retard
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter une tâche
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Total tâches</p>
                <p className="text-3xl font-bold text-blue-900">{totalTasks}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-700 mb-1">En attente</p>
                <p className="text-3xl font-bold text-yellow-900">{pendingTasks}</p>
              </div>
              <Clock className="w-10 h-10 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">En cours</p>
                <p className="text-3xl font-bold text-blue-900">{inProgressTasks}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Terminées</p>
                <p className="text-3xl font-bold text-green-900">{completedTasks}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 mb-1">En retard</p>
                <p className="text-3xl font-bold text-red-900">{overdueTasks}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtres */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher des tâches ou employés..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
                <SelectItem value="in_progress">En cours</SelectItem>
                <SelectItem value="completed">Terminées</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les types</SelectItem>
                <SelectItem value="onboarding">Intégration</SelectItem>
                <SelectItem value="offboarding">Départ</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Priorité" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes priorités</SelectItem>
                <SelectItem value="critical">Critique</SelectItem>
                <SelectItem value="high">Haute</SelectItem>
                <SelectItem value="medium">Moyenne</SelectItem>
                <SelectItem value="low">Faible</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="tasks">
            Toutes les tâches ({filteredTasks.length})
          </TabsTrigger>
          <TabsTrigger value="by-employee">
            Par employé ({employeeGroups.length})
          </TabsTrigger>
          <TabsTrigger value="workflows">
            Workflows ({activeWorkflows.length})
          </TabsTrigger>
        </TabsList>

        {/* Vue toutes les tâches */}
        <TabsContent value="tasks" className="mt-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-slate-600">Chargement des tâches...</p>
            </div>
          ) : filteredTasks.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Calendar className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune tâche trouvée</p>
                <p className="text-sm">Ajustez vos filtres ou ajoutez une nouvelle tâche</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredTasks.map((task) => (
                <OnboardingTaskCard
                  key={task.id}
                  task={task}
                  onUpdateStatus={handleUpdateStatus}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Vue par employé */}
        <TabsContent value="by-employee" className="mt-6">
          {employeeGroups.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p>Aucun employé avec des tâches en cours</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {employeeGroups.map((group) => {
                const progress = group.total > 0 ? Math.round((group.completed / group.total) * 100) : 0;
                
                return (
                  <Card key={group.email} className="border-none shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                            <span className="text-white font-bold text-lg">
                              {group.employee.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <h3 className="font-bold text-lg text-slate-900">{group.employee}</h3>
                            <p className="text-sm text-slate-600">{group.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="bg-yellow-50 text-yellow-700">
                            {group.pending} en attente
                          </Badge>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {group.in_progress} en cours
                          </Badge>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {group.completed} terminées
                          </Badge>
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-slate-700">Progression</span>
                          <span className="text-sm font-bold text-blue-600">{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        {group.tasks.map((task) => (
                          <OnboardingTaskCard
                            key={task.id}
                            task={task}
                            onUpdateStatus={handleUpdateStatus}
                          />
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Vue workflows */}
        <TabsContent value="workflows" className="mt-6">
          {activeWorkflows.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <TrendingUp className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun workflow actif</p>
                <p className="text-sm">Les workflows sont créés automatiquement lors de l'ajout d'employés</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {activeWorkflows.map((workflow) => {
                const workflowTasks = tasks.filter(t => 
                  t.employee_email === workflow.employee_email && 
                  t.task_type === workflow.workflow_type
                );
                const completedCount = workflowTasks.filter(t => t.status === 'completed').length;
                const progress = workflowTasks.length > 0 
                  ? Math.round((completedCount / workflowTasks.length) * 100) 
                  : 0;

                return (
                  <Card key={workflow.id} className="border-none shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={workflow.workflow_type === 'onboarding' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
                              {workflow.workflow_type === 'onboarding' ? 'Intégration' : 'Départ'}
                            </Badge>
                          </div>
                          <h3 className="font-bold text-lg">{workflow.employee_name}</h3>
                          <p className="text-sm text-slate-600">{workflow.position} • {workflow.department}</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium text-slate-700">Progression</span>
                            <span className="text-sm font-bold text-blue-600">{progress}%</span>
                          </div>
                          <Progress value={progress} className="h-2" />
                          <p className="text-xs text-slate-500 mt-1">
                            {completedCount} sur {workflowTasks.length} tâches terminées
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <p className="text-slate-600">Début</p>
                            <p className="font-medium">{format(new Date(workflow.start_date), 'dd/MM/yyyy')}</p>
                          </div>
                          {workflow.expected_completion_date && (
                            <div>
                              <p className="text-slate-600">Fin prévue</p>
                              <p className="font-medium">{format(new Date(workflow.expected_completion_date), 'dd/MM/yyyy')}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {showForm && (
        <OnboardingTaskForm
          employees={employees}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}
    </div>
  );
}
