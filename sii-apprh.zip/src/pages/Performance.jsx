import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Award, Target, Star, MessageSquare, BarChart3, User, Sparkles } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import PerformanceCard from "../components/performance/PerformanceCard";
import PerformanceForm from "../components/performance/PerformanceForm";
import PerformanceDashboard from "../components/performance/PerformanceDashboard";
import EmployeePerformanceHistory from "../components/performance/EmployeePerformanceHistory";
import GoalsTracking from "../components/performance/GoalsTracking";
import PerformanceAnalytics from "../components/performance/PerformanceAnalytics";
import SelfAssessmentForm from "../components/performance/SelfAssessmentForm";
import PeerFeedbackForm from "../components/performance/PeerFeedbackForm";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import AIPerformanceHelper from "../components/ai/AIPerformanceHelper";
import AIPerformanceSentimentAnalysis from "../components/ai/AIPerformanceSentimentAnalysis";
import ContinuousFeedbackForm from "../components/feedback/ContinuousFeedbackForm";
import ContinuousFeedbackList from "../components/feedback/ContinuousFeedbackList";
import AIFeedbackAnalysis from "../components/ai/AIFeedbackAnalysis";
import AIPerformanceReviewAssistant from "../components/ai/AIPerformanceReviewAssistant";
import { notifyPerformanceReview } from "../components/notifications/NotificationTriggers";

export default function Performance() {
  const [showForm, setShowForm] = useState(false);
  const [showSelfAssessmentForm, setShowSelfAssessmentForm] = useState(false);
  const [showPeerFeedbackForm, setShowPeerFeedbackForm] = useState(false);
  const [showContinuousFeedbackForm, setShowContinuousFeedbackForm] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: reviews = [] } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list('-review_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['performanceGoals'],
    queryFn: () => base44.entities.PerformanceGoal.list('-created_date'),
  });

  const { data: selfAssessments = [] } = useQuery({
    queryKey: ['selfAssessments'],
    queryFn: () => base44.entities.SelfAssessment.list('-assessment_date'),
  });

  const { data: peerFeedbacks = [] } = useQuery({
    queryKey: ['peerFeedbacks'],
    queryFn: () => base44.entities.PeerFeedback.list('-feedback_date'),
  });

  const { data: continuousFeedbacks = [] } = useQuery({
    queryKey: ['continuousFeedbacks'],
    queryFn: () => base44.entities.ContinuousFeedback.list('-created_date'),
  });

  const createReviewMutation = useMutation({
    mutationFn: async (data) => {
      const review = await base44.entities.PerformanceReview.create(data);
      
      // Créer notification pour l'employé
      try {
        await base44.entities.Notification.create({
          user_email: data.employee_email,
          user_name: data.employee_name,
          notification_type: "performance_review",
          title: "Nouvelle évaluation de performance",
          message: `Votre évaluation de performance pour ${data.review_period} est disponible.`,
          priority: "high",
          action_url: "/Performance",
          action_label: "Consulter",
          related_id: review.id,
          related_type: "PerformanceReview",
          icon: "award"
        });
      } catch (error) {
        console.error("Erreur lors de la création de la notification:", error);
      }

      return review;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['performanceReviews'] });
      setShowForm(false);
      toast({
        title: "Évaluation créée",
        description: "L'évaluation de performance a été enregistrée avec succès.",
      });
    },
  });

  const createSelfAssessmentMutation = useMutation({
    mutationFn: async (data) => {
      const assessment = await base44.entities.SelfAssessment.create(data);
      
      // Notifier les RH si soumis
      if (data.status === 'submitted') {
        try {
          await base44.entities.Notification.create({
            user_email: 'rh@sii.com',
            user_name: 'RH',
            notification_type: "system",
            title: "Nouvelle auto-évaluation",
            message: `${data.employee_name} a soumis son auto-évaluation pour ${data.review_period}.`,
            priority: "medium",
            action_url: "/Performance",
            action_label: "Consulter",
            icon: "star"
          });
        } catch (error) {
          console.error("Erreur lors de la création de la notification:", error);
        }
      }

      return assessment;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['selfAssessments'] });
      setShowSelfAssessmentForm(false);
      toast({
        title: variables.status === 'submitted' ? "Auto-évaluation soumise" : "Brouillon enregistré",
        description: variables.status === 'submitted' 
          ? "Votre auto-évaluation a été soumise avec succès." 
          : "Votre auto-évaluation a été enregistrée en brouillon.",
      });
    },
  });

  const createPeerFeedbackMutation = useMutation({
    mutationFn: async (data) => {
      const feedback = await base44.entities.PeerFeedback.create(data);
      
      // Notifier les RH si soumis
      if (data.status === 'submitted') {
        try {
          await base44.entities.Notification.create({
            user_email: 'rh@sii.com',
            user_name: 'RH',
            notification_type: "system",
            title: "Nouveau feedback pair",
            message: `Un feedback collègue ${data.is_anonymous ? '(anonyme)' : `de ${data.reviewer_name}`} a été soumis pour ${data.reviewed_employee_name}.`,
            priority: "medium",
            action_url: "/Performance",
            action_label: "Consulter",
            icon: "message-square"
          });
        } catch (error) {
          console.error("Erreur lors de la création de la notification:", error);
        }
      }

      return feedback;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['peerFeedbacks'] });
      setShowPeerFeedbackForm(false);
      toast({
        title: variables.status === 'submitted' ? "Feedback soumis" : "Brouillon enregistré",
        description: variables.status === 'submitted' 
          ? "Votre feedback a été soumis avec succès." 
          : "Votre feedback a été enregistré en brouillon.",
      });
    },
  });

  const createContinuousFeedbackMutation = useMutation({
    mutationFn: async (data) => {
      const feedback = await base44.entities.ContinuousFeedback.create(data);
      
      // Notifier le destinataire
      await base44.entities.Notification.create({
        user_email: data.receiver_email,
        user_name: data.receiver_name,
        notification_type: "system",
        title: "Nouveau feedback reçu",
        message: `${data.is_anonymous ? 'Quelqu\'un' : data.giver_name} vous a laissé un feedback.`,
        priority: "medium",
        action_url: "/Performance?tab=continuous",
        action_label: "Voir",
        icon: "message-square"
      });

      return feedback;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['continuousFeedbacks'] });
      setShowContinuousFeedbackForm(false);
      toast({
        title: "Feedback envoyé ✅",
        description: "Votre feedback a été transmis",
      });
    },
  });

  const acknowledgeFeedbackMutation = useMutation({
    mutationFn: (id) => base44.entities.ContinuousFeedback.update(id, {
      status: 'acknowledged',
      acknowledged_date: new Date().toISOString()
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['continuousFeedbacks'] });
      toast({ title: "Marqué comme lu" });
    },
  });

  const respondToFeedbackMutation = useMutation({
    mutationFn: ({ id, response }) => base44.entities.ContinuousFeedback.update(id, { response }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['continuousFeedbacks'] });
      toast({ title: "Réponse envoyée" });
    },
  });

  // Stats
  const totalReviews = reviews.length;
  const totalGoals = goals.length;
  const completedGoals = goals.filter(g => g.status === 'completed').length;
  const totalSelfAssessments = selfAssessments.filter(s => s.status === 'submitted' || s.status === 'reviewed').length;
  const totalPeerFeedbacks = peerFeedbacks.filter(p => p.status === 'submitted' || p.status === 'reviewed').length;
  const totalContinuousFeedbacks = continuousFeedbacks.length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Gestion de la Performance</h1>
          <p className="text-slate-600 mt-1">
            {totalReviews} évaluations • {totalGoals} objectifs • {totalContinuousFeedbacks} feedbacks continus
          </p>
        </div>
        <div className="flex gap-3 flex-wrap">
          <Button
            onClick={() => setShowContinuousFeedbackForm(true)}
            className="bg-green-600 hover:bg-green-700"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Donner un feedback
          </Button>
          <Button
            onClick={() => setShowSelfAssessmentForm(true)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Star className="w-4 h-4 mr-2" />
            Mon auto-évaluation
          </Button>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nouvelle évaluation
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Évaluations</p>
                <p className="text-3xl font-bold text-blue-900">{totalReviews}</p>
              </div>
              <div className="w-12 h-12 bg-blue-200 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-blue-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Objectifs</p>
                <p className="text-3xl font-bold text-green-900">{totalGoals}</p>
                <p className="text-xs text-green-600 mt-1">{completedGoals} complétés</p>
              </div>
              <div className="w-12 h-12 bg-green-200 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-green-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Auto-éval.</p>
                <p className="text-3xl font-bold text-purple-900">{totalSelfAssessments}</p>
              </div>
              <div className="w-12 h-12 bg-purple-200 rounded-xl flex items-center justify-center">
                <Star className="w-6 h-6 text-purple-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Feedbacks</p>
                <p className="text-3xl font-bold text-orange-900">{totalPeerFeedbacks}</p>
              </div>
              <div className="w-12 h-12 bg-orange-200 rounded-xl flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-orange-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-indigo-50 to-indigo-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-indigo-700 mb-1">Employés</p>
                <p className="text-3xl font-bold text-indigo-900">{employees.length}</p>
              </div>
              <div className="w-12 h-12 bg-indigo-200 rounded-xl flex items-center justify-center">
                <User className="w-6 h-6 text-indigo-700" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md flex flex-wrap h-auto">
          <TabsTrigger value="dashboard" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="ai-assistant" className="gap-2">
            <Sparkles className="w-4 h-4" />
            Assistant IA
          </TabsTrigger>
          <TabsTrigger value="continuous" className="gap-2">
            <MessageSquare className="w-4 h-4" />
            Feedbacks ({totalContinuousFeedbacks})
          </TabsTrigger>
          <TabsTrigger value="reviews" className="gap-2">
            <Award className="w-4 h-4" />
            Évaluations ({totalReviews})
          </TabsTrigger>
          <TabsTrigger value="goals" className="gap-2">
            <Target className="w-4 h-4" />
            Objectifs ({totalGoals})
          </TabsTrigger>
          <TabsTrigger value="by-employee" className="gap-2">
            <User className="w-4 h-4" />
            Par employé
          </TabsTrigger>
          <TabsTrigger value="ai-analysis" className="gap-2">
            <Sparkles className="w-4 h-4" />
            Analyse IA
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-6">
          <PerformanceDashboard
            reviews={reviews}
            goals={goals}
            selfAssessments={selfAssessments}
            peerFeedbacks={peerFeedbacks}
            employees={employees}
          />
        </TabsContent>

        <TabsContent value="reviews" className="mt-6">
          {reviews.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Award className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune évaluation enregistrée</p>
                <p className="text-sm">Commencez par créer une évaluation de performance</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {reviews.map((review) => (
                <PerformanceCard key={review.id} review={review} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="goals" className="mt-6">
          {/* Assistant IA pour objectifs */}
          <div className="mb-6">
            <AIPerformanceHelper type="goals" employeeData={{}} />
          </div>
          
          <GoalsTracking goals={goals} employees={employees} reviews={reviews} />
        </TabsContent>

        <TabsContent value="self-assessments" className="mt-6">
          {selfAssessments.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Star className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune auto-évaluation</p>
                <p className="text-sm mb-4">Les employés peuvent soumettre leur auto-évaluation</p>
                <Button
                  onClick={() => setShowSelfAssessmentForm(true)}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  <Star className="w-4 h-4 mr-2" />
                  Créer mon auto-évaluation
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {selfAssessments.map((assessment) => (
                <Card key={assessment.id} className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={
                            assessment.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                            assessment.status === 'reviewed' ? 'bg-green-100 text-green-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {assessment.status === 'submitted' ? 'Soumis' :
                             assessment.status === 'reviewed' ? 'Examiné' :
                             'Brouillon'}
                          </Badge>
                          <Badge variant="outline">Auto-évaluation</Badge>
                        </div>
                        <h3 className="font-bold text-lg">{assessment.employee_name}</h3>
                        <p className="text-sm text-slate-600">{assessment.review_period}</p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-purple-600 text-lg">
                          {assessment.overall_rating}/5 ⭐
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Technique</p>
                        <p className="font-semibold">{assessment.technical_skills_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Communication</p>
                        <p className="font-semibold">{assessment.communication_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Équipe</p>
                        <p className="font-semibold">{assessment.teamwork_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Leadership</p>
                        <p className="font-semibold">{assessment.leadership_rating}/5</p>
                      </div>
                    </div>

                    {assessment.achievements && (
                      <div className="mb-3 p-3 bg-green-50 rounded-lg border border-green-200">
                        <p className="text-xs font-medium text-green-700 mb-1">🏆 Réalisations</p>
                        <p className="text-sm text-green-900">{assessment.achievements}</p>
                      </div>
                    )}

                    {assessment.areas_for_growth && (
                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <p className="text-xs font-medium text-blue-700 mb-1">📈 Développement</p>
                        <p className="text-sm text-blue-900">{assessment.areas_for_growth}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="peer-feedback" className="mt-6">
          {peerFeedbacks.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun feedback entre pairs</p>
                <p className="text-sm mb-4">Encouragez le feedback à 360° entre collègues</p>
                <Button
                  onClick={() => setShowPeerFeedbackForm(true)}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Donner un feedback
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {peerFeedbacks.map((feedback) => (
                <Card key={feedback.id} className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={
                            feedback.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                            feedback.status === 'reviewed' ? 'bg-green-100 text-green-800' :
                            'bg-gray-100 text-gray-800'
                          }>
                            {feedback.status === 'submitted' ? 'Soumis' :
                             feedback.status === 'reviewed' ? 'Examiné' :
                             'Brouillon'}
                          </Badge>
                          {feedback.is_anonymous && (
                            <Badge variant="outline" className="bg-amber-50 text-amber-700">
                              🔒 Anonyme
                            </Badge>
                          )}
                        </div>
                        <h3 className="font-bold text-lg">{feedback.reviewed_employee_name}</h3>
                        <p className="text-sm text-slate-600">
                          Par: {feedback.is_anonymous ? 'Anonyme' : feedback.reviewer_name}
                        </p>
                        <p className="text-xs text-slate-500">{feedback.review_period}</p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-orange-600 text-lg">
                          {feedback.overall_rating}/5 ⭐
                        </Badge>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Collaboration</p>
                        <p className="font-semibold">{feedback.collaboration_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Communication</p>
                        <p className="font-semibold">{feedback.communication_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Fiabilité</p>
                        <p className="font-semibold">{feedback.reliability_rating}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Expertise</p>
                        <p className="font-semibold">{feedback.technical_expertise_rating}/5</p>
                      </div>
                    </div>

                    {feedback.strengths && (
                      <div className="mb-3 p-3 bg-green-50 rounded-lg border border-green-200">
                        <p className="text-xs font-medium text-green-700 mb-1">✨ Points forts</p>
                        <p className="text-sm text-green-900">{feedback.strengths}</p>
                      </div>
                    )}

                    {feedback.areas_for_improvement && (
                      <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                        <p className="text-xs font-medium text-orange-700 mb-1">📈 À améliorer</p>
                        <p className="text-sm text-orange-900">{feedback.areas_for_improvement}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="by-employee" className="mt-6">
          <EmployeePerformanceHistory
            reviews={reviews}
            goals={goals}
            selfAssessments={selfAssessments}
            peerFeedbacks={peerFeedbacks}
            employees={employees}
          />
        </TabsContent>

        <TabsContent value="ai-assistant" className="mt-6">
          <AIPerformanceReviewAssistant
            employees={employees}
            continuousFeedbacks={continuousFeedbacks}
            peerFeedbacks={peerFeedbacks}
            selfAssessments={selfAssessments}
            performanceGoals={goals}
            onUseReview={(reviewData) => {
              createMutation.mutate(reviewData);
            }}
          />
        </TabsContent>

        <TabsContent value="continuous" className="mt-6 space-y-6">
          <ContinuousFeedbackList
            feedbacks={continuousFeedbacks}
            currentUser={employees.find(e => e.email === 'current_user')}
            onAcknowledge={(id) => acknowledgeFeedbackMutation.mutate(id)}
            onRespond={(id, response) => respondToFeedbackMutation.mutate({ id, response })}
          />
        </TabsContent>

        <TabsContent value="ai-analysis" className="mt-6">
          <AIFeedbackAnalysis
            feedbacks={continuousFeedbacks}
            employees={employees}
          />
        </TabsContent>
      </Tabs>

      {showForm && (
        <PerformanceForm
          employees={employees}
          onSubmit={(data) => createReviewMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createReviewMutation.isPending}
        />
      )}

      {showSelfAssessmentForm && (
        <SelfAssessmentForm
          onSubmit={(data) => createSelfAssessmentMutation.mutate(data)}
          onCancel={() => setShowSelfAssessmentForm(false)}
          isSubmitting={createSelfAssessmentMutation.isPending}
        />
      )}

      {showPeerFeedbackForm && (
        <PeerFeedbackForm
          employees={employees}
          onSubmit={(data) => createPeerFeedbackMutation.mutate(data)}
          onCancel={() => setShowPeerFeedbackForm(false)}
          isSubmitting={createPeerFeedbackMutation.isPending}
        />
      )}

      {showContinuousFeedbackForm && (
        <ContinuousFeedbackForm
          employees={employees}
          onSubmit={(data) => createContinuousFeedbackMutation.mutate(data)}
          onCancel={() => setShowContinuousFeedbackForm(false)}
          isSubmitting={createContinuousFeedbackMutation.isPending}
        />
      )}
    </div>
  );
}