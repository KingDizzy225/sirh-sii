import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Heart, 
  Plus, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  Shield,
  Send,
  MessageSquare
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusColors = {
  nouveau: "bg-orange-100 text-orange-800",
  en_cours: "bg-blue-100 text-blue-800",
  en_attente: "bg-yellow-100 text-yellow-800",
  resolu: "bg-green-100 text-green-800",
  cloture: "bg-gray-100 text-gray-800",
};

const statusLabels = {
  nouveau: "Nouveau",
  en_cours: "En cours",
  en_attente: "En attente",
  resolu: "Résolu",
  cloture: "Clôturé",
};

const caseTypeLabels = {
  soutien_personnel: "💙 Soutien personnel",
  aide_administrative: "📋 Aide administrative",
  conflit: "⚖️ Gestion de conflit",
  conseil: "💬 Conseil",
  urgence_sociale: "🚨 Urgence sociale",
  accompagnement_familial: "👨‍👩‍👧‍👦 Accompagnement familial",
  sante_mentale: "🧠 Santé mentale",
  autre: "📁 Autre",
};

const caseTypes = [
  { value: "soutien_personnel", label: "💙 Soutien personnel", description: "Besoin d'écoute ou de soutien" },
  { value: "aide_administrative", label: "📋 Aide administrative", description: "Aide pour des démarches" },
  { value: "conseil", label: "💬 Conseil", description: "Demande de conseil" },
  { value: "urgence_sociale", label: "🚨 Urgence sociale", description: "Situation urgente" },
  { value: "accompagnement_familial", label: "👨‍👩‍👧‍👦 Accompagnement familial", description: "Questions familiales" },
  { value: "sante_mentale", label: "🧠 Santé mentale", description: "Bien-être mental" },
  { value: "autre", label: "📁 Autre", description: "Autre demande" },
];

export default function MySocialSupport() {
  const [user, setUser] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    case_type: "soutien_personnel",
    subject: "",
    description: "",
    priority: "moyenne",
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: cases = [], isLoading } = useQuery({
    queryKey: ['mySocialSupportCases', user?.email],
    queryFn: () => base44.entities.SocialWorkerCase.filter({ employee_email: user.email }),
    enabled: !!user?.email,
  });

  const createCaseMutation = useMutation({
    mutationFn: (data) => base44.entities.SocialWorkerCase.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySocialSupportCases'] });
      setShowForm(false);
      setFormData({
        case_type: "soutien_personnel",
        subject: "",
        description: "",
        priority: "moyenne",
      });
      toast({ 
        title: "Demande envoyée ✅", 
        description: "L'assistante sociale vous contactera bientôt.",
      });
    },
    onError: () => {
      toast({ 
        title: "Erreur", 
        description: "Impossible d'envoyer la demande.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!user) return;
    
    createCaseMutation.mutate({
      employee_email: user.email,
      employee_name: user.full_name || user.email,
      case_type: formData.case_type,
      subject: formData.subject,
      description: formData.description,
      priority: formData.priority,
      status: "nouveau",
      is_confidential: true,
      created_by_employee: true,
    });
  };

  // Stats
  const pendingCases = cases.filter(c => c.status === 'nouveau' || c.status === 'en_cours' || c.status === 'en_attente');
  const resolvedCases = cases.filter(c => c.status === 'resolu' || c.status === 'cloture');

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-pink-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 p-6 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Heart className="w-8 h-8 text-pink-600" />
              Soutien Social
            </h1>
            <p className="text-slate-600 mt-1">Contactez l'assistante sociale en toute confidentialité</p>
          </div>
          <Button 
            onClick={() => setShowForm(true)}
            className="bg-pink-600 hover:bg-pink-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nouvelle demande
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-orange-700 mb-1">En cours</p>
                  <p className="text-3xl font-bold text-orange-900">{pendingCases.length}</p>
                </div>
                <Clock className="w-10 h-10 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Résolus</p>
                  <p className="text-3xl font-bold text-green-900">{resolvedCases.length}</p>
                </div>
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-pink-50 to-pink-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-pink-700 mb-1">Total</p>
                  <p className="text-3xl font-bold text-pink-900">{cases.length}</p>
                </div>
                <Heart className="w-10 h-10 text-pink-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Confidentiality Notice */}
        <Alert className="bg-pink-50 border-pink-200">
          <Shield className="w-4 h-4 text-pink-600" />
          <AlertDescription className="text-pink-800">
            <strong>Confidentialité garantie :</strong> Vos échanges sont strictement confidentiels.
          </AlertDescription>
        </Alert>

        {/* Cases List */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <div className="w-8 h-8 border-4 border-pink-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : cases.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="p-12 text-center">
              <Heart className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <p className="text-lg font-medium text-slate-700 mb-2">Aucune demande</p>
              <p className="text-slate-500 mb-4">Vous n'avez pas encore contacté l'assistante sociale</p>
              <Button onClick={() => setShowForm(true)} className="bg-pink-600 hover:bg-pink-700">
                <Plus className="w-4 h-4 mr-2" />
                Faire une demande
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {cases.map((caseItem) => {
              const status = caseItem.status || 'nouveau';
              const isResolved = status === 'resolu' || status === 'cloture';

              return (
                <Card 
                  key={caseItem.id} 
                  className={`border-2 ${
                    isResolved 
                      ? 'border-green-200 bg-green-50' 
                      : status === 'nouveau'
                      ? 'border-orange-200 bg-orange-50'
                      : 'border-blue-200 bg-blue-50'
                  }`}
                >
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <Badge className={statusColors[status] || "bg-gray-100"}>
                            {isResolved ? <CheckCircle className="w-3 h-3 mr-1" /> : <Clock className="w-3 h-3 mr-1" />}
                            {statusLabels[status] || status}
                          </Badge>
                          <Badge variant="outline" className="bg-white">
                            {caseTypeLabels[caseItem.case_type] || caseItem.case_type}
                          </Badge>
                        </div>
                        <h4 className="font-semibold text-slate-900 text-lg mb-1">
                          {caseItem.subject || "Demande de soutien"}
                        </h4>
                        {caseItem.description && (
                          <p className="text-sm text-slate-700 line-clamp-2">{caseItem.description}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 mt-3 pt-3 border-t border-slate-200">
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        <span>
                          {format(new Date(caseItem.created_date), 'dd/MM/yyyy', { locale: fr })}
                        </span>
                      </div>
                      {caseItem.assigned_to_social_worker_name && (
                        <div className="flex items-center gap-1">
                          <Heart className="w-3 h-3 text-pink-600" />
                          <span>Pris en charge par <strong>{caseItem.assigned_to_social_worker_name}</strong></span>
                        </div>
                      )}
                    </div>

                    {caseItem.actions_taken && (
                      <div className="mt-4 p-3 bg-white rounded-lg border">
                        <p className="text-xs font-medium text-slate-700 mb-1">Actions entreprises :</p>
                        <p className="text-sm text-slate-600">{caseItem.actions_taken}</p>
                      </div>
                    )}

                    {isResolved && (
                      <div className="mt-3 p-3 bg-green-100 rounded-lg border border-green-300">
                        <div className="flex items-center gap-2 text-sm text-green-800">
                          <CheckCircle className="w-4 h-4" />
                          <span className="font-medium">Dossier résolu</span>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Form Modal */}
        {showForm && (
          <Dialog open={true} onOpenChange={() => setShowForm(false)}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-600" />
                  Nouvelle demande de soutien
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Type de demande *</Label>
                  <Select
                    value={formData.case_type}
                    onValueChange={(value) => setFormData({...formData, case_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {caseTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Sujet *</Label>
                  <Input
                    value={formData.subject}
                    onChange={(e) => setFormData({...formData, subject: e.target.value})}
                    placeholder="Décrivez brièvement votre demande"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Description *</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    rows={4}
                    placeholder="Expliquez votre situation..."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Urgence</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({...formData, priority: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="faible">Non urgent</SelectItem>
                      <SelectItem value="moyenne">Normal</SelectItem>
                      <SelectItem value="elevee">Urgent</SelectItem>
                      <SelectItem value="urgente">Très urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="flex-1">
                    Annuler
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createCaseMutation.isPending}
                    className="flex-1 bg-pink-600 hover:bg-pink-700"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {createCaseMutation.isPending ? 'Envoi...' : 'Envoyer'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}