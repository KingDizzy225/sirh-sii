
import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Users,
  Calendar,
  Building2,
  Award,
  FileText,
  Menu,
  LogOut,
  MessageSquare,
  UserPlus,
  Briefcase,
  GraduationCap,
  UserCheck,
  UserCircle,
  Heart,
  CalendarDays,
  Target,
  Network,
  Shield,
  Bell,
  User,
  Search,
  PenTool
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { base44 } from "@/api/base44Client";
import NotificationCenter from "./components/notifications/NotificationCenter";
import GlobalSearch from "./components/search/GlobalSearch";
import { Button } from "@/components/ui/button";

/**
 * Récupérer le rôle de l'utilisateur
 */
async function getUserRole(userEmail) {
  try {
    const roles = await base44.entities.UserRole.filter({
      user_email: userEmail,
      is_active: true
    });
    return roles[0] || null;
  } catch (error) {
    console.error("Error fetching user role:", error);
    return null;
  }
}

// Menu pour les RH (admins)
const adminNavigationItems = [
  {
    title: "Tableau de bord",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
    requiredPermission: { module: "analytics", permission: "view_dashboard" }
  },
  {
    title: "Messages",
    url: createPageUrl("Chat"),
    icon: MessageSquare,
    requiredPermission: null // Accessible à tous
  },
  {
    title: "Employés",
    url: createPageUrl("Employees"),
    icon: Users,
    requiredPermission: { module: "employees", permission: "view" }
  },
  {
    title: "Organigramme",
    url: createPageUrl("Organigramme"),
    icon: Network,
    requiredPermission: { module: "employees", permission: "view" }
  },
  {
    title: "GPEC",
    url: createPageUrl("GPEC"),
    icon: Target,
    requiredPermission: { module: "employees", permission: "view" }
  },
  {
    title: "Congés",
    url: createPageUrl("LeaveManagement"),
    icon: Calendar,
    requiredPermission: { module: "leave", permission: "view" }
  },
  {
    title: "Départements",
    url: createPageUrl("Departments"),
    icon: Building2,
    requiredPermission: { module: "departments", permission: "view" }
  },
  {
    title: "Performance",
    url: createPageUrl("Performance"),
    icon: Award,
    requiredPermission: { module: "performance", permission: "view" }
  },
  {
    title: "Soutien Social",
    url: createPageUrl("SocialSupport"),
    icon: Heart,
    requiredPermission: null // Accessible à tous les admins
  },
  {
    title: "Documents",
    url: createPageUrl("Documents"),
    icon: FileText,
    requiredPermission: { module: "documents", permission: "view" }
  },
  {
    title: "Workflows Automatisés",
    url: createPageUrl("WorkflowManagement"),
    icon: UserPlus,
    requiredPermission: { module: "settings", permission: "manage_workflows" }
  },
  {
    title: "Intégration & Départ",
    url: createPageUrl("Onboarding"),
    icon: UserPlus,
    requiredPermission: { module: "employees", permission: "view" }
  },
  {
    title: "Recrutement",
    url: createPageUrl("Recruitment"),
    icon: Briefcase,
    requiredPermission: { module: "recruitment", permission: "view" }
  },
  {
    title: "Formation",
    url: createPageUrl("TrainingManagement"),
    icon: GraduationCap,
    requiredPermission: { module: "training", permission: "view" }
  },
  {
    title: "Rôles & Permissions",
    url: createPageUrl("RoleManagement"),
    icon: Shield,
    requiredPermission: { module: "settings", permission: "manage_roles" }
  },
];

// Menu pour les employés (non-admins)
const employeeNavigationItems = [
  {
    title: "Portail Employé",
    url: createPageUrl("EmployeePortal"),
    icon: UserCircle,
  },
  {
    title: "Mon Profil",
    url: createPageUrl("MyProfile"),
    icon: User,
  },
  {
    title: "Mes Signatures",
    url: createPageUrl("MySignatures"),
    icon: PenTool,
  },
  {
    title: "Soutien Social",
    url: createPageUrl("MySocialSupport"),
    icon: Heart,
  },
  {
    title: "Messages",
    url: createPageUrl("Chat"),
    icon: MessageSquare,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [filteredMenuItems, setFilteredMenuItems] = useState([]);
  const [showGlobalSearch, setShowGlobalSearch] = useState(false);

  // Keyboard shortcut for global search (Ctrl+K or Cmd+K)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setShowGlobalSearch(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Vérifier si l'utilisateur a un rôle admin
        const role = await getUserRole(currentUser.email);
        setUserRole(role);
        const userIsAdmin = role !== null || currentUser.role === 'admin';
        setIsAdmin(userIsAdmin);

        // Filtrer les items du menu selon les permissions
        if (userIsAdmin) {
          const filtered = await Promise.all(
            adminNavigationItems.map(async (item) => {
              // Si pas de permission requise, afficher l'item
              if (!item.requiredPermission) {
                return item;
              }

              // Si l'utilisateur est admin de base44 sans UserRole spécifique, donner tous les accès
              if (currentUser.role === 'admin' && !role) {
                return item;
              }

              // Super admin voit tout
              if (role?.role_type === 'super_admin') {
                return item;
              }

              // Vérifier la permission spécifique
              const { module, permission } = item.requiredPermission;
              const hasAccess = role?.permissions?.[module]?.[permission] === true;

              return hasAccess ? item : null;
            })
          );

          setFilteredMenuItems(filtered.filter(Boolean));
        } else {
          setFilteredMenuItems(employeeNavigationItems);
        }
      } catch (error) {
        console.error("Error loading user:", error);
        setFilteredMenuItems(employeeNavigationItems);
      }
    };
    loadUser();
  }, []);

  const handleLogout = () => {
    base44.auth.logout();
  };

  const navigationItems = filteredMenuItems;

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 to-blue-50">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader className="border-b border-slate-200 p-6">
            <div className="flex items-center gap-3">
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ff4c7c10dd9052b64d91b1/50328bf82_LogoSII.jpg"
                alt="SII Logo"
                className="h-12 w-auto object-contain"
              />
              <div>
                <h2 className="font-bold text-slate-900 text-base leading-tight">Système RH</h2>
                <p className="text-xs text-slate-500">
                  {isAdmin ? (userRole ? userRole.role_name : 'Ressources Humaines') : 'Portail Employé'}
                </p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-3 py-2">
                {isAdmin ? 'Menu RH' : 'Mon Espace'}
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url ? 'bg-blue-100 text-blue-700 font-medium shadow-sm' : 'text-slate-600'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2.5">
                          <item.icon className="w-5 h-5" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-200 p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-3 px-2">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-semibold text-sm">
                    {user?.full_name?.charAt(0) || user?.email?.charAt(0) || 'U'}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900 text-sm truncate">
                    {user?.full_name || user?.email || 'Utilisateur'}
                  </p>
                  <p className="text-xs text-slate-500 truncate">
                    {isAdmin ? (userRole?.role_name || 'Admin RH') : 'Employé'}
                  </p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
              >
                <LogOut className="w-4 h-4" />
                <span>Déconnexion</span>
              </button>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="md:hidden hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200">
                <Menu className="w-5 h-5" />
              </SidebarTrigger>
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ff4c7c10dd9052b64d91b1/50328bf82_LogoSII.jpg"
                alt="SII Logo"
                className="h-8 w-auto object-contain md:hidden"
              />
              <h1 className="text-lg font-semibold text-slate-900 md:hidden">
                {isAdmin ? 'Système RH' : 'Portail Employé'}
              </h1>
            </div>

            <div className="flex items-center gap-3">
              {/* Global Search Button */}
              <Button
                variant="outline"
                onClick={() => setShowGlobalSearch(true)}
                className="hidden md:flex items-center gap-2"
              >
                <Search className="w-4 h-4" />
                <span className="text-sm text-slate-600">Rechercher...</span>
                <kbd className="ml-2 px-2 py-0.5 text-xs font-semibold text-slate-500 bg-slate-100 border border-slate-200 rounded">
                  ⌘K
                </kbd>
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowGlobalSearch(true)}
                className="md:hidden"
              >
                <Search className="w-5 h-5" />
              </Button>

              {/* Notification Center */}
              {user && <NotificationCenter user={user} />}
            </div>
          </header>

          {/* Global Search Modal */}
          {user && (
            <GlobalSearch
              isOpen={showGlobalSearch}
              onClose={() => setShowGlobalSearch(false)}
              userRole={isAdmin ? 'admin' : 'employee'}
            />
          )}


          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
