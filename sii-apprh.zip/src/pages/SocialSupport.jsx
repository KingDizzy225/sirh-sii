import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, Heart, Users, AlertCircle } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import SocialWorkerCaseCard from "../components/social-support/SocialWorkerCaseCard";
import SocialWorkerCaseForm from "../components/social-support/SocialWorkerCaseForm";
import SocialWorkerCaseDetails from "../components/social-support/SocialWorkerCaseDetails";

export default function SocialSupport() {
  const [showForm, setShowForm] = useState(false);
  const [selectedCase, setSelectedCase] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");
  const [activeTab, setActiveTab] = useState("all");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: cases = [], isLoading } = useQuery({
    queryKey: ['socialWorkerCases'],
    queryFn: () => base44.entities.SocialWorkerCase.list('-created_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const caseData = await base44.entities.SocialWorkerCase.create({
        ...data,
        start_date: new Date().toISOString().split('T')[0],
        last_update_date: new Date().toISOString(),
      });

      // Envoyer une notification à l'employé
      if (data.employee_email) {
        await base44.integrations.Core.SendEmail({
          to: data.employee_email,
          subject: "Nouveau dossier d'accompagnement social",
          body: `Bonjour ${data.employee_name},\n\nUn dossier d'accompagnement social a été ouvert pour vous concernant : ${data.subject}.\n\nNotre assistante sociale vous contactera prochainement.\n\nCordialement,\nL'équipe RH`
        });
      }

      return caseData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['socialWorkerCases'] });
      setShowForm(false);
      toast({
        title: "Dossier créé",
        description: "Le dossier social a été créé avec succès.",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SocialWorkerCase.update(id, {
      ...data,
      last_update_date: new Date().toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['socialWorkerCases'] });
      setSelectedCase(null);
      toast({
        title: "Dossier mis à jour",
        description: "Le dossier a été modifié avec succès.",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SocialWorkerCase.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['socialWorkerCases'] });
      setSelectedCase(null);
      toast({
        title: "Dossier supprimé",
        description: "Le dossier a été supprimé.",
        variant: "destructive",
      });
    },
  });

  // Filtrer les dossiers
  const filteredCases = cases.filter(c => {
    const matchesSearch = c.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         c.employee_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         c.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || c.status === filterStatus;
    const matchesPriority = filterPriority === "all" || c.priority === filterPriority;
    const matchesTab = activeTab === "all" || c.status === activeTab;
    
    return matchesSearch && matchesStatus && matchesPriority && matchesTab;
  });

  // Statistiques
  const totalCases = cases.length;
  const newCases = cases.filter(c => c.status === 'nouveau').length;
  const inProgressCases = cases.filter(c => c.status === 'en_cours').length;
  const urgentCases = cases.filter(c => c.priority === 'urgente').length;
  const resolvedCases = cases.filter(c => c.status === 'resolu' || c.status === 'cloture').length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Heart className="w-8 h-8 text-pink-600" />
            Soutien Social
          </h1>
          <p className="text-slate-600 mt-1">{totalCases} dossiers • {newCases} nouveaux</p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-pink-600 hover:bg-pink-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouveau dossier
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Total dossiers</p>
                <p className="text-3xl font-bold text-blue-900">{totalCases}</p>
              </div>
              <Heart className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Nouveaux</p>
                <p className="text-3xl font-bold text-orange-900">{newCases}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">En cours</p>
                <p className="text-3xl font-bold text-purple-900">{inProgressCases}</p>
              </div>
              <Users className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 mb-1">Urgents</p>
                <p className="text-3xl font-bold text-red-900">{urgentCases}</p>
              </div>
              <AlertCircle className="w-10 h-10 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher par employé, sujet ou description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="nouveau">Nouveau</SelectItem>
                <SelectItem value="en_cours">En cours</SelectItem>
                <SelectItem value="en_attente">En attente</SelectItem>
                <SelectItem value="resolu">Résolu</SelectItem>
                <SelectItem value="cloture">Clôturé</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Priorité" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes priorités</SelectItem>
                <SelectItem value="faible">Faible</SelectItem>
                <SelectItem value="moyenne">Moyenne</SelectItem>
                <SelectItem value="elevee">Élevée</SelectItem>
                <SelectItem value="urgente">Urgente</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="all">Tous ({totalCases})</TabsTrigger>
          <TabsTrigger value="nouveau">Nouveaux ({newCases})</TabsTrigger>
          <TabsTrigger value="en_cours">En cours ({inProgressCases})</TabsTrigger>
          <TabsTrigger value="resolu">Résolus ({resolvedCases})</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          {isLoading ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 border-4 border-pink-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-slate-600">Chargement des dossiers...</p>
            </div>
          ) : filteredCases.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Heart className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun dossier trouvé</p>
                <p className="text-sm">
                  {searchTerm || filterStatus !== "all" || filterPriority !== "all"
                    ? "Essayez de modifier vos filtres"
                    : "Commencez par créer un nouveau dossier"}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCases.map((caseItem) => (
                <SocialWorkerCaseCard 
                  key={caseItem.id} 
                  caseItem={caseItem}
                  onView={() => setSelectedCase(caseItem)}
                  onDelete={(id) => {
                    if (window.confirm("Êtes-vous sûr de vouloir supprimer ce dossier ?")) {
                      deleteMutation.mutate(id);
                    }
                  }}
                />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {showForm && (
        <SocialWorkerCaseForm
          employees={employees}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}

      {selectedCase && (
        <SocialWorkerCaseDetails
          caseItem={selectedCase}
          onClose={() => setSelectedCase(null)}
          onUpdate={(data) => updateMutation.mutate({ id: selectedCase.id, data })}
          isUpdating={updateMutation.isPending}
        />
      )}
    </div>
  );
}