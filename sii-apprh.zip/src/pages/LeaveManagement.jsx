import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Filter, Calendar as CalendarIcon, Users, ChevronLeft, ChevronRight, Download } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend, isSameDay, addMonths, subMonths } from "date-fns";
import { fr } from "date-fns/locale";
import LeaveRequestCard from "../components/leave/LeaveRequestCard";
import LeaveRequestForm from "../components/leave/LeaveRequestForm";

const leaveTypeColors = {
  vacation: "bg-blue-500",
  sick: "bg-red-500",
  personal: "bg-purple-500",
  maternity: "bg-pink-500",
  paternity: "bg-indigo-500",
  unpaid: "bg-gray-500",
  annual: "bg-blue-500",
  other: "bg-orange-500",
};

const leaveTypeLabels = {
  vacation: "Congé annuel",
  sick: "Congé maladie",
  personal: "Congé personnel",
  maternity: "Congé maternité",
  paternity: "Congé paternité",
  unpaid: "Sans solde",
  annual: "Congé annuel",
  other: "Autre",
};

export default function LeaveManagement() {
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("requests");
  
  // Calendar state
  const [currentDate, setCurrentDate] = useState(new Date());
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [filterEmployee, setFilterEmployee] = useState("all");
  const [selectedLeave, setSelectedLeave] = useState(null);

  const queryClient = useQueryClient();

  const { data: leaveRequests = [], isLoading } = useQuery({
    queryKey: ['leaveRequests'],
    queryFn: () => base44.entities.LeaveRequest.list('-created_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.LeaveRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leaveRequests'] });
      setShowForm(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.LeaveRequest.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leaveRequests'] });
    },
  });

  const handleStatusUpdate = async (id, status, notes) => {
    const user = await base44.auth.me();
    updateMutation.mutate({
      id,
      data: {
        status,
        reviewed_by: user.email,
        review_notes: notes
      }
    });
  };

  const filteredRequests = filter === "all" 
    ? leaveRequests 
    : leaveRequests.filter(r => r.status === filter);

  const pendingCount = leaveRequests.filter(r => r.status === 'pending').length;
  const approvedLeaves = leaveRequests.filter(r => r.status === 'approved');

  // Calendar logic
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const activeEmployees = employees.filter(e => e.status === 'active');
  const filteredEmployees = activeEmployees.filter(emp => {
    const matchesDepartment = filterDepartment === "all" || emp.department === filterDepartment;
    const matchesEmployee = filterEmployee === "all" || emp.id === filterEmployee;
    return matchesDepartment && matchesEmployee;
  });

  const getLeaveForDay = (employee, date) => {
    return approvedLeaves.find(leave => {
      if (leave.employee_email !== employee.email) return false;
      const startDate = new Date(leave.start_date);
      const endDate = new Date(leave.end_date);
      return date >= startDate && date <= endDate;
    });
  };

  const monthLeaves = approvedLeaves.filter(leave => {
    const startDate = new Date(leave.start_date);
    const endDate = new Date(leave.end_date);
    return (startDate <= monthEnd && endDate >= monthStart);
  });

  const totalDaysOff = monthLeaves.reduce((sum, leave) => sum + (leave.days_count || 0), 0);
  const activeLeaves = monthLeaves.filter(leave => {
    const now = new Date();
    const startDate = new Date(leave.start_date);
    const endDate = new Date(leave.end_date);
    return now >= startDate && now <= endDate;
  }).length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <CalendarIcon className="w-8 h-8 text-blue-600" />
            Gestion des Congés
          </h1>
          <p className="text-slate-600 mt-1">
            {pendingCount} demande{pendingCount > 1 ? 's' : ''} en attente • {approvedLeaves.length} approuvé{approvedLeaves.length > 1 ? 's' : ''}
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouvelle demande
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">En attente</p>
                <p className="text-3xl font-bold text-orange-900">{pendingCount}</p>
              </div>
              <CalendarIcon className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Approuvées</p>
                <p className="text-3xl font-bold text-green-900">{approvedLeaves.length}</p>
              </div>
              <CalendarIcon className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">En congé maintenant</p>
                <p className="text-3xl font-bold text-blue-900">{activeLeaves}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Jours ce mois</p>
                <p className="text-3xl font-bold text-purple-900">{totalDaysOff}</p>
              </div>
              <CalendarIcon className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md grid w-full grid-cols-2">
          <TabsTrigger value="requests" className="gap-2">
            <Filter className="w-4 h-4" />
            Demandes ({leaveRequests.length})
          </TabsTrigger>
          <TabsTrigger value="calendar" className="gap-2">
            <CalendarIcon className="w-4 h-4" />
            Calendrier
          </TabsTrigger>
        </TabsList>

        {/* TAB: Demandes */}
        <TabsContent value="requests" className="mt-6 space-y-6">
          {/* Filters */}
          <Tabs value={filter} onValueChange={setFilter}>
            <TabsList className="bg-white shadow-md">
              <TabsTrigger value="all">Toutes ({leaveRequests.length})</TabsTrigger>
              <TabsTrigger value="pending">
                En attente
                {pendingCount > 0 && (
                  <span className="ml-2 px-2 py-0.5 text-xs bg-orange-100 text-orange-800 rounded-full">
                    {pendingCount}
                  </span>
                )}
              </TabsTrigger>
              <TabsTrigger value="approved">
                Approuvées ({approvedLeaves.length})
              </TabsTrigger>
              <TabsTrigger value="rejected">Rejetées</TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Leave Requests */}
          {isLoading ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-slate-600">Chargement...</p>
            </div>
          ) : filteredRequests.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <CalendarIcon className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune demande trouvée</p>
                <p className="text-sm">Les demandes de congé apparaîtront ici</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredRequests.map((request) => (
                <LeaveRequestCard
                  key={request.id}
                  request={request}
                  onStatusUpdate={handleStatusUpdate}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* TAB: Calendrier */}
        <TabsContent value="calendar" className="mt-6 space-y-6">
          {/* Calendar Navigation & Filters */}
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                {/* Navigation mois */}
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="icon" onClick={() => setCurrentDate(subMonths(currentDate, 1))}>
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <div className="text-center min-w-[200px]">
                    <h2 className="text-2xl font-bold text-slate-900">
                      {format(currentDate, 'MMMM yyyy', { locale: fr })}
                    </h2>
                  </div>
                  <Button variant="outline" size="icon" onClick={() => setCurrentDate(addMonths(currentDate, 1))}>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" onClick={() => setCurrentDate(new Date())}>
                    Aujourd'hui
                  </Button>
                </div>

                {/* Filtres */}
                <div className="flex gap-3 w-full md:w-auto">
                  <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                    <SelectTrigger className="w-full md:w-48">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Département" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous les départements</SelectItem>
                      {departments.map(dept => (
                        <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterEmployee} onValueChange={setFilterEmployee}>
                    <SelectTrigger className="w-full md:w-48">
                      <SelectValue placeholder="Employé" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous les employés</SelectItem>
                      {activeEmployees.map(emp => (
                        <SelectItem key={emp.id} value={emp.id}>{emp.full_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Légende */}
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-4">
                <p className="text-sm font-semibold text-slate-700 mr-4">Légende :</p>
                {Object.entries(leaveTypeLabels).map(([key, label]) => (
                  <div key={key} className="flex items-center gap-2">
                    <div className={`w-4 h-4 rounded ${leaveTypeColors[key]}`}></div>
                    <span className="text-sm text-slate-600">{label}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-slate-200"></div>
                  <span className="text-sm text-slate-600">Week-end</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Calendar Grid */}
          <Card className="border-none shadow-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[1200px]">
                  <thead className="bg-slate-50 border-b-2 border-slate-200">
                    <tr>
                      <th className="sticky left-0 bg-slate-50 z-10 px-4 py-3 text-left text-sm font-semibold text-slate-900 min-w-[200px]">
                        Employé
                      </th>
                      {daysInMonth.map((day, idx) => (
                        <th
                          key={idx}
                          className={`px-2 py-3 text-center text-xs font-medium min-w-[40px] ${
                            isSameDay(day, new Date())
                              ? 'bg-blue-100 text-blue-900'
                              : isWeekend(day)
                              ? 'bg-slate-100 text-slate-500'
                              : 'text-slate-700'
                          }`}
                        >
                          <div>{format(day, 'EEE', { locale: fr })}</div>
                          <div className="text-base font-bold">{format(day, 'd')}</div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredEmployees.length === 0 ? (
                      <tr>
                        <td colSpan={daysInMonth.length + 1} className="px-4 py-12 text-center text-slate-500">
                          <CalendarIcon className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                          <p>Aucun employé à afficher</p>
                        </td>
                      </tr>
                    ) : (
                      filteredEmployees.map((employee) => (
                        <tr key={employee.id} className="hover:bg-slate-50">
                          <td className="sticky left-0 bg-white hover:bg-slate-50 z-10 px-4 py-3 border-r border-slate-200">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                                <span className="text-white font-semibold text-xs">
                                  {employee.full_name?.charAt(0) || 'E'}
                                </span>
                              </div>
                              <div className="min-w-0">
                                <p className="font-medium text-sm text-slate-900 truncate">
                                  {employee.full_name}
                                </p>
                                <p className="text-xs text-slate-500 truncate">
                                  {employee.position}
                                </p>
                              </div>
                            </div>
                          </td>
                          {daysInMonth.map((day, idx) => {
                            const leave = getLeaveForDay(employee, day);
                            const isWeekendDay = isWeekend(day);
                            const isToday = isSameDay(day, new Date());

                            return (
                              <td
                                key={idx}
                                className={`px-1 py-2 text-center relative ${
                                  isToday ? 'bg-blue-50' : isWeekendDay ? 'bg-slate-50' : ''
                                }`}
                                onClick={() => leave && setSelectedLeave({ ...leave, employee })}
                              >
                                {leave ? (
                                  <div
                                    className={`${leaveTypeColors[leave.leave_type]} h-8 rounded cursor-pointer hover:opacity-80 transition-opacity`}
                                    title={`${employee.full_name} - ${leaveTypeLabels[leave.leave_type]}`}
                                  />
                                ) : isWeekendDay ? (
                                  <div className="h-8 bg-slate-200 rounded opacity-30" />
                                ) : null}
                              </td>
                            );
                          })}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Leave Request Form */}
      {showForm && (
        <LeaveRequestForm
          employees={employees}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}

      {/* Détails du congé sélectionné */}
      {selectedLeave && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedLeave(null)}
        >
          <Card 
            className="max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-slate-900">Détails du congé</h3>
                <Button variant="ghost" size="icon" onClick={() => setSelectedLeave(null)}>
                  ✕
                </Button>
              </div>
              
              <div>
                <p className="text-sm text-slate-600">Employé</p>
                <p className="font-semibold text-slate-900">{selectedLeave.employee?.full_name}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600">Type de congé</p>
                <Badge className={`${leaveTypeColors[selectedLeave.leave_type]} text-white`}>
                  {leaveTypeLabels[selectedLeave.leave_type]}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-slate-600">Période</p>
                <p className="font-medium text-slate-900">
                  {format(new Date(selectedLeave.start_date), 'dd MMM yyyy', { locale: fr })} - {format(new Date(selectedLeave.end_date), 'dd MMM yyyy', { locale: fr })}
                </p>
                <p className="text-sm text-slate-500 mt-1">
                  {selectedLeave.days_count} jour{selectedLeave.days_count > 1 ? 's' : ''}
                </p>
              </div>
              {selectedLeave.reason && (
                <div>
                  <p className="text-sm text-slate-600">Motif</p>
                  <p className="text-sm text-slate-900 bg-slate-50 p-3 rounded">{selectedLeave.reason}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}