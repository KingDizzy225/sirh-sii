import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Target, 
  TrendingUp, 
  Users, 
  Award, 
  AlertTriangle,
  User,
  Briefcase,
  GraduationCap,
  ArrowRight,
  Plus,
  Search,
  Star,
  Route,
  Grid3x3,
  Sparkles
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ScatterChart, Scatter, Cell } from "recharts";
import CareerPathForm from "../components/gpec/CareerPathForm";
import SuccessionPlanForm from "../components/gpec/SuccessionPlanForm";
import TalentPoolForm from "../components/gpec/TalentPoolForm";
import AIGPECInsights from "../components/ai/AIGPECInsights";
import AICareerPathSuggestions from "../components/ai/AICareerPathSuggestions";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function GPEC() {
  const [activeTab, setActiveTab] = useState("overview");
  const [searchTerm, setSearchTerm] = useState("");
  const [showCareerPathForm, setShowCareerPathForm] = useState(false);
  const [showSuccessionForm, setShowSuccessionForm] = useState(false);
  const [showTalentPoolForm, setShowTalentPoolForm] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: performanceReviews = [] } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list('-review_date'),
  });

  const { data: careerPaths = [] } = useQuery({
    queryKey: ['careerPaths'],
    queryFn: () => base44.entities.CareerPath.list('-created_date'),
  });

  const { data: successionPlans = [] } = useQuery({
    queryKey: ['successionPlans'],
    queryFn: () => base44.entities.SuccessionPlan.list('-created_date'),
  });

  const { data: talentPool = [] } = useQuery({
    queryKey: ['talentPool'],
    queryFn: () => base44.entities.TalentPool.list('-last_assessment_date'),
  });

  const { data: skillGaps = [] } = useQuery({
    queryKey: ['skillGaps'],
    queryFn: () => base44.entities.SkillGap.list('-identified_date'),
  });

  // Mutations
  const createCareerPathMutation = useMutation({
    mutationFn: (data) => base44.entities.CareerPath.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['careerPaths'] });
      setShowCareerPathForm(false);
      toast({ title: "Plan de carrière créé", description: "Le plan a été enregistré avec succès." });
    },
  });

  const createSuccessionPlanMutation = useMutation({
    mutationFn: (data) => base44.entities.SuccessionPlan.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['successionPlans'] });
      setShowSuccessionForm(false);
      toast({ title: "Plan de succession créé", description: "Le plan a été enregistré avec succès." });
    },
  });

  const createTalentPoolMutation = useMutation({
    mutationFn: (data) => base44.entities.TalentPool.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['talentPool'] });
      setShowTalentPoolForm(false);
      toast({ title: "Talent ajouté", description: "Le talent a été ajouté au vivier." });
    },
  });

  // ANALYSE DES COMPÉTENCES CRITIQUES
  const criticalSkills = [...new Set(skills.map(s => s.skill_name))];
  
  const skillGapAnalysis = criticalSkills.map(skillName => {
    const employeesWithSkill = skills.filter(s => s.skill_name === skillName);
    const advancedEmployees = employeesWithSkill.filter(s => 
      s.proficiency_level === 'advanced' || s.proficiency_level === 'expert'
    ).length;
    
    return {
      skillName,
      total: employeesWithSkill.length,
      advanced: advancedEmployees,
      gap: advancedEmployees < 3,
      priority: advancedEmployees === 0 ? 'critical' : advancedEmployees < 2 ? 'high' : 'medium'
    };
  }).sort((a, b) => {
    const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
    return priorityOrder[a.priority] - priorityOrder[b.priority];
  });

  // TALENTS À HAUT POTENTIEL
  const highPotentials = talentPool.filter(t => 
    t.talent_category === 'high_potential' || 
    (t.performance_rating >= 4 && t.potential_rating >= 4)
  );

  // POSTES CRITIQUES
  const criticalPositions = successionPlans.filter(sp => 
    sp.is_critical_position || 
    sp.risk_level === 'critical' || 
    sp.risk_level === 'high'
  );

  // 9-BOX GRID DATA
  const nineBoxData = talentPool.map(talent => ({
    name: talent.employee_name,
    performance: talent.performance_rating,
    potential: talent.potential_rating,
    category: talent.talent_category,
    retention_risk: talent.retention_risk
  }));

  // STATISTIQUES
  const totalCareerPlans = careerPaths.filter(cp => cp.status === 'active').length;
  const activeSuccessionPlans = successionPlans.filter(sp => sp.status === 'active').length;
  const criticalSkillGaps = skillGapAnalysis.filter(s => s.priority === 'critical' || s.priority === 'high').length;

  const priorityColors = {
    critical: 'bg-red-100 text-red-800 border-red-300',
    high: 'bg-orange-100 text-orange-800 border-orange-300',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    low: 'bg-green-100 text-green-800 border-green-300',
  };

  const readinessColors = {
    ready_now: 'bg-green-100 text-green-800',
    ready_1_2_years: 'bg-blue-100 text-blue-800',
    ready_3_5_years: 'bg-yellow-100 text-yellow-800',
    needs_development: 'bg-orange-100 text-orange-800',
    not_ready: 'bg-red-100 text-red-800',
    developing: 'bg-yellow-100 text-yellow-800',
    ready_soon: 'bg-blue-100 text-blue-800',
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Target className="w-8 h-8 text-blue-600" />
            GPEC - Gestion Prévisionnelle des Emplois et Compétences
          </h1>
          <p className="text-slate-600 mt-1">
            Pilotage stratégique des talents, compétences et successions
          </p>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Plans de carrière</p>
                <p className="text-3xl font-bold text-blue-900">{totalCareerPlans}</p>
              </div>
              <Route className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Vivier de talents</p>
                <p className="text-3xl font-bold text-purple-900">{talentPool.length}</p>
                <p className="text-xs text-purple-600 mt-1">{highPotentials.length} hauts potentiels</p>
              </div>
              <Award className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 mb-1">Plans de succession</p>
                <p className="text-3xl font-bold text-red-900">{activeSuccessionPlans}</p>
                <p className="text-xs text-red-600 mt-1">{criticalPositions.length} critiques</p>
              </div>
              <AlertTriangle className="w-10 h-10 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Employés actifs</p>
                <p className="text-3xl font-bold text-green-900">{employees.length}</p>
              </div>
              <Users className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Écarts de compétences</p>
                <p className="text-3xl font-bold text-orange-900">{criticalSkillGaps}</p>
              </div>
              <GraduationCap className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md flex flex-wrap h-auto">
          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="ai-career">
            <Sparkles className="w-4 h-4 mr-2" />
            Parcours IA
          </TabsTrigger>
          <TabsTrigger value="talents">Vivier ({talentPool.length})</TabsTrigger>
          <TabsTrigger value="careers">Carrières ({totalCareerPlans})</TabsTrigger>
          <TabsTrigger value="succession">Succession ({activeSuccessionPlans})</TabsTrigger>
          <TabsTrigger value="skills">Compétences</TabsTrigger>
          <TabsTrigger value="nine-box">9-Box Grid</TabsTrigger>
        </TabsList>

        {/* VUE D'ENSEMBLE */}
        <TabsContent value="overview" className="mt-6 space-y-6">
          {/* IA GPEC Insights */}
          <AIGPECInsights
            employees={employees}
            performanceReviews={performanceReviews}
            skills={skills}
            talentPool={talentPool}
          />

          {/* Alertes critiques */}
          {(criticalPositions.length > 0 || criticalSkillGaps > 0) && (
            <Card className="border-l-4 border-red-500 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-900">
                  <AlertTriangle className="w-5 h-5" />
                  Alertes critiques
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {criticalPositions.length > 0 && (
                  <div className="p-3 bg-white rounded border border-red-200">
                    <p className="font-semibold text-red-900 mb-1">
                      {criticalPositions.length} postes critiques nécessitent une attention immédiate
                    </p>
                    <p className="text-sm text-red-700">
                      Action requise: Identifier et former des successeurs
                    </p>
                  </div>
                )}
                {criticalSkillGaps > 0 && (
                  <div className="p-3 bg-white rounded border border-red-200">
                    <p className="font-semibold text-red-900 mb-1">
                      {criticalSkillGaps} écarts de compétences critiques détectés
                    </p>
                    <p className="text-sm text-red-700">
                      Action requise: Formation urgente ou recrutement externe
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Graphiques */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Répartition des talents par catégorie</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={[
                    { name: 'Haut Potentiel', value: talentPool.filter(t => t.talent_category === 'high_potential').length },
                    { name: 'Haute Performance', value: talentPool.filter(t => t.talent_category === 'high_performer').length },
                    { name: 'Talent Clé', value: talentPool.filter(t => t.talent_category === 'key_talent').length },
                    { name: 'Émergent', value: talentPool.filter(t => t.talent_category === 'emerging_talent').length },
                    { name: 'Solide', value: talentPool.filter(t => t.talent_category === 'solid_performer').length },
                  ]}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" angle={-15} textAnchor="end" height={80} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#8b5cf6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Top 10 écarts de compétences</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={skillGapAnalysis.slice(0, 10)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="skillName" type="category" width={120} />
                    <Tooltip />
                    <Bar dataKey="total" fill="#3b82f6" name="Total" />
                    <Bar dataKey="advanced" fill="#10b981" name="Experts" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Insights */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Recommandations stratégiques
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {criticalSkillGaps > 0 && (
                  <div className="p-4 bg-red-50 border-l-4 border-red-500 rounded">
                    <p className="font-semibold text-red-900 mb-2">🔴 Urgent</p>
                    <p className="text-sm text-red-800">
                      Combler les {criticalSkillGaps} écarts de compétences critiques par formation ou recrutement
                    </p>
                  </div>
                )}

                {highPotentials.length > 5 && (
                  <div className="p-4 bg-green-50 border-l-4 border-green-500 rounded">
                    <p className="font-semibold text-green-900 mb-2">✅ Opportunité</p>
                    <p className="text-sm text-green-800">
                      {highPotentials.length} talents à haut potentiel identifiés - Mettre en place des plans de développement
                    </p>
                  </div>
                )}

                {careerPaths.filter(cp => cp.status === 'active').length < employees.length * 0.3 && (
                  <div className="p-4 bg-blue-50 border-l-4 border-blue-500 rounded">
                    <p className="font-semibold text-blue-900 mb-2">💡 Suggestion</p>
                    <p className="text-sm text-blue-800">
                      Augmenter le nombre de plans de carrière pour améliorer l'engagement et la rétention
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PARCOURS CARRIÈRE IA */}
        <TabsContent value="ai-career" className="mt-6">
          <AICareerPathSuggestions />
        </TabsContent>

        {/* VIVIER DE TALENTS */}
        <TabsContent value="talents" className="mt-6 space-y-6">
          <div className="flex justify-between items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher un talent..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button onClick={() => setShowTalentPoolForm(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Ajouter un talent
            </Button>
          </div>

          {talentPool.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Star className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun talent dans le vivier</p>
                <p className="text-sm">Commencez par identifier vos talents clés</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {talentPool
                .filter(t => searchTerm === "" || 
                  t.employee_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                  t.current_position.toLowerCase().includes(searchTerm.toLowerCase())
                )
                .map(talent => (
                  <Card key={talent.id} className="border-2 border-purple-200 hover:border-purple-400 transition-colors shadow-lg">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center">
                          <span className="text-white font-bold text-xl">
                            {talent.employee_name?.charAt(0) || 'T'}
                          </span>
                        </div>
                        <div className="flex-1">
                          <p className="font-bold text-slate-900">{talent.employee_name}</p>
                          <p className="text-sm text-slate-600">{talent.current_position}</p>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">Catégorie</span>
                          <Badge className="bg-purple-100 text-purple-800">
                            {talent.talent_category === 'high_potential' ? '🌟 Haut Potentiel' :
                             talent.talent_category === 'high_performer' ? '⚡ Haute Perf' :
                             talent.talent_category === 'key_talent' ? '🔑 Talent Clé' :
                             talent.talent_category === 'emerging_talent' ? '🌱 Émergent' :
                             '✅ Solide'}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="p-2 bg-blue-50 rounded">
                            <p className="text-xs text-blue-700">Performance</p>
                            <p className="font-bold text-blue-900">{talent.performance_rating}/5</p>
                          </div>
                          <div className="p-2 bg-purple-50 rounded">
                            <p className="text-xs text-purple-700">Potentiel</p>
                            <p className="font-bold text-purple-900">{talent.potential_rating}/5</p>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">Risque de départ</span>
                          <Badge className={
                            talent.retention_risk === 'critical' ? 'bg-red-600' :
                            talent.retention_risk === 'high' ? 'bg-orange-600' :
                            talent.retention_risk === 'medium' ? 'bg-yellow-600' :
                            'bg-green-600'
                          }>
                            {talent.retention_risk === 'critical' ? '🔴 Critique' :
                             talent.retention_risk === 'high' ? '🟠 Élevé' :
                             talent.retention_risk === 'medium' ? '🟡 Moyen' :
                             '🟢 Faible'}
                          </Badge>
                        </div>

                        {talent.key_strengths && talent.key_strengths.length > 0 && (
                          <div className="pt-2 border-t">
                            <p className="text-xs font-medium text-slate-700 mb-1">Points forts</p>
                            <div className="flex flex-wrap gap-1">
                              {talent.key_strengths.slice(0, 3).map((strength, idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {strength}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
            </div>
          )}
        </TabsContent>

        {/* PLANS DE CARRIÈRE */}
        <TabsContent value="careers" className="mt-6 space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => setShowCareerPathForm(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau plan de carrière
            </Button>
          </div>

          {careerPaths.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Route className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun plan de carrière</p>
                <p className="text-sm">Créez des plans de développement pour vos collaborateurs</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {careerPaths.map(cp => (
                <Card key={cp.id} className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={readinessColors[cp.readiness_level]}>
                            {cp.readiness_level === 'ready_now' ? 'Prêt maintenant' :
                             cp.readiness_level === 'ready_soon' ? 'Bientôt prêt' :
                             cp.readiness_level === 'developing' ? 'En développement' :
                             'Pas encore prêt'}
                          </Badge>
                          <Badge variant="outline">{cp.estimated_timeline}</Badge>
                        </div>
                        <p className="font-bold text-lg text-slate-900">{cp.employee_name}</p>
                        <p className="text-sm text-slate-600">{cp.current_position}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-slate-600">Objectif:</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline">{cp.current_position}</Badge>
                          <ArrowRight className="w-4 h-4 text-slate-400" />
                          <Badge className="bg-blue-100 text-blue-800">{cp.target_position}</Badge>
                        </div>
                      </div>

                      {cp.skill_gaps && cp.skill_gaps.length > 0 && (
                        <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                          <p className="text-xs font-medium text-orange-700 mb-1">
                            Écarts de compétences ({cp.skill_gaps.length})
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {cp.skill_gaps.slice(0, 3).map((gap, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {gap}
                              </Badge>
                            ))}
                            {cp.skill_gaps.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{cp.skill_gaps.length - 3}
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      {cp.development_actions && cp.development_actions.length > 0 && (
                        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                          <p className="text-xs font-medium text-green-700 mb-1">
                            Actions en cours ({cp.development_actions.length})
                          </p>
                          {cp.development_actions.slice(0, 2).map((action, idx) => (
                            <p key={idx} className="text-xs text-green-800">
                              • {action.action}
                            </p>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* PLANS DE SUCCESSION */}
        <TabsContent value="succession" className="mt-6 space-y-6">
          <div className="flex justify-end">
            <Button onClick={() => setShowSuccessionForm(true)} className="bg-red-600 hover:bg-red-700">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau plan de succession
            </Button>
          </div>

          {successionPlans.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun plan de succession</p>
                <p className="text-sm">Identifiez les postes critiques et leurs successeurs</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {successionPlans.map(sp => (
                <Card key={sp.id} className={`shadow-lg ${sp.is_critical_position ? 'border-2 border-red-400' : 'border-none'}`}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {sp.is_critical_position && (
                            <Badge className="bg-red-600">🔴 Critique</Badge>
                          )}
                          <Badge className={priorityColors[sp.risk_level]}>
                            Risque: {sp.risk_level === 'critical' ? 'Critique' :
                                    sp.risk_level === 'high' ? 'Élevé' :
                                    sp.risk_level === 'medium' ? 'Moyen' : 'Faible'}
                          </Badge>
                        </div>
                        <h3 className="font-bold text-lg text-slate-900">{sp.position_title}</h3>
                        <p className="text-sm text-slate-600">{sp.department}</p>
                        {sp.current_holder_name && (
                          <p className="text-sm text-slate-500 mt-1">
                            Titulaire: {sp.current_holder_name}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600">Successeurs identifiés</span>
                        <Badge variant="outline" className="text-lg font-bold">
                          {sp.internal_candidates_count || sp.successors?.length || 0}
                        </Badge>
                      </div>

                      {sp.successors && sp.successors.length > 0 && (
                        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                          <p className="text-xs font-medium text-green-700 mb-2">Successeurs potentiels:</p>
                          {sp.successors.slice(0, 3).map((successor, idx) => (
                            <div key={idx} className="flex items-center justify-between py-1">
                              <span className="text-sm font-medium text-green-900">
                                #{successor.priority} {successor.employee_name}
                              </span>
                              <Badge className={readinessColors[successor.readiness]} variant="outline">
                                {successor.readiness === 'ready_now' ? 'Prêt' :
                                 successor.readiness === 'ready_1_2_years' ? '1-2 ans' :
                                 successor.readiness === 'ready_3_5_years' ? '3-5 ans' :
                                 'Développement'}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      )}

                      {sp.emergency_backup && sp.emergency_backup.employee_name && (
                        <div className="p-2 bg-blue-50 rounded border border-blue-200">
                          <p className="text-xs text-blue-700">
                            🚨 Backup d'urgence: <strong>{sp.emergency_backup.employee_name}</strong>
                          </p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* COMPÉTENCES */}
        <TabsContent value="skills" className="mt-6 space-y-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Analyse des écarts de compétences</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {skillGapAnalysis.slice(0, 15).map((skill, idx) => (
                  <div 
                    key={idx} 
                    className={`p-4 rounded-lg border-2 ${priorityColors[skill.priority]}`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-3">
                        <GraduationCap className="w-5 h-5" />
                        <div>
                          <h4 className="font-semibold">{skill.skillName}</h4>
                          <p className="text-xs">
                            {skill.total} employé{skill.total > 1 ? 's' : ''} • {skill.advanced} expert{skill.advanced > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <Badge className={priorityColors[skill.priority]}>
                        {skill.priority === 'critical' ? 'Critique' :
                         skill.priority === 'high' ? 'Élevée' :
                         skill.priority === 'medium' ? 'Moyenne' : 'Faible'}
                      </Badge>
                    </div>
                    
                    {skill.gap && (
                      <div className="mt-2 p-2 bg-white/50 rounded text-sm">
                        <p className="font-medium">⚠️ Action recommandée:</p>
                        <p className="text-xs mt-1">
                          {skill.priority === 'critical' 
                            ? 'Recrutement urgent ou formation accélérée nécessaire'
                            : 'Planifier des formations pour développer l\'expertise'}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 9-BOX GRID */}
        <TabsContent value="nine-box" className="mt-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Grid3x3 className="w-5 h-5" />
                Matrice 9-Box: Performance vs Potentiel
              </CardTitle>
            </CardHeader>
            <CardContent>
              {nineBoxData.length === 0 ? (
                <p className="text-slate-500 text-center py-12">
                  Aucune donnée disponible. Ajoutez des talents au vivier pour voir la matrice.
                </p>
              ) : (
                <ResponsiveContainer width="100%" height={500}>
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      type="number" 
                      dataKey="performance" 
                      name="Performance" 
                      domain={[0.5, 5.5]}
                      label={{ value: 'Performance', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      type="number" 
                      dataKey="potential" 
                      name="Potentiel" 
                      domain={[0.5, 5.5]}
                      label={{ value: 'Potentiel', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip 
                      cursor={{ strokeDasharray: '3 3' }}
                      content={({ payload }) => {
                        if (payload && payload.length > 0) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-white p-3 border-2 border-slate-200 rounded-lg shadow-lg">
                              <p className="font-bold">{data.name}</p>
                              <p className="text-sm">Performance: {data.performance}/5</p>
                              <p className="text-sm">Potentiel: {data.potential}/5</p>
                              <Badge className="mt-1">{data.category}</Badge>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Scatter data={nineBoxData} fill="#8b5cf6">
                      {nineBoxData.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={
                            entry.retention_risk === 'critical' ? '#ef4444' :
                            entry.retention_risk === 'high' ? '#f59e0b' :
                            entry.talent_category === 'high_potential' ? '#8b5cf6' :
                            '#3b82f6'
                          }
                        />
                      ))}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Forms */}
      {showCareerPathForm && (
        <CareerPathForm
          employees={employees}
          onSubmit={(data) => createCareerPathMutation.mutate(data)}
          onCancel={() => setShowCareerPathForm(false)}
          isSubmitting={createCareerPathMutation.isPending}
        />
      )}

      {showSuccessionForm && (
        <SuccessionPlanForm
          employees={employees}
          departments={departments}
          onSubmit={(data) => createSuccessionPlanMutation.mutate(data)}
          onCancel={() => setShowSuccessionForm(false)}
          isSubmitting={createSuccessionPlanMutation.isPending}
        />
      )}

      {showTalentPoolForm && (
        <TalentPoolForm
          employees={employees}
          onSubmit={(data) => createTalentPoolMutation.mutate(data)}
          onCancel={() => setShowTalentPoolForm(false)}
          isSubmitting={createTalentPoolMutation.isPending}
        />
      )}
    </div>
  );
}