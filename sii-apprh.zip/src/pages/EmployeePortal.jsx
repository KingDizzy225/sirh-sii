import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  FileText,
  Calendar,
  Briefcase,
  Heart,
  Clock,
  Award,
  Target,
  Star,
  MessageSquare,
  User,
  Sparkles
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

// Import forms
import EmployeeDocumentRequestForm from "../components/employee-portal/EmployeeDocumentRequestForm";
import EmployeeLeaveRequestForm from "../components/employee-portal/EmployeeLeaveRequestForm";

import SelfAssessmentForm from "../components/performance/SelfAssessmentForm";
import PeerFeedbackForm from "../components/performance/PeerFeedbackForm";

// Import lists
import MyDocumentRequests from "../components/employee-portal/MyDocumentRequests";
import MyLeaveRequests from "../components/employee-portal/MyLeaveRequests";
import EmployeeJobApplications from "../components/employee-portal/EmployeeJobApplications";
import AISmartGoalGenerator from "../components/ai/AISmartGoalGenerator";

export default function EmployeePortal() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [showDocumentRequestForm, setShowDocumentRequestForm] = useState(false);
  const [showLeaveRequestForm, setShowLeaveRequestForm] = useState(false);

  const [showSelfAssessmentForm, setShowSelfAssessmentForm] = useState(false);
  const [showPeerFeedbackForm, setShowPeerFeedbackForm] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  // Fetch data - Only load when tab is active or needed
  const { data: documentRequests = [] } = useQuery({
    queryKey: ['myDocumentRequests', user?.email],
    queryFn: () => base44.entities.DocumentRequest.filter({ employee_email: user.email }),
    enabled: !!user && (activeTab === 'overview' || activeTab === 'documents'),
  });

  const { data: leaveRequests = [] } = useQuery({
    queryKey: ['myLeaveRequests', user?.email],
    queryFn: () => base44.entities.LeaveRequest.filter({ employee_email: user.email }),
    enabled: !!user && (activeTab === 'overview' || activeTab === 'leaves'),
  });



  const { data: jobPostings = [] } = useQuery({
    queryKey: ['jobPostings'],
    queryFn: () => base44.entities.JobPosting.filter({ status: 'active' }),
    enabled: activeTab === 'overview' || activeTab === 'jobs',
  });

  const { data: performanceReviews = [] } = useQuery({
    queryKey: ['myPerformanceReviews', user?.email],
    queryFn: () => base44.entities.PerformanceReview.filter({ employee_email: user.email }),
    enabled: !!user && (activeTab === 'overview' || activeTab === 'performance'),
  });

  const { data: performanceGoals = [] } = useQuery({
    queryKey: ['myPerformanceGoals', user?.email],
    queryFn: () => base44.entities.PerformanceGoal.filter({ employee_email: user.email }),
    enabled: !!user && (activeTab === 'overview' || activeTab === 'performance'),
  });

  const { data: selfAssessments = [] } = useQuery({
    queryKey: ['mySelfAssessments', user?.email],
    queryFn: () => base44.entities.SelfAssessment.filter({ employee_email: user.email }),
    enabled: !!user && activeTab === 'performance',
  });

  const { data: peerFeedbacksGiven = [] } = useQuery({
    queryKey: ['myPeerFeedbacksGiven', user?.email],
    queryFn: () => base44.entities.PeerFeedback.filter({ reviewer_email: user.email }),
    enabled: !!user, // Kept as is, as it's not removed by outline.
  });

  const { data: peerFeedbacksReceived = [] } = useQuery({
    queryKey: ['myPeerFeedbacksReceived', user?.email],
    queryFn: () => base44.entities.PeerFeedback.filter({ reviewed_employee_email: user.email }),
    enabled: !!user && activeTab === 'performance',
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
    enabled: showPeerFeedbackForm || activeTab === 'goals',
  });

  const { data: myEmployeeRecord } = useQuery({
    queryKey: ['myEmployeeRecord', user?.email],
    queryFn: () => base44.entities.Employee.filter({ email: user.email }),
    enabled: !!user && activeTab === 'goals',
  });

  // Mutations
  const createDocumentRequestMutation = useMutation({
    mutationFn: (data) => base44.entities.DocumentRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myDocumentRequests'] });
      setShowDocumentRequestForm(false);
      toast({ 
        title: "Demande envoyée", 
        description: "Votre demande de document a été soumise.",
        duration: 5000,
      });
    },
  });

  const createLeaveRequestMutation = useMutation({
    mutationFn: (data) => base44.entities.LeaveRequest.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myLeaveRequests'] });
      setShowLeaveRequestForm(false);
      toast({ 
        title: "Demande envoyée", 
        description: "Votre demande de congé a été soumise.",
        duration: 5000,
      });
    },
  });



  const createSelfAssessmentMutation = useMutation({
    mutationFn: (data) => base44.entities.SelfAssessment.create(data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['mySelfAssessments'] });
      setShowSelfAssessmentForm(false);
      toast({
        title: variables.status === 'submitted' ? "Auto-évaluation soumise" : "Brouillon enregistré",
        description: variables.status === 'submitted'
          ? "Votre auto-évaluation a été soumise avec succès."
          : "Votre auto-évaluation a été enregistrée en brouillon.",
        duration: 5000,
      });
    },
  });

  const createPeerFeedbackMutation = useMutation({
    mutationFn: (data) => base44.entities.PeerFeedback.create(data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['myPeerFeedbacksGiven'] });
      setShowPeerFeedbackForm(false);
      toast({
        title: variables.status === 'submitted' ? "Feedback soumis" : "Brouillon enregistré",
        description: variables.status === 'submitted'
          ? "Votre feedback a été soumis avec succès."
          : "Votre feedback a été enregistré en brouillon.",
        duration: 5000,
      });
    },
  });

  const createGoalMutation = useMutation({
    mutationFn: (data) => base44.entities.PerformanceGoal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myPerformanceGoals'] });
      toast({
        title: "Objectif créé ✅",
        description: "Votre nouvel objectif a été ajouté.",
        duration: 5000,
      });
    },
  });

  // Stats - with safe defaults
  const pendingDocumentRequests = documentRequests?.filter(r => r.status === 'pending').length || 0;
  const pendingLeaveRequests = leaveRequests?.filter(r => r.status === 'pending').length || 0;

  const myGoals = performanceGoals?.filter(g => g.status !== 'completed' && g.status !== 'cancelled') || [];
  const completedGoals = performanceGoals?.filter(g => g.status === 'completed').length || 0;
  const lastReview = performanceReviews && performanceReviews.length > 0
    ? performanceReviews.sort((a, b) => new Date(b.review_date) - new Date(a.review_date))[0]
    : null;

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Chargement de votre portail...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg">
              <span className="text-white font-bold text-2xl">
                {user.full_name?.charAt(0) || user.email.charAt(0)}
              </span>
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">
                Bonjour, {user.full_name || user.email} 👋
              </h1>
              <p className="text-slate-600">Portail Employé - Gérez vos demandes et consultez vos informations</p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-700 mb-1">Demandes en attente</p>
                  <p className="text-3xl font-bold text-blue-900">
                    {pendingDocumentRequests + pendingLeaveRequests}
                  </p>
                </div>
                <Clock className="w-10 h-10 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Postes disponibles</p>
                  <p className="text-3xl font-bold text-green-900">{jobPostings.length}</p>
                </div>
                <Briefcase className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-700 mb-1">Mes objectifs</p>
                  <p className="text-3xl font-bold text-purple-900">{myGoals.length}</p>
                  <p className="text-xs text-purple-600 mt-1">{completedGoals} complétés</p>
                </div>
                <Target className="w-10 h-10 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-orange-700 mb-1">Dernière évaluation</p>
                  <p className="text-2xl font-bold text-orange-900">
                    {lastReview ? `${lastReview.overall_rating}/5` : 'N/A'}
                  </p>
                  <p className="text-xs text-orange-600 mt-1">
                    {lastReview ? lastReview.review_period : 'Aucune'}
                  </p>
                </div>
                <Award className="w-10 h-10 text-orange-600" />
              </div>
            </CardContent>
          </Card>


        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-white shadow-md flex flex-wrap h-auto">
            <TabsTrigger value="overview">Accueil</TabsTrigger>
            <TabsTrigger value="goals" className="flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              Mes Objectifs IA
            </TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="leaves">Congés</TabsTrigger>
            <TabsTrigger value="jobs">Postes</TabsTrigger>
            <TabsTrigger value="profile">Profil</TabsTrigger>
          </TabsList>

          {/* VUE D'ENSEMBLE */}
          <TabsContent value="overview" className="mt-6 space-y-6">
            {/* Actions rapides */}
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Actions rapides</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Button
                    onClick={() => setShowLeaveRequestForm(true)}
                    className="h-24 flex flex-col gap-2 bg-blue-600 hover:bg-blue-700"
                  >
                    <Calendar className="w-8 h-8" />
                    <span>Demander un congé</span>
                  </Button>
                  <Button
                    onClick={() => setShowDocumentRequestForm(true)}
                    className="h-24 flex flex-col gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <FileText className="w-8 h-8" />
                    <span>Demander un document</span>
                  </Button>
                  <Button
                    onClick={() => setShowSelfAssessmentForm(true)}
                    className="h-24 flex flex-col gap-2 bg-purple-600 hover:bg-purple-700"
                  >
                    <Star className="w-8 h-8" />
                    <span>Mon auto-évaluation</span>
                  </Button>
                  <Button
                    onClick={() => setShowPeerFeedbackForm(true)}
                    className="h-24 flex flex-col gap-2 bg-orange-600 hover:bg-orange-700"
                  >
                    <MessageSquare className="w-8 h-8" />
                    <span>Feedback collègue</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Mes objectifs de performance */}
            {myGoals.length > 0 && (
              <Card className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-purple-600" />
                    Mes objectifs en cours ({myGoals.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {myGoals.slice(0, 3).map(goal => (
                      <div key={goal.id} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <p className="font-semibold text-slate-900">{goal.goal_title}</p>
                            <p className="text-sm text-slate-600">
                              Échéance: {format(new Date(goal.target_date), 'dd/MM/yyyy')}
                            </p>
                          </div>
                          <Badge className="bg-purple-600">
                            {goal.progress_percentage || 0}%
                          </Badge>
                        </div>
                        <div className="w-full bg-purple-200 rounded-full h-2">
                          <div
                            className="bg-purple-600 h-2 rounded-full transition-all"
                            style={{ width: `${goal.progress_percentage || 0}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Dernière évaluation */}
            {lastReview && (
              <Card className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-orange-600" />
                    Dernière évaluation de performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600">Période: {lastReview.review_period}</p>
                        <p className="text-sm text-slate-600">
                          Date: {format(new Date(lastReview.review_date), 'dd/MM/yyyy')}
                        </p>
                      </div>
                      <Badge className="bg-orange-600 text-2xl py-2 px-4">
                        {lastReview.overall_rating}/5 ⭐
                      </Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Technique</p>
                        <p className="font-semibold text-lg">{lastReview.technical_skills}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Communication</p>
                        <p className="font-semibold text-lg">{lastReview.communication}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Équipe</p>
                        <p className="font-semibold text-lg">{lastReview.teamwork}/5</p>
                      </div>
                      <div className="p-3 bg-slate-50 rounded-lg">
                        <p className="text-xs text-slate-600">Leadership</p>
                        <p className="font-semibold text-lg">{lastReview.leadership}/5</p>
                      </div>
                    </div>

                    {lastReview.strengths && (
                      <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                        <p className="text-xs font-medium text-green-700 mb-1">✨ Points forts</p>
                        <p className="text-sm text-green-900">{lastReview.strengths}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Postes disponibles */}
            {jobPostings.length > 0 && (
              <Card className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-green-600" />
                    Opportunités internes ({jobPostings.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {jobPostings.slice(0, 3).map(job => (
                      <div key={job.id} className="p-4 bg-green-50 rounded-lg border border-green-200 hover:border-green-400 transition-colors cursor-pointer">
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-semibold text-slate-900">{job.title}</p>
                            <p className="text-sm text-slate-600">{job.department} • {job.location}</p>
                            {job.salary_range && (
                              <p className="text-sm text-green-700 mt-1">{job.salary_range}</p>
                            )}
                          </div>
                          <Badge className="bg-green-600">
                            {job.employment_type}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* MES OBJECTIFS IA */}
          <TabsContent value="goals" className="mt-6 space-y-6">
            <Card className="border-none shadow-lg bg-gradient-to-r from-purple-50 to-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  Générateur d'Objectifs SMART par IA
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  L'IA analyse vos compétences, votre performance et les opportunités de l'entreprise pour vous suggérer des objectifs personnalisés.
                </p>
              </CardContent>
            </Card>

            {myEmployeeRecord && myEmployeeRecord[0] ? (
              <AISmartGoalGenerator
                employee={myEmployeeRecord[0]}
                onGoalCreated={(goalData) => createGoalMutation.mutate(goalData)}
              />
            ) : (
              <Card className="border-none shadow-lg">
                <CardContent className="p-12 text-center">
                  <Target className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-slate-600">Chargement de votre profil...</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* PERFORMANCE */}
          <TabsContent value="performance" className="mt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Button
                onClick={() => setActiveTab('goals')}
                className="h-20 flex items-center justify-center gap-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Sparkles className="w-6 h-6" />
                <span className="text-lg">Objectifs SMART IA</span>
              </Button>
              <Button
                onClick={() => setShowSelfAssessmentForm(true)}
                className="h-20 flex items-center justify-center gap-3 bg-purple-600 hover:bg-purple-700"
              >
                <Star className="w-6 h-6" />
                <span className="text-lg">Mon auto-évaluation</span>
              </Button>
              <Button
                onClick={() => setShowPeerFeedbackForm(true)}
                className="h-20 flex items-center justify-center gap-3 bg-orange-600 hover:bg-orange-700"
              >
                <MessageSquare className="w-6 h-6" />
                <span className="text-lg">Donner un feedback</span>
              </Button>
            </div>

            <div className="text-center py-12">
              <Button
                onClick={() => window.location.href = '/MyProfile'}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <User className="w-4 h-4 mr-2" />
                Voir ma performance complète sur mon profil
              </Button>
            </div>
          </TabsContent>

          {/* DOCUMENTS */}
          <TabsContent value="documents" className="mt-6 space-y-6">
            <Button
              onClick={() => setShowDocumentRequestForm(true)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <FileText className="w-4 h-4 mr-2" />
              Nouvelle demande de document
            </Button>
            <MyDocumentRequests requests={documentRequests} />
          </TabsContent>

          {/* CONGÉS */}
          <TabsContent value="leaves" className="mt-6 space-y-6">
            <Button
              onClick={() => setShowLeaveRequestForm(true)}
              className="bg-green-600 hover:bg-green-700"
            >
              <Calendar className="w-4 h-4 mr-2" />
              Nouvelle demande de congé
            </Button>
            <MyLeaveRequests requests={leaveRequests} />
          </TabsContent>

          {/* POSTES */}
          <TabsContent value="jobs" className="mt-6">
            <EmployeeJobApplications jobPostings={jobPostings} />
          </TabsContent>



          {/* PROFIL */}
          <TabsContent value="profile" className="mt-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Mon profil complet
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <span className="text-white font-bold text-3xl">
                      {user.full_name?.charAt(0) || user.email.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-slate-900">{user.full_name || user.email}</p>
                    <p className="text-slate-600">{user.email}</p>
                  </div>
                </div>

                <Button
                  onClick={() => window.location.href = '/MyProfile'}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Voir mon profil complet avec toutes mes évaluations
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Forms */}
        {showDocumentRequestForm && (
          <EmployeeDocumentRequestForm
            onSubmit={(data) => createDocumentRequestMutation.mutate({
              ...data,
              employee_email: user.email,
              employee_name: user.full_name || user.email,
            })}
            onCancel={() => setShowDocumentRequestForm(false)}
            isSubmitting={createDocumentRequestMutation.isPending}
          />
        )}

        {showLeaveRequestForm && (
          <EmployeeLeaveRequestForm
            onSubmit={(data) => createLeaveRequestMutation.mutate({
              ...data,
              employee_email: user.email,
              employee_name: user.full_name || user.email,
            })}
            onCancel={() => setShowLeaveRequestForm(false)}
            isSubmitting={createLeaveRequestMutation.isPending}
          />
        )}



        {showSelfAssessmentForm && (
          <SelfAssessmentForm
            onSubmit={(data) => createSelfAssessmentMutation.mutate(data)}
            onCancel={() => setShowSelfAssessmentForm(false)}
            isSubmitting={createSelfAssessmentMutation.isPending}
          />
        )}

        {showPeerFeedbackForm && (
          <PeerFeedbackForm
            employees={employees}
            onSubmit={(data) => createPeerFeedbackMutation.mutate(data)}
            onCancel={() => setShowPeerFeedbackForm(false)}
            isSubmitting={createPeerFeedbackMutation.isPending}
          />
        )}
      </div>
    </div>
  );
}