import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, Filter, FileText, Calendar, X, MessageSquare, CheckCircle, Sparkles, BarChart3, History, Shield } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import DocumentCard from "../components/documents/DocumentCard";
import DocumentForm from "../components/documents/DocumentForm";
import DocumentVersionHistory from "../components/documents/DocumentVersionHistory";
import DocumentShareForm from "../components/documents/DocumentShareForm";
import DocumentUploadNewVersion from "../components/documents/DocumentUploadNewVersion";
import DocumentRequestCard from "../components/documents/DocumentRequestCard";
import DocumentGenerator from "../components/documents/DocumentGenerator";
import AdvancedDocumentSearch from "../components/documents/AdvancedDocumentSearch";
import DocumentApproval from "../components/documents/DocumentApproval";
import SignatureWorkflow from "../components/signature/SignatureWorkflow";
import SignatureStatus from "../components/signature/SignatureStatus";
import DocumentAuditTrail from "../components/documents/DocumentAuditTrail";
import DocumentReporting from "../components/documents/DocumentReporting";
import { logDocumentAction, AUDIT_ACTIONS } from "../components/documents/DocumentAuditService";
import DocumentPermissionManager from "../components/documents/DocumentPermissionManager";
import { useToast } from "@/components/ui/use-toast";
import { format, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";
import { filterDocumentsByAccess, canDeleteDocument, canShareDocument } from "../components/documents/DocumentAccessControl";
import { notifyDocumentRequestStatus } from "../components/notifications/NotificationTriggers";

export default function Documents() {
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterEmployee, setFilterEmployee] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [activeTab, setActiveTab] = useState("all");
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [showShareForm, setShowShareForm] = useState(false);
  const [showUploadNewVersion, setShowUploadNewVersion] = useState(false);
  const [showDocGenerator, setShowDocGenerator] = useState(false);
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [showApprovalDialog, setShowApprovalDialog] = useState(false);
  const [showSignatureRequest, setShowSignatureRequest] = useState(false);
  const [showSignatureStatus, setShowSignatureStatus] = useState(false);
  const [selectedEmployeeForGen, setSelectedEmployeeForGen] = useState(null);
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [user, setUser] = useState(null);
  const [userRole, setUserRole] = useState(null);
  const [requestFilter, setRequestFilter] = useState("all");
  const [advancedSearchFilters, setAdvancedSearchFilters] = useState(null);
  const [showAuditTrail, setShowAuditTrail] = useState(false);
  const [showReporting, setShowReporting] = useState(false);
  const [showPermissionManager, setShowPermissionManager] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Charger le rôle de l'utilisateur
        const roles = await base44.entities.UserRole.filter({
          user_email: currentUser.email,
          is_active: true
        });
        setUserRole(roles[0] || null);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['documents'],
    queryFn: () => base44.entities.Document.list('-created_date'),
  });

  const { data: documentRequests = [] } = useQuery({
    queryKey: ['documentRequests'],
    queryFn: () => base44.entities.DocumentRequest.list('-created_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const doc = await base44.entities.Document.create({
        ...data,
        current_version: 1,
        last_modified_date: new Date().toISOString(),
        last_modified_by: data.uploaded_by,
        status: "actif"
      });

      await base44.entities.DocumentVersion.create({
        document_id: doc.id,
        version_number: 1,
        file_url: data.file_url,
        uploaded_by: data.uploaded_by,
        uploaded_by_name: user?.full_name || data.uploaded_by,
        upload_date: new Date().toISOString(),
        change_notes: "Version initiale",
        is_current: true
      });

      // Log audit
      if (user) {
        await logDocumentAction({
          document: doc,
          action: AUDIT_ACTIONS.CREATED,
          actor: user,
          details: { document_type: data.document_type }
        });
      }

      return doc;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      setShowForm(false);
      toast({
        title: "Document ajouté",
        description: "Le document a été téléchargé avec succès.",
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le document.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const doc = documents.find(d => d.id === id);
      const versions = await base44.entities.DocumentVersion.filter({ document_id: id });
      const shares = await base44.entities.DocumentShare.filter({ document_id: id });
      
      // Log audit before deletion
      if (user && doc) {
        await logDocumentAction({
          document: doc,
          action: AUDIT_ACTIONS.DELETED,
          actor: user
        });
      }
      
      await Promise.all([
        ...versions.map(v => base44.entities.DocumentVersion.delete(v.id)),
        ...shares.map(s => base44.entities.DocumentShare.delete(s.id)),
      ]);

      await base44.entities.Document.delete(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      toast({
        title: "Document supprimé",
        description: "Le document et toutes ses versions ont été supprimés.",
        variant: "destructive",
      });
    },
  });

  const shareMutation = useMutation({
    mutationFn: async (data) => {
      await base44.entities.DocumentShare.create({
        document_id: selectedDocument.id,
        document_title: selectedDocument.title,
        shared_by: user.email,
        shared_by_name: user.full_name || user.email,
        shared_date: new Date().toISOString(),
        ...data
      });

      await base44.entities.Document.update(selectedDocument.id, {
        is_shared: true
      });

      // Log audit
      if (user) {
        await logDocumentAction({
          document: selectedDocument,
          action: AUDIT_ACTIONS.SHARED,
          actor: user,
          targetEmail: data.shared_with_email,
          targetName: data.shared_with_name,
          details: { permission: data.permission }
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      setShowShareForm(false);
      setSelectedDocument(null);
      toast({
        title: "Document partagé",
        description: "Le document a été partagé avec succès.",
      });
    },
  });

  const updateRequestMutation = useMutation({
    mutationFn: async ({ id, data, request }) => {
      await base44.entities.DocumentRequest.update(id, data);
      
      // Notifier l'employé du changement de statut
      if (data.status) {
        await notifyDocumentRequestStatus(request, data.status);
      }
      
      return { id, data };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documentRequests'] });
    },
  });

  const handleRequestStatusUpdate = (id, status, notes, documentUrl) => {
    const request = documentRequests.find(r => r.id === id);
    updateRequestMutation.mutate({
      id,
      data: {
        status,
        response_notes: notes,
        document_url: documentUrl
      },
      request
    });
  };

  // Filtrer les documents avec recherche avancée
  const filteredDocuments = documents.filter(doc => {
    // Filtres de base
    if (!advancedSearchFilters) {
      const matchesSearch = doc.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           doc.employee_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           doc.description?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = filterType === "all" || doc.document_type === filterType;
      const matchesEmployee = filterEmployee === "all" || doc.employee_email === filterEmployee;
      const matchesStatus = filterStatus === "all" || doc.status === filterStatus;
      const matchesTab = activeTab === "all" || activeTab === "requests" || doc.document_type === activeTab;
      
      let matchesDate = true;
      if (dateRange.start && dateRange.end) {
        const docDate = new Date(doc.upload_date || doc.created_date);
        matchesDate = isWithinInterval(docDate, {
          start: new Date(dateRange.start),
          end: new Date(dateRange.end)
        });
      }
      
      return matchesSearch && matchesType && matchesEmployee && matchesStatus && matchesTab && matchesDate;
    }

    // Filtres avancés
    const filters = advancedSearchFilters;
    
    const matchesSearch = !filters.searchTerm || 
      doc.title?.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
      doc.employee_name?.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
      doc.description?.toLowerCase().includes(filters.searchTerm.toLowerCase());
    
    const matchesType = filters.documentType === "all" || doc.document_type === filters.documentType;
    const matchesEmployee = filters.employeeEmail === "all" || doc.employee_email === filters.employeeEmail;
    const matchesStatus = filters.status === "all" || doc.status === filters.status;
    const matchesUploader = filters.uploadedBy === "all" || doc.uploaded_by === filters.uploadedBy;
    
    const matchesShared = filters.isShared === "all" || 
      (filters.isShared === "shared" && doc.is_shared) ||
      (filters.isShared === "not_shared" && !doc.is_shared);
    
    let matchesDate = true;
    if (filters.dateFrom && filters.dateTo) {
      const docDate = new Date(doc.upload_date || doc.created_date);
      matchesDate = isWithinInterval(docDate, {
        start: new Date(filters.dateFrom),
        end: new Date(filters.dateTo)
      });
    }
    
    let matchesTags = true;
    if (filters.tags) {
      const searchTags = filters.tags.toLowerCase().split(',').map(t => t.trim());
      matchesTags = doc.tags?.some(tag => 
        searchTags.some(st => tag.toLowerCase().includes(st))
      );
    }

    // Département (via employé)
    let matchesDept = true;
    if (filters.department !== "all") {
      const emp = employees.find(e => e.email === doc.employee_email);
      matchesDept = emp?.department === filters.department;
    }
    
    return matchesSearch && matchesType && matchesEmployee && matchesStatus && 
           matchesUploader && matchesShared && matchesDate && matchesTags && matchesDept;
  });

  // Filtrer les demandes
  const filteredRequests = requestFilter === "all" 
    ? documentRequests 
    : documentRequests.filter(r => r.status === requestFilter);

  const pendingRequestsCount = documentRequests.filter(r => r.status === 'pending').length;

  // Statistiques
  const totalDocs = documents.length;
  const contractDocs = documents.filter(d => d.document_type === "Contrat").length;
  const idDocs = documents.filter(d => d.document_type === "Carte d'identité").length;
  const certificateDocs = documents.filter(d => d.document_type === "Certificat").length;
  const sharedDocs = documents.filter(d => d.is_shared).length;
  const signedDocs = documents.filter(d => d.status === "signé").length;
  const awaitingSignatureDocs = documents.filter(d => d.status === "en_attente_signature").length;

  const documentTypes = [
    { value: "Contrat", label: "Contrat", color: "bg-blue-100 text-blue-800" },
    { value: "Carte d'identité", label: "Carte d'identité", color: "bg-green-100 text-green-800" },
    { value: "CV", label: "CV", color: "bg-purple-100 text-purple-800" },
    { value: "Certificat", label: "Certificat", color: "bg-orange-100 text-orange-800" },
    { value: "Attestation", label: "Attestation", color: "bg-pink-100 text-pink-800" },
    { value: "Fiche de paie", label: "Fiche de paie", color: "bg-yellow-100 text-yellow-800" },
    { value: "Autre", label: "Autre", color: "bg-gray-100 text-gray-800" },
  ];

  const hasActiveFilters = dateRange.start || dateRange.end || filterType !== "all" || filterEmployee !== "all" || filterStatus !== "all";

  const clearFilters = () => {
    setDateRange({ start: "", end: "" });
    setFilterType("all");
    setFilterEmployee("all");
    setFilterStatus("all");
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <FileText className="w-8 h-8 text-blue-600" />
            Gestion Documentaire Avancée
          </h1>
          <p className="text-slate-600 mt-1">
            {totalDocs} documents • {signedDocs} signés • {awaitingSignatureDocs} en attente signature • {pendingRequestsCount} demandes
          </p>
        </div>
        <div className="flex gap-3 flex-wrap">
          <Button
            onClick={() => setShowPermissionManager(!showPermissionManager)}
            variant={showPermissionManager ? "default" : "outline"}
            className={showPermissionManager ? "bg-purple-600 hover:bg-purple-700 gap-2" : "gap-2"}
          >
            <Shield className="w-4 h-4" />
            Permissions
          </Button>
          <Button
            onClick={() => setShowReporting(!showReporting)}
            variant={showReporting ? "default" : "outline"}
            className={showReporting ? "bg-green-600 hover:bg-green-700 gap-2" : "gap-2"}
          >
            <BarChart3 className="w-4 h-4" />
            Reporting
          </Button>
          <Button
            onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
            variant="outline"
            className="gap-2"
          >
            <Search className="w-4 h-4" />
            Recherche avancée
          </Button>
          <Button
            onClick={() => {
              setSelectedEmployeeForGen(null);
              setShowDocGenerator(true);
            }}
            className="bg-purple-600 hover:bg-purple-700 gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Générer un document
          </Button>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-blue-600 hover:bg-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Uploader
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Total documents</p>
                <p className="text-3xl font-bold text-blue-900">{totalDocs}</p>
              </div>
              <FileText className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Contrats</p>
                <p className="text-3xl font-bold text-green-900">{contractDocs}</p>
              </div>
              <FileText className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Pièces d'identité</p>
                <p className="text-3xl font-bold text-purple-900">{idDocs}</p>
              </div>
              <FileText className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Certificats</p>
                <p className="text-3xl font-bold text-orange-900">{certificateDocs}</p>
              </div>
              <FileText className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card 
          className="border-none shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100 cursor-pointer hover:shadow-xl transition-shadow"
          onClick={() => setActiveTab('requests')}
        >
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-yellow-700 mb-1">Demandes</p>
                <p className="text-3xl font-bold text-yellow-900">{pendingRequestsCount}</p>
                <p className="text-xs text-yellow-600 mt-1">en attente</p>
              </div>
              <MessageSquare className="w-10 h-10 text-yellow-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Permission Manager */}
      {showPermissionManager && (
        <DocumentPermissionManager
          employees={employees}
          departments={departments}
        />
      )}

      {/* Reporting */}
      {showReporting && (
        <DocumentReporting 
          documents={documents}
          employees={employees}
          departments={departments}
        />
      )}

      {/* Recherche avancée */}
      {showAdvancedSearch && (
        <AdvancedDocumentSearch
          employees={employees}
          departments={departments}
          documents={documents}
          totalResults={filteredDocuments.length}
          onSearch={(filters) => {
            setAdvancedSearchFilters(filters);
            setShowAdvancedSearch(false);
          }}
        />
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md flex-wrap h-auto">
          <TabsTrigger value="all">
            Tous les documents ({documents.length})
          </TabsTrigger>
          <TabsTrigger value="requests" className="gap-2">
            <MessageSquare className="w-4 h-4" />
            Demandes ({documentRequests.length})
            {pendingRequestsCount > 0 && (
              <Badge className="ml-1 bg-orange-500">{pendingRequestsCount}</Badge>
            )}
          </TabsTrigger>
          {documentTypes.map(type => (
            <TabsTrigger key={type.value} value={type.value}>
              {type.label} ({documents.filter(d => d.document_type === type.value).length})
            </TabsTrigger>
          ))}
        </TabsList>

        {/* Onglet Demandes */}
        <TabsContent value="requests" className="mt-6">
          <div className="space-y-6">
            {/* Filtres pour les demandes */}
            <Card className="border-none shadow-lg">
              <CardContent className="p-6">
                <Tabs value={requestFilter} onValueChange={setRequestFilter}>
                  <TabsList className="bg-white shadow-md">
                    <TabsTrigger value="all">Toutes les demandes</TabsTrigger>
                    <TabsTrigger value="pending">
                      En attente
                      {pendingRequestsCount > 0 && (
                        <span className="ml-2 px-2 py-0.5 text-xs bg-orange-100 text-orange-800 rounded-full">
                          {pendingRequestsCount}
                        </span>
                      )}
                    </TabsTrigger>
                    <TabsTrigger value="processing">En cours</TabsTrigger>
                    <TabsTrigger value="completed">Terminées</TabsTrigger>
                    <TabsTrigger value="rejected">Rejetées</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardContent>
            </Card>

            {/* Liste des demandes */}
            {filteredRequests.length === 0 ? (
              <Card className="border-none shadow-lg">
                <CardContent className="p-12 text-center text-slate-500">
                  <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">Aucune demande trouvée</p>
                  <p className="text-sm">Les employés peuvent faire leurs demandes via le Portail Employé</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredRequests.map((request) => (
                  <DocumentRequestCard
                    key={request.id}
                    request={request}
                    onStatusUpdate={handleRequestStatusUpdate}
                  />
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Onglets documents existants */}
        <TabsContent value={activeTab} className="mt-6">
          {activeTab !== 'requests' && (
            <>
              {/* Filters */}
              <Card className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex flex-col md:flex-row gap-4">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                        <Input
                          placeholder="Rechercher par titre, employé ou description..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                      
                      <Select value={filterType} onValueChange={setFilterType}>
                        <SelectTrigger className="w-full md:w-48">
                          <Filter className="w-4 h-4 mr-2" />
                          <SelectValue placeholder="Type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Tous les types</SelectItem>
                          {documentTypes.map(type => (
                            <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={filterEmployee} onValueChange={setFilterEmployee}>
                        <SelectTrigger className="w-full md:w-48">
                          <SelectValue placeholder="Employé" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Tous les employés</SelectItem>
                          {employees.map(emp => (
                            <SelectItem key={emp.id} value={emp.email}>
                              {emp.full_name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>

                      <Select value={filterStatus} onValueChange={setFilterStatus}>
                        <SelectTrigger className="w-full md:w-48">
                          <SelectValue placeholder="Statut" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Tous les statuts</SelectItem>
                          <SelectItem value="actif">Actif</SelectItem>
                          <SelectItem value="brouillon">Brouillon</SelectItem>
                          <SelectItem value="archivé">Archivé</SelectItem>
                          <SelectItem value="obsolète">Obsolète</SelectItem>
                        </SelectContent>
                      </Select>

                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full md:w-auto gap-2">
                            <Calendar className="w-4 h-4" />
                            Période
                            {dateRange.start && dateRange.end && (
                              <Badge variant="secondary" className="ml-2">
                                Actif
                              </Badge>
                            )}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-80">
                          <div className="space-y-4">
                            <h4 className="font-semibold text-sm">Filtrer par période</h4>
                            <div className="space-y-2">
                              <Label htmlFor="start-date">Date de début</Label>
                              <Input
                                id="start-date"
                                type="date"
                                value={dateRange.start}
                                onChange={(e) => setDateRange({...dateRange, start: e.target.value})}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="end-date">Date de fin</Label>
                              <Input
                                id="end-date"
                                type="date"
                                value={dateRange.end}
                                onChange={(e) => setDateRange({...dateRange, end: e.target.value})}
                                min={dateRange.start}
                              />
                            </div>
                          </div>
                        </PopoverContent>
                      </Popover>
                    </div>

                    {hasActiveFilters && (
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="gap-2">
                          Filtres actifs
                        </Badge>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={clearFilters}
                          className="h-6 text-xs gap-1"
                        >
                          <X className="w-3 h-3" />
                          Réinitialiser
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Documents Grid */}
              {isLoading ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-slate-600">Chargement des documents...</p>
                </div>
              ) : filteredDocuments.length === 0 ? (
                <Card className="border-none shadow-lg">
                  <CardContent className="p-12 text-center text-slate-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <p className="text-lg font-medium mb-2">Aucun document trouvé</p>
                    <p className="text-sm">
                      {searchTerm || hasActiveFilters
                        ? "Essayez de modifier vos filtres de recherche"
                        : "Commencez par ajouter un document"}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredDocuments.map((document) => {
                    const canDelete = canDeleteDocument(document, user?.email, userRole);
                    const canShare = canShareDocument(document, user?.email, userRole);

                    return (
                      <DocumentCard 
                        key={document.id} 
                        document={document}
                        canDelete={canDelete}
                        canShare={canShare}
                        onDelete={(id) => {
                          if (canDelete && window.confirm("Êtes-vous sûr de vouloir supprimer ce document et toutes ses versions ?")) {
                            deleteMutation.mutate(id);
                          }
                        }}
                        onViewHistory={(doc) => {
                          setSelectedDocument(doc);
                          setShowVersionHistory(true);
                        }}
                        onShare={(doc) => {
                          if (canShare) {
                            setSelectedDocument(doc);
                            setShowShareForm(true);
                          }
                        }}
                        onUploadNewVersion={(doc) => {
                          setSelectedDocument(doc);
                          setShowUploadNewVersion(true);
                        }}
                        onRequestApproval={(doc) => {
                          setSelectedDocument(doc);
                          setShowApprovalDialog(true);
                        }}
                        onRequestSignature={(doc) => {
                          setSelectedDocument(doc);
                          setShowSignatureRequest(true);
                        }}
                        onViewAuditTrail={(doc) => {
                          setSelectedDocument(doc);
                          setShowAuditTrail(true);
                        }}
                      />
                    );
                  })}
                </div>
              )}
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Modals */}
      {showForm && (
        <DocumentForm
          employees={employees}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}

      {showVersionHistory && selectedDocument && (
        <>
          <DocumentVersionHistory
            document={selectedDocument}
            onClose={() => {
              setShowVersionHistory(false);
              setSelectedDocument(null);
            }}
          />
          <SignatureStatus 
            document={selectedDocument}
            onViewSignature={(sig) => {
              // Afficher la signature dans un modal
              const img = new Image();
              img.src = sig.signature_data;
              const win = window.open();
              win.document.write(img.outerHTML);
            }}
          />
        </>
      )}

      {showShareForm && selectedDocument && (
        <DocumentShareForm
          document={selectedDocument}
          employees={employees}
          departments={departments}
          onSubmit={(data) => shareMutation.mutate(data)}
          onCancel={() => {
            setShowShareForm(false);
            setSelectedDocument(null);
          }}
          isSubmitting={shareMutation.isPending}
        />
      )}

      {showUploadNewVersion && selectedDocument && (
        <DocumentUploadNewVersion
          document={selectedDocument}
          currentVersion={selectedDocument.current_version || 1}
          onSuccess={() => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            queryClient.invalidateQueries({ queryKey: ['documentVersions'] });
            setShowUploadNewVersion(false);
            setSelectedDocument(null);
            toast({
              title: "Nouvelle version créée",
              description: "La nouvelle version du document a été uploadée avec succès.",
            });
          }}
          onCancel={() => {
            setShowUploadNewVersion(false);
            setSelectedDocument(null);
          }}
        />
      )}

      {showDocGenerator && (
        <Dialog open={true} onOpenChange={() => setShowDocGenerator(false)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Sélectionner un employé</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Select 
                value={selectedEmployeeForGen?.id || ""} 
                onValueChange={(empId) => {
                  const emp = employees.find(e => e.id === empId);
                  setSelectedEmployeeForGen(emp);
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un employé" />
                </SelectTrigger>
                <SelectContent className="max-h-[400px]">
                  {employees.filter(e => e.status === 'active').map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedEmployeeForGen && (
                <Button
                  onClick={() => {
                    setShowDocGenerator(false);
                    // Ouvrir le générateur avec l'employé sélectionné
                    setTimeout(() => setShowDocGenerator(true), 100);
                  }}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  Continuer
                </Button>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {showDocGenerator && selectedEmployeeForGen && (
        <DocumentGenerator
          employee={selectedEmployeeForGen}
          onClose={() => {
            setShowDocGenerator(false);
            setSelectedEmployeeForGen(null);
          }}
          onGenerated={() => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
          }}
        />
      )}

      {showApprovalDialog && selectedDocument && (
        <DocumentApproval
          document={selectedDocument}
          onClose={() => {
            setShowApprovalDialog(false);
            setSelectedDocument(null);
          }}
          onApproved={() => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
          }}
        />
      )}

      {showSignatureRequest && selectedDocument && (
        <SignatureWorkflow
          document={selectedDocument}
          onClose={() => {
            setShowSignatureRequest(false);
            setSelectedDocument(null);
          }}
          onRequestSent={() => {
            queryClient.invalidateQueries({ queryKey: ['documents'] });
            toast({
              title: "Demandes de signature envoyées",
              description: "Les signataires ont été notifiés par email et notification",
              duration: 5000,
            });
          }}
        />
      )}

      {showAuditTrail && selectedDocument && (
        <DocumentAuditTrail
          document={selectedDocument}
          onClose={() => {
            setShowAuditTrail(false);
            setSelectedDocument(null);
          }}
        />
      )}
    </div>
  );
}