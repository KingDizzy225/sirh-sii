import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Employees from "./Employees";

import LeaveManagement from "./LeaveManagement";

import Attendance from "./Attendance";

import Departments from "./Departments";

import Performance from "./Performance";

import Documents from "./Documents";

import DocumentRequests from "./DocumentRequests";

import EmployeePortal from "./EmployeePortal";

import Onboarding from "./Onboarding";

import Recruitment from "./Recruitment";

import TrainingManagement from "./TrainingManagement";

import Assets from "./Assets";

import WorkflowManagement from "./WorkflowManagement";

import SocialSupport from "./SocialSupport";

import Organigramme from "./Organigramme";

import GPEC from "./GPEC";

import RoleManagement from "./RoleManagement";

import Chat from "./Chat";

import Notifications from "./Notifications";

import MyProfile from "./MyProfile";

import OrganigrammeStaffLine from "./OrganigrammeStaffLine";

import NotificationSettings from "./NotificationSettings";

import MySignatures from "./MySignatures";

import MySocialSupport from "./MySocialSupport";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Employees: Employees,
    
    LeaveManagement: LeaveManagement,
    
    Attendance: Attendance,
    
    Departments: Departments,
    
    Performance: Performance,
    
    Documents: Documents,
    
    DocumentRequests: DocumentRequests,
    
    EmployeePortal: EmployeePortal,
    
    Onboarding: Onboarding,
    
    Recruitment: Recruitment,
    
    TrainingManagement: TrainingManagement,
    
    Assets: Assets,
    
    WorkflowManagement: WorkflowManagement,
    
    SocialSupport: SocialSupport,
    
    Organigramme: Organigramme,
    
    GPEC: GPEC,
    
    RoleManagement: RoleManagement,
    
    Chat: Chat,
    
    Notifications: Notifications,
    
    MyProfile: MyProfile,
    
    OrganigrammeStaffLine: OrganigrammeStaffLine,
    
    NotificationSettings: NotificationSettings,
    
    MySignatures: MySignatures,
    
    MySocialSupport: MySocialSupport,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Employees" element={<Employees />} />
                
                <Route path="/LeaveManagement" element={<LeaveManagement />} />
                
                <Route path="/Attendance" element={<Attendance />} />
                
                <Route path="/Departments" element={<Departments />} />
                
                <Route path="/Performance" element={<Performance />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/DocumentRequests" element={<DocumentRequests />} />
                
                <Route path="/EmployeePortal" element={<EmployeePortal />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/Recruitment" element={<Recruitment />} />
                
                <Route path="/TrainingManagement" element={<TrainingManagement />} />
                
                <Route path="/Assets" element={<Assets />} />
                
                <Route path="/WorkflowManagement" element={<WorkflowManagement />} />
                
                <Route path="/SocialSupport" element={<SocialSupport />} />
                
                <Route path="/Organigramme" element={<Organigramme />} />
                
                <Route path="/GPEC" element={<GPEC />} />
                
                <Route path="/RoleManagement" element={<RoleManagement />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
                <Route path="/MyProfile" element={<MyProfile />} />
                
                <Route path="/OrganigrammeStaffLine" element={<OrganigrammeStaffLine />} />
                
                <Route path="/NotificationSettings" element={<NotificationSettings />} />
                
                <Route path="/MySignatures" element={<MySignatures />} />
                
                <Route path="/MySocialSupport" element={<MySocialSupport />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}