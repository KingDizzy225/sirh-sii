
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Shield, Users, Search, Plus, Edit, Trash2, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

// Définition des rôles prédéfinis avec leurs permissions
const ROLE_TEMPLATES = {
  super_admin: {
    name: "Super Administrateur",
    description: "Accès complet à toutes les fonctionnalités",
    color: "bg-red-100 text-red-800",
    permissions: {
      employees: { view: true, create: true, edit: true, delete: true, view_salary: true },
      leave: { view: true, approve: true, reject: true },
      attendance: { view: true, manage: true },
      recruitment: { view: true, manage_jobs: true, manage_candidates: true, schedule_interviews: true },
      performance: { view: true, create_review: true, approve_review: true },
      training: { view: true, create: true, manage: true },
      documents: { view: true, upload: true, delete: true, share: true },
      departments: { view: true, manage: true },
      analytics: { view_dashboard: true, view_reports: true, export_data: true },
      settings: { manage_roles: true, manage_workflows: true, system_settings: true }
    }
  },
  rh_manager: {
    name: "Manager RH",
    description: "Gestion complète des RH sauf paramètres système",
    color: "bg-blue-100 text-blue-800",
    permissions: {
      employees: { view: true, create: true, edit: true, delete: false, view_salary: true },
      leave: { view: true, approve: true, reject: true },
      attendance: { view: true, manage: true },
      recruitment: { view: true, manage_jobs: true, manage_candidates: true, schedule_interviews: true },
      performance: { view: true, create_review: true, approve_review: true },
      training: { view: true, create: true, manage: true },
      documents: { view: true, upload: true, delete: false, share: true },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: true, view_reports: true, export_data: true },
      settings: { manage_roles: false, manage_workflows: true, system_settings: false }
    }
  },
  rh_recruiter: {
    name: "Recruteur RH",
    description: "Gestion du recrutement et des candidatures",
    color: "bg-purple-100 text-purple-800",
    permissions: {
      employees: { view: true, create: false, edit: false, delete: false, view_salary: false },
      leave: { view: false, approve: false, reject: false },
      attendance: { view: false, manage: false },
      recruitment: { view: true, manage_jobs: true, manage_candidates: true, schedule_interviews: true },
      performance: { view: false, create_review: false, approve_review: false },
      training: { view: false, create: false, manage: false },
      documents: { view: true, upload: true, delete: false, share: false },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: false, view_reports: false, export_data: false },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  },
  department_manager: {
    name: "Manager de Département",
    description: "Gestion de son département uniquement",
    color: "bg-green-100 text-green-800",
    permissions: {
      employees: { view: true, create: false, edit: true, delete: false, view_salary: false },
      leave: { view: true, approve: true, reject: true },
      attendance: { view: true, manage: true },
      recruitment: { view: true, manage_jobs: false, manage_candidates: false, schedule_interviews: false },
      performance: { view: true, create_review: true, approve_review: false },
      training: { view: true, create: false, manage: false },
      documents: { view: true, upload: false, delete: false, share: false },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: true, view_reports: false, export_data: false },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  },
  payroll_admin: {
    name: "Administrateur Paie",
    description: "Gestion de la paie et données salariales",
    color: "bg-yellow-100 text-yellow-800",
    permissions: {
      employees: { view: true, create: false, edit: false, delete: false, view_salary: true },
      leave: { view: true, approve: false, reject: false },
      attendance: { view: true, manage: false },
      recruitment: { view: false, manage_jobs: false, manage_candidates: false, schedule_interviews: false },
      performance: { view: true, create_review: false, approve_review: false },
      training: { view: false, create: false, manage: false },
      documents: { view: true, upload: true, delete: false, share: false },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: true, view_reports: true, export_data: true },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  },
  training_manager: {
    name: "Manager Formation",
    description: "Gestion des formations et compétences",
    color: "bg-indigo-100 text-indigo-800",
    permissions: {
      employees: { view: true, create: false, edit: false, delete: false, view_salary: false },
      leave: { view: false, approve: false, reject: false },
      attendance: { view: false, manage: false },
      recruitment: { view: false, manage_jobs: false, manage_candidates: false, schedule_interviews: false },
      performance: { view: true, create_review: false, approve_review: false },
      training: { view: true, create: true, manage: true },
      documents: { view: true, upload: true, delete: false, share: true },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: true, view_reports: false, export_data: false },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  },
  document_manager: {
    name: "Gestionnaire Documents",
    description: "Gestion des documents RH",
    color: "bg-pink-100 text-pink-800",
    permissions: {
      employees: { view: true, create: false, edit: false, delete: false, view_salary: false },
      leave: { view: false, approve: false, reject: false },
      attendance: { view: false, manage: false },
      recruitment: { view: false, manage_jobs: false, manage_candidates: false, schedule_interviews: false },
      performance: { view: false, create_review: false, approve_review: false },
      training: { view: false, create: false, manage: false },
      documents: { view: true, upload: true, delete: true, share: true },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: false, view_reports: false, export_data: false },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  },
  performance_manager: {
    name: "Manager Performance",
    description: "Gestion des évaluations et objectifs",
    color: "bg-orange-100 text-orange-800",
    permissions: {
      employees: { view: true, create: false, edit: false, delete: false, view_salary: false },
      leave: { view: false, approve: false, reject: false },
      attendance: { view: false, manage: false },
      recruitment: { view: false, manage_jobs: false, manage_candidates: false, schedule_interviews: false },
      performance: { view: true, create_review: true, approve_review: true },
      training: { view: true, create: false, manage: false },
      documents: { view: true, upload: false, delete: false, share: false },
      departments: { view: true, manage: false },
      analytics: { view_dashboard: true, view_reports: true, export_data: false },
      settings: { manage_roles: false, manage_workflows: false, system_settings: false }
    }
  }
};

export default function RoleManagement() {
  const [showRoleForm, setShowRoleForm] = useState(false);
  const [selectedRole, setSelectedRole] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("users");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: userRoles = [] } = useQuery({
    queryKey: ['userRoles'],
    queryFn: () => base44.entities.UserRole.list('-assigned_date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const createRoleMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();
      return base44.entities.UserRole.create({
        ...data,
        assigned_by: user.email,
        assigned_date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userRoles'] });
      setShowRoleForm(false);
      setSelectedRole(null);
      toast({
        title: "Rôle attribué",
        description: "Le rôle a été attribué avec succès.",
      });
    },
  });

  const updateRoleMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.UserRole.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userRoles'] });
      setShowRoleForm(false);
      setSelectedRole(null);
      toast({
        title: "Rôle mis à jour",
        description: "Le rôle a été modifié avec succès.",
      });
    },
  });

  const deleteRoleMutation = useMutation({
    mutationFn: (id) => base44.entities.UserRole.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userRoles'] });
      toast({
        title: "Rôle supprimé",
        description: "Le rôle a été retiré.",
        variant: "destructive",
      });
    },
  });

  const filteredRoles = userRoles.filter(role =>
    role.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    role.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    role.role_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Stats
  const totalRoles = userRoles.length;
  const activeRoles = userRoles.filter(r => r.is_active).length;
  const roleDistribution = Object.entries(
    userRoles.reduce((acc, role) => {
      acc[role.role_type] = (acc[role.role_type] || 0) + 1;
      return acc;
    }, {})
  ).map(([type, count]) => ({
    type,
    name: ROLE_TEMPLATES[type]?.name || type,
    count
  }));

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-600" />
            Gestion des Rôles et Permissions
          </h1>
          <p className="text-slate-600 mt-1">
            Définissez les accès et permissions des utilisateurs
          </p>
        </div>
        <Button onClick={() => setShowRoleForm(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Attribuer un rôle
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Total rôles attribués</p>
                <p className="text-3xl font-bold text-blue-900">{totalRoles}</p>
              </div>
              <Shield className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Rôles actifs</p>
                <p className="text-3xl font-bold text-green-900">{activeRoles}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Types de rôles</p>
                <p className="text-3xl font-bold text-purple-900">{roleDistribution.length}</p>
              </div>
              <Users className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="users">Utilisateurs ({totalRoles})</TabsTrigger>
          <TabsTrigger value="roles">Types de rôles</TabsTrigger>
          <TabsTrigger value="permissions">Matrice de permissions</TabsTrigger>
        </TabsList>

        {/* UTILISATEURS */}
        <TabsContent value="users" className="mt-6 space-y-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle>Rôles attribués</CardTitle>
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <Input
                    placeholder="Rechercher un utilisateur..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredRoles.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Shield className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">Aucun rôle attribué</p>
                  <p className="text-sm">Commencez par attribuer des rôles aux utilisateurs</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredRoles.map((role) => (
                    <Card key={role.id} className="border-2">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3 flex-1">
                            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                              <span className="text-white font-bold">
                                {role.user_name?.charAt(0) || 'U'}
                              </span>
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <p className="font-semibold text-slate-900">{role.user_name}</p>
                                {!role.is_active && <Badge variant="outline">Désactivé</Badge>}
                              </div>
                              <p className="text-sm text-slate-600">{role.user_email}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <Badge className={ROLE_TEMPLATES[role.role_type]?.color || 'bg-gray-100 text-gray-800'}>
                                  {role.role_name || ROLE_TEMPLATES[role.role_type]?.name}
                                </Badge>
                                {role.department_restriction && (
                                  <Badge variant="outline">
                                    {role.department_restriction}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setSelectedRole(role);
                                setShowRoleForm(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                if (window.confirm("Retirer ce rôle ?")) {
                                  deleteRoleMutation.mutate(role.id);
                                }
                              }}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* TYPES DE RÔLES */}
        <TabsContent value="roles" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Object.entries(ROLE_TEMPLATES).map(([key, template]) => {
              const count = roleDistribution.find(r => r.type === key)?.count || 0;
              return (
                <Card key={key} className="border-2 hover:border-blue-400 transition-colors">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg mb-2">{template.name}</CardTitle>
                        <p className="text-sm text-slate-600">{template.description}</p>
                      </div>
                      <Badge className={template.color}>{count}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-xs font-semibold text-slate-700 uppercase mb-2">Permissions principales</p>
                      {Object.entries(template.permissions).slice(0, 5).map(([module, perms]) => (
                        <div key={module} className="text-xs text-slate-600">
                          <span className="font-medium capitalize">{module}:</span>{' '}
                          {Object.entries(perms).filter(([_, v]) => v).length} permissions
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* MATRICE DE PERMISSIONS */}
        <TabsContent value="permissions" className="mt-6">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Matrice de permissions par rôle</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-slate-200">
                      <th className="text-left p-3 font-semibold">Module / Permission</th>
                      {Object.values(ROLE_TEMPLATES).map((template, idx) => (
                        <th key={idx} className="p-3 text-center font-semibold text-xs">
                          {template.name.split(' ')[0]}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(ROLE_TEMPLATES.super_admin.permissions).map(([module, perms]) => (
                      <React.Fragment key={module}>
                        <tr className="border-b border-slate-100 bg-slate-50">
                          <td colSpan={Object.keys(ROLE_TEMPLATES).length + 1} className="p-2 font-semibold text-xs uppercase text-slate-700">
                            {module}
                          </td>
                        </tr>
                        {Object.keys(perms).map((perm) => (
                          <tr key={`${module}-${perm}`} className="border-b border-slate-100 hover:bg-slate-50">
                            <td className="p-3 text-slate-700">{perm.replace('_', ' ')}</td>
                            {Object.values(ROLE_TEMPLATES).map((template, idx) => (
                              <td key={idx} className="p-3 text-center">
                                {template.permissions[module]?.[perm] ? (
                                  <CheckCircle className="w-5 h-5 text-green-600 mx-auto" />
                                ) : (
                                  <XCircle className="w-5 h-5 text-slate-300 mx-auto" />
                                )}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </React.Fragment>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Formulaire d'attribution */}
      {showRoleForm && (
        <RoleFormDialog
          role={selectedRole}
          employees={employees}
          departments={departments}
          roleTemplates={ROLE_TEMPLATES}
          onSubmit={(data) => {
            if (selectedRole) {
              updateRoleMutation.mutate({ id: selectedRole.id, data });
            } else {
              createRoleMutation.mutate(data);
            }
          }}
          onCancel={() => {
            setShowRoleForm(false);
            setSelectedRole(null);
          }}
          isSubmitting={createRoleMutation.isPending || updateRoleMutation.isPending}
        />
      )}
    </div>
  );
}

// Composant formulaire
function RoleFormDialog({ role, employees, departments, roleTemplates, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    user_email: role?.user_email || "",
    user_name: role?.user_name || "",
    role_type: role?.role_type || "rh_manager",
    role_name: role?.role_name || "",
    department_restriction: role?.department_restriction || "",
    is_active: role?.is_active !== false,
    notes: role?.notes || "",
    permissions: role?.permissions || roleTemplates.rh_manager.permissions
  });

  const handleRoleTypeChange = (roleType) => {
    setFormData({
      ...formData,
      role_type: roleType,
      role_name: roleTemplates[roleType]?.name || "",
      permissions: roleTemplates[roleType]?.permissions || {}
    });
  };

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      user_email: email,
      user_name: employee?.full_name || ""
    });
  };

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {role ? "Modifier le rôle" : "Attribuer un rôle"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Sélection utilisateur */}
          <div>
            <Label>Utilisateur *</Label>
            <Select
              value={formData.user_email}
              onValueChange={handleEmployeeChange}
              disabled={!!role}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un utilisateur" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.email}>
                    {emp.full_name} - {emp.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Type de rôle */}
          <div>
            <Label>Type de rôle *</Label>
            <Select
              value={formData.role_type}
              onValueChange={handleRoleTypeChange}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(roleTemplates).map(([key, template]) => (
                  <SelectItem key={key} value={key}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500 mt-1">
              {roleTemplates[formData.role_type]?.description}
            </p>
          </div>

          {/* Restriction département (pour department_manager) */}
          {formData.role_type === 'department_manager' && (
            <div>
              <Label>Département *</Label>
              <Select
                value={formData.department_restriction}
                onValueChange={(value) => setFormData({ ...formData, department_restriction: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un département" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Statut */}
          <div className="flex items-center gap-2">
            <Checkbox
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
            <Label>Rôle actif</Label>
          </div>

          {/* Notes */}
          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Notes sur l'attribution de ce rôle..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onCancel} disabled={isSubmitting}>
              Annuler
            </Button>
            <Button
              onClick={() => onSubmit(formData)}
              disabled={isSubmitting || !formData.user_email || !formData.role_type}
            >
              {isSubmitting ? "En cours..." : role ? "Mettre à jour" : "Attribuer"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
