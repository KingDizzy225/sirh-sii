import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link2, Copy, CheckCircle } from "lucide-react";
import DocumentRequestCard from "../components/documents/DocumentRequestCard";

export default function DocumentRequests() {
  const [filter, setFilter] = useState("all");
  const [copied, setCopied] = useState(false);

  const queryClient = useQueryClient();

  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['documentRequests'],
    queryFn: () => base44.entities.DocumentRequest.list('-created_date'),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DocumentRequest.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documentRequests'] });
    },
  });

  const handleStatusUpdate = (id, status, notes, documentUrl) => {
    updateMutation.mutate({
      id,
      data: {
        status,
        response_notes: notes,
        document_url: documentUrl
      }
    });
  };

  const filteredRequests = filter === "all" 
    ? requests 
    : requests.filter(r => r.status === filter);

  const pendingCount = requests.filter(r => r.status === 'pending').length;

  const employeePortalUrl = `${window.location.origin}${window.location.pathname}?page=EmployeePortal`;

  const copyLink = () => {
    navigator.clipboard.writeText(employeePortalUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Demandes de documents</h1>
          <p className="text-slate-600 mt-1">{pendingCount} demandes en attente</p>
        </div>
      </div>

      <Card className="shadow-lg border-none bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200">
        <CardHeader>
          <CardTitle className="text-lg">Portail employé</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-600 mb-4">
            Partagez ce lien avec vos employés pour qu'ils puissent demander des documents RH
          </p>
          <div className="flex gap-2">
            <div className="flex-1 p-3 bg-white rounded-lg border border-slate-200 font-mono text-sm truncate">
              {employeePortalUrl}
            </div>
            <Button onClick={copyLink} variant="outline">
              {copied ? (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Copié!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copier
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="all">Toutes les demandes</TabsTrigger>
          <TabsTrigger value="pending">
            En attente
            {pendingCount > 0 && (
              <span className="ml-2 px-2 py-0.5 text-xs bg-orange-100 text-orange-800 rounded-full">
                {pendingCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="processing">En cours</TabsTrigger>
          <TabsTrigger value="completed">Terminées</TabsTrigger>
          <TabsTrigger value="rejected">Rejetées</TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <div className="text-center py-12">Chargement...</div>
      ) : filteredRequests.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          <p>Aucune demande trouvée</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredRequests.map((request) => (
            <DocumentRequestCard
              key={request.id}
              request={request}
              onStatusUpdate={handleStatusUpdate}
            />
          ))}
        </div>
      )}
    </div>
  );
}