import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, GraduationCap, Award, TrendingUp, Users, BookOpen, Grid3x3, Sparkles } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import TrainingCard from "../components/training/TrainingCard";
import TrainingForm from "../components/training/TrainingForm";
import SkillMatrix from "../components/training/SkillMatrix";
import SkillCatalog from "../components/training/SkillCatalog";
import TrainingAnalytics from "../components/training/TrainingAnalytics";
import EmployeeSkillManagement from "../components/training/EmployeeSkillManagement";
import AITrainingRecommender from "../components/ai/AITrainingRecommender";
import { notifyTrainingAssignment } from "../components/notifications/NotificationTriggers";
import TrainingCertificateUpload from "../components/training/TrainingCertificateUpload";
import SkillGapAnalysis from "../components/training/SkillGapAnalysis";
import TrainingNeedsReport from "../components/training/TrainingNeedsReport";
import CertificatesList from "../components/training/CertificatesList";
import AITrainingGapRecommender from "../components/ai/AITrainingGapRecommender";

export default function TrainingManagement() {
  const [showForm, setShowForm] = useState(false);
  const [activeTab, setActiveTab] = useState("trainings");
  const [showCertificateUpload, setShowCertificateUpload] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedTraining, setSelectedTraining] = useState(null);

  const queryClient = useQueryClient();

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list('-training_date'),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: enrollments = [] } = useQuery({
    queryKey: ['trainingEnrollments'],
    queryFn: () => base44.entities.TrainingEnrollment.list('-enrollment_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Training.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trainings'] });
      setShowForm(false);
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Training.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trainings'] });
    },
  });

  // Statistiques
  const publishedTrainings = trainings.filter(t => t.status === 'published').length;
  const ongoingTrainings = trainings.filter(t => t.status === 'ongoing').length;
  const totalEnrollments = enrollments.length;
  const completedEnrollments = enrollments.filter(e => e.status === 'completed').length;
  const totalSkills = [...new Set(skills.map(s => s.skill_name))].length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <GraduationCap className="w-8 h-8 text-blue-600" />
            Gestion de la Formation
          </h1>
          <p className="text-slate-600 mt-1">
            {trainings.length} formations • {totalEnrollments} inscriptions • {totalSkills} compétences
          </p>
        </div>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700 shadow-lg"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouvelle formation
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Formations publiées</p>
                <p className="text-3xl font-bold text-blue-900">{publishedTrainings}</p>
              </div>
              <div className="w-12 h-12 bg-blue-200 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-blue-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">En cours</p>
                <p className="text-3xl font-bold text-green-900">{ongoingTrainings}</p>
              </div>
              <div className="w-12 h-12 bg-green-200 rounded-xl flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-green-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Inscriptions</p>
                <p className="text-3xl font-bold text-purple-900">{totalEnrollments}</p>
              </div>
              <div className="w-12 h-12 bg-purple-200 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-purple-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Terminées</p>
                <p className="text-3xl font-bold text-orange-900">{completedEnrollments}</p>
              </div>
              <div className="w-12 h-12 bg-orange-200 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-orange-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-pink-50 to-pink-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-pink-700 mb-1">Compétences</p>
                <p className="text-3xl font-bold text-pink-900">{totalSkills}</p>
              </div>
              <div className="w-12 h-12 bg-pink-200 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-pink-700" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md flex flex-wrap h-auto">
          <TabsTrigger value="trainings" className="gap-2">
            <GraduationCap className="w-4 h-4" />
            Formations ({trainings.length})
          </TabsTrigger>
          <TabsTrigger value="enrollments" className="gap-2">
            <Users className="w-4 h-4" />
            Inscriptions ({totalEnrollments})
          </TabsTrigger>
          <TabsTrigger value="matrix" className="gap-2">
            <Grid3x3 className="w-4 h-4" />
            Matrice
          </TabsTrigger>
          <TabsTrigger value="skills" className="gap-2">
            <Award className="w-4 h-4" />
            Compétences ({totalSkills})
          </TabsTrigger>
          <TabsTrigger value="employees" className="gap-2">
            <Users className="w-4 h-4" />
            Par employé
          </TabsTrigger>
          <TabsTrigger value="certificates" className="gap-2">
            <Award className="w-4 h-4" />
            Certificats
          </TabsTrigger>
          <TabsTrigger value="gaps" className="gap-2">
            <TrendingUp className="w-4 h-4" />
            Analyse gaps
          </TabsTrigger>
          <TabsTrigger value="needs" className="gap-2">
            <BookOpen className="w-4 h-4" />
            Besoins
          </TabsTrigger>
          <TabsTrigger value="ai-recommender" className="gap-2">
            <Sparkles className="w-4 h-4" />
            Recommandations IA
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trainings" className="mt-6">
          {trainings.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <GraduationCap className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune formation planifiée</p>
                <p className="text-sm">Commencez par créer une nouvelle formation</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {trainings.map((training) => (
                <div key={training.id}>
                  <TrainingCard training={training} />
                  <div className="flex gap-2 mt-2">
                    {training.status === 'draft' && (
                      <Button
                        size="sm"
                        onClick={() => updateStatusMutation.mutate({ 
                          id: training.id, 
                          status: 'published' 
                        })}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        Publier
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="enrollments" className="mt-6">
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              {enrollments.length === 0 ? (
                <div className="text-center py-12 text-slate-500">
                  <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">Aucune inscription</p>
                  <p className="text-sm">Les inscriptions apparaîtront ici</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {enrollments.map((enrollment) => (
                    <div
                      key={enrollment.id}
                      className="p-4 border border-slate-200 rounded-lg hover:border-blue-300 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-slate-900">{enrollment.training_title}</h4>
                          <p className="text-sm text-slate-600 mt-1">
                            {enrollment.employee_name} • {enrollment.enrollment_type}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className={`px-2 py-1 rounded text-xs font-medium ${
                              enrollment.status === 'completed' ? 'bg-green-100 text-green-800' :
                              enrollment.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {enrollment.status}
                            </span>
                            {enrollment.progress_percentage > 0 && (
                              <span className="text-xs text-slate-600">
                                {enrollment.progress_percentage}% complété
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="matrix" className="mt-6">
          <SkillMatrix skills={skills} employees={employees} />
        </TabsContent>

        <TabsContent value="skills" className="mt-6">
          <SkillCatalog skills={skills} employees={employees} />
        </TabsContent>

        <TabsContent value="employees" className="mt-6">
          <EmployeeSkillManagement 
            employees={employees} 
            skills={skills}
            trainings={trainings}
            AIComponent={AITrainingRecommender}
          />
        </TabsContent>

        <TabsContent value="certificates" className="mt-6">
          <div className="mb-4">
            <Button 
              onClick={() => setShowCertificateUpload(true)} 
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Award className="w-4 h-4 mr-2" />
              Télécharger un certificat
            </Button>
          </div>
          <CertificatesList />
        </TabsContent>

        <TabsContent value="gaps" className="mt-6">
          <SkillGapAnalysis />
        </TabsContent>

        <TabsContent value="needs" className="mt-6">
          <TrainingNeedsReport />
        </TabsContent>

        <TabsContent value="ai-recommender" className="mt-6">
          <AITrainingGapRecommender />
        </TabsContent>
      </Tabs>

      {showForm && (
        <TrainingForm
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}

      {showCertificateUpload && (
        <TrainingCertificateUpload
          employee={selectedEmployee}
          training={selectedTraining}
          onClose={() => {
            setShowCertificateUpload(false);
            setSelectedEmployee(null);
            setSelectedTraining(null);
          }}
          onSuccess={() => {
            queryClient.invalidateQueries(['certificates']);
          }}
        />
      )}
    </div>
  );
}