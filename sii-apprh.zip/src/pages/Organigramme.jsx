import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { 
  Users, 
  Search, 
  ZoomIn, 
  ZoomOut, 
  Download, 
  Maximize2,
  User,
  Mail,
  Phone,
  Building2,
  ChevronDown,
  ChevronRight,
  Edit,
  Save,
  X,
  RefreshCw,
  Move,
  AlertCircle,
  Trash2,
  AlertTriangle,
  Sparkles
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import AIOrganigrammeBuilder from "../components/ai/AIOrganigrammeBuilder";

export default function Organigramme() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [zoom, setZoom] = useState(100);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [expandedNodes, setExpandedNodes] = useState({});
  const [editMode, setEditMode] = useState(false);
  const [dragMode, setDragMode] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [employeeToEdit, setEmployeeToEdit] = useState(null);
  const [employeeToDelete, setEmployeeToDelete] = useState(null);
  const [newManagerEmail, setNewManagerEmail] = useState("");
  const [deleteOption, setDeleteOption] = useState("no-manager");
  const [reassignManagerEmail, setReassignManagerEmail] = useState("");
  const [showAIBuilder, setShowAIBuilder] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const updateManagerMutation = useMutation({
    mutationFn: ({ employeeId, managerEmail, managerName }) => 
      base44.entities.Employee.update(employeeId, { 
        manager_email: managerEmail,
        manager_name: managerName
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setShowEditDialog(false);
      setEmployeeToEdit(null);
      setNewManagerEmail("");
      toast({
        title: "Hiérarchie mise à jour",
        description: "Le changement de manager a été enregistré avec succès.",
        duration: 5000,
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour la hiérarchie.",
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  const deleteEmployeeMutation = useMutation({
    mutationFn: async ({ employeeId, subordinates, option, reassignTo }) => {
      if (subordinates.length > 0) {
        if (option === "reassign" && reassignTo) {
          const newManager = employees.find(e => e.email === reassignTo);
          await Promise.all(
            subordinates.map(sub => 
              base44.entities.Employee.update(sub.id, {
                manager_email: reassignTo,
                manager_name: newManager?.full_name || reassignTo
              })
            )
          );
        } else if (option === "no-manager") {
          await Promise.all(
            subordinates.map(sub => 
              base44.entities.Employee.update(sub.id, {
                manager_email: null,
                manager_name: null
              })
            )
          );
        }
      }

      await base44.entities.Employee.delete(employeeId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setShowDeleteDialog(false);
      setEmployeeToDelete(null);
      setReassignManagerEmail("");
      setDeleteOption("no-manager");
      toast({
        title: "Employé supprimé",
        description: "L'employé a été retiré de l'organigramme avec succès.",
        duration: 5000,
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de supprimer l'employé.",
        variant: "destructive",
        duration: 5000,
      });
    },
  });

  const handleApplyAIChanges = async (changes) => {
    try {
      toast({
        title: "Application en cours...",
        description: `Mise à jour de ${changes.length} employé(s)`,
        duration: 5000,
      });

      // Appliquer tous les changements
      await Promise.all(
        changes.map(change => {
          const employee = employees.find(e => e.email === change.employee_email);
          if (!employee) return Promise.resolve();

          return base44.entities.Employee.update(employee.id, {
            manager_email: change.suggested_manager_email,
            manager_name: change.suggested_manager_name
          });
        })
      );

      queryClient.invalidateQueries({ queryKey: ['employees'] });
      setShowAIBuilder(false);

      toast({
        title: "✅ Organigramme mis à jour",
        description: `${changes.length} changement(s) appliqué(s) avec succès`,
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur application changements IA:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'appliquer certains changements",
        variant: "destructive",
        duration: 5000,
      });
    }
  };

  // Construire la hiérarchie
  const buildHierarchy = () => {
    const byDepartment = {};
    
    employees.forEach(emp => {
      const dept = emp.department || 'Sans département';
      if (!byDepartment[dept]) {
        byDepartment[dept] = {
          name: dept,
          manager: null,
          members: [],
          teams: {}
        };
      }

      if (emp.manager_email) {
        if (!byDepartment[dept].teams[emp.manager_email]) {
          const manager = employees.find(e => e.email === emp.manager_email);
          byDepartment[dept].teams[emp.manager_email] = {
            manager: manager || { full_name: emp.manager_name || emp.manager_email, email: emp.manager_email },
            members: []
          };
        }
        byDepartment[dept].teams[emp.manager_email].members.push(emp);
      } else {
        if (!byDepartment[dept].manager) {
          byDepartment[dept].manager = emp;
        } else {
          byDepartment[dept].members.push(emp);
        }
      }
    });

    return byDepartment;
  };

  const hierarchy = buildHierarchy();

  const filteredHierarchy = Object.entries(hierarchy).filter(([deptName]) => {
    if (filterDepartment !== "all" && deptName !== filterDepartment) return false;
    return true;
  });

  const toggleNode = (nodeId) => {
    setExpandedNodes(prev => ({
      ...prev,
      [nodeId]: !prev[nodeId]
    }));
  };

  const handleExport = () => {
    window.print();
  };

  const handleEditManager = (employee) => {
    setEmployeeToEdit(employee);
    setNewManagerEmail(employee.manager_email || "");
    setShowEditDialog(true);
  };

  const handleDeleteEmployee = (employee) => {
    setEmployeeToDelete(employee);
    setDeleteOption("no-manager");
    setReassignManagerEmail("");
    setShowDeleteDialog(true);
  };

  const handleSaveManagerChange = () => {
    if (!employeeToEdit) return;

    const newManager = employees.find(e => e.email === newManagerEmail);
    
    if (newManagerEmail === employeeToEdit.email) {
      toast({
        title: "Erreur",
        description: "Un employé ne peut pas être son propre manager.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    if (newManager && newManager.manager_email === employeeToEdit.email) {
      toast({
        title: "Erreur",
        description: "Cette assignation créerait une boucle hiérarchique.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    updateManagerMutation.mutate({
      employeeId: employeeToEdit.id,
      managerEmail: newManagerEmail || null,
      managerName: newManager?.full_name || null
    });
  };

  const handleConfirmDelete = () => {
    if (!employeeToDelete) return;

    // Trouver les subordonnés
    const subordinates = employees.filter(e => e.manager_email === employeeToDelete.email);

    if (subordinates.length > 0 && deleteOption === "reassign" && !reassignManagerEmail) {
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner un manager pour réassigner les subordonnés.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    deleteEmployeeMutation.mutate({
      employeeId: employeeToDelete.id,
      subordinates,
      option: deleteOption,
      reassignTo: reassignManagerEmail
    });
  };

  // Gestion du drag and drop
  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const draggedEmployeeEmail = result.draggableId;
    const newManagerEmail = result.destination.droppableId;

    const draggedEmployee = employees.find(e => e.email === draggedEmployeeEmail);
    const newManager = employees.find(e => e.email === newManagerEmail);

    if (!draggedEmployee) return;

    if (draggedEmployeeEmail === newManagerEmail) {
      toast({
        title: "Opération impossible",
        description: "Un employé ne peut pas être son propre manager.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    if (newManager && newManager.manager_email === draggedEmployeeEmail) {
      toast({
        title: "Opération impossible",
        description: "Cette action créerait une boucle hiérarchique.",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    if (newManager && newManager.department !== draggedEmployee.department) {
      toast({
        title: "Attention",
        description: "L'employé et le manager sont dans des départements différents.",
        duration: 5000,
      });
    }

    updateManagerMutation.mutate({
      employeeId: draggedEmployee.id,
      managerEmail: newManagerEmail === "no-manager" ? null : newManagerEmail,
      managerName: newManager?.full_name || null
    });
  };

  const EmployeeCard = ({ employee, isManager = false, level = 0, isDragMode = false }) => {
    const hasTeam = Object.values(hierarchy).some(dept => 
      Object.values(dept.teams).some(team => team.manager?.email === employee.email)
    );

    const CardContent_Component = (
      <Card 
        className={`shadow-lg hover:shadow-xl transition-all cursor-pointer border-2 ${
          isManager ? 'border-blue-500 bg-gradient-to-br from-blue-50 to-white' : 'border-slate-200'
        } ${selectedEmployee?.id === employee.id ? 'ring-2 ring-blue-500' : ''} ${
          isDragMode ? 'cursor-move hover:border-green-500' : ''
        }`}
        onClick={() => !isDragMode && setSelectedEmployee(employee)}
      >
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {hasTeam && !isDragMode && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleNode(employee.email);
                }}
                className="mt-2"
              >
                {expandedNodes[employee.email] ? (
                  <ChevronDown className="w-4 h-4 text-slate-600" />
                ) : (
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                )}
              </button>
            )}
            
            {isDragMode && (
              <Move className="w-5 h-5 text-green-600 mt-2 flex-shrink-0" />
            )}
            
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-lg">
                {employee.full_name?.charAt(0) || 'E'}
              </span>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-bold text-slate-900 truncate">{employee.full_name}</h3>
                {isManager && (
                  <Badge className="bg-blue-600">Manager</Badge>
                )}
              </div>
              <p className="text-sm text-blue-600 font-medium truncate">{employee.position}</p>
              <p className="text-xs text-slate-500 truncate">{employee.department}</p>
              
              {!isDragMode && (
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-600">
                  <div className="flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    <span className="truncate">{employee.email}</span>
                  </div>
                  {employee.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      <span>{employee.phone}</span>
                    </div>
                  )}
                </div>
              )}

              {editMode && !isDragMode && (
                <div className="flex gap-2 mt-3">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleEditManager(employee);
                    }}
                    className="flex-1"
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Modifier
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteEmployee(employee);
                    }}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );

    return (
      <div 
        className={`relative ${level > 0 ? 'ml-8' : ''}`}
        style={{ marginLeft: level > 0 ? `${level * 2}rem` : 0 }}
      >
        {isDragMode ? (
          <Droppable droppableId={employee.email}>
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={`p-2 rounded-lg transition-colors ${
                  snapshot.isDraggingOver ? 'bg-green-100 border-2 border-green-500' : ''
                }`}
              >
                <Draggable draggableId={employee.email} index={0}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      className={snapshot.isDragging ? 'opacity-50' : ''}
                    >
                      {CardContent_Component}
                    </div>
                  )}
                </Draggable>
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        ) : (
          CardContent_Component
        )}

        {hasTeam && expandedNodes[employee.email] && !isDragMode && (
          <div className="mt-4 space-y-4">
            {Object.values(hierarchy).map(dept => 
              Object.entries(dept.teams)
                .filter(([managerEmail]) => managerEmail === employee.email)
                .map(([_, team]) => (
                  <div key={team.manager.email} className="space-y-3">
                    {team.members.map(member => (
                      <EmployeeCard 
                        key={member.id} 
                        employee={member} 
                        level={level + 1}
                        isDragMode={isDragMode}
                      />
                    ))}
                  </div>
                ))
            )}
          </div>
        )}
      </div>
    );
  };

  const totalEmployees = employees.length;
  const totalManagers = [...new Set(employees.map(e => e.manager_email).filter(Boolean))].length;
  const avgTeamSize = totalManagers > 0 ? Math.round(totalEmployees / totalManagers) : 0;

  const potentialManagers = employees.filter(e => 
    employeeToEdit ? e.id !== employeeToEdit.id : true
  );

  // Managers potentiels pour réassignation (exclure l'employé à supprimer)
  const potentialReassignManagers = employees.filter(e => 
    employeeToDelete ? e.id !== employeeToDelete.id : true
  );

  // Trouver les subordonnés de l'employé à supprimer
  const subordinatesOfEmployeeToDelete = employeeToDelete 
    ? employees.filter(e => e.manager_email === employeeToDelete.email)
    : [];

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Users className="w-8 h-8 text-blue-600" />
            Organigramme Interactif
          </h1>
          <p className="text-slate-600 mt-1">
            Visualisation de la structure organisationnelle
          </p>
        </div>
        <div className="flex gap-3 flex-wrap">
          <Button
            onClick={() => setShowAIBuilder(!showAIBuilder)}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            IA - Générer la hiérarchie
          </Button>
          <Button 
            variant={dragMode ? "default" : "outline"}
            onClick={() => {
              setDragMode(!dragMode);
              setEditMode(false);
              setShowAIBuilder(false);
            }}
            className={dragMode ? "bg-green-600 hover:bg-green-700" : ""}
          >
            <Move className="w-4 h-4 mr-2" />
            {dragMode ? "Glisser-Déposer activé" : "Mode Glisser-Déposer"}
          </Button>
          <Button 
            variant={editMode ? "default" : "outline"}
            onClick={() => {
              setEditMode(!editMode);
              setDragMode(false);
              setShowAIBuilder(false);
            }}
            className={editMode ? "bg-orange-600 hover:bg-orange-700" : ""}
          >
            <Edit className="w-4 h-4 mr-2" />
            {editMode ? "Mode édition" : "Modifier"}
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </Button>
        </div>
      </div>

      {/* IA Builder */}
      {showAIBuilder && (
        <AIOrganigrammeBuilder 
          employees={employees} 
          onApplyChanges={handleApplyAIChanges}
          onClose={() => setShowAIBuilder(false)}
        />
      )}

      {dragMode && (
        <Card className="border-green-500 bg-green-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Move className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-semibold text-green-900">Mode Glisser-Déposer activé</p>
                <p className="text-sm text-green-700">
                  Glissez un employé sur un autre pour le définir comme son nouveau manager
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {editMode && !dragMode && (
        <Card className="border-orange-500 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Edit className="w-5 h-5 text-orange-600" />
              <div>
                <p className="font-semibold text-orange-900">Mode édition activé</p>
                <p className="text-sm text-orange-700">
                  Cliquez sur "Modifier" pour changer le manager ou sur l'icône poubelle pour supprimer un employé
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Total employés</p>
                <p className="text-3xl font-bold text-blue-900">{totalEmployees}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Managers</p>
                <p className="text-3xl font-bold text-purple-900">{totalManagers}</p>
              </div>
              <User className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Taille moyenne équipe</p>
                <p className="text-3xl font-bold text-green-900">{avgTeamSize}</p>
              </div>
              <Building2 className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters & Controls */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Département" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les départements</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setZoom(Math.min(150, zoom + 10))}
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setZoom(Math.max(50, zoom - 10))}
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon"
                onClick={() => setZoom(100)}
              >
                <Maximize2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Organigramme */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <div 
          className="overflow-auto bg-gradient-to-br from-slate-50 to-blue-50 p-8 rounded-lg shadow-inner"
          style={{ minHeight: '600px' }}
        >
          <div style={{ zoom: `${zoom}%` }} className="space-y-8">
            {filteredHierarchy.length === 0 ? (
              <Card className="border-none shadow-lg">
                <CardContent className="p-12 text-center text-slate-500">
                  <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">Aucun employé trouvé</p>
                  <p className="text-sm">Ajustez vos filtres de recherche</p>
                </CardContent>
              </Card>
            ) : (
              filteredHierarchy.map(([deptName, dept]) => (
                <div key={deptName} className="space-y-6">
                  <Card className="border-none shadow-xl bg-gradient-to-r from-slate-700 to-slate-800">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3">
                        <Building2 className="w-8 h-8 text-white" />
                        <div>
                          <h2 className="text-2xl font-bold text-white">{deptName}</h2>
                          <p className="text-slate-300 text-sm">
                            {dept.manager ? 
                              `Responsable: ${dept.manager.full_name}` : 
                              'Aucun responsable désigné'
                            }
                          </p>
                        </div>
                        <Badge variant="secondary" className="ml-auto">
                          {Object.values(dept.teams).reduce((sum, team) => sum + team.members.length, 0) + 
                           (dept.manager ? 1 : 0) + dept.members.length} employés
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>

                  {dept.manager && (
                    <div className="flex justify-center">
                      <div className="w-full max-w-md">
                        <EmployeeCard 
                          employee={dept.manager} 
                          isManager={true}
                          isDragMode={dragMode}
                        />
                      </div>
                    </div>
                  )}

                  <div className="space-y-8">
                    {Object.entries(dept.teams)
                      .filter(([managerEmail]) => managerEmail !== dept.manager?.email)
                      .map(([managerEmail, team]) => (
                      <div key={managerEmail}>
                        <div className="flex justify-center mb-4">
                          <div className="w-full max-w-md">
                            <EmployeeCard 
                              employee={team.manager} 
                              isManager={true}
                              isDragMode={dragMode}
                            />
                          </div>
                        </div>
                      </div>
                    ))}

                    {dept.members.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {dept.members.map(emp => (
                          <EmployeeCard 
                            key={emp.id} 
                            employee={emp}
                            isDragMode={dragMode}
                          />
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </DragDropContext>

      {/* Dialog de modification du manager */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Changer le manager de {employeeToEdit?.full_name}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            <div className="p-4 bg-slate-50 rounded-lg">
              <p className="text-sm text-slate-600 mb-1">Employé</p>
              <p className="font-semibold">{employeeToEdit?.full_name}</p>
              <p className="text-sm text-slate-600">{employeeToEdit?.position}</p>
            </div>

            <div className="space-y-2">
              <Label>Nouveau manager</Label>
              <Select value={newManagerEmail} onValueChange={setNewManagerEmail}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un manager" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  <SelectItem value={null}>Aucun manager (top niveau)</SelectItem>
                  {potentialManagers.map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position} ({emp.department})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {employeeToEdit?.manager_email && (
              <div className="p-3 bg-blue-50 rounded border border-blue-200">
                <p className="text-xs text-blue-700 mb-1">Manager actuel</p>
                <p className="text-sm font-medium text-blue-900">
                  {employeeToEdit.manager_name || employeeToEdit.manager_email}
                </p>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => {
                setShowEditDialog(false);
                setEmployeeToEdit(null);
                setNewManagerEmail("");
              }}
            >
              <X className="w-4 h-4 mr-2" />
              Annuler
            </Button>
            <Button
              onClick={handleSaveManagerChange}
              disabled={updateManagerMutation.isPending}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {updateManagerMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Enregistrement...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Enregistrer
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog de suppression */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              Supprimer {employeeToDelete?.full_name}
            </DialogTitle>
            <DialogDescription>
              Cette action est irréversible. L'employé sera définitivement retiré de l'organigramme.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 pt-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <p className="font-semibold text-red-900">{employeeToDelete?.full_name}</p>
              <p className="text-sm text-red-700">{employeeToDelete?.position}</p>
              <p className="text-xs text-red-600">{employeeToDelete?.department}</p>
            </div>

            {subordinatesOfEmployeeToDelete.length > 0 && (
              <div className="space-y-3">
                <div className="p-3 bg-orange-50 rounded border border-orange-200">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-4 h-4 text-orange-600" />
                    <p className="font-semibold text-orange-900">
                      {subordinatesOfEmployeeToDelete.length} employé(s) dépendent de ce manager
                    </p>
                  </div>
                  <div className="text-xs text-orange-700 space-y-1">
                    {subordinatesOfEmployeeToDelete.map(sub => (
                      <p key={sub.id}>• {sub.full_name} ({sub.position})</p>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Que faire avec les subordonnés ?</Label>
                  <RadioGroup value={deleteOption} onValueChange={setDeleteOption}>
                    <div className="flex items-start space-x-2 p-3 rounded-lg border hover:bg-slate-50">
                      <RadioGroupItem value="no-manager" id="no-manager" />
                      <Label htmlFor="no-manager" className="cursor-pointer flex-1">
                        <p className="font-medium">Les laisser sans manager</p>
                        <p className="text-xs text-slate-600">Ils apparaîtront au niveau supérieur</p>
                      </Label>
                    </div>
                    <div className="flex items-start space-x-2 p-3 rounded-lg border hover:bg-slate-50">
                      <RadioGroupItem value="reassign" id="reassign" />
                      <Label htmlFor="reassign" className="cursor-pointer flex-1">
                        <p className="font-medium">Les réassigner à un autre manager</p>
                        <p className="text-xs text-slate-600">Sélectionnez un nouveau manager ci-dessous</p>
                      </Label>
                    </div>
                  </RadioGroup>

                  {deleteOption === "reassign" && (
                    <div className="space-y-2 ml-6">
                      <Label>Nouveau manager</Label>
                      <Select value={reassignManagerEmail} onValueChange={setReassignManagerEmail}>
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner un manager" />
                        </SelectTrigger>
                        <SelectContent className="max-h-[200px]">
                          {potentialReassignManagers.map(emp => (
                            <SelectItem key={emp.id} value={emp.email}>
                              {emp.full_name} - {emp.position}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setEmployeeToDelete(null);
                setReassignManagerEmail("");
                setDeleteOption("no-manager");
              }}
            >
              <X className="w-4 h-4 mr-2" />
              Annuler
            </Button>
            <Button
              onClick={handleConfirmDelete}
              disabled={deleteEmployeeMutation.isPending}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteEmployeeMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Suppression...
                </>
              ) : (
                <>
                  <Trash2 className="w-4 h-4 mr-2" />
                  Supprimer définitivement
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Détails employé sélectionné */}
      {selectedEmployee && !dragMode && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedEmployee(null)}
        >
          <Card 
            className="max-w-2xl w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader className="border-b bg-gradient-to-r from-blue-500 to-blue-600">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-2xl">
                    {selectedEmployee.full_name?.charAt(0) || 'E'}
                  </span>
                </div>
                <div>
                  <CardTitle className="text-white text-2xl">{selectedEmployee.full_name}</CardTitle>
                  <p className="text-blue-100">{selectedEmployee.position}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Email</p>
                  <p className="font-medium">{selectedEmployee.email}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Téléphone</p>
                  <p className="font-medium">{selectedEmployee.phone || 'Non renseigné'}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Département</p>
                  <p className="font-medium">{selectedEmployee.department}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Type d'emploi</p>
                  <p className="font-medium capitalize">{selectedEmployee.employment_type?.replace('_', ' ')}</p>
                </div>
                {selectedEmployee.manager_name && (
                  <div className="col-span-2">
                    <p className="text-sm text-slate-600 mb-1">Manager</p>
                    <p className="font-medium">{selectedEmployee.manager_name}</p>
                  </div>
                )}
              </div>
              <div className="flex gap-3">
                {editMode && (
                  <>
                    <Button 
                      onClick={() => {
                        setSelectedEmployee(null);
                        handleEditManager(selectedEmployee);
                      }}
                      className="flex-1 bg-orange-600 hover:bg-orange-700"
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      Changer de manager
                    </Button>
                    <Button 
                      onClick={() => {
                        setSelectedEmployee(null);
                        handleDeleteEmployee(selectedEmployee);
                      }}
                      variant="outline"
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Supprimer
                    </Button>
                  </>
                )}
                <Button onClick={() => setSelectedEmployee(null)} variant="outline" className="flex-1">
                  Fermer
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}