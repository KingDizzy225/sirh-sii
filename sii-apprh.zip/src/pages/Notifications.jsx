import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Bell,
  Calendar,
  FileText,
  Award,
  MessageSquare,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  Trash2,
  CheckCheck,
  Filter,
  Archive
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useNavigate } from "react-router-dom";

const NOTIFICATION_ICONS = {
  leave_request: Calendar,
  leave_approved: CheckCircle,
  leave_rejected: XCircle,
  performance_review: Award,
  document_uploaded: FileText,
  document_shared: FileText,
  training_assigned: Award,
  message_received: MessageSquare,
  mention: MessageSquare,
  task_assigned: CheckCircle,
  deadline_reminder: Clock,
  system: AlertCircle,
};

const NOTIFICATION_COLORS = {
  leave_request: "text-blue-600 bg-blue-50",
  leave_approved: "text-green-600 bg-green-50",
  leave_rejected: "text-red-600 bg-red-50",
  performance_review: "text-purple-600 bg-purple-50",
  document_uploaded: "text-indigo-600 bg-indigo-50",
  document_shared: "text-indigo-600 bg-indigo-50",
  training_assigned: "text-orange-600 bg-orange-50",
  message_received: "text-blue-600 bg-blue-50",
  mention: "text-pink-600 bg-pink-50",
  task_assigned: "text-green-600 bg-green-50",
  deadline_reminder: "text-yellow-600 bg-yellow-50",
  system: "text-slate-600 bg-slate-50",
};

const PRIORITY_COLORS = {
  urgent: "bg-red-100 text-red-800 border-red-300",
  high: "bg-orange-100 text-orange-800 border-orange-300",
  medium: "bg-blue-100 text-blue-800 border-blue-300",
  low: "bg-slate-100 text-slate-800 border-slate-300",
};

export default function Notifications() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const [filterPriority, setFilterPriority] = useState("all");

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter({ 
      user_email: user?.email 
    }),
    enabled: !!user,
  });

  const markAsReadMutation = useMutation({
    mutationFn: ({ id }) => base44.entities.Notification.update(id, {
      is_read: true,
      read_at: new Date().toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const deleteAllReadMutation = useMutation({
    mutationFn: async () => {
      const readNotifs = notifications.filter(n => n.is_read);
      await Promise.all(readNotifs.map(n => base44.entities.Notification.delete(n.id)));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifs = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifs.map(n => 
          base44.entities.Notification.update(n.id, {
            is_read: true,
            read_at: new Date().toISOString(),
          })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate({ id: notification.id });
    }
    
    if (notification.action_url) {
      navigate(notification.action_url);
    }
  };

  // Filtrage
  const filteredNotifications = notifications
    .filter(n => {
      if (activeTab === 'unread' && n.is_read) return false;
      if (activeTab === 'read' && !n.is_read) return false;
      if (filterPriority !== 'all' && n.priority !== filterPriority) return false;
      return true;
    })
    .sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const readCount = notifications.filter(n => n.is_read).length;

  // Stats par type
  const notifByType = notifications.reduce((acc, n) => {
    acc[n.notification_type] = (acc[n.notification_type] || 0) + 1;
    return acc;
  }, {});

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 md:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Bell className="w-8 h-8 text-blue-600" />
              Centre de Notifications
            </h1>
            <p className="text-slate-600 mt-1">
              Gérez toutes vos notifications et alertes
            </p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <Button
              variant="outline"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={unreadCount === 0 || markAllAsReadMutation.isPending}
            >
              <CheckCheck className="w-4 h-4 mr-2" />
              Tout marquer comme lu
            </Button>
            <Button
              variant="outline"
              onClick={() => deleteAllReadMutation.mutate()}
              disabled={readCount === 0 || deleteAllReadMutation.isPending}
              className="text-red-600 hover:text-red-700"
            >
              <Archive className="w-4 h-4 mr-2" />
              Archiver les lues
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-700 mb-1">Non lues</p>
                  <p className="text-3xl font-bold text-blue-900">{unreadCount}</p>
                </div>
                <Bell className="w-10 h-10 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Lues</p>
                  <p className="text-3xl font-bold text-green-900">{readCount}</p>
                </div>
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-700 mb-1">Total</p>
                  <p className="text-3xl font-bold text-purple-900">{notifications.length}</p>
                </div>
                <Archive className="w-10 h-10 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="border-none shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              <Filter className="w-5 h-5 text-slate-500" />
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value)}
                className="px-3 py-2 rounded-md border border-slate-200 text-sm"
              >
                <option value="all">Toutes priorités</option>
                <option value="urgent">🔴 Urgent</option>
                <option value="high">🟠 Haute</option>
                <option value="medium">🔵 Moyenne</option>
                <option value="low">⚪ Faible</option>
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Notifications Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-white shadow-md">
            <TabsTrigger value="all">
              Toutes ({notifications.length})
            </TabsTrigger>
            <TabsTrigger value="unread">
              Non lues ({unreadCount})
            </TabsTrigger>
            <TabsTrigger value="read">
              Lues ({readCount})
            </TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {isLoading ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-slate-600">Chargement des notifications...</p>
              </div>
            ) : filteredNotifications.length === 0 ? (
              <Card className="border-none shadow-lg">
                <CardContent className="p-12 text-center text-slate-500">
                  <Bell className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">Aucune notification</p>
                  <p className="text-sm">
                    {activeTab === 'unread' ? 'Toutes vos notifications ont été lues' : 
                     activeTab === 'read' ? 'Aucune notification lue' :
                     'Vous n\'avez aucune notification pour le moment'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {filteredNotifications.map((notification) => {
                  const Icon = NOTIFICATION_ICONS[notification.notification_type] || Bell;
                  const colorClass = NOTIFICATION_COLORS[notification.notification_type] || "text-slate-600 bg-slate-50";
                  
                  return (
                    <Card
                      key={notification.id}
                      className={`border-2 hover:border-blue-300 transition-all cursor-pointer group ${
                        !notification.is_read ? 'border-blue-200 bg-blue-50/30' : 'border-slate-200'
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                            <Icon className="w-6 h-6" />
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h3 className={`font-semibold ${!notification.is_read ? 'text-slate-900' : 'text-slate-600'}`}>
                                  {notification.title}
                                </h3>
                                {!notification.is_read && (
                                  <div className="w-2 h-2 bg-blue-600 rounded-full" />
                                )}
                              </div>
                              <Badge className={`${PRIORITY_COLORS[notification.priority]} border`}>
                                {notification.priority}
                              </Badge>
                            </div>
                            
                            <p className="text-sm text-slate-700 mb-3">
                              {notification.message}
                            </p>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3 text-xs text-slate-500">
                                <span>
                                  {format(new Date(notification.created_date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                                </span>
                                {notification.sender_name && (
                                  <>
                                    <span>•</span>
                                    <span>De: {notification.sender_name}</span>
                                  </>
                                )}
                              </div>
                              
                              {notification.action_label && (
                                <span className="text-sm text-blue-600 font-medium flex items-center gap-1">
                                  {notification.action_label}
                                  <span>→</span>
                                </span>
                              )}
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteMutation.mutate(notification.id);
                            }}
                            className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-red-50 rounded-lg"
                          >
                            <Trash2 className="w-5 h-5 text-red-500" />
                          </button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}