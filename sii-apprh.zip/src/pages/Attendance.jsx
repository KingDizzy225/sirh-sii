import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar as CalendarIcon, Plus, Download } from "lucide-react";
import { format, startOfMonth, endOfMonth } from "date-fns";
import AttendanceCalendar from "../components/attendance/AttendanceCalendar";
import AttendanceForm from "../components/attendance/AttendanceForm";
import AttendanceStats from "../components/attendance/AttendanceStats";

export default function Attendance() {
  const [showForm, setShowForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());

  const queryClient = useQueryClient();

  const { data: attendance = [], isLoading } = useQuery({
    queryKey: ['attendance'],
    queryFn: () => base44.entities.Attendance.list('-date'),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Attendance.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['attendance'] });
      setShowForm(false);
    },
  });

  const today = format(new Date(), 'yyyy-MM-dd');
  const todayAttendance = attendance.filter(a => a.date === today);

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Attendance Tracking</h1>
          <p className="text-slate-600 mt-1">
            {todayAttendance.length} of {employees.length} marked today
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            className="shadow-md"
          >
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button
            onClick={() => setShowForm(true)}
            className="bg-blue-600 hover:bg-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Mark Attendance
          </Button>
        </div>
      </div>

      {/* Stats */}
      <AttendanceStats attendance={attendance} employees={employees} />

      {/* Calendar View */}
      <Card className="shadow-lg border-none">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="w-5 h-5" />
            Attendance Calendar
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <AttendanceCalendar 
            attendance={attendance}
            selectedDate={selectedDate}
            onDateSelect={setSelectedDate}
          />
        </CardContent>
      </Card>

      {/* Attendance Form */}
      {showForm && (
        <AttendanceForm
          employees={employees}
          existingAttendance={todayAttendance}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}
    </div>
  );
}