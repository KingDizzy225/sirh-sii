import { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  Send, 
  Plus, 
  Search, 
  Users, 
  Hash,
  X,
  Paperclip,
  Smile,
  MoreVertical
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function Chat() {
  const [user, setUser] = useState(null);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [showNewChannel, setShowNewChannel] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const messagesEndRef = useRef(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  // Auto-refresh messages toutes les 3 secondes
  const { data: channels = [] } = useQuery({
    queryKey: ['chatChannels', user?.email],
    queryFn: () => base44.entities.ChatChannel.filter({ 
      members: user?.email,
      is_active: true 
    }),
    enabled: !!user,
    refetchInterval: 5000, // Rafraîchir toutes les 5 secondes
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['chatMessages', selectedChannel?.id],
    queryFn: () => base44.entities.ChatMessage.filter({ 
      channel_id: selectedChannel?.id,
      is_deleted: false
    }),
    enabled: !!selectedChannel,
    refetchInterval: 3000, // Rafraîchir toutes les 3 secondes
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (messageData) => {
      const msg = await base44.entities.ChatMessage.create(messageData);
      
      // Mettre à jour le canal avec le dernier message
      await base44.entities.ChatChannel.update(selectedChannel.id, {
        last_message: messageData.message,
        last_message_date: new Date().toISOString(),
        last_message_by: user.full_name || user.email,
      });

      return msg;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chatMessages'] });
      queryClient.invalidateQueries({ queryKey: ['chatChannels'] });
      setNewMessage("");
    },
  });

  const createChannelMutation = useMutation({
    mutationFn: (data) => base44.entities.ChatChannel.create(data),
    onSuccess: (newChannel) => {
      queryClient.invalidateQueries({ queryKey: ['chatChannels'] });
      setShowNewChannel(false);
      setSelectedChannel(newChannel);
    },
  });

  // Scroll vers le bas quand les messages changent
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedChannel) return;

    sendMessageMutation.mutate({
      channel_id: selectedChannel.id,
      sender_email: user.email,
      sender_name: user.full_name || user.email,
      message: newMessage,
      message_type: "text",
      read_by: [user.email],
    });
  };

  const filteredChannels = channels.filter(ch =>
    ch.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ch.member_names?.some(name => name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const directChannels = filteredChannels.filter(ch => ch.channel_type === 'direct');
  const groupChannels = filteredChannels.filter(ch => ch.channel_type !== 'direct');

  return (
    <div className="h-screen flex flex-col bg-slate-50">
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Liste des canaux */}
        <div className="w-80 bg-white border-r border-slate-200 flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <MessageSquare className="w-6 h-6 text-blue-600" />
                Messages
              </h1>
              <Button
                size="sm"
                onClick={() => setShowNewChannel(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Rechercher..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 text-sm"
              />
            </div>
          </div>

          {/* Liste des canaux */}
          <div className="flex-1 overflow-y-auto">
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="w-full rounded-none border-b">
                <TabsTrigger value="all" className="flex-1">Tous</TabsTrigger>
                <TabsTrigger value="direct" className="flex-1">Directs</TabsTrigger>
                <TabsTrigger value="groups" className="flex-1">Groupes</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-0">
                <ChannelList
                  channels={filteredChannels}
                  selectedChannel={selectedChannel}
                  onSelectChannel={setSelectedChannel}
                  currentUser={user}
                />
              </TabsContent>

              <TabsContent value="direct" className="mt-0">
                <ChannelList
                  channels={directChannels}
                  selectedChannel={selectedChannel}
                  onSelectChannel={setSelectedChannel}
                  currentUser={user}
                />
              </TabsContent>

              <TabsContent value="groups" className="mt-0">
                <ChannelList
                  channels={groupChannels}
                  selectedChannel={selectedChannel}
                  onSelectChannel={setSelectedChannel}
                  currentUser={user}
                />
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Zone de chat */}
        <div className="flex-1 flex flex-col">
          {selectedChannel ? (
            <>
              {/* Header du chat */}
              <div className="bg-white border-b border-slate-200 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                        {getChannelInitials(selectedChannel, user)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h2 className="font-semibold text-slate-900">
                        {getChannelName(selectedChannel, user)}
                      </h2>
                      <p className="text-xs text-slate-500">
                        {selectedChannel.members?.length} membre(s)
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => (
                  <MessageBubble
                    key={message.id}
                    message={message}
                    isOwn={message.sender_email === user?.email}
                  />
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Input message */}
              <div className="bg-white border-t border-slate-200 p-4">
                <div className="flex items-end gap-2">
                  <Button variant="ghost" size="sm" className="mb-2">
                    <Paperclip className="w-5 h-5 text-slate-400" />
                  </Button>
                  <Textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleSendMessage();
                      }
                    }}
                    placeholder="Tapez votre message..."
                    rows={2}
                    className="flex-1 resize-none"
                  />
                  <Button variant="ghost" size="sm" className="mb-2">
                    <Smile className="w-5 h-5 text-slate-400" />
                  </Button>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim() || sendMessageMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700 mb-2"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-500">
              <div className="text-center">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium">Sélectionnez une conversation</p>
                <p className="text-sm">Ou créez une nouvelle conversation</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal nouveau canal */}
      {showNewChannel && (
        <NewChannelDialog
          employees={employees}
          currentUser={user}
          onSubmit={(data) => createChannelMutation.mutate(data)}
          onCancel={() => setShowNewChannel(false)}
          isSubmitting={createChannelMutation.isPending}
        />
      )}
    </div>
  );
}

// Composant liste de canaux
function ChannelList({ channels, selectedChannel, onSelectChannel, currentUser }) {
  if (channels.length === 0) {
    return (
      <div className="p-8 text-center text-slate-500">
        <p className="text-sm">Aucune conversation</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-slate-100">
      {channels.map((channel) => (
        <button
          key={channel.id}
          onClick={() => onSelectChannel(channel)}
          className={`w-full p-3 hover:bg-slate-50 transition-colors text-left ${
            selectedChannel?.id === channel.id ? 'bg-blue-50' : ''
          }`}
        >
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-gradient-to-br from-blue-500 to-blue-600 text-white text-sm">
                {getChannelInitials(channel, currentUser)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <p className="font-medium text-slate-900 truncate text-sm">
                  {getChannelName(channel, currentUser)}
                </p>
                {channel.last_message_date && (
                  <span className="text-xs text-slate-500">
                    {format(new Date(channel.last_message_date), 'HH:mm')}
                  </span>
                )}
              </div>
              {channel.last_message && (
                <p className="text-xs text-slate-500 truncate">
                  {channel.last_message}
                </p>
              )}
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}

// Composant bulle de message
function MessageBubble({ message, isOwn }) {
  return (
    <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
      <div className={`max-w-md ${isOwn ? 'order-2' : 'order-1'}`}>
        {!isOwn && (
          <p className="text-xs text-slate-600 mb-1 ml-2">{message.sender_name}</p>
        )}
        <div
          className={`rounded-2xl px-4 py-2 ${
            isOwn
              ? 'bg-blue-600 text-white'
              : 'bg-white border border-slate-200 text-slate-900'
          }`}
        >
          <p className="text-sm whitespace-pre-wrap break-words">{message.message}</p>
          <p className={`text-xs mt-1 ${isOwn ? 'text-blue-100' : 'text-slate-400'}`}>
            {format(new Date(message.created_date), 'HH:mm', { locale: fr })}
          </p>
        </div>
      </div>
    </div>
  );
}

// Dialog nouveau canal
function NewChannelDialog({ employees, currentUser, onSubmit, onCancel, isSubmitting }) {
  const [channelType, setChannelType] = useState("direct");
  const [selectedMembers, setSelectedMembers] = useState([]);
  const [channelName, setChannelName] = useState("");
  const [description, setDescription] = useState("");

  const handleSubmit = () => {
    const memberEmails = [currentUser.email, ...selectedMembers];
    const memberNames = memberEmails.map(email => {
      if (email === currentUser.email) return currentUser.full_name || currentUser.email;
      const emp = employees.find(e => e.email === email);
      return emp?.full_name || email;
    });

    onSubmit({
      name: channelName || memberNames.filter(n => n !== (currentUser.full_name || currentUser.email)).join(', '),
      channel_type: channelType,
      description,
      members: memberEmails,
      member_names: memberNames,
      admin_emails: [currentUser.email],
      created_by: currentUser.email,
      created_by_name: currentUser.full_name || currentUser.email,
    });
  };

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Nouvelle conversation</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label>Type de conversation</Label>
            <Select value={channelType} onValueChange={setChannelType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="direct">Message direct</SelectItem>
                <SelectItem value="group">Groupe</SelectItem>
                <SelectItem value="department">Département</SelectItem>
                <SelectItem value="project">Projet</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {channelType !== 'direct' && (
            <>
              <div>
                <Label>Nom du canal</Label>
                <Input
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  placeholder="Ex: Équipe Marketing"
                />
              </div>

              <div>
                <Label>Description</Label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Description du canal..."
                  rows={3}
                />
              </div>
            </>
          )}

          <div>
            <Label>Membres ({selectedMembers.length} sélectionné(s))</Label>
            <div className="max-h-48 overflow-y-auto border rounded-lg p-2 space-y-2 mt-2">
              {employees
                .filter(emp => emp.email !== currentUser?.email)
                .map((emp) => (
                  <div key={emp.id} className="flex items-center gap-2">
                    <Checkbox
                      checked={selectedMembers.includes(emp.email)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          if (channelType === 'direct' && selectedMembers.length >= 1) {
                            return; // Limite à 1 membre pour direct
                          }
                          setSelectedMembers([...selectedMembers, emp.email]);
                        } else {
                          setSelectedMembers(selectedMembers.filter(e => e !== emp.email));
                        }
                      }}
                    />
                    <label className="text-sm cursor-pointer">
                      {emp.full_name} - {emp.position}
                    </label>
                  </div>
                ))}
            </div>
            {channelType === 'direct' && (
              <p className="text-xs text-slate-500 mt-1">
                Sélectionnez 1 personne pour un message direct
              </p>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={
                isSubmitting ||
                selectedMembers.length === 0 ||
                (channelType === 'direct' && selectedMembers.length !== 1)
              }
            >
              Créer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Utilitaires
function getChannelName(channel, currentUser) {
  if (channel.name) return channel.name;
  
  // Pour les conversations directes, afficher l'autre personne
  if (channel.channel_type === 'direct') {
    const otherMembers = channel.member_names?.filter(
      name => name !== (currentUser?.full_name || currentUser?.email)
    );
    return otherMembers?.[0] || 'Conversation';
  }
  
  return channel.member_names?.join(', ') || 'Canal';
}

function getChannelInitials(channel, currentUser) {
  const name = getChannelName(channel, currentUser);
  return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
}