import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Users, 
  Search, 
  Building2,
  User,
  Mail,
  Phone,
  ChevronDown,
  ChevronRight,
  Network,
  GitBranch,
  UserCog,
  Lightbulb,
  Shield,
  Info,
  Download,
  Eye,
  EyeOff
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function OrganigrammeStaffLine() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [expandedNodes, setExpandedNodes] = useState({});
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [viewMode, setViewMode] = useState("combined"); // combined, line-only, staff-only
  const [showStaffRelations, setShowStaffRelations] = useState(true);

  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  // Construire la hiérarchie Staff and Line
  const buildStaffLineHierarchy = () => {
    const byDepartment = {};
    
    employees.forEach(emp => {
      const dept = emp.department || 'Sans département';
      if (!byDepartment[dept]) {
        byDepartment[dept] = {
          name: dept,
          lineManager: null,
          lineEmployees: [],
          staffEmployees: [],
          teams: {}
        };
      }

      const isStaff = emp.position_type === 'staff';

      if (emp.manager_email) {
        // C'est un employé avec un manager (relation Line)
        if (!byDepartment[dept].teams[emp.manager_email]) {
          const manager = employees.find(e => e.email === emp.manager_email);
          byDepartment[dept].teams[emp.manager_email] = {
            manager: manager || { 
              full_name: emp.manager_name || emp.manager_email, 
              email: emp.manager_email,
              position_type: 'line'
            },
            lineMembers: [],
            staffMembers: []
          };
        }
        
        if (isStaff) {
          byDepartment[dept].teams[emp.manager_email].staffMembers.push(emp);
        } else {
          byDepartment[dept].teams[emp.manager_email].lineMembers.push(emp);
        }
      } else {
        // C'est un manager de département (top niveau)
        if (!byDepartment[dept].lineManager) {
          byDepartment[dept].lineManager = emp;
        } else {
          if (isStaff) {
            byDepartment[dept].staffEmployees.push(emp);
          } else {
            byDepartment[dept].lineEmployees.push(emp);
          }
        }
      }
    });

    return byDepartment;
  };

  const hierarchy = buildStaffLineHierarchy();

  const filteredHierarchy = Object.entries(hierarchy).filter(([deptName]) => {
    if (filterDepartment !== "all" && deptName !== filterDepartment) return false;
    return true;
  });

  const toggleNode = (nodeId) => {
    setExpandedNodes(prev => ({
      ...prev,
      [nodeId]: !prev[nodeId]
    }));
  };

  const EmployeeCard = ({ employee, isManager = false, isStaff = false, level = 0 }) => {
    const hasLineTeam = Object.values(hierarchy).some(dept => 
      Object.values(dept.teams).some(team => 
        team.manager?.email === employee.email && team.lineMembers.length > 0
      )
    );

    const hasStaffTeam = Object.values(hierarchy).some(dept => 
      Object.values(dept.teams).some(team => 
        team.manager?.email === employee.email && team.staffMembers.length > 0
      )
    );

    const hasTeam = hasLineTeam || hasStaffTeam;

    // Récupérer les relations staff (managers fonctionnels)
    const functionalManagers = employee.functional_managers || [];

    const borderStyle = isStaff 
      ? 'border-purple-400 border-dashed' 
      : 'border-blue-500 border-solid';

    const bgStyle = isStaff
      ? 'bg-gradient-to-br from-purple-50 to-white'
      : 'bg-gradient-to-br from-blue-50 to-white';

    return (
      <div 
        className={`relative ${level > 0 ? 'ml-8' : ''}`}
        style={{ marginLeft: level > 0 ? `${level * 2}rem` : 0 }}
      >
        <Card 
          className={`shadow-lg hover:shadow-xl transition-all cursor-pointer border-2 ${borderStyle} ${bgStyle} ${
            selectedEmployee?.id === employee.id ? 'ring-2 ring-orange-500' : ''
          }`}
          onClick={() => setSelectedEmployee(employee)}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {hasTeam && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleNode(employee.email);
                  }}
                  className="mt-2"
                >
                  {expandedNodes[employee.email] ? (
                    <ChevronDown className="w-4 h-4 text-slate-600" />
                  ) : (
                    <ChevronRight className="w-4 h-4 text-slate-600" />
                  )}
                </button>
              )}
              
              <div className={`w-12 h-12 rounded-full ${
                isStaff 
                  ? 'bg-gradient-to-br from-purple-500 to-purple-600' 
                  : 'bg-gradient-to-br from-blue-500 to-blue-600'
              } flex items-center justify-center flex-shrink-0`}>
                {isStaff ? (
                  <Lightbulb className="w-6 h-6 text-white" />
                ) : (
                  <span className="text-white font-bold text-lg">
                    {employee.full_name?.charAt(0) || 'E'}
                  </span>
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <h3 className="font-bold text-slate-900 truncate">{employee.full_name}</h3>
                  {isManager && (
                    <Badge className={isStaff ? 'bg-purple-600' : 'bg-blue-600'}>
                      {isStaff ? 'Staff Manager' : 'Line Manager'}
                    </Badge>
                  )}
                  {isStaff && !isManager && (
                    <Badge variant="outline" className="border-purple-500 text-purple-700">
                      <UserCog className="w-3 h-3 mr-1" />
                      Staff
                    </Badge>
                  )}
                  {!isStaff && !isManager && (
                    <Badge variant="outline" className="border-blue-500 text-blue-700">
                      <Shield className="w-3 h-3 mr-1" />
                      Line
                    </Badge>
                  )}
                </div>
                <p className="text-sm text-blue-600 font-medium truncate">{employee.position}</p>
                <p className="text-xs text-slate-500 truncate">{employee.department}</p>
                
                <div className="flex items-center gap-3 mt-2 text-xs text-slate-600">
                  <div className="flex items-center gap-1">
                    <Mail className="w-3 h-3" />
                    <span className="truncate">{employee.email}</span>
                  </div>
                  {employee.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      <span>{employee.phone}</span>
                    </div>
                  )}
                </div>

                {/* Relations fonctionnelles (Staff) */}
                {showStaffRelations && functionalManagers.length > 0 && (
                  <div className="mt-3 p-2 bg-purple-50 rounded border border-purple-200">
                    <p className="text-xs font-semibold text-purple-900 mb-1 flex items-center gap-1">
                      <GitBranch className="w-3 h-3" />
                      Relations Staff (Conseil/Expertise)
                    </p>
                    {functionalManagers.map((fm, idx) => (
                      <div key={idx} className="text-xs text-purple-700 flex items-center gap-1">
                        <span>→</span>
                        <span className="font-medium">{fm.name}</span>
                        <span className="text-purple-500">({fm.role || 'Conseiller'})</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Afficher les équipes Line et Staff */}
        {hasTeam && expandedNodes[employee.email] && (
          <div className="mt-4 space-y-6">
            {Object.values(hierarchy).map(dept => 
              Object.entries(dept.teams)
                .filter(([managerEmail]) => managerEmail === employee.email)
                .map(([_, team]) => (
                  <div key={team.manager.email} className="space-y-4">
                    {/* Équipe Line */}
                    {team.lineMembers.length > 0 && (viewMode === 'combined' || viewMode === 'line-only') && (
                      <div>
                        <div className="flex items-center gap-2 mb-3 ml-8">
                          <div className="h-px flex-1 bg-blue-300"></div>
                          <Badge className="bg-blue-600">
                            <Shield className="w-3 h-3 mr-1" />
                            Équipe Line ({team.lineMembers.length})
                          </Badge>
                          <div className="h-px flex-1 bg-blue-300"></div>
                        </div>
                        <div className="space-y-3">
                          {team.lineMembers.map(member => (
                            <EmployeeCard 
                              key={member.id} 
                              employee={member} 
                              isStaff={false}
                              level={level + 1}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Équipe Staff */}
                    {team.staffMembers.length > 0 && (viewMode === 'combined' || viewMode === 'staff-only') && (
                      <div>
                        <div className="flex items-center gap-2 mb-3 ml-8">
                          <div className="h-px flex-1 bg-purple-300"></div>
                          <Badge className="bg-purple-600">
                            <UserCog className="w-3 h-3 mr-1" />
                            Équipe Staff ({team.staffMembers.length})
                          </Badge>
                          <div className="h-px flex-1 bg-purple-300"></div>
                        </div>
                        <div className="space-y-3">
                          {team.staffMembers.map(member => (
                            <EmployeeCard 
                              key={member.id} 
                              employee={member} 
                              isStaff={true}
                              level={level + 1}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))
            )}
          </div>
        )}
      </div>
    );
  };

  const totalEmployees = employees.length;
  const lineEmployees = employees.filter(e => e.position_type !== 'staff').length;
  const staffEmployees = employees.filter(e => e.position_type === 'staff').length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Network className="w-8 h-8 text-blue-600" />
            Organigramme Staff and Line
          </h1>
          <p className="text-slate-600 mt-1">
            Structure organisationnelle hiérarchique (Line) et fonctionnelle (Staff)
          </p>
        </div>
        <Button variant="outline" onClick={() => window.print()}>
          <Download className="w-4 h-4 mr-2" />
          Exporter
        </Button>
      </div>

      {/* Légende */}
      <Card className="border-none shadow-lg bg-gradient-to-r from-blue-50 via-purple-50 to-blue-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Info className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-900">Comprendre le modèle Staff and Line</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-blue-100 rounded-lg border-2 border-blue-500">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-blue-700" />
                <h4 className="font-semibold text-blue-900">Relations LINE (Ligne hiérarchique)</h4>
              </div>
              <p className="text-sm text-blue-800">
                Relations d'<strong>autorité directe</strong> : pouvoir de décision, évaluation, 
                et gestion des ressources. Ce sont les relations de management hiérarchique classiques.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <div className="w-8 h-0.5 bg-blue-600"></div>
                <span className="text-xs text-blue-700">Ligne continue bleue</span>
              </div>
            </div>

            <div className="p-4 bg-purple-100 rounded-lg border-2 border-purple-500 border-dashed">
              <div className="flex items-center gap-2 mb-2">
                <UserCog className="w-5 h-5 text-purple-700" />
                <h4 className="font-semibold text-purple-900">Relations STAFF (État-major/Conseil)</h4>
              </div>
              <p className="text-sm text-purple-800">
                Relations de <strong>conseil et d'expertise</strong> : support fonctionnel, expertise technique, 
                recommandations sans autorité hiérarchique directe.
              </p>
              <div className="mt-2 flex items-center gap-2">
                <div className="w-8 h-0.5 border-t-2 border-purple-600 border-dashed"></div>
                <span className="text-xs text-purple-700">Ligne pointillée violette</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-slate-50 to-slate-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-700 mb-1">Total employés</p>
                <p className="text-3xl font-bold text-slate-900">{totalEmployees}</p>
              </div>
              <Users className="w-10 h-10 text-slate-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Postes Line</p>
                <p className="text-3xl font-bold text-blue-900">{lineEmployees}</p>
                <p className="text-xs text-blue-600">{Math.round((lineEmployees/totalEmployees)*100)}%</p>
              </div>
              <Shield className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Postes Staff</p>
                <p className="text-3xl font-bold text-purple-900">{staffEmployees}</p>
                <p className="text-xs text-purple-600">{Math.round((staffEmployees/totalEmployees)*100)}%</p>
              </div>
              <UserCog className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contrôles de vue */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Département" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les départements</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={viewMode} onValueChange={setViewMode}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Mode de vue" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="combined">
                  <div className="flex items-center gap-2">
                    <Network className="w-4 h-4" />
                    Vue combinée
                  </div>
                </SelectItem>
                <SelectItem value="line-only">
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Line uniquement
                  </div>
                </SelectItem>
                <SelectItem value="staff-only">
                  <div className="flex items-center gap-2">
                    <UserCog className="w-4 h-4" />
                    Staff uniquement
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant={showStaffRelations ? "default" : "outline"}
              onClick={() => setShowStaffRelations(!showStaffRelations)}
              className="gap-2"
            >
              {showStaffRelations ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              Relations Staff
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Organigramme */}
      <div 
        className="overflow-auto bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 p-8 rounded-lg shadow-inner"
        style={{ minHeight: '600px' }}
      >
        <div className="space-y-8">
          {filteredHierarchy.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun employé trouvé</p>
                <p className="text-sm">Ajustez vos filtres de recherche</p>
              </CardContent>
            </Card>
          ) : (
            filteredHierarchy.map(([deptName, dept]) => (
              <div key={deptName} className="space-y-6">
                <Card className="border-none shadow-xl bg-gradient-to-r from-slate-700 to-slate-800">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-8 h-8 text-white" />
                      <div>
                        <h2 className="text-2xl font-bold text-white">{deptName}</h2>
                        <p className="text-slate-300 text-sm">
                          {dept.lineManager ? 
                            `Responsable: ${dept.lineManager.full_name}` : 
                            'Aucun responsable désigné'
                          }
                        </p>
                      </div>
                      <div className="ml-auto flex gap-2">
                        <Badge variant="secondary" className="bg-blue-600 text-white">
                          <Shield className="w-3 h-3 mr-1" />
                          {dept.lineEmployees.length + Object.values(dept.teams).reduce((sum, team) => sum + team.lineMembers.length, 0) + (dept.lineManager && dept.lineManager.position_type !== 'staff' ? 1 : 0)} Line
                        </Badge>
                        <Badge variant="secondary" className="bg-purple-600 text-white">
                          <UserCog className="w-3 h-3 mr-1" />
                          {dept.staffEmployees.length + Object.values(dept.teams).reduce((sum, team) => sum + team.staffMembers.length, 0)} Staff
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {dept.lineManager && (
                  <div className="flex justify-center">
                    <div className="w-full max-w-md">
                      <EmployeeCard 
                        employee={dept.lineManager} 
                        isManager={true}
                        isStaff={dept.lineManager.position_type === 'staff'}
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-8">
                  {Object.entries(dept.teams)
                    .filter(([managerEmail]) => managerEmail !== dept.lineManager?.email)
                    .map(([managerEmail, team]) => (
                    <div key={managerEmail}>
                      <div className="flex justify-center mb-4">
                        <div className="w-full max-w-md">
                          <EmployeeCard 
                            employee={team.manager} 
                            isManager={true}
                            isStaff={team.manager.position_type === 'staff'}
                          />
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Employés sans manager */}
                  {(dept.lineEmployees.length > 0 || dept.staffEmployees.length > 0) && (
                    <div className="space-y-4">
                      {dept.lineEmployees.length > 0 && (viewMode === 'combined' || viewMode === 'line-only') && (
                        <div>
                          <Badge className="bg-blue-600 mb-3">
                            <Shield className="w-3 h-3 mr-1" />
                            Employés Line sans manager assigné
                          </Badge>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {dept.lineEmployees.map(emp => (
                              <EmployeeCard 
                                key={emp.id} 
                                employee={emp}
                                isStaff={false}
                              />
                            ))}
                          </div>
                        </div>
                      )}

                      {dept.staffEmployees.length > 0 && (viewMode === 'combined' || viewMode === 'staff-only') && (
                        <div>
                          <Badge className="bg-purple-600 mb-3">
                            <UserCog className="w-3 h-3 mr-1" />
                            Employés Staff sans manager assigné
                          </Badge>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {dept.staffEmployees.map(emp => (
                              <EmployeeCard 
                                key={emp.id} 
                                employee={emp}
                                isStaff={true}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Détails employé sélectionné */}
      {selectedEmployee && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedEmployee(null)}
        >
          <Card 
            className="max-w-2xl w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader className={`border-b ${
              selectedEmployee.position_type === 'staff'
                ? 'bg-gradient-to-r from-purple-500 to-purple-600'
                : 'bg-gradient-to-r from-blue-500 to-blue-600'
            }`}>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                  {selectedEmployee.position_type === 'staff' ? (
                    <Lightbulb className="w-8 h-8 text-purple-600" />
                  ) : (
                    <span className="text-blue-600 font-bold text-2xl">
                      {selectedEmployee.full_name?.charAt(0) || 'E'}
                    </span>
                  )}
                </div>
                <div>
                  <CardTitle className="text-white text-2xl">{selectedEmployee.full_name}</CardTitle>
                  <p className="text-white/90">{selectedEmployee.position}</p>
                  <Badge className={selectedEmployee.position_type === 'staff' ? 'bg-purple-800' : 'bg-blue-800'}>
                    {selectedEmployee.position_type === 'staff' ? 'Poste Staff' : 'Poste Line'}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-slate-600 mb-1">Email</p>
                  <p className="font-medium">{selectedEmployee.email}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Téléphone</p>
                  <p className="font-medium">{selectedEmployee.phone || 'Non renseigné'}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Département</p>
                  <p className="font-medium">{selectedEmployee.department}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-600 mb-1">Type de poste</p>
                  <Badge className={selectedEmployee.position_type === 'staff' ? 'bg-purple-600' : 'bg-blue-600'}>
                    {selectedEmployee.position_type === 'staff' ? 'Staff (Conseil/Expertise)' : 'Line (Hiérarchique)'}
                  </Badge>
                </div>
                {selectedEmployee.manager_name && (
                  <div className="col-span-2">
                    <p className="text-sm text-slate-600 mb-1">Manager hiérarchique (Line)</p>
                    <p className="font-medium">{selectedEmployee.manager_name}</p>
                  </div>
                )}
                {selectedEmployee.functional_managers && selectedEmployee.functional_managers.length > 0 && (
                  <div className="col-span-2">
                    <p className="text-sm text-slate-600 mb-2">Managers fonctionnels (Staff)</p>
                    <div className="space-y-2">
                      {selectedEmployee.functional_managers.map((fm, idx) => (
                        <div key={idx} className="p-2 bg-purple-50 rounded border border-purple-200">
                          <p className="font-medium text-purple-900">{fm.name}</p>
                          <p className="text-xs text-purple-700">{fm.role} • {fm.department}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              <Button onClick={() => setSelectedEmployee(null)} className="w-full">
                Fermer
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}