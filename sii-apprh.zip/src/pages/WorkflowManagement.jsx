import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Plus, CheckCircle, Clock, AlertCircle, PlayCircle, Users, Settings } from "lucide-react";
import { format } from "date-fns";

export default function WorkflowManagement() {
  const [activeTab, setActiveTab] = useState("active");
  const [user, setUser] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: workflows = [] } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.Workflow.list('-created_date'),
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['onboardingTasks'],
    queryFn: () => base44.entities.OnboardingTask.list('-created_date'),
  });

  const { data: templates = [] } = useQuery({
    queryKey: ['workflowTemplates'],
    queryFn: () => base44.entities.WorkflowTemplate.list(),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  // Initialiser les templates par défaut si aucun n'existe
  const initializeTemplatesMutation = useMutation({
    mutationFn: async () => {
      const onboardingTemplate = {
        name: "Onboarding Standard",
        workflow_type: "onboarding",
        description: "Processus d'intégration standard pour les nouveaux employés",
        is_default: true,
        is_active: true,
        tasks: [
          {
            title: "Créer le dossier employé",
            description: "Créer le dossier administratif complet de l'employé dans le système RH",
            assigned_to_department: "RH",
            priority: "critical",
            days_offset: -2,
            dependencies: []
          },
          {
            title: "Préparer le contrat de travail",
            description: "Rédiger et préparer le contrat de travail pour signature",
            assigned_to_department: "RH",
            priority: "high",
            days_offset: -2,
            dependencies: [0]
          },
          {
            title: "Commander l'équipement informatique",
            description: "Commander ordinateur, téléphone et accessoires nécessaires",
            assigned_to_department: "IT",
            priority: "high",
            days_offset: -5,
            dependencies: []
          },
          {
            title: "Créer les comptes utilisateur",
            description: "Créer email, accès réseau et comptes logiciels",
            assigned_to_department: "IT",
            priority: "critical",
            days_offset: -1,
            dependencies: [2]
          },
          {
            title: "Préparer l'espace de travail",
            description: "Installer le bureau, chaise et fournitures",
            assigned_to_department: "Logistique",
            priority: "medium",
            days_offset: -1,
            dependencies: []
          },
          {
            title: "Session d'accueil et orientation",
            description: "Présentation de l'entreprise, visite des locaux, remise du badge",
            assigned_to_department: "RH",
            priority: "critical",
            days_offset: 0,
            dependencies: [1, 4]
          },
          {
            title: "Formation aux outils internes",
            description: "Formation aux logiciels et processus de l'entreprise",
            assigned_to_department: "IT",
            priority: "high",
            days_offset: 0,
            dependencies: [3, 5]
          },
          {
            title: "Rencontre avec le manager",
            description: "Première réunion avec le manager direct pour définir les objectifs",
            assigned_to_department: "Manager",
            priority: "high",
            days_offset: 0,
            dependencies: [5]
          },
          {
            title: "Présentation à l'équipe",
            description: "Présentation aux collègues et membres de l'équipe",
            assigned_to_department: "Manager",
            priority: "medium",
            days_offset: 0,
            dependencies: [5]
          },
          {
            title: "Compléter les documents administratifs",
            description: "Remplir et signer tous les documents nécessaires (mutuelle, etc.)",
            assigned_to_department: "Employé",
            priority: "high",
            days_offset: 1,
            dependencies: [5]
          },
          {
            title: "Formation sécurité",
            description: "Formation obligatoire sur les règles de sécurité",
            assigned_to_department: "RH",
            priority: "high",
            days_offset: 2,
            dependencies: [5]
          },
          {
            title: "Point de suivi J+7",
            description: "Réunion de suivi après la première semaine",
            assigned_to_department: "Manager",
            priority: "medium",
            days_offset: 7,
            dependencies: [7]
          },
          {
            title: "Point de suivi J+30",
            description: "Évaluation après le premier mois",
            assigned_to_department: "RH",
            priority: "medium",
            days_offset: 30,
            dependencies: [11]
          }
        ]
      };

      const offboardingTemplate = {
        name: "Offboarding Standard",
        workflow_type: "offboarding",
        description: "Processus de départ standard pour les employés",
        is_default: true,
        is_active: true,
        tasks: [
          {
            title: "Notification de départ",
            description: "Informer les parties prenantes du départ de l'employé",
            assigned_to_department: "RH",
            priority: "critical",
            days_offset: -14,
            dependencies: []
          },
          {
            title: "Planifier la transition",
            description: "Organiser le transfert des responsabilités",
            assigned_to_department: "Manager",
            priority: "high",
            days_offset: -14,
            dependencies: [0]
          },
          {
            title: "Entretien de départ",
            description: "Réaliser l'entretien de sortie avec l'employé",
            assigned_to_department: "RH",
            priority: "high",
            days_offset: -7,
            dependencies: []
          },
          {
            title: "Récupération du matériel",
            description: "Récupérer ordinateur, téléphone, badge et clés",
            assigned_to_department: "IT",
            priority: "critical",
            days_offset: 0,
            dependencies: []
          },
          {
            title: "Désactivation des accès",
            description: "Désactiver email, accès réseau et comptes logiciels",
            assigned_to_department: "IT",
            priority: "critical",
            days_offset: 0,
            dependencies: [3]
          },
          {
            title: "Solde de tout compte",
            description: "Calculer et préparer le solde de tout compte",
            assigned_to_department: "RH",
            priority: "critical",
            days_offset: 0,
            dependencies: []
          },
          {
            title: "Certificat de travail",
            description: "Générer et remettre le certificat de travail",
            assigned_to_department: "RH",
            priority: "high",
            days_offset: 0,
            dependencies: []
          },
          {
            title: "Restitution des documents",
            description: "Récupérer tous les documents confidentiels",
            assigned_to_department: "Manager",
            priority: "high",
            days_offset: 0,
            dependencies: []
          },
          {
            title: "Archivage du dossier",
            description: "Archiver le dossier employé selon les règles légales",
            assigned_to_department: "RH",
            priority: "medium",
            days_offset: 7,
            dependencies: [5, 6]
          },
          {
            title: "Clôture administrative",
            description: "Finaliser tous les aspects administratifs du départ",
            assigned_to_department: "RH",
            priority: "medium",
            days_offset: 30,
            dependencies: [8]
          }
        ]
      };

      await base44.entities.WorkflowTemplate.create(onboardingTemplate);
      await base44.entities.WorkflowTemplate.create(offboardingTemplate);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflowTemplates'] });
    },
  });

  // Initialiser automatiquement les templates si aucun n'existe
  useEffect(() => {
    if (templates.length === 0 && user?.role === 'admin') {
      initializeTemplatesMutation.mutate();
    }
  }, [templates.length, user]);

  const activeWorkflows = workflows.filter(w => w.status === 'in_progress' || w.status === 'not_started');
  const completedWorkflows = workflows.filter(w => w.status === 'completed');
  const onboardingCount = activeWorkflows.filter(w => w.workflow_type === 'onboarding').length;
  const offboardingCount = activeWorkflows.filter(w => w.workflow_type === 'offboarding').length;

  const statusColors = {
    not_started: "bg-gray-100 text-gray-800",
    in_progress: "bg-blue-100 text-blue-800",
    completed: "bg-green-100 text-green-800",
    cancelled: "bg-red-100 text-red-800",
  };

  const statusLabels = {
    not_started: "Non démarré",
    in_progress: "En cours",
    completed: "Terminé",
    cancelled: "Annulé",
  };

  const statusIcons = {
    not_started: Clock,
    in_progress: PlayCircle,
    completed: CheckCircle,
    cancelled: AlertCircle,
  };

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Workflows Automatisés</h1>
          <p className="text-slate-600 mt-1">
            {activeWorkflows.length} workflows actifs • {onboardingCount} intégrations • {offboardingCount} départs
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => setActiveTab('templates')}
            className="gap-2"
          >
            <Settings className="w-4 h-4" />
            Templates
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Workflows actifs</p>
                <p className="text-3xl font-bold text-blue-900">{activeWorkflows.length}</p>
              </div>
              <PlayCircle className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Intégrations</p>
                <p className="text-3xl font-bold text-green-900">{onboardingCount}</p>
              </div>
              <Users className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Départs</p>
                <p className="text-3xl font-bold text-orange-900">{offboardingCount}</p>
              </div>
              <Users className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Terminés</p>
                <p className="text-3xl font-bold text-purple-900">{completedWorkflows.length}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="active">Actifs ({activeWorkflows.length})</TabsTrigger>
          <TabsTrigger value="completed">Terminés ({completedWorkflows.length})</TabsTrigger>
          <TabsTrigger value="templates">Templates ({templates.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="mt-6">
          {activeWorkflows.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <PlayCircle className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucun workflow actif</p>
                <p className="text-sm">Les workflows seront créés automatiquement lors de l'ajout ou du départ d'employés</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {activeWorkflows.map((workflow) => {
                const StatusIcon = statusIcons[workflow.status];
                const workflowTasks = tasks.filter(t => 
                  t.employee_email === workflow.employee_email && 
                  t.task_type === workflow.workflow_type
                );
                const completedTasks = workflowTasks.filter(t => t.status === 'completed').length;
                const progress = workflowTasks.length > 0 
                  ? Math.round((completedTasks / workflowTasks.length) * 100) 
                  : 0;

                return (
                  <Card key={workflow.id} className="border-none shadow-lg">
                    <CardHeader className="border-b border-slate-100">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={workflow.workflow_type === 'onboarding' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
                              {workflow.workflow_type === 'onboarding' ? 'Intégration' : 'Départ'}
                            </Badge>
                            <Badge className={statusColors[workflow.status]}>
                              {statusLabels[workflow.status]}
                            </Badge>
                          </div>
                          <CardTitle className="text-lg">{workflow.employee_name}</CardTitle>
                          <p className="text-sm text-slate-600 mt-1">
                            {workflow.position} • {workflow.department}
                          </p>
                        </div>
                        <StatusIcon className="w-8 h-8 text-slate-400" />
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-slate-700">Progression</span>
                          <span className="text-sm font-bold text-blue-600">{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                        <p className="text-xs text-slate-500 mt-1">
                          {completedTasks} sur {workflowTasks.length} tâches terminées
                        </p>
                      </div>

                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-600">Date de début</span>
                        <span className="font-medium">{format(new Date(workflow.start_date), 'dd/MM/yyyy')}</span>
                      </div>

                      {workflow.expected_completion_date && (
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-600">Fin prévue</span>
                          <span className="font-medium">{format(new Date(workflow.expected_completion_date), 'dd/MM/yyyy')}</span>
                        </div>
                      )}

                      <Button 
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        onClick={() => window.location.href = '/Onboarding'}
                      >
                        Voir les tâches
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          {completedWorkflows.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <CheckCircle className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p>Aucun workflow terminé pour le moment</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {completedWorkflows.map((workflow) => (
                <Card key={workflow.id} className="border-none shadow-lg">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <Badge className={workflow.workflow_type === 'onboarding' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
                          {workflow.workflow_type === 'onboarding' ? 'Intégration' : 'Départ'}
                        </Badge>
                        <CardTitle className="text-lg mt-2">{workflow.employee_name}</CardTitle>
                        <p className="text-sm text-slate-600">{workflow.position}</p>
                      </div>
                      <CheckCircle className="w-8 h-8 text-green-600" />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600">Terminé le</span>
                      <span className="font-medium">
                        {workflow.actual_completion_date 
                          ? format(new Date(workflow.actual_completion_date), 'dd/MM/yyyy')
                          : 'N/A'}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="templates" className="mt-6">
          {templates.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <Settings className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-slate-500 mb-4">Initialisation des templates en cours...</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {templates.map((template) => (
                <Card key={template.id} className="border-none shadow-lg">
                  <CardHeader className="border-b border-slate-100">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={template.workflow_type === 'onboarding' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
                            {template.workflow_type === 'onboarding' ? 'Onboarding' : 'Offboarding'}
                          </Badge>
                          {template.is_default && (
                            <Badge variant="outline" className="bg-blue-50 text-blue-700">Par défaut</Badge>
                          )}
                        </div>
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                        <p className="text-sm text-slate-600 mt-1">{template.description}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600">Nombre de tâches</span>
                        <span className="font-semibold text-slate-900">{template.tasks?.length || 0}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-600">Statut</span>
                        <Badge className={template.is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                          {template.is_active ? 'Actif' : 'Inactif'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}