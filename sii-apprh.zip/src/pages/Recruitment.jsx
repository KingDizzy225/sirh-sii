import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Briefcase, Users, Calendar, TrendingUp, UserCheck, Sparkles, UserPlus } from "lucide-react";
import { Badge } from "@/components/ui/badge";

import JobPostingCard from "../components/recruitment/JobPostingCard";
import JobPostingForm from "../components/recruitment/JobPostingForm";
import CandidateCard from "../components/recruitment/CandidateCard";
import CandidateForm from "../components/recruitment/CandidateForm";
import RecruitmentPipeline from "../components/recruitment/RecruitmentPipeline";
import CandidateDetailsModal from "../components/recruitment/CandidateDetailsModal";
import InterviewScheduler from "../components/recruitment/InterviewScheduler";
import RecruitmentStats from "../components/recruitment/RecruitmentStats";
import CandidateTrackingDashboard from "../components/recruitment/CandidateTrackingDashboard";
import CandidateAdvancedFilters from "../components/recruitment/CandidateAdvancedFilters";
import CandidateGroups from "../components/recruitment/CandidateGroups";
import AIRecruitmentMatcher from "../components/ai/AIRecruitmentMatcher";
import AIJobDescriptionGenerator from "../components/ai/AIJobDescriptionGenerator";
import AICandidateScreening from "../components/ai/AICandidateScreening";
import { notifyNewJobPosting, notifyCandidateStatusChange } from "../components/notifications/NotificationTriggers";

export default function Recruitment() {
  const [showJobForm, setShowJobForm] = useState(false);
  const [activeTab, setActiveTab] = useState("pipeline");
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [selectedJobForAI, setSelectedJobForAI] = useState(null);
  const [showAIMatcher, setShowAIMatcher] = useState(false);
  const [showAIJobGenerator, setShowAIJobGenerator] = useState(false);
  const [showAIScreening, setShowAIScreening] = useState(false);
  const [selectedJobForScreening, setSelectedJobForScreening] = useState(null);
  const [showCandidateForm, setShowCandidateForm] = useState(false);
  const [candidateFilters, setCandidateFilters] = useState({});
  const [candidateGroups, setCandidateGroups] = useState([]);

  const queryClient = useQueryClient();

  const { data: jobPostings = [] } = useQuery({
    queryKey: ['jobPostings'],
    queryFn: () => base44.entities.JobPosting.list('-posted_date'),
  });

  const { data: candidates = [] } = useQuery({
    queryKey: ['candidates'],
    queryFn: () => base44.entities.Candidate.list('-application_date'),
  });

  const { data: interviews = [] } = useQuery({
    queryKey: ['interviews'],
    queryFn: () => base44.entities.Interview.list('-interview_date'),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const createJobMutation = useMutation({
    mutationFn: (data) => base44.entities.JobPosting.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobPostings'] });
      setShowJobForm(false);
    },
  });

  const createCandidateMutation = useMutation({
    mutationFn: (data) => base44.entities.Candidate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      setShowCandidateForm(false);
    },
  });

  const updateCandidateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Candidate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
    },
  });

  const handleCandidateUpdate = (candidateId, data) => {
    updateCandidateMutation.mutate({ id: candidateId, data });
  };

  // Stats
  const activeJobs = jobPostings.filter(j => j.status === 'active').length;
  const totalCandidates = candidates.length;
  const activeCandidates = candidates.filter(c => 
    c.status !== 'rejected' && c.status !== 'hired'
  ).length;
  const upcomingInterviews = interviews.filter(i => 
    i.status === 'scheduled' && new Date(i.interview_date) > new Date()
  ).length;

  return (
    <div className="p-6 md:p-8 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Briefcase className="w-8 h-8 text-blue-600" />
            Gestion du Recrutement
          </h1>
          <p className="text-slate-600 mt-1">
            {activeJobs} postes actifs • {totalCandidates} candidatures • {upcomingInterviews} entretiens
          </p>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={() => setShowAIJobGenerator(true)}
            className="bg-purple-600 hover:bg-purple-700 shadow-lg"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Générer avec IA
          </Button>
          <Button
            onClick={() => setShowJobForm(true)}
            className="bg-blue-600 hover:bg-blue-700 shadow-lg"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nouvelle offre
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Offres actives</p>
                <p className="text-3xl font-bold text-blue-900">{activeJobs}</p>
              </div>
              <div className="w-12 h-12 bg-blue-200 rounded-xl flex items-center justify-center">
                <Briefcase className="w-6 h-6 text-blue-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Candidatures</p>
                <p className="text-3xl font-bold text-green-900">{totalCandidates}</p>
              </div>
              <div className="w-12 h-12 bg-green-200 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-green-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Actives</p>
                <p className="text-3xl font-bold text-purple-900">{activeCandidates}</p>
              </div>
              <div className="w-12 h-12 bg-purple-200 rounded-xl flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-purple-700" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Entretiens</p>
                <p className="text-3xl font-bold text-orange-900">{upcomingInterviews}</p>
              </div>
              <div className="w-12 h-12 bg-orange-200 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-700" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-white shadow-md grid w-full grid-cols-3 md:grid-cols-6">
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="tracking">Suivi</TabsTrigger>
          <TabsTrigger value="jobs">Offres ({jobPostings.length})</TabsTrigger>
          <TabsTrigger value="candidates">Candidats ({totalCandidates})</TabsTrigger>
          <TabsTrigger value="interviews">Entretiens ({interviews.length})</TabsTrigger>
          <TabsTrigger value="stats">Statistiques</TabsTrigger>
        </TabsList>

        <TabsContent value="pipeline" className="mt-6">
          <RecruitmentPipeline 
            candidates={candidates} 
            jobPostings={jobPostings} 
            onCandidateUpdate={handleCandidateUpdate}
          />
        </TabsContent>

        <TabsContent value="tracking" className="mt-6">
          <CandidateTrackingDashboard 
            candidates={candidates} 
            jobPostings={jobPostings}
            interviews={interviews}
          />
        </TabsContent>

        <TabsContent value="jobs" className="mt-6">
          {jobPostings.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Briefcase className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune offre d'emploi</p>
                <p className="text-sm">Créez votre première offre pour commencer</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {jobPostings.map((job) => {
                const jobCandidates = candidates.filter(c => c.job_posting_id === job.id);
                return (
                  <div key={job.id}>
                    <JobPostingCard 
                      job={job}
                      onSelectForAI={() => {
                        setSelectedJobForAI(job);
                        setShowAIMatcher(true);
                      }}
                    />
                    {jobCandidates.length > 0 && (
                      <Button
                        onClick={() => {
                          setSelectedJobForScreening(job);
                          setShowAIScreening(true);
                        }}
                        className="w-full mt-2 bg-purple-600 hover:bg-purple-700"
                        size="sm"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        Tri IA ({jobCandidates.length} candidatures)
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="candidates" className="mt-6 space-y-6">
                      {/* Filtres avancés */}
                      <CandidateAdvancedFilters 
                        jobPostings={jobPostings}
                        onFilterChange={setCandidateFilters}
                      />

                      {/* Groupes de candidats */}
                      <CandidateGroups
                        candidates={candidates}
                        groups={candidateGroups}
                        onGroupsChange={setCandidateGroups}
                      />

                      {/* Bouton ajouter candidature */}
                      <div className="flex justify-end">
                        <Button onClick={() => setShowCandidateForm(true)} className="bg-green-600 hover:bg-green-700">
                          <UserPlus className="w-4 h-4 mr-2" />
                          Ajouter une candidature
                        </Button>
                      </div>

                      {/* AI Matcher si un job est sélectionné */}
                      {showAIMatcher && selectedJobForAI && selectedCandidate && (
                        <AIRecruitmentMatcher
                          candidate={selectedCandidate}
                          jobPosting={selectedJobForAI}
                        />
                      )}

                      {candidates.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center text-slate-500">
                <Users className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                <p className="text-lg font-medium mb-2">Aucune candidature</p>
                <p className="text-sm">Les candidatures apparaîtront ici</p>
              </CardContent>
            </Card>
          ) : (
                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                            {candidates
                              .filter(candidate => {
                                const f = candidateFilters || {};
                                if (Object.keys(f).length === 0) return true;

                                // Recherche texte
                                if (f.search) {
                                  const search = f.search.toLowerCase();
                                  const matchName = candidate.full_name?.toLowerCase().includes(search);
                                  const matchEmail = candidate.email?.toLowerCase().includes(search);
                                  const matchSkills = (candidate.skills || []).some(s => s.toLowerCase().includes(search));
                                  if (!matchName && !matchEmail && !matchSkills) return false;
                                }

                                // Poste
                                if (f.jobPostingId && candidate.job_posting_id !== f.jobPostingId) return false;

                                // Statuts
                                if ((f.statuses || []).length > 0 && !f.statuses.includes(candidate.status)) return false;

                                // Sources
                                if ((f.sources || []).length > 0 && !f.sources.includes(candidate.source)) return false;

                                // Score
                                if (f.minScore > 0 && (candidate.overall_score || 0) < f.minScore) return false;
                                if (f.maxScore < 100 && (candidate.overall_score || 100) > f.maxScore) return false;

                                // Expérience
                                if (f.minExperience > 0 && (candidate.experience_years || 0) < f.minExperience) return false;
                                if (f.maxExperience < 20 && (candidate.experience_years || 0) > f.maxExperience) return false;

                                // Compétences
                                if ((f.skills || []).length > 0) {
                                  const hasAllSkills = f.skills.every(skill => 
                                    (candidate.skills || []).some(s => s.toLowerCase().includes(skill.toLowerCase()))
                                  );
                                  if (!hasAllSkills) return false;
                                }

                                // CV
                                if (f.hasResume && !candidate.resume_url) return false;

                                return true;
                              })
                              .map((candidate) => (
                <div key={candidate.id}>
                  <CandidateCard
                    candidate={candidate}
                    onClick={() => setSelectedCandidate(candidate)}
                  />
                  {selectedCandidate?.id === candidate.id && jobPostings.length > 0 && (
                    <div className="mt-3">
                      <Button
                        onClick={() => {
                          setSelectedJobForAI(
                            jobPostings.find(j => j.id === candidate.job_posting_id) || jobPostings[0]
                          );
                          setShowAIMatcher(true);
                        }}
                        className="w-full bg-purple-600 hover:bg-purple-700"
                      >
                        <Sparkles className="w-4 h-4 mr-2" />
                        Analyser avec l'IA
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="interviews" className="mt-6">
          <InterviewScheduler 
            candidates={candidates} 
            jobPostings={jobPostings}
            interviews={interviews}
          />
        </TabsContent>

        <TabsContent value="stats" className="mt-6">
          <RecruitmentStats
            candidates={candidates}
            jobPostings={jobPostings}
            interviews={interviews}
          />
        </TabsContent>
      </Tabs>

      {showJobForm && (
        <JobPostingForm
          onSubmit={(data) => createJobMutation.mutate(data)}
          onCancel={() => setShowJobForm(false)}
          isSubmitting={createJobMutation.isPending}
        />
      )}

      {selectedCandidate && !showAIMatcher && (
        <CandidateDetailsModal
          candidate={selectedCandidate}
          onClose={() => {
            setSelectedCandidate(null);
            queryClient.invalidateQueries({ queryKey: ['candidates'] });
          }}
        />
      )}

      {showAIJobGenerator && (
        <AIJobDescriptionGenerator
          onClose={() => setShowAIJobGenerator(false)}
          departments={departments}
          onGenerated={(jobData) => {
            createJobMutation.mutate(jobData);
            setShowAIJobGenerator(false);
          }}
        />
      )}

      {showCandidateForm && (
        <CandidateForm
          jobPostings={jobPostings}
          onSubmit={(data) => createCandidateMutation.mutate(data)}
          onCancel={() => setShowCandidateForm(false)}
          isSubmitting={createCandidateMutation.isPending}
        />
      )}

      {showAIScreening && selectedJobForScreening && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
              <h2 className="text-xl font-bold">Tri IA - {selectedJobForScreening.title}</h2>
              <Button
                variant="ghost"
                onClick={() => {
                  setShowAIScreening(false);
                  setSelectedJobForScreening(null);
                }}
              >
                Fermer
              </Button>
            </div>
            <div className="p-6">
              <AICandidateScreening
                candidates={candidates.filter(c => c.job_posting_id === selectedJobForScreening.id)}
                jobPosting={selectedJobForScreening}
                onScreeningComplete={() => {
                  queryClient.invalidateQueries({ queryKey: ['candidates'] });
                  setShowAIScreening(false);
                  setSelectedJobForScreening(null);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}