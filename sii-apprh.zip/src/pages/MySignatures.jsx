import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  PenTool, 
  FileText, 
  Clock, 
  CheckCircle, 
  Calendar,
  User,
  AlertCircle,
  Eye
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import SignDocument from "../components/signature/SignDocument";

const roleLabels = {
  employee: "Employé",
  manager: "Manager",
  hr: "RH",
  director: "Directeur",
  witness: "Témoin"
};

export default function MySignatures() {
  const [user, setUser] = useState(null);
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [showSignDialog, setShowSignDialog] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const { data: pendingSignatures = [], isLoading: loadingPending } = useQuery({
    queryKey: ['myPendingSignatures', user?.email],
    queryFn: () => base44.entities.DocumentSignature.filter({
      signer_email: user.email,
      status: 'pending'
    }),
    enabled: !!user?.email,
  });

  const { data: signedSignatures = [], isLoading: loadingSigned } = useQuery({
    queryKey: ['mySignedSignatures', user?.email],
    queryFn: () => base44.entities.DocumentSignature.filter({
      signer_email: user.email,
      status: 'signed'
    }),
    enabled: !!user?.email,
  });

  const handleSignClick = async (signature) => {
    try {
      const docs = await base44.entities.Document.filter({ id: signature.document_id });
      if (docs && docs.length > 0) {
        setSelectedDocument(docs[0]);
        setSelectedRequest(signature);
        setShowSignDialog(true);
      }
    } catch (error) {
      console.error("Erreur chargement document:", error);
    }
  };

  const handleSignComplete = () => {
    setShowSignDialog(false);
    setSelectedRequest(null);
    setSelectedDocument(null);
    queryClient.invalidateQueries({ queryKey: ['myPendingSignatures'] });
    queryClient.invalidateQueries({ queryKey: ['mySignedSignatures'] });
  };

  // Calcul des signatures urgentes
  const urgentSignatures = pendingSignatures.filter(s => {
    if (!s.deadline) return false;
    try {
      const deadline = new Date(s.deadline);
      const daysUntilDeadline = Math.ceil((deadline - new Date()) / (1000 * 60 * 60 * 24));
      return daysUntilDeadline <= 3;
    } catch {
      return false;
    }
  });

  const isLoading = !user || loadingPending || loadingSigned;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50 p-6 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <PenTool className="w-8 h-8 text-yellow-600" />
            Mes Signatures Électroniques
          </h1>
          <p className="text-slate-600 mt-1">Gérez vos documents à signer</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-yellow-700 mb-1">À signer</p>
                  <p className="text-3xl font-bold text-yellow-900">{pendingSignatures.length}</p>
                </div>
                <Clock className="w-10 h-10 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-red-50 to-red-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-red-700 mb-1">Urgent</p>
                  <p className="text-3xl font-bold text-red-900">{urgentSignatures.length}</p>
                </div>
                <AlertCircle className="w-10 h-10 text-red-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Signés</p>
                  <p className="text-3xl font-bold text-green-900">{signedSignatures.length}</p>
                </div>
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Documents en attente */}
        {pendingSignatures.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PenTool className="w-5 h-5 text-yellow-600" />
                Documents en attente ({pendingSignatures.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingSignatures.map((signature) => {
                let deadline = null;
                let isOverdue = false;
                let daysUntilDeadline = null;
                let isUrgent = false;

                if (signature.deadline) {
                  try {
                    deadline = new Date(signature.deadline);
                    isOverdue = deadline < new Date();
                    daysUntilDeadline = Math.ceil((deadline - new Date()) / (1000 * 60 * 60 * 24));
                    isUrgent = daysUntilDeadline <= 3 && !isOverdue;
                  } catch {
                    // Ignore
                  }
                }

                return (
                  <Card 
                    key={signature.id} 
                    className={`border-2 ${
                      isOverdue ? 'border-red-300 bg-red-50' :
                      isUrgent ? 'border-orange-300 bg-orange-50' :
                      'border-yellow-200 bg-yellow-50'
                    }`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <FileText className="w-8 h-8 text-blue-600 flex-shrink-0" />
                          <div className="flex-1">
                            <h4 className="font-bold text-slate-900 mb-1">
                              {signature.document_title || "Document"}
                            </h4>
                            {signature.document_type && (
                              <p className="text-sm text-slate-600 mb-2">{signature.document_type}</p>
                            )}

                            <div className="flex flex-wrap items-center gap-2 mb-3">
                              {signature.signer_role && (
                                <Badge variant="outline" className="text-xs">
                                  {roleLabels[signature.signer_role] || signature.signer_role}
                                </Badge>
                              )}
                              {isOverdue && (
                                <Badge className="bg-red-600 text-xs">⚠️ En retard</Badge>
                              )}
                              {isUrgent && (
                                <Badge className="bg-orange-600 text-xs">🔥 Urgent</Badge>
                              )}
                            </div>

                            <div className="space-y-1 text-xs text-slate-600">
                              {signature.requested_by_name && (
                                <div className="flex items-center gap-2">
                                  <User className="w-3 h-3" />
                                  <span>Demandé par: {signature.requested_by_name}</span>
                                </div>
                              )}
                              {deadline && (
                                <div className="flex items-center gap-2">
                                  <Calendar className="w-3 h-3" />
                                  <span>Échéance: {format(deadline, 'd MMMM yyyy', { locale: fr })}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        <Button
                          onClick={() => handleSignClick(signature)}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <PenTool className="w-4 h-4 mr-2" />
                          Signer
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </CardContent>
          </Card>
        )}

        {/* Documents signés */}
        {signedSignatures.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Documents signés ({signedSignatures.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {signedSignatures.map((signature) => (
                <Card key={signature.id} className="border-green-200 bg-green-50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-slate-900">
                          {signature.document_title || "Document"}
                        </p>
                        {signature.document_type && (
                          <p className="text-sm text-slate-600 mb-1">{signature.document_type}</p>
                        )}
                        {signature.signed_date && (
                          <p className="text-xs text-green-700">
                            Signé le {format(new Date(signature.signed_date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Message si aucune signature */}
        {pendingSignatures.length === 0 && signedSignatures.length === 0 && (
          <Card className="border-none shadow-lg">
            <CardContent className="p-12 text-center">
              <PenTool className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <p className="text-lg font-medium text-slate-700 mb-2">Aucune signature</p>
              <p className="text-slate-500">Vous n'avez aucun document à signer</p>
            </CardContent>
          </Card>
        )}

        {/* Sign Dialog */}
        {showSignDialog && selectedRequest && selectedDocument && (
          <SignDocument
            signatureRequest={selectedRequest}
            document={selectedDocument}
            onClose={() => {
              setShowSignDialog(false);
              setSelectedRequest(null);
              setSelectedDocument(null);
            }}
            onSigned={handleSignComplete}
          />
        )}
      </div>
    </div>
  );
}