import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  LayoutDashboard, 
  Download, 
  Settings,
  RefreshCw,
  Eye,
  GripVertical,
  Calendar,
  Users,
  TrendingUp
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

// Import widgets
import TurnoverRateWidget from "../components/dashboard-hr/TurnoverRateWidget";
import TimeToHireWidget from "../components/dashboard-hr/TimeToHireWidget";
import LineStaffDistributionWidget from "../components/dashboard-hr/LineStaffDistributionWidget";
import TeamDiversityWidget from "../components/dashboard-hr/TeamDiversityWidget";
import CostPerHireWidget from "../components/dashboard-hr/CostPerHireWidget";
import HeadcountTrendWidget from "../components/dashboard-hr/HeadcountTrendWidget";
import DepartmentBreakdownWidget from "../components/dashboard-hr/DepartmentBreakdownWidget";
import PerformanceOverviewWidget from "../components/dashboard-hr/PerformanceOverviewWidget";
import WidgetCustomizer from "../components/dashboard-hr/WidgetCustomizer";

const DEFAULT_WIDGET_ORDER = [
  'turnover',
  'timeToHire',
  'lineStaff',
  'diversity',
  'costPerHire',
  'headcount',
  'departments',
  'performance'
];

const DEFAULT_VISIBLE_WIDGETS = {
  turnover: true,
  timeToHire: true,
  lineStaff: true,
  diversity: true,
  costPerHire: true,
  headcount: true,
  departments: true,
  performance: true,
};

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [periodFilter, setPeriodFilter] = useState("current_year");
  const [widgetOrder, setWidgetOrder] = useState(DEFAULT_WIDGET_ORDER);
  const [visibleWidgets, setVisibleWidgets] = useState(DEFAULT_VISIBLE_WIDGETS);
  const [showCustomizer, setShowCustomizer] = useState(false);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
        
        if (!currentUser.role || currentUser.role !== 'admin') {
          window.location.href = createPageUrl("EmployeePortal");
          return;
        }
        
        setLoading(false);

        // Load saved preferences
        const savedOrder = localStorage.getItem("dashboard_widget_order");
        const savedVisible = localStorage.getItem("dashboard_visible_widgets");
        
        if (savedOrder) {
          setWidgetOrder(JSON.parse(savedOrder));
        }
        if (savedVisible) {
          setVisibleWidgets(JSON.parse(savedVisible));
        }
      } catch (error) {
        console.error("Error loading user:", error);
        setLoading(false);
      }
    };
    loadUser();
  }, []);

  // Fetch data
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: user?.role === 'admin',
  });

  const { data: candidates = [] } = useQuery({
    queryKey: ['candidates'],
    queryFn: () => base44.entities.Candidate.list('-application_date'),
    enabled: user?.role === 'admin',
  });

  const { data: jobPostings = [] } = useQuery({
    queryKey: ['jobPostings'],
    queryFn: () => base44.entities.JobPosting.list(),
    enabled: user?.role === 'admin',
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
    enabled: user?.role === 'admin',
  });

  const { data: performanceReviews = [] } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list('-review_date'),
    enabled: user?.role === 'admin',
  });

  const { data: leaveRequests = [] } = useQuery({
    queryKey: ['leaveRequests'],
    queryFn: () => base44.entities.LeaveRequest.list('-created_date'),
    enabled: user?.role === 'admin',
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(widgetOrder);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setWidgetOrder(items);
    localStorage.setItem("dashboard_widget_order", JSON.stringify(items));
  };

  const handleToggleWidget = (widgetId) => {
    const updated = { ...visibleWidgets, [widgetId]: !visibleWidgets[widgetId] };
    setVisibleWidgets(updated);
    localStorage.setItem("dashboard_visible_widgets", JSON.stringify(updated));
  };

  const handleResetLayout = () => {
    setWidgetOrder(DEFAULT_WIDGET_ORDER);
    setVisibleWidgets(DEFAULT_VISIBLE_WIDGETS);
    localStorage.removeItem("dashboard_widget_order");
    localStorage.removeItem("dashboard_visible_widgets");
  };

  const handleExport = () => {
    window.print();
  };

  if (loading || !user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Chargement du tableau de bord...</p>
        </div>
      </div>
    );
  }

  // Quick stats
  const activeEmployees = employees.filter(e => e.status === 'active').length;
  const pendingLeaves = leaveRequests.filter(r => r.status === 'pending').length;
  const activeCandidates = candidates.filter(c => c.status !== 'rejected' && c.status !== 'hired').length;
  
  const lineEmployees = employees.filter(e => e.position_type === 'line' && e.status === 'active').length;
  const staffEmployees = employees.filter(e => e.position_type === 'staff' && e.status === 'active').length;
  const lineStaffRatio = staffEmployees > 0 ? (lineEmployees / staffEmployees).toFixed(1) : 'N/A';

  // Render widget based on ID
  const renderWidget = (widgetId) => {
    const widgetMap = {
      turnover: <TurnoverRateWidget employees={employees} />,
      timeToHire: <TimeToHireWidget candidates={candidates} jobPostings={jobPostings} />,
      lineStaff: <LineStaffDistributionWidget employees={employees} />,
      diversity: <TeamDiversityWidget employees={employees} />,
      costPerHire: <CostPerHireWidget candidates={candidates} employees={employees} />,
      headcount: <HeadcountTrendWidget employees={employees} />,
      departments: <DepartmentBreakdownWidget employees={employees} departments={departments} />,
      performance: <PerformanceOverviewWidget reviews={performanceReviews} employees={employees} />,
    };

    return widgetMap[widgetId] || null;
  };

  const visibleWidgetsList = widgetOrder.filter(id => visibleWidgets[id]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-6 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2 flex items-center gap-3">
              <LayoutDashboard className="w-8 h-8 text-blue-600" />
              Tableau de Bord RH
            </h1>
            <p className="text-slate-600">
              Vue d'ensemble personnalisable de vos indicateurs clés
            </p>
          </div>
          <div className="flex gap-3 flex-wrap">
            <Select value={periodFilter} onValueChange={setPeriodFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current_month">Mois en cours</SelectItem>
                <SelectItem value="current_quarter">Trimestre</SelectItem>
                <SelectItem value="current_year">Année en cours</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline"
              onClick={() => setShowCustomizer(true)}
            >
              <Settings className="w-4 h-4 mr-2" />
              Personnaliser
            </Button>
            <Button variant="outline" onClick={handleExport}>
              <Download className="w-4 h-4 mr-2" />
              Exporter
            </Button>
          </div>
        </div>

        {/* Quick KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-700 mb-1">Effectif actif</p>
                  <p className="text-3xl font-bold text-blue-900">{activeEmployees}</p>
                </div>
                <Users className="w-10 h-10 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-orange-700 mb-1">Congés en attente</p>
                  <p className="text-3xl font-bold text-orange-900">{pendingLeaves}</p>
                </div>
                <Calendar className="w-10 h-10 text-orange-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Candidats actifs</p>
                  <p className="text-3xl font-bold text-green-900">{activeCandidates}</p>
                </div>
                <TrendingUp className="w-10 h-10 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-purple-700 mb-1">Ratio Line:Staff</p>
                  <p className="text-3xl font-bold text-purple-900">{lineStaffRatio}:1</p>
                </div>
                <Users className="w-10 h-10 text-purple-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Customizable Widgets Grid */}
        {visibleWidgetsList.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="p-12 text-center">
              <Eye className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                Aucun widget affiché
              </h3>
              <p className="text-sm text-slate-600 mb-4">
                Personnalisez votre tableau de bord en activant des widgets
              </p>
              <Button onClick={() => setShowCustomizer(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Personnaliser le tableau de bord
              </Button>
            </CardContent>
          </Card>
        ) : (
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="widgets">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                  className="grid grid-cols-1 lg:grid-cols-2 gap-6"
                >
                  {visibleWidgetsList.map((widgetId, index) => (
                    <Draggable key={widgetId} draggableId={widgetId} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`relative ${snapshot.isDragging ? 'opacity-75' : ''}`}
                        >
                          <div
                            {...provided.dragHandleProps}
                            className="absolute top-4 right-4 z-10 cursor-move p-2 bg-white rounded-lg shadow-md hover:bg-slate-50 transition-colors"
                          >
                            <GripVertical className="w-5 h-5 text-slate-400" />
                          </div>
                          {renderWidget(widgetId)}
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        )}

        {/* Info Card */}
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <LayoutDashboard className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-900 mb-1">
                  💡 Personnalisez votre tableau de bord
                </p>
                <p className="text-xs text-blue-700">
                  Réorganisez les widgets par glisser-déposer • Masquez/Affichez les indicateurs selon vos besoins • Vos préférences sont sauvegardées automatiquement
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Widget Customizer Dialog */}
      <WidgetCustomizer
        isOpen={showCustomizer}
        onClose={() => setShowCustomizer(false)}
        visibleWidgets={visibleWidgets}
        onToggleWidget={handleToggleWidget}
        onReset={handleResetLayout}
      />
    </div>
  );
}