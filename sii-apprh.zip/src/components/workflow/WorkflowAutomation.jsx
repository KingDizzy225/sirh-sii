import React from "react";
import { base44 } from "@/api/base44Client";
import { format, addDays } from "date-fns";

/**
 * Génère automatiquement un workflow et ses tâches pour un employé
 * @param {Object} employee - L'employé concerné
 * @param {string} workflowType - 'onboarding' ou 'offboarding'
 * @param {string} startDate - Date de début du workflow
 * @param {Object} template - Template de workflow à utiliser (optionnel)
 * @returns {Promise} - Workflow créé
 */
export async function generateWorkflow(employee, workflowType, startDate, template = null) {
  try {
    // Si pas de template fourni, récupérer le template par défaut
    if (!template) {
      const templates = await base44.entities.WorkflowTemplate.filter({
        workflow_type: workflowType,
        is_default: true,
        is_active: true
      });
      
      if (templates.length === 0) {
        throw new Error(`Aucun template ${workflowType} par défaut trouvé`);
      }
      
      template = templates[0];
    }

    // Calculer la date de fin prévue (dernière tâche + son offset)
    const maxOffset = Math.max(...template.tasks.map(t => t.days_offset || 0));
    const expectedCompletionDate = format(addDays(new Date(startDate), maxOffset), 'yyyy-MM-dd');

    // Créer le workflow
    const workflow = await base44.entities.Workflow.create({
      employee_email: employee.email,
      employee_name: employee.full_name,
      workflow_type: workflowType,
      template_id: template.id,
      start_date: startDate,
      expected_completion_date: expectedCompletionDate,
      status: 'not_started',
      progress_percentage: 0,
      department: employee.department,
      position: employee.position,
      notes: `Workflow ${workflowType === 'onboarding' ? "d'intégration" : 'de départ'} généré automatiquement`
    });

    console.log("✅ Workflow créé:", workflow.id);

    // Créer toutes les tâches du workflow
    const tasksPromises = template.tasks.map(async (taskTemplate, index) => {
      const taskDueDate = format(
        addDays(new Date(startDate), taskTemplate.days_offset || 0),
        'yyyy-MM-dd'
      );

      const assigneeEmail = await getAssigneeEmail(taskTemplate.assigned_to_department, employee);

      const task = await base44.entities.OnboardingTask.create({
        employee_email: employee.email,
        employee_name: employee.full_name,
        task_type: workflowType,
        title: taskTemplate.title,
        description: taskTemplate.description,
        assigned_to: assigneeEmail,
        department: taskTemplate.assigned_to_department,
        due_date: taskDueDate,
        status: 'pending',
        priority: taskTemplate.priority || 'medium',
        notes: `Tâche ${index + 1}/${template.tasks.length} du workflow ${template.name}`
      });

      // Créer une notification pour l'assigné
      await createTaskNotification(task, assigneeEmail, employee);

      return task;
    });

    const createdTasks = await Promise.all(tasksPromises);
    console.log(`✅ ${createdTasks.length} tâches créées`);

    // Créer notification pour l'employé
    await createWelcomeNotification(employee, workflowType, workflow);

    // Créer notification pour le manager
    if (employee.manager_email) {
      await createManagerNotification(employee, workflowType, workflow);
    }

    // Mettre à jour le statut du workflow
    await base44.entities.Workflow.update(workflow.id, {
      status: 'in_progress'
    });

    console.log("✅ Workflow initialisé avec succès");

    return workflow;
  } catch (error) {
    console.error('❌ Erreur lors de la génération du workflow:', error);
    throw error;
  }
}

/**
 * Détermine l'email de la personne à qui assigner la tâche
 */
async function getAssigneeEmail(department, employee) {
  try {
    // Pour les tâches assignées au manager ou à l'employé
    if (department === 'Manager') {
      return employee.manager_email || 'rh@sii.com';
    }
    if (department === 'Employé') {
      return employee.email;
    }

    // Chercher un utilisateur avec le rôle approprié pour le département
    const roles = await base44.entities.UserRole.filter({ is_active: true });
    
    // Mapping des départements vers les rôles
    const departmentRoleMap = {
      'RH': ['rh_manager', 'super_admin'],
      'IT': ['super_admin'],
      'Finance': ['payroll_admin', 'super_admin'],
      'Logistique': ['super_admin']
    };

    const relevantRoles = departmentRoleMap[department] || ['super_admin'];
    
    for (const role of roles) {
      if (relevantRoles.includes(role.role_type)) {
        return role.user_email;
      }
    }

    // Fallback: chercher un employé du département
    const deptEmployees = await base44.entities.Employee.filter({ 
      department: department,
      status: 'active' 
    });
    
    if (deptEmployees.length > 0) {
      return deptEmployees[0].email;
    }

    // Dernier recours: email générique
    return 'rh@sii.com';
  } catch (error) {
    console.error('Erreur lors de la récupération de l\'assigné:', error);
    return 'rh@sii.com';
  }
}

/**
 * Crée une notification pour une tâche assignée
 */
async function createTaskNotification(task, assigneeEmail, employee) {
  try {
    await base44.entities.Notification.create({
      user_email: assigneeEmail,
      user_name: assigneeEmail,
      notification_type: "task_assigned",
      title: "Nouvelle tâche assignée",
      message: `Vous avez une nouvelle tâche pour ${employee.full_name}: ${task.title}`,
      priority: task.priority === 'critical' ? 'urgent' : task.priority,
      action_url: "/Onboarding",
      action_label: "Voir la tâche",
      related_id: task.id,
      related_type: "OnboardingTask",
      icon: "check-circle"
    });
  } catch (error) {
    console.error('Erreur lors de la création de la notification:', error);
  }
}

/**
 * Crée une notification de bienvenue pour l'employé
 */
async function createWelcomeNotification(employee, workflowType, workflow) {
  try {
    if (workflowType === 'onboarding') {
      await base44.entities.Notification.create({
        user_email: employee.email,
        user_name: employee.full_name,
        notification_type: "system",
        title: `Bienvenue chez ${workflow.department || 'SII'} ! 🎉`,
        message: `Votre processus d'intégration a commencé. Consultez vos tâches à réaliser dans le portail employé.`,
        priority: "high",
        action_url: "/EmployeePortal",
        action_label: "Accéder au portail",
        icon: "sparkles"
      });
    } else {
      await base44.entities.Notification.create({
        user_email: employee.email,
        user_name: employee.full_name,
        notification_type: "system",
        title: "Processus de départ initialisé",
        message: "Votre processus de départ a été lancé. Veuillez consulter vos tâches à accomplir.",
        priority: "high",
        action_url: "/EmployeePortal",
        action_label: "Voir les tâches",
        icon: "info"
      });
    }
  } catch (error) {
    console.error('Erreur lors de la création de la notification de bienvenue:', error);
  }
}

/**
 * Crée une notification pour le manager
 */
async function createManagerNotification(employee, workflowType, workflow) {
  try {
    if (workflowType === 'onboarding') {
      await base44.entities.Notification.create({
        user_email: employee.manager_email,
        user_name: employee.manager_name || employee.manager_email,
        notification_type: "system",
        title: "Nouveau membre d'équipe",
        message: `${employee.full_name} rejoint votre équipe. Un workflow d'intégration a été créé.`,
        priority: "medium",
        action_url: "/Onboarding",
        action_label: "Voir le workflow",
        related_id: workflow.id,
        related_type: "Workflow",
        icon: "users"
      });
    } else {
      await base44.entities.Notification.create({
        user_email: employee.manager_email,
        user_name: employee.manager_name || employee.manager_email,
        notification_type: "system",
        title: "Départ d'un membre d'équipe",
        message: `${employee.full_name} quitte l'équipe. Un workflow de départ a été créé.`,
        priority: "medium",
        action_url: "/Onboarding",
        action_label: "Voir le workflow",
        related_id: workflow.id,
        related_type: "Workflow",
        icon: "alert-circle"
      });
    }
  } catch (error) {
    console.error('Erreur lors de la création de la notification manager:', error);
  }
}

/**
 * Met à jour la progression d'un workflow et crée des rappels si nécessaire
 */
export async function updateWorkflowProgress(workflowId, employeeEmail, workflowType) {
  try {
    // Récupérer toutes les tâches du workflow
    const tasks = await base44.entities.OnboardingTask.filter({
      employee_email: employeeEmail,
      task_type: workflowType
    });

    if (tasks.length === 0) return;

    // Calculer la progression
    const completedTasks = tasks.filter(t => t.status === 'completed').length;
    const progress = Math.round((completedTasks / tasks.length) * 100);

    // Mettre à jour le workflow
    const updateData = {
      progress_percentage: progress
    };

    // Si toutes les tâches sont terminées, marquer le workflow comme terminé
    if (progress === 100) {
      updateData.status = 'completed';
      updateData.actual_completion_date = format(new Date(), 'yyyy-MM-dd');

      // Créer notification de fin de workflow
      await createCompletionNotification(employeeEmail, workflowType);
    } else if (progress > 0) {
      updateData.status = 'in_progress';
    }

    await base44.entities.Workflow.update(workflowId, updateData);

    // Vérifier les tâches en retard et créer des rappels
    await checkOverdueTasks(tasks);

    console.log(`✅ Progression mise à jour: ${progress}%`);
  } catch (error) {
    console.error('Erreur lors de la mise à jour de la progression:', error);
  }
}

/**
 * Vérifie les tâches en retard et crée des notifications de rappel
 */
async function checkOverdueTasks(tasks) {
  try {
    const today = new Date();
    const overdueTasks = tasks.filter(task => {
      if (task.status === 'completed') return false;
      const dueDate = new Date(task.due_date);
      return dueDate < today;
    });

    for (const task of overdueTasks) {
      // Vérifier si un rappel a déjà été envoyé récemment
      const existingNotifications = await base44.entities.Notification.filter({
        user_email: task.assigned_to,
        related_id: task.id,
        notification_type: "deadline_reminder"
      });

      // Si aucun rappel dans les dernières 24h, en créer un
      const recentReminder = existingNotifications.find(n => {
        const notifDate = new Date(n.created_date);
        const daysDiff = Math.floor((today - notifDate) / (1000 * 60 * 60 * 24));
        return daysDiff < 1;
      });

      if (!recentReminder) {
        await base44.entities.Notification.create({
          user_email: task.assigned_to,
          user_name: task.assigned_to,
          notification_type: "deadline_reminder",
          title: "⚠️ Tâche en retard",
          message: `La tâche "${task.title}" pour ${task.employee_name} est en retard.`,
          priority: "urgent",
          action_url: "/Onboarding",
          action_label: "Compléter maintenant",
          related_id: task.id,
          related_type: "OnboardingTask",
          icon: "alert-triangle"
        });
      }
    }
  } catch (error) {
    console.error('Erreur lors de la vérification des tâches en retard:', error);
  }
}

/**
 * Crée une notification de fin de workflow
 */
async function createCompletionNotification(employeeEmail, workflowType) {
  try {
    const message = workflowType === 'onboarding' 
      ? "Félicitations ! Votre processus d'intégration est terminé. Bienvenue dans l'équipe ! 🎉"
      : "Votre processus de départ est terminé. Nous vous souhaitons le meilleur pour la suite.";

    await base44.entities.Notification.create({
      user_email: employeeEmail,
      user_name: employeeEmail,
      notification_type: "system",
      title: workflowType === 'onboarding' ? "Intégration terminée ✅" : "Processus de départ terminé",
      message: message,
      priority: "high",
      icon: "check-circle"
    });

    // Notifier les RH
    await base44.entities.Notification.create({
      user_email: 'rh@sii.com',
      user_name: 'RH',
      notification_type: "system",
      title: `Workflow ${workflowType} terminé`,
      message: `Le workflow ${workflowType} de ${employeeEmail} est terminé.`,
      priority: "medium",
      action_url: "/WorkflowManagement",
      action_label: "Voir les workflows",
      icon: "check-circle"
    });
  } catch (error) {
    console.error('Erreur lors de la création de la notification de fin:', error);
  }
}

/**
 * Génère automatiquement des documents d'onboarding
 */
export async function generateOnboardingDocuments(employee) {
  try {
    const documents = [
      {
        title: "Guide d'intégration",
        description: "Guide complet pour les premiers jours",
        document_type: "Autre",
        content_type: "guide"
      },
      {
        title: "Liste de contacts",
        description: "Contacts clés dans l'entreprise",
        document_type: "Autre",
        content_type: "contacts"
      },
      {
        title: "Procédures internes",
        description: "Procédures et processus de l'entreprise",
        document_type: "Autre",
        content_type: "procedures"
      }
    ];

    // Ces documents pourraient être générés via LLM ou templates
    console.log(`📄 Génération de ${documents.length} documents pour ${employee.full_name}`);
    
    // Créer notifications pour l'accès aux documents
    await base44.entities.Notification.create({
      user_email: employee.email,
      user_name: employee.full_name,
      notification_type: "document_shared",
      title: "Documents d'intégration disponibles",
      message: `${documents.length} documents ont été préparés pour votre intégration.`,
      priority: "medium",
      action_url: "/Documents",
      action_label: "Consulter les documents",
      icon: "file-text"
    });

    return documents;
  } catch (error) {
    console.error('Erreur lors de la génération des documents:', error);
    return [];
  }
}

/**
 * Planifie automatiquement les réunions d'intégration
 */
export async function scheduleMeetings(employee, workflowType) {
  try {
    if (workflowType !== 'onboarding') return;

    const meetings = [
      {
        title: "Session d'accueil RH",
        description: "Présentation de l'entreprise et tour des locaux",
        attendees: [employee.email, 'rh@sii.com'],
        day_offset: 0,
        duration_hours: 2
      },
      {
        title: "Rencontre avec le manager",
        description: "Première réunion avec votre manager direct",
        attendees: [employee.email, employee.manager_email],
        day_offset: 0,
        duration_hours: 1
      },
      {
        title: "Présentation de l'équipe",
        description: "Rencontrez votre équipe",
        attendees: [employee.email, employee.manager_email],
        day_offset: 0,
        duration_hours: 1
      },
      {
        title: "Point de suivi 1 semaine",
        description: "Bilan après la première semaine",
        attendees: [employee.email, employee.manager_email, 'rh@sii.com'],
        day_offset: 7,
        duration_hours: 0.5
      },
      {
        title: "Évaluation de fin de période d'essai",
        description: "Évaluation officielle de fin de période d'essai",
        attendees: [employee.email, employee.manager_email, 'rh@sii.com'],
        day_offset: 90,
        duration_hours: 1
      }
    ];

    console.log(`📅 Planification de ${meetings.length} réunions pour ${employee.full_name}`);

    // Créer notifications pour les réunions
    for (const meeting of meetings) {
      const meetingDate = format(addDays(new Date(employee.hire_date), meeting.day_offset), 'dd/MM/yyyy');
      
      for (const attendee of meeting.attendees) {
        if (attendee) {
          await base44.entities.Notification.create({
            user_email: attendee,
            user_name: attendee,
            notification_type: "system",
            title: `Réunion planifiée: ${meeting.title}`,
            message: `${meeting.description} - Prévu le ${meetingDate}`,
            priority: meeting.day_offset <= 1 ? "high" : "medium",
            icon: "calendar"
          });
        }
      }
    }

    return meetings;
  } catch (error) {
    console.error('Erreur lors de la planification des réunions:', error);
    return [];
  }
}

/**
 * Hook React pour générer automatiquement un workflow
 */
export function useWorkflowGeneration() {
  const generateOnboarding = async (employee, hireDate) => {
    const workflow = await generateWorkflow(employee, 'onboarding', hireDate);
    
    // Générer documents et planifier réunions
    await generateOnboardingDocuments(employee);
    await scheduleMeetings(employee, 'onboarding');
    
    return workflow;
  };

  const generateOffboarding = async (employee, departureDate) => {
    return await generateWorkflow(employee, 'offboarding', departureDate);
  };

  return {
    generateOnboarding,
    generateOffboarding
  };
}

export default {
  generateWorkflow,
  updateWorkflowProgress,
  generateOnboardingDocuments,
  scheduleMeetings,
  useWorkflowGeneration
};