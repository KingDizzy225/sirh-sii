import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, TrendingUp, User, Calendar } from "lucide-react";
import { format } from "date-fns";

export default function PerformanceCard({ review }) {
  const getRatingColor = (rating) => {
    if (rating >= 4.5) return "text-green-600 bg-green-50";
    if (rating >= 3.5) return "text-blue-600 bg-blue-50";
    if (rating >= 2.5) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  const categories = [
    { label: "Technical Skills", value: review.technical_skills },
    { label: "Communication", value: review.communication },
    { label: "Teamwork", value: review.teamwork },
    { label: "Leadership", value: review.leadership },
  ];

  return (
    <Card className="shadow-lg border-none overflow-hidden">
      <div className="h-2 bg-gradient-to-r from-blue-500 to-purple-600" />
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{review.employee_name}</h3>
              <p className="text-sm text-slate-600">{review.review_period}</p>
            </div>
          </div>
          <div className={`px-4 py-2 rounded-xl ${getRatingColor(review.overall_rating)}`}>
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 fill-current" />
              <span className="font-bold text-lg">{review.overall_rating.toFixed(1)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-sm text-slate-600 mb-4">
          <Calendar className="w-4 h-4" />
          <span>Reviewed on {format(new Date(review.review_date), 'MMM d, yyyy')}</span>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          {categories.map((category) => (
            <div key={category.label} className="p-3 rounded-lg bg-slate-50">
              <p className="text-xs text-slate-600 mb-1">{category.label}</p>
              <div className="flex items-center gap-2">
                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3 h-3 ${
                        i < category.value 
                          ? 'fill-yellow-400 text-yellow-400' 
                          : 'fill-slate-200 text-slate-200'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm font-semibold text-slate-900">{category.value}</span>
              </div>
            </div>
          ))}
        </div>

        {review.strengths && (
          <div className="p-3 rounded-lg bg-green-50 border border-green-200 mb-3">
            <p className="text-xs font-medium text-green-700 mb-1">Strengths</p>
            <p className="text-sm text-slate-700">{review.strengths}</p>
          </div>
        )}

        {review.areas_for_improvement && (
          <div className="p-3 rounded-lg bg-orange-50 border border-orange-200 mb-3">
            <p className="text-xs font-medium text-orange-700 mb-1">Areas for Improvement</p>
            <p className="text-sm text-slate-700">{review.areas_for_improvement}</p>
          </div>
        )}

        {review.goals && (
          <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <p className="text-xs font-medium text-blue-700">Goals</p>
            </div>
            <p className="text-sm text-slate-700">{review.goals}</p>
          </div>
        )}

        {review.reviewer_email && (
          <div className="mt-4 pt-4 border-t border-slate-200">
            <p className="text-xs text-slate-500">Reviewed by: {review.reviewer_email}</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}