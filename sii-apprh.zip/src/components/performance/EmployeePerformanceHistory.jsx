import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { format } from "date-fns";
import { User, TrendingUp, Calendar } from "lucide-react";

export default function EmployeePerformanceHistory({ employees, reviews }) {
  const [selectedEmployee, setSelectedEmployee] = useState("");

  const employeeReviews = reviews
    .filter(r => r.employee_email === selectedEmployee)
    .sort((a, b) => new Date(a.review_date) - new Date(b.review_date));

  // Données pour le graphique d'évolution
  const evolutionData = employeeReviews.map(review => ({
    periode: review.review_period,
    note: review.overall_rating,
    date: format(new Date(review.review_date), 'dd/MM/yyyy'),
  }));

  // Dernière évaluation pour le radar
  const latestReview = employeeReviews[employeeReviews.length - 1];
  const radarData = latestReview ? [
    { skill: 'Technique', value: latestReview.technical_skills },
    { skill: 'Communication', value: latestReview.communication },
    { skill: 'Travail d\'équipe', value: latestReview.teamwork },
    { skill: 'Leadership', value: latestReview.leadership },
  ] : [];

  const employee = employees.find(e => e.email === selectedEmployee);

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle>Sélectionner un employé</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
            <SelectTrigger>
              <SelectValue placeholder="Choisir un employé..." />
            </SelectTrigger>
            <SelectContent>
              {employees.map(emp => (
                <SelectItem key={emp.id} value={emp.email}>
                  {emp.full_name} - {emp.position}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedEmployee && employeeReviews.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <p className="text-slate-500">Aucune évaluation pour cet employé</p>
          </CardContent>
        </Card>
      )}

      {selectedEmployee && employeeReviews.length > 0 && (
        <>
          {/* Profil de l'employé */}
          <Card className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white">
                    {employee?.full_name?.charAt(0) || 'E'}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-slate-900">{employee?.full_name}</h3>
                  <p className="text-blue-600">{employee?.position}</p>
                  <p className="text-sm text-slate-600">{employee?.department}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-600">Nombre d'évaluations</p>
                  <p className="text-3xl font-bold text-blue-600">{employeeReviews.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Graphiques */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Évolution des performances
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={evolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="periode" />
                    <YAxis domain={[0, 5]} />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="note" 
                      stroke="#3b82f6" 
                      strokeWidth={2}
                      name="Note globale"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {latestReview && (
              <Card className="border-none shadow-lg">
                <CardHeader>
                  <CardTitle>Compétences actuelles</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={radarData}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="skill" />
                      <PolarRadiusAxis domain={[0, 5]} />
                      <Radar
                        name="Compétences"
                        dataKey="value"
                        stroke="#3b82f6"
                        fill="#3b82f6"
                        fillOpacity={0.6}
                      />
                      <Tooltip />
                    </RadarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Historique détaillé */}
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Historique des évaluations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {employeeReviews.reverse().map((review, index) => (
                  <div key={review.id} className="p-4 rounded-lg border border-slate-200 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-semibold text-slate-900">{review.review_period}</h4>
                          <Badge className="bg-blue-100 text-blue-800">
                            {review.overall_rating.toFixed(1)} ⭐
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-600">
                          {format(new Date(review.review_date), 'dd MMMM yyyy')}
                        </p>
                      </div>
                      <p className="text-xs text-slate-500">
                        Par {review.reviewer_email}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                      <div className="p-2 bg-slate-50 rounded">
                        <p className="text-xs text-slate-600">Technique</p>
                        <p className="font-semibold">{review.technical_skills}/5</p>
                      </div>
                      <div className="p-2 bg-slate-50 rounded">
                        <p className="text-xs text-slate-600">Communication</p>
                        <p className="font-semibold">{review.communication}/5</p>
                      </div>
                      <div className="p-2 bg-slate-50 rounded">
                        <p className="text-xs text-slate-600">Équipe</p>
                        <p className="font-semibold">{review.teamwork}/5</p>
                      </div>
                      <div className="p-2 bg-slate-50 rounded">
                        <p className="text-xs text-slate-600">Leadership</p>
                        <p className="font-semibold">{review.leadership}/5</p>
                      </div>
                    </div>

                    {review.strengths && (
                      <div className="mb-2">
                        <p className="text-xs font-medium text-green-700 mb-1">Points forts</p>
                        <p className="text-sm text-slate-700">{review.strengths}</p>
                      </div>
                    )}

                    {review.areas_for_improvement && (
                      <div className="mb-2">
                        <p className="text-xs font-medium text-orange-700 mb-1">Axes d'amélioration</p>
                        <p className="text-sm text-slate-700">{review.areas_for_improvement}</p>
                      </div>
                    )}

                    {review.goals && (
                      <div>
                        <p className="text-xs font-medium text-blue-700 mb-1">Objectifs fixés</p>
                        <p className="text-sm text-slate-700">{review.goals}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}