import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, Star } from "lucide-react";

export default function SelfAssessmentForm({ assessment, onSubmit, onCancel, isSubmitting }) {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState(assessment || {
    review_period: "",
    assessment_date: format(new Date(), 'yyyy-MM-dd'),
    technical_skills_rating: 3,
    communication_rating: 3,
    teamwork_rating: 3,
    leadership_rating: 3,
    overall_rating: 3,
    achievements: "",
    challenges: "",
    areas_for_growth: "",
    career_goals: "",
    training_needs: "",
    additional_comments: "",
    status: "draft"
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      employee_email: user.email,
      employee_name: user.full_name || user.email,
      status: "submitted"
    });
  };

  const saveDraft = () => {
    onSubmit({
      ...formData,
      employee_email: user.email,
      employee_name: user.full_name || user.email,
      status: "draft"
    });
  };

  const ratingCategories = [
    { key: "technical_skills_rating", label: "Compétences techniques", icon: "💻" },
    { key: "communication_rating", label: "Communication", icon: "💬" },
    { key: "teamwork_rating", label: "Travail d'équipe", icon: "👥" },
    { key: "leadership_rating", label: "Leadership", icon: "🎯" },
    { key: "overall_rating", label: "Évaluation globale", icon: "⭐" },
  ];

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Auto-évaluation de performance
          </DialogTitle>
        </DialogHeader>

        {user && (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">
                    {user.full_name?.charAt(0) || user.email.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{user.full_name || user.email}</p>
                  <p className="text-sm text-slate-600">Auto-évaluation de mes performances</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="review_period">Période d'évaluation *</Label>
              <Input
                id="review_period"
                value={formData.review_period}
                onChange={(e) => setFormData({...formData, review_period: e.target.value})}
                placeholder="ex: T1 2025, Année 2024"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="assessment_date">Date *</Label>
              <Input
                id="assessment_date"
                type="date"
                value={formData.assessment_date}
                onChange={(e) => setFormData({...formData, assessment_date: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <Star className="w-5 h-5 text-blue-600" />
              Mes auto-évaluations (1-5)
            </h3>
            <p className="text-sm text-slate-600">
              Évaluez honnêtement vos compétences et performances dans chaque domaine.
            </p>
            {ratingCategories.map(({ key, label, icon }) => (
              <div key={key} className="space-y-2 p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-2">
                    <span>{icon}</span>
                    {label}
                  </Label>
                  <Badge variant="outline" className="text-lg font-bold">
                    {formData[key]}/5
                  </Badge>
                </div>
                <Slider
                  value={[formData[key]]}
                  onValueChange={([value]) => setFormData({...formData, [key]: value})}
                  min={1}
                  max={5}
                  step={0.5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-slate-500">
                  <span>Insuffisant</span>
                  <span>Excellent</span>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-4 border-t pt-6">
            <h3 className="font-semibold text-slate-900">Mes réflexions</h3>

            <div className="space-y-2">
              <Label htmlFor="achievements">🏆 Réalisations principales</Label>
              <Textarea
                id="achievements"
                value={formData.achievements}
                onChange={(e) => setFormData({...formData, achievements: e.target.value})}
                rows={3}
                placeholder="Quelles sont vos principales réalisations durant cette période ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="challenges">⚠️ Défis rencontrés</Label>
              <Textarea
                id="challenges"
                value={formData.challenges}
                onChange={(e) => setFormData({...formData, challenges: e.target.value})}
                rows={3}
                placeholder="Quels défis avez-vous rencontrés ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="areas_for_growth">📈 Domaines de développement</Label>
              <Textarea
                id="areas_for_growth"
                value={formData.areas_for_growth}
                onChange={(e) => setFormData({...formData, areas_for_growth: e.target.value})}
                rows={3}
                placeholder="Dans quels domaines souhaitez-vous vous développer ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="career_goals">🎯 Objectifs de carrière</Label>
              <Textarea
                id="career_goals"
                value={formData.career_goals}
                onChange={(e) => setFormData({...formData, career_goals: e.target.value})}
                rows={3}
                placeholder="Quels sont vos objectifs de carrière à court et moyen terme ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="training_needs">📚 Besoins en formation</Label>
              <Textarea
                id="training_needs"
                value={formData.training_needs}
                onChange={(e) => setFormData({...formData, training_needs: e.target.value})}
                rows={3}
                placeholder="Quelles formations vous aideraient à progresser ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="additional_comments">💭 Commentaires additionnels</Label>
              <Textarea
                id="additional_comments"
                value={formData.additional_comments}
                onChange={(e) => setFormData({...formData, additional_comments: e.target.value})}
                rows={3}
                placeholder="Autres remarques ou suggestions..."
              />
            </div>
          </div>

          <div className="flex justify-between gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={saveDraft}
                disabled={isSubmitting}
              >
                💾 Enregistrer brouillon
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isSubmitting ? '⏳ Envoi...' : '✅ Soumettre l\'auto-évaluation'}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}