import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Plus, Target, Calendar, AlertCircle, CheckCircle } from "lucide-react";
import { format, isAfter, isBefore } from "date-fns";
import GoalForm from "./GoalForm";

const statusColors = {
  not_started: "bg-gray-100 text-gray-800",
  in_progress: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  delayed: "bg-red-100 text-red-800",
  cancelled: "bg-slate-100 text-slate-800",
};

const statusLabels = {
  not_started: "Non commencé",
  in_progress: "En cours",
  completed: "Terminé",
  delayed: "En retard",
  cancelled: "Annulé",
};

const priorityColors = {
  low: "bg-blue-100 text-blue-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-orange-100 text-orange-800",
  critical: "bg-red-100 text-red-800",
};

export default function GoalsTracking({ goals, employees, reviews }) {
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("all");

  const queryClient = useQueryClient();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.PerformanceGoal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
      setShowForm(false);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PerformanceGoal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['performanceGoals'] });
    },
  });

  // Vérifier les objectifs en retard
  const goalsWithStatus = goals.map(goal => {
    const isOverdue = goal.status !== 'completed' && goal.status !== 'cancelled' && 
                      isBefore(new Date(goal.target_date), new Date());
    return {
      ...goal,
      actualStatus: isOverdue ? 'delayed' : goal.status
    };
  });

  const filteredGoals = filter === "all" 
    ? goalsWithStatus 
    : goalsWithStatus.filter(g => g.actualStatus === filter);

  const handleUpdateProgress = (goalId, newProgress) => {
    let newStatus = 'in_progress';
    if (newProgress === 100) {
      newStatus = 'completed';
    } else if (newProgress === 0) {
      newStatus = 'not_started';
    }

    updateMutation.mutate({
      id: goalId,
      data: {
        progress_percentage: newProgress,
        status: newStatus,
        ...(newStatus === 'completed' && { completion_date: format(new Date(), 'yyyy-MM-dd') })
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex gap-2 flex-wrap">
          <Button
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
            size="sm"
          >
            Tous ({goalsWithStatus.length})
          </Button>
          <Button
            variant={filter === "in_progress" ? "default" : "outline"}
            onClick={() => setFilter("in_progress")}
            size="sm"
          >
            En cours ({goalsWithStatus.filter(g => g.actualStatus === 'in_progress').length})
          </Button>
          <Button
            variant={filter === "completed" ? "default" : "outline"}
            onClick={() => setFilter("completed")}
            size="sm"
          >
            Terminés ({goalsWithStatus.filter(g => g.actualStatus === 'completed').length})
          </Button>
          <Button
            variant={filter === "delayed" ? "default" : "outline"}
            onClick={() => setFilter("delayed")}
            size="sm"
            className="text-red-600"
          >
            En retard ({goalsWithStatus.filter(g => g.actualStatus === 'delayed').length})
          </Button>
        </div>

        <Button
          onClick={() => setShowForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouvel objectif
        </Button>
      </div>

      {filteredGoals.length === 0 ? (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <Target className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-500">Aucun objectif trouvé</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredGoals.map((goal) => (
            <Card key={goal.id} className="border-none shadow-lg">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Badge className={statusColors[goal.actualStatus]}>
                        {statusLabels[goal.actualStatus]}
                      </Badge>
                      <Badge className={priorityColors[goal.priority]} variant="outline">
                        Priorité {goal.priority}
                      </Badge>
                      {goal.actualStatus === 'delayed' && (
                        <Badge className="bg-red-100 text-red-800">
                          <AlertCircle className="w-3 h-3 mr-1" />
                          Retard
                        </Badge>
                      )}
                    </div>
                    <CardTitle className="text-lg">{goal.goal_title}</CardTitle>
                    <p className="text-sm text-slate-600 mt-1">{goal.employee_name}</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {goal.goal_description && (
                  <p className="text-sm text-slate-700">{goal.goal_description}</p>
                )}

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Progression</span>
                    <span className="font-semibold text-slate-900">{goal.progress_percentage}%</span>
                  </div>
                  <Progress value={goal.progress_percentage} className="h-2" />
                  {goal.actualStatus !== 'completed' && goal.actualStatus !== 'cancelled' && (
                    <div className="flex gap-2 mt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateProgress(goal.id, Math.min(100, goal.progress_percentage + 25))}
                      >
                        +25%
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleUpdateProgress(goal.id, 100)}
                      >
                        Marquer terminé
                      </Button>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Calendar className="w-4 h-4" />
                  <span>
                    Date cible: {format(new Date(goal.target_date), 'dd/MM/yyyy')}
                  </span>
                </div>

                {goal.completion_date && (
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    <span>
                      Terminé le {format(new Date(goal.completion_date), 'dd/MM/yyyy')}
                    </span>
                  </div>
                )}

                {goal.notes && (
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <p className="text-xs font-medium text-slate-700 mb-1">Notes</p>
                    <p className="text-sm text-slate-600">{goal.notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showForm && (
        <GoalForm
          employees={employees}
          reviews={reviews}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}
    </div>
  );
}