import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, TrendingUp, Users, Award, Calendar } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";
import { format, startOfYear, endOfYear, eachMonthOfInterval, isSameMonth } from "date-fns";

export default function PerformanceAnalytics({ reviews, employees, goals }) {
  // Analyse des tendances au fil du temps
  const currentYear = new Date().getFullYear();
  const yearStart = startOfYear(new Date());
  const yearEnd = endOfYear(new Date());
  const months = eachMonthOfInterval({ start: yearStart, end: yearEnd });

  const monthlyData = months.map(month => {
    const monthReviews = reviews.filter(r => 
      isSameMonth(new Date(r.review_date), month)
    );
    const avgRating = monthReviews.length > 0
      ? (monthReviews.reduce((sum, r) => sum + r.overall_rating, 0) / monthReviews.length).toFixed(2)
      : 0;
    
    return {
      month: format(month, 'MMM'),
      evaluations: monthReviews.length,
      moyenne: parseFloat(avgRating),
    };
  });

  // Comparaison des compétences moyennes
  const skillsAverage = {
    technical: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.technical_skills, 0) / reviews.length).toFixed(2) : 0,
    communication: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.communication, 0) / reviews.length).toFixed(2) : 0,
    teamwork: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.teamwork, 0) / reviews.length).toFixed(2) : 0,
    leadership: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.leadership, 0) / reviews.length).toFixed(2) : 0,
  };

  const skillsData = [
    { competence: 'Technique', moyenne: parseFloat(skillsAverage.technical) },
    { competence: 'Communication', moyenne: parseFloat(skillsAverage.communication) },
    { competence: 'Équipe', moyenne: parseFloat(skillsAverage.teamwork) },
    { competence: 'Leadership', moyenne: parseFloat(skillsAverage.leadership) },
  ];

  // Taux de réalisation des objectifs par catégorie
  const goalsByCategory = {};
  goals.forEach(goal => {
    if (!goalsByCategory[goal.category]) {
      goalsByCategory[goal.category] = { total: 0, completed: 0 };
    }
    goalsByCategory[goal.category].total += 1;
    if (goal.status === 'completed') {
      goalsByCategory[goal.category].completed += 1;
    }
  });

  const categoryData = Object.entries(goalsByCategory).map(([category, data]) => ({
    categorie: category,
    taux: data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0,
  }));

  const exportData = () => {
    const data = {
      resume: {
        total_evaluations: reviews.length,
        moyenne_globale: reviews.length > 0 
          ? (reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length).toFixed(2)
          : 0,
        total_objectifs: goals.length,
        objectifs_completes: goals.filter(g => g.status === 'completed').length,
      },
      competences_moyennes: skillsAverage,
      tendances_mensuelles: monthlyData,
      objectifs_par_categorie: categoryData,
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analyse_performances_${format(new Date(), 'yyyy-MM-dd')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-900">Analyses et Rapports</h2>
        <Button onClick={exportData} variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Exporter les données
        </Button>
      </div>

      {/* Statistiques clés */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total évaluations</p>
                <p className="text-3xl font-bold text-slate-900">{reviews.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Award className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Employés évalués</p>
                <p className="text-3xl font-bold text-slate-900">
                  {[...new Set(reviews.map(r => r.employee_email))].length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Note moyenne</p>
                <p className="text-3xl font-bold text-slate-900">
                  {reviews.length > 0 
                    ? (reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length).toFixed(2)
                    : 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Taux d'objectifs</p>
                <p className="text-3xl font-bold text-slate-900">
                  {goals.length > 0 
                    ? Math.round((goals.filter(g => g.status === 'completed').length / goals.length) * 100)
                    : 0}%
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques d'analyse */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Tendances mensuelles {currentYear}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis yAxisId="left" orientation="left" domain={[0, 5]} />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Legend />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="moyenne" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  name="Note moyenne"
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="evaluations" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  name="Nb évaluations"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle>Compétences moyennes (entreprise)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={skillsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="competence" />
                <YAxis domain={[0, 5]} />
                <Tooltip />
                <Bar dataKey="moyenne" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg lg:col-span-2">
          <CardHeader>
            <CardTitle>Taux de réalisation des objectifs par catégorie</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="categorie" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Bar dataKey="taux" fill="#10b981" name="Taux de réalisation (%)" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <Card className="border-none shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle>Insights et Recommandations</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {reviews.length === 0 && (
            <p className="text-sm text-slate-700">
              ⚠️ Aucune évaluation n'a encore été réalisée. Commencez par évaluer vos employés.
            </p>
          )}
          
          {reviews.length > 0 && parseFloat(skillsAverage.leadership) < 3.5 && (
            <p className="text-sm text-slate-700">
              💡 Le leadership est le domaine avec la note la plus basse ({skillsAverage.leadership}/5). 
              Envisagez des formations en management.
            </p>
          )}

          {goals.length > 0 && goals.filter(g => g.status === 'delayed').length > 0 && (
            <p className="text-sm text-slate-700">
              ⏰ {goals.filter(g => g.status === 'delayed').length} objectif(s) sont en retard. 
              Une revue avec les employés concernés est recommandée.
            </p>
          )}

          {employees.length > 0 && reviews.length > 0 && 
           (reviews.length / employees.length) < 1 && (
            <p className="text-sm text-slate-700">
              📊 Seulement {Math.round((reviews.length / employees.length) * 100)}% de vos employés ont été évalués. 
              Planifiez des évaluations pour les autres.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}