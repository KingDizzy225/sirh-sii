import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  Award, 
  Target, 
  Users, 
  Calendar,
  Star,
  MessageSquare,
  CheckCircle
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from "recharts";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export default function PerformanceDashboard({ reviews, goals, selfAssessments, peerFeedbacks, employees }) {
  // Stats globales
  const totalReviews = reviews.length;
  const totalGoals = goals.length;
  const completedGoals = goals.filter(g => g.status === 'completed').length;
  const goalCompletionRate = totalGoals > 0 ? Math.round((completedGoals / totalGoals) * 100) : 0;
  
  const totalSelfAssessments = selfAssessments.length;
  const submittedSelfAssessments = selfAssessments.filter(s => s.status === 'submitted' || s.status === 'reviewed').length;
  
  const totalPeerFeedbacks = peerFeedbacks.length;
  const submittedPeerFeedbacks = peerFeedbacks.filter(p => p.status === 'submitted' || p.status === 'reviewed').length;

  // Moyenne des évaluations
  const avgOverallRating = reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.overall_rating, 0) / reviews.length).toFixed(1)
    : 0;

  // Distribution des évaluations par note
  const ratingDistribution = [
    { name: '1-2', count: reviews.filter(r => r.overall_rating < 2.5).length },
    { name: '2-3', count: reviews.filter(r => r.overall_rating >= 2.5 && r.overall_rating < 3.5).length },
    { name: '3-4', count: reviews.filter(r => r.overall_rating >= 3.5 && r.overall_rating < 4.5).length },
    { name: '4-5', count: reviews.filter(r => r.overall_rating >= 4.5).length },
  ];

  // Distribution des objectifs par statut
  const goalStatusDistribution = [
    { name: 'Non démarrés', value: goals.filter(g => g.status === 'not_started').length },
    { name: 'En cours', value: goals.filter(g => g.status === 'in_progress').length },
    { name: 'Terminés', value: goals.filter(g => g.status === 'completed').length },
    { name: 'En retard', value: goals.filter(g => g.status === 'delayed').length },
  ].filter(item => item.value > 0);

  // Évolution des évaluations par compétence
  const avgBySkill = [
    {
      skill: 'Technique',
      moyenne: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.technical_skills, 0) / reviews.length).toFixed(1) : 0
    },
    {
      skill: 'Communication',
      moyenne: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.communication, 0) / reviews.length).toFixed(1) : 0
    },
    {
      skill: 'Équipe',
      moyenne: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.teamwork, 0) / reviews.length).toFixed(1) : 0
    },
    {
      skill: 'Leadership',
      moyenne: reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.leadership, 0) / reviews.length).toFixed(1) : 0
    },
  ];

  // Top 5 employés par nombre d'objectifs complétés
  const employeeGoalCompletion = employees.map(emp => {
    const empGoals = goals.filter(g => g.employee_email === emp.email);
    const completed = empGoals.filter(g => g.status === 'completed').length;
    return {
      name: emp.full_name,
      completed,
      total: empGoals.length
    };
  }).filter(e => e.total > 0)
    .sort((a, b) => b.completed - a.completed)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Évaluations</p>
                <p className="text-3xl font-bold text-blue-900">{totalReviews}</p>
                <p className="text-xs text-blue-600 mt-1">Moyenne: {avgOverallRating}/5</p>
              </div>
              <Award className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Objectifs</p>
                <p className="text-3xl font-bold text-green-900">{totalGoals}</p>
                <p className="text-xs text-green-600 mt-1">{goalCompletionRate}% complétés</p>
              </div>
              <Target className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Auto-évaluations</p>
                <p className="text-3xl font-bold text-purple-900">{submittedSelfAssessments}</p>
                <p className="text-xs text-purple-600 mt-1">sur {totalSelfAssessments}</p>
              </div>
              <Star className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Feedbacks pairs</p>
                <p className="text-3xl font-bold text-orange-900">{submittedPeerFeedbacks}</p>
                <p className="text-xs text-orange-600 mt-1">sur {totalPeerFeedbacks}</p>
              </div>
              <MessageSquare className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Distribution des évaluations */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Distribution des évaluations</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={ratingDistribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Statut des objectifs */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Statut des objectifs</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={goalStatusDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {goalStatusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Moyennes par compétence */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Moyennes par compétence</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={avgBySkill} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" domain={[0, 5]} />
                <YAxis dataKey="skill" type="category" width={100} />
                <Tooltip />
                <Bar dataKey="moyenne" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top employés - objectifs complétés */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">Top 5 - Objectifs complétés</CardTitle>
          </CardHeader>
          <CardContent>
            {employeeGoalCompletion.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-8">Aucune donnée disponible</p>
            ) : (
              <div className="space-y-4">
                {employeeGoalCompletion.map((emp, index) => {
                  const completionRate = emp.total > 0 ? Math.round((emp.completed / emp.total) * 100) : 0;
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="w-6 h-6 flex items-center justify-center p-0">
                            {index + 1}
                          </Badge>
                          <span className="text-sm font-medium">{emp.name}</span>
                        </div>
                        <span className="text-sm font-bold text-green-600">
                          {emp.completed}/{emp.total}
                        </span>
                      </div>
                      <Progress value={completionRate} className="h-2" />
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            Insights et recommandations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {avgOverallRating >= 4 && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">
                  ✅ Excellentes performances globales avec une moyenne de {avgOverallRating}/5
                </p>
              </div>
            )}

            {goalCompletionRate < 50 && totalGoals > 0 && (
              <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <p className="text-sm text-orange-800">
                  ⚠️ Taux de complétion des objectifs à {goalCompletionRate}%. Envisagez un suivi renforcé.
                </p>
              </div>
            )}

            {submittedSelfAssessments < employees.length / 2 && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-800">
                  💡 Encouragez davantage d'auto-évaluations ({submittedSelfAssessments} soumises sur {employees.length} employés)
                </p>
              </div>
            )}

            {submittedPeerFeedbacks < 10 && (
              <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                <p className="text-sm text-purple-800">
                  👥 Promouvoir le feedback entre pairs pour une évaluation à 360°
                </p>
              </div>
            )}

            {reviews.length === 0 && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <p className="text-sm text-slate-600">
                  📊 Commencez par créer des évaluations de performance pour suivre les progrès des employés
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}