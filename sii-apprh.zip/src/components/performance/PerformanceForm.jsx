import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";

export default function PerformanceForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    review_period: "",
    review_date: format(new Date(), 'yyyy-MM-dd'),
    overall_rating: 3,
    technical_skills: 3,
    communication: 3,
    teamwork: 3,
    leadership: 3,
    strengths: "",
    areas_for_improvement: "",
    goals: "",
    comments: "",
  });

  const [reviewer, setReviewer] = useState(null);

  useEffect(() => {
    const loadReviewer = async () => {
      try {
        const user = await base44.auth.me();
        setReviewer(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadReviewer();
  }, []);

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      employee_email: email,
      employee_name: employee?.full_name || ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      reviewer_email: reviewer?.email || ""
    });
  };

  const ratingCategories = [
    { key: "overall_rating", label: "Évaluation globale" },
    { key: "technical_skills", label: "Compétences techniques" },
    { key: "communication", label: "Communication" },
    { key: "teamwork", label: "Travail d'équipe" },
    { key: "leadership", label: "Leadership" },
  ];

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nouvelle évaluation de performance</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="employee">Employé *</Label>
              <Select
                value={formData.employee_email}
                onValueChange={handleEmployeeChange}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un employé" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="review_period">Période d'évaluation *</Label>
              <Input
                id="review_period"
                value={formData.review_period}
                onChange={(e) => setFormData({...formData, review_period: e.target.value})}
                placeholder="ex: T1 2025"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="review_date">Date d'évaluation *</Label>
              <Input
                id="review_date"
                type="date"
                value={formData.review_date}
                onChange={(e) => setFormData({...formData, review_date: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Évaluations (1-5)</h3>
            {ratingCategories.map(({ key, label }) => (
              <div key={key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>{label}</Label>
                  <span className="text-sm font-semibold text-blue-600">{formData[key]}</span>
                </div>
                <Slider
                  value={[formData[key]]}
                  onValueChange={([value]) => setFormData({...formData, [key]: value})}
                  min={1}
                  max={5}
                  step={0.5}
                  className="w-full"
                />
              </div>
            ))}
          </div>

          <div className="space-y-2">
            <Label htmlFor="strengths">Points forts</Label>
            <Textarea
              id="strengths"
              value={formData.strengths}
              onChange={(e) => setFormData({...formData, strengths: e.target.value})}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="areas_for_improvement">Axes d'amélioration</Label>
            <Textarea
              id="areas_for_improvement"
              value={formData.areas_for_improvement}
              onChange={(e) => setFormData({...formData, areas_for_improvement: e.target.value})}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="goals">Objectifs pour la prochaine période</Label>
            <Textarea
              id="goals"
              value={formData.goals}
              onChange={(e) => setFormData({...formData, goals: e.target.value})}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="comments">Commentaires additionnels</Label>
            <Textarea
              id="comments"
              value={formData.comments}
              onChange={(e) => setFormData({...formData, comments: e.target.value})}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Enregistrement...' : 'Soumettre l\'évaluation'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}