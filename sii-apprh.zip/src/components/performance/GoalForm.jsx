import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";

export default function GoalForm({ employees, reviews, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    review_id: "",
    goal_title: "",
    goal_description: "",
    category: "technical",
    target_date: "",
    priority: "medium",
    status: "not_started",
    progress_percentage: 0,
    notes: "",
  });

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      employee_email: email,
      employee_name: employee?.full_name || ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const employeeReviews = reviews.filter(r => r.employee_email === formData.employee_email);

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nouvel objectif de performance</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="employee">Employé *</Label>
              <Select
                value={formData.employee_email}
                onValueChange={handleEmployeeChange}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un employé" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {employeeReviews.length > 0 && (
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="review">Lier à une évaluation (optionnel)</Label>
                <Select
                  value={formData.review_id}
                  onValueChange={(value) => setFormData({...formData, review_id: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner une évaluation" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Aucune évaluation</SelectItem>
                    {employeeReviews.map(review => (
                      <SelectItem key={review.id} value={review.id}>
                        {review.review_period} - {format(new Date(review.review_date), 'dd/MM/yyyy')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="goal_title">Titre de l'objectif *</Label>
              <Input
                id="goal_title"
                value={formData.goal_title}
                onChange={(e) => setFormData({...formData, goal_title: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="goal_description">Description</Label>
              <Textarea
                id="goal_description"
                value={formData.goal_description}
                onChange={(e) => setFormData({...formData, goal_description: e.target.value})}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Catégorie</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({...formData, category: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical">Technique</SelectItem>
                  <SelectItem value="leadership">Leadership</SelectItem>
                  <SelectItem value="communication">Communication</SelectItem>
                  <SelectItem value="productivity">Productivité</SelectItem>
                  <SelectItem value="development">Développement</SelectItem>
                  <SelectItem value="other">Autre</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priorité</Label>
              <Select
                value={formData.priority}
                onValueChange={(value) => setFormData({...formData, priority: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Basse</SelectItem>
                  <SelectItem value="medium">Moyenne</SelectItem>
                  <SelectItem value="high">Haute</SelectItem>
                  <SelectItem value="critical">Critique</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="target_date">Date cible *</Label>
              <Input
                id="target_date"
                type="date"
                value={formData.target_date}
                onChange={(e) => setFormData({...formData, target_date: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                rows={2}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Création...' : 'Créer l\'objectif'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}