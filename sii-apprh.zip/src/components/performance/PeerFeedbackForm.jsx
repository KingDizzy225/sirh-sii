import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Star, Lock } from "lucide-react";

export default function PeerFeedbackForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    reviewed_employee_email: "",
    reviewed_employee_name: "",
    review_period: "",
    feedback_date: format(new Date(), 'yyyy-MM-dd'),
    collaboration_rating: 3,
    communication_rating: 3,
    reliability_rating: 3,
    technical_expertise_rating: 3,
    overall_rating: 3,
    strengths: "",
    areas_for_improvement: "",
    specific_examples: "",
    additional_comments: "",
    is_anonymous: false,
    status: "draft"
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      reviewed_employee_email: email,
      reviewed_employee_name: employee?.full_name || ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      reviewer_email: user.email,
      reviewer_name: user.full_name || user.email,
      status: "submitted"
    });
  };

  const saveDraft = () => {
    onSubmit({
      ...formData,
      reviewer_email: user.email,
      reviewer_name: user.full_name || user.email,
      status: "draft"
    });
  };

  const ratingCategories = [
    { key: "collaboration_rating", label: "Collaboration", icon: "🤝", description: "Travail en équipe, coopération" },
    { key: "communication_rating", label: "Communication", icon: "💬", description: "Clarté, écoute, partage d'informations" },
    { key: "reliability_rating", label: "Fiabilité", icon: "✅", description: "Respect des engagements, ponctualité" },
    { key: "technical_expertise_rating", label: "Expertise technique", icon: "💡", description: "Compétences et connaissances techniques" },
    { key: "overall_rating", label: "Évaluation globale", icon: "⭐", description: "Impression générale de collaboration" },
  ];

  // Filtrer les employés pour ne pas pouvoir s'auto-évaluer
  const availableEmployees = employees.filter(emp => emp.email !== user?.email);

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Feedback collègue
          </DialogTitle>
        </DialogHeader>

        {user && (
          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">
                    {user.full_name?.charAt(0) || user.email.charAt(0)}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">{user.full_name || user.email}</p>
                  <p className="text-sm text-slate-600">Vous donnez un feedback à un collègue</p>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="anonymous"
                    checked={formData.is_anonymous}
                    onCheckedChange={(checked) => setFormData({...formData, is_anonymous: checked})}
                  />
                  <Label htmlFor="anonymous" className="text-sm cursor-pointer flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    Anonyme
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="reviewed_employee">Collègue à évaluer *</Label>
              <Select
                value={formData.reviewed_employee_email}
                onValueChange={handleEmployeeChange}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un collègue" />
                </SelectTrigger>
                <SelectContent>
                  {availableEmployees.map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="review_period">Période d'évaluation *</Label>
              <Select
                value={formData.review_period}
                onValueChange={(value) => setFormData({...formData, review_period: value})}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner une période" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="T1 2025">T1 2025</SelectItem>
                  <SelectItem value="T2 2025">T2 2025</SelectItem>
                  <SelectItem value="T3 2025">T3 2025</SelectItem>
                  <SelectItem value="T4 2025">T4 2025</SelectItem>
                  <SelectItem value="Année 2025">Année 2025</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <Star className="w-5 h-5 text-purple-600" />
              Évaluations (1-5)
            </h3>
            <p className="text-sm text-slate-600">
              Évaluez votre collègue de manière constructive et objective, basée sur votre expérience de collaboration.
            </p>
            {ratingCategories.map(({ key, label, icon, description }) => (
              <div key={key} className="space-y-2 p-4 bg-slate-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <Label className="flex items-center gap-2 mb-1">
                      <span>{icon}</span>
                      {label}
                    </Label>
                    <p className="text-xs text-slate-500">{description}</p>
                  </div>
                  <Badge variant="outline" className="text-lg font-bold">
                    {formData[key]}/5
                  </Badge>
                </div>
                <Slider
                  value={[formData[key]]}
                  onValueChange={([value]) => setFormData({...formData, [key]: value})}
                  min={1}
                  max={5}
                  step={0.5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-slate-500">
                  <span>À améliorer</span>
                  <span>Excellent</span>
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-4 border-t pt-6">
            <h3 className="font-semibold text-slate-900">Feedback détaillé</h3>

            <div className="space-y-2">
              <Label htmlFor="strengths">✨ Points forts</Label>
              <Textarea
                id="strengths"
                value={formData.strengths}
                onChange={(e) => setFormData({...formData, strengths: e.target.value})}
                rows={3}
                placeholder="Quels sont les points forts de ce collègue dans votre collaboration ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="areas_for_improvement">📈 Axes d'amélioration</Label>
              <Textarea
                id="areas_for_improvement"
                value={formData.areas_for_improvement}
                onChange={(e) => setFormData({...formData, areas_for_improvement: e.target.value})}
                rows={3}
                placeholder="Quels aspects pourraient être améliorés ?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="specific_examples">📝 Exemples concrets</Label>
              <Textarea
                id="specific_examples"
                value={formData.specific_examples}
                onChange={(e) => setFormData({...formData, specific_examples: e.target.value})}
                rows={3}
                placeholder="Partagez des exemples concrets de situations de collaboration..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="additional_comments">💭 Commentaires additionnels</Label>
              <Textarea
                id="additional_comments"
                value={formData.additional_comments}
                onChange={(e) => setFormData({...formData, additional_comments: e.target.value})}
                rows={2}
                placeholder="Autres remarques..."
              />
            </div>
          </div>

          {formData.is_anonymous && (
            <Card className="bg-amber-50 border-amber-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-2">
                  <Lock className="w-4 h-4 text-amber-700 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-amber-900">Feedback anonyme</p>
                    <p className="text-xs text-amber-700">
                      Votre identité ne sera pas révélée au collègue évalué. Seuls les RH auront accès à cette information.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-between gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={saveDraft}
                disabled={isSubmitting}
              >
                💾 Enregistrer brouillon
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isSubmitting ? '⏳ Envoi...' : '✅ Soumettre le feedback'}
              </Button>
            </div>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}