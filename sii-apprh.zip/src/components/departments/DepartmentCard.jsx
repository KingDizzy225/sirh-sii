import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, Edit, User } from "lucide-react";

const colors = [
  "from-blue-500 to-blue-600",
  "from-green-500 to-green-600",
  "from-purple-500 to-purple-600",
  "from-orange-500 to-orange-600",
  "from-pink-500 to-pink-600",
  "from-indigo-500 to-indigo-600",
];

export default function DepartmentCard({ department, employees, onEdit }) {
  const colorIndex = Math.abs(department.name.charCodeAt(0)) % colors.length;

  return (
    <Card className="hover:shadow-xl transition-all duration-300 border-none shadow-lg overflow-hidden">
      <div className={`h-32 bg-gradient-to-br ${colors[colorIndex]} p-6 relative`}>
        <div className="absolute inset-0 bg-black opacity-10" />
        <div className="relative">
          <div className="w-16 h-16 bg-white rounded-xl shadow-lg flex items-center justify-center mb-3">
            <Building2 className="w-8 h-8 text-slate-700" />
          </div>
        </div>
      </div>
      
      <CardContent className="p-6 -mt-8 relative">
        <div className="bg-white rounded-lg p-4 shadow-md mb-4">
          <h3 className="font-bold text-xl text-slate-900 mb-2">{department.name}</h3>
          {department.description && (
            <p className="text-sm text-slate-600 line-clamp-2">{department.description}</p>
          )}
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-slate-600">Employés</span>
            </div>
            <span className="font-semibold text-slate-900">{employees.length}</span>
          </div>

          {department.manager_email && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-slate-50">
              <User className="w-4 h-4 text-purple-600" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-slate-500">Responsable</p>
                <p className="text-sm font-medium text-slate-900 truncate">{department.manager_email}</p>
              </div>
            </div>
          )}
        </div>

        <Button
          variant="outline"
          onClick={onEdit}
          className="w-full"
        >
          <Edit className="w-4 h-4 mr-2" />
          Modifier
        </Button>
      </CardContent>
    </Card>
  );
}