import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Heart } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SocialWorkerCaseForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    case_type: "soutien_personnel",
    subject: "",
    description: "",
    status: "nouveau",
    priority: "moyenne",
    assigned_to_social_worker_email: "",
    assigned_to_social_worker_name: "",
    notes: "",
    follow_up_needed: false,
    next_follow_up_date: "",
    is_confidential: true,
    created_by_employee: false,
  });

  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
        // Auto-assigner l'assistante sociale actuelle
        setFormData(prev => ({
          ...prev,
          assigned_to_social_worker_email: user.email,
          assigned_to_social_worker_name: user.full_name || user.email,
        }));
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleEmployeeChange = (employeeId) => {
    const employee = employees.find(e => e.id === employeeId);
    setFormData({
      ...formData,
      employee_email: employee?.email || "",
      employee_name: employee?.full_name || ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const caseTypes = [
    { value: "soutien_personnel", label: "💙 Soutien personnel" },
    { value: "aide_administrative", label: "📋 Aide administrative" },
    { value: "conflit", label: "⚖️ Gestion de conflit" },
    { value: "conseil", label: "💬 Conseil" },
    { value: "urgence_sociale", label: "🚨 Urgence sociale" },
    { value: "accompagnement_familial", label: "👨‍👩‍👧‍👦 Accompagnement familial" },
    { value: "sante_mentale", label: "🧠 Santé mentale" },
    { value: "autre", label: "📁 Autre" },
  ];

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-600" />
            Nouveau dossier social
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employee Selection */}
          <div className="space-y-2">
            <Label htmlFor="employee">Employé concerné *</Label>
            <Select
              value={formData.employee_email}
              onValueChange={handleEmployeeChange}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un employé" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{emp.full_name}</span>
                      <span className="text-xs text-slate-500">
                        {emp.position ? `- ${emp.position}` : ''}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Case Type */}
          <div className="space-y-2">
            <Label htmlFor="case_type">Type de dossier *</Label>
            <Select
              value={formData.case_type}
              onValueChange={(value) => setFormData({...formData, case_type: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {caseTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Subject */}
          <div className="space-y-2">
            <Label htmlFor="subject">Sujet *</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({...formData, subject: e.target.value})}
              placeholder="ex: Demande d'accompagnement personnel"
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description de la situation *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={4}
              placeholder="Décrivez la situation en détail..."
              required
            />
          </div>

          {/* Priority and Status */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Priorité</Label>
              <Select
                value={formData.priority}
                onValueChange={(value) => setFormData({...formData, priority: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="faible">Faible</SelectItem>
                  <SelectItem value="moyenne">Moyenne</SelectItem>
                  <SelectItem value="elevee">Élevée</SelectItem>
                  <SelectItem value="urgente">⚠️ Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Statut</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({...formData, status: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nouveau">Nouveau</SelectItem>
                  <SelectItem value="en_cours">En cours</SelectItem>
                  <SelectItem value="en_attente">En attente</SelectItem>
                  <SelectItem value="resolu">Résolu</SelectItem>
                  <SelectItem value="cloture">Clôturé</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes confidentielles (optionnel)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
              placeholder="Notes internes pour l'assistante sociale..."
            />
          </div>

          {/* Follow-up */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="follow_up_needed"
                checked={formData.follow_up_needed}
                onCheckedChange={(checked) => setFormData({...formData, follow_up_needed: checked})}
              />
              <Label htmlFor="follow_up_needed" className="cursor-pointer">
                Nécessite un suivi
              </Label>
            </div>

            {formData.follow_up_needed && (
              <div className="space-y-2">
                <Label htmlFor="next_follow_up_date">Date du prochain suivi</Label>
                <Input
                  id="next_follow_up_date"
                  type="date"
                  value={formData.next_follow_up_date}
                  onChange={(e) => setFormData({...formData, next_follow_up_date: e.target.value})}
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            )}
          </div>

          {/* Confidentiality */}
          <div className="flex items-center space-x-2 p-3 bg-pink-50 rounded-lg border border-pink-200">
            <Checkbox
              id="is_confidential"
              checked={formData.is_confidential}
              onCheckedChange={(checked) => setFormData({...formData, is_confidential: checked})}
            />
            <Label htmlFor="is_confidential" className="cursor-pointer text-sm">
              🔒 Dossier confidentiel (recommandé)
            </Label>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.employee_email} 
              className="bg-pink-600 hover:bg-pink-700"
            >
              {isSubmitting ? 'Création...' : 'Créer le dossier'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}