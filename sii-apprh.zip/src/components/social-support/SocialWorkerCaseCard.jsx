import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, Calendar, Eye, Trash2, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusColors = {
  nouveau: "bg-orange-100 text-orange-800 border-orange-200",
  en_cours: "bg-blue-100 text-blue-800 border-blue-200",
  en_attente: "bg-yellow-100 text-yellow-800 border-yellow-200",
  resolu: "bg-green-100 text-green-800 border-green-200",
  cloture: "bg-gray-100 text-gray-800 border-gray-200",
};

const statusLabels = {
  nouveau: "Nouveau",
  en_cours: "En cours",
  en_attente: "En attente",
  resolu: "Résolu",
  cloture: "Clôturé",
};

const priorityColors = {
  faible: "bg-gray-100 text-gray-800",
  moyenne: "bg-blue-100 text-blue-800",
  elevee: "bg-orange-100 text-orange-800",
  urgente: "bg-red-100 text-red-800",
};

const priorityLabels = {
  faible: "Faible",
  moyenne: "Moyenne",
  elevee: "Élevée",
  urgente: "Urgente ⚠️",
};

const caseTypeLabels = {
  soutien_personnel: "Soutien personnel",
  aide_administrative: "Aide administrative",
  conflit: "Gestion de conflit",
  conseil: "Conseil",
  urgence_sociale: "Urgence sociale",
  accompagnement_familial: "Accompagnement familial",
  sante_mentale: "Santé mentale",
  autre: "Autre",
};

const caseTypeIcons = {
  soutien_personnel: "💙",
  aide_administrative: "📋",
  conflit: "⚖️",
  conseil: "💬",
  urgence_sociale: "🚨",
  accompagnement_familial: "👨‍👩‍👧‍👦",
  sante_mentale: "🧠",
  autre: "📁",
};

export default function SocialWorkerCaseCard({ caseItem, onView, onDelete }) {
  const statusColor = statusColors[caseItem.status] || statusColors["nouveau"];
  const priorityColor = priorityColors[caseItem.priority] || priorityColors["moyenne"];
  const typeLabel = caseTypeLabels[caseItem.case_type] || caseItem.case_type;
  const typeIcon = caseTypeIcons[caseItem.case_type] || "📁";

  return (
    <Card className="hover:shadow-xl transition-all duration-300 border-none shadow-lg group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center shadow-md text-2xl">
            {typeIcon}
          </div>
          <div className="flex flex-col items-end gap-2">
            <Badge className={`${statusColor} border`}>
              {statusLabels[caseItem.status]}
            </Badge>
            <Badge className={priorityColor}>
              {priorityLabels[caseItem.priority]}
            </Badge>
          </div>
        </div>

        <div className="mb-3">
          <Badge variant="outline" className="mb-2 bg-pink-50 text-pink-700 border-pink-200">
            {typeLabel}
          </Badge>
          <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2">
            {caseItem.subject}
          </h3>
        </div>

        {caseItem.description && (
          <p className="text-sm text-slate-600 mb-4 line-clamp-2">
            {caseItem.description}
          </p>
        )}

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <User className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span className="truncate">{caseItem.employee_name}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span>{format(new Date(caseItem.start_date || caseItem.created_date), 'dd/MM/yyyy', { locale: fr })}</span>
          </div>
          {caseItem.follow_up_needed && (
            <div className="flex items-center gap-2 text-sm text-orange-600">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span className="font-medium">Suivi requis</span>
            </div>
          )}
        </div>

        {caseItem.assigned_to_social_worker_name && (
          <div className="mb-4 p-2 bg-pink-50 rounded-lg border border-pink-100">
            <p className="text-xs text-slate-600">Assigné à:</p>
            <p className="text-sm font-medium text-pink-700">{caseItem.assigned_to_social_worker_name}</p>
          </div>
        )}

        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => onView(caseItem)}
          >
            <Eye className="w-4 h-4 mr-2" />
            Voir
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => onDelete(caseItem.id)}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}