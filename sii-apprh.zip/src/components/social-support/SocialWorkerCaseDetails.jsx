import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  User, Calendar, Heart, AlertCircle, FileText, 
  Clock, CheckCircle, Edit, Save, X 
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusColors = {
  nouveau: "bg-orange-100 text-orange-800 border-orange-200",
  en_cours: "bg-blue-100 text-blue-800 border-blue-200",
  en_attente: "bg-yellow-100 text-yellow-800 border-yellow-200",
  resolu: "bg-green-100 text-green-800 border-green-200",
  cloture: "bg-gray-100 text-gray-800 border-gray-200",
};

const statusLabels = {
  nouveau: "Nouveau",
  en_cours: "En cours",
  en_attente: "En attente",
  resolu: "Résolu",
  cloture: "Clôturé",
};

const priorityColors = {
  faible: "bg-gray-100 text-gray-800",
  moyenne: "bg-blue-100 text-blue-800",
  elevee: "bg-orange-100 text-orange-800",
  urgente: "bg-red-100 text-red-800",
};

const priorityLabels = {
  faible: "Faible",
  moyenne: "Moyenne",
  elevee: "Élevée",
  urgente: "Urgente ⚠️",
};

const caseTypeLabels = {
  soutien_personnel: "💙 Soutien personnel",
  aide_administrative: "📋 Aide administrative",
  conflit: "⚖️ Gestion de conflit",
  conseil: "💬 Conseil",
  urgence_sociale: "🚨 Urgence sociale",
  accompagnement_familial: "👨‍👩‍👧‍👦 Accompagnement familial",
  sante_mentale: "🧠 Santé mentale",
  autre: "📁 Autre",
};

export default function SocialWorkerCaseDetails({ caseItem, onClose, onUpdate, isUpdating }) {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    status: caseItem.status,
    priority: caseItem.priority,
    notes: caseItem.notes || "",
    actions_taken: caseItem.actions_taken || "",
    follow_up_needed: caseItem.follow_up_needed || false,
    next_follow_up_date: caseItem.next_follow_up_date || "",
    resolution_date: caseItem.resolution_date || "",
  });

  const handleSave = () => {
    onUpdate(formData);
    setIsEditing(false);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <Heart className="w-6 h-6 text-pink-600" />
              <div>
                <DialogTitle className="text-xl">{caseItem.subject}</DialogTitle>
                <div className="flex items-center gap-2 mt-2">
                  <Badge className={`${statusColors[caseItem.status]} border`}>
                    {statusLabels[caseItem.status]}
                  </Badge>
                  <Badge className={priorityColors[caseItem.priority]}>
                    {priorityLabels[caseItem.priority]}
                  </Badge>
                  <Badge variant="outline" className="bg-pink-50 text-pink-700">
                    {caseTypeLabels[caseItem.case_type]}
                  </Badge>
                </div>
              </div>
            </div>
            {!isEditing && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="gap-2"
              >
                <Edit className="w-4 h-4" />
                Modifier
              </Button>
            )}
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-6">
          {/* Informations employé */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <User className="w-5 h-5" />
                Employé concerné
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">
                    {caseItem.employee_name?.charAt(0) || 'E'}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{caseItem.employee_name}</p>
                  <p className="text-sm text-slate-600">{caseItem.employee_email}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <FileText className="w-5 h-5" />
                Description de la situation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-700 whitespace-pre-wrap">{caseItem.description}</p>
            </CardContent>
          </Card>

          {/* Dates */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Calendar className="w-5 h-5" />
                Dates importantes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="p-3 bg-slate-50 rounded-lg">
                  <p className="text-xs text-slate-600 mb-1">Date d'ouverture</p>
                  <p className="font-medium">
                    {format(new Date(caseItem.start_date || caseItem.created_date), 'dd/MM/yyyy', { locale: fr })}
                  </p>
                </div>

                {caseItem.last_update_date && (
                  <div className="p-3 bg-slate-50 rounded-lg">
                    <p className="text-xs text-slate-600 mb-1">Dernière mise à jour</p>
                    <p className="font-medium">
                      {format(new Date(caseItem.last_update_date), "dd/MM/yyyy 'à' HH:mm", { locale: fr })}
                    </p>
                  </div>
                )}

                {caseItem.resolution_date && (
                  <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-xs text-green-700 mb-1">Date de résolution</p>
                    <p className="font-medium text-green-900">
                      {format(new Date(caseItem.resolution_date), 'dd/MM/yyyy', { locale: fr })}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Assistante sociale assignée */}
          {caseItem.assigned_to_social_worker_name && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Heart className="w-5 h-5" />
                  Assistante sociale assignée
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 p-4 bg-pink-50 rounded-lg border border-pink-200">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-pink-600 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {caseItem.assigned_to_social_worker_name?.charAt(0) || 'A'}
                    </span>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900">{caseItem.assigned_to_social_worker_name}</p>
                    {caseItem.assigned_to_social_worker_email && (
                      <p className="text-sm text-slate-600">{caseItem.assigned_to_social_worker_email}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Section éditable */}
          {isEditing ? (
            <Card className="border-2 border-blue-500">
              <CardHeader className="bg-blue-50">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Edit className="w-5 h-5" />
                  Modification du dossier
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="status">Statut</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData({...formData, status: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="nouveau">Nouveau</SelectItem>
                        <SelectItem value="en_cours">En cours</SelectItem>
                        <SelectItem value="en_attente">En attente</SelectItem>
                        <SelectItem value="resolu">Résolu</SelectItem>
                        <SelectItem value="cloture">Clôturé</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="priority">Priorité</Label>
                    <Select
                      value={formData.priority}
                      onValueChange={(value) => setFormData({...formData, priority: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="faible">Faible</SelectItem>
                        <SelectItem value="moyenne">Moyenne</SelectItem>
                        <SelectItem value="elevee">Élevée</SelectItem>
                        <SelectItem value="urgente">⚠️ Urgente</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="actions_taken">Actions entreprises</Label>
                  <Textarea
                    id="actions_taken"
                    value={formData.actions_taken}
                    onChange={(e) => setFormData({...formData, actions_taken: e.target.value})}
                    rows={4}
                    placeholder="Décrivez les actions que vous avez entreprises..."
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes confidentielles</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    rows={4}
                    placeholder="Notes internes..."
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="follow_up_needed"
                      checked={formData.follow_up_needed}
                      onCheckedChange={(checked) => setFormData({...formData, follow_up_needed: checked})}
                    />
                    <Label htmlFor="follow_up_needed" className="cursor-pointer">
                      Nécessite un suivi
                    </Label>
                  </div>

                  {formData.follow_up_needed && (
                    <div className="space-y-2">
                      <Label htmlFor="next_follow_up_date">Date du prochain suivi</Label>
                      <Input
                        id="next_follow_up_date"
                        type="date"
                        value={formData.next_follow_up_date}
                        onChange={(e) => setFormData({...formData, next_follow_up_date: e.target.value})}
                      />
                    </div>
                  )}
                </div>

                {(formData.status === 'resolu' || formData.status === 'cloture') && (
                  <div className="space-y-2">
                    <Label htmlFor="resolution_date">Date de résolution</Label>
                    <Input
                      id="resolution_date"
                      type="date"
                      value={formData.resolution_date}
                      onChange={(e) => setFormData({...formData, resolution_date: e.target.value})}
                    />
                  </div>
                )}

                <div className="flex gap-3 pt-4 border-t">
                  <Button
                    variant="outline"
                    onClick={() => setIsEditing(false)}
                    className="flex-1"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Annuler
                  </Button>
                  <Button
                    onClick={handleSave}
                    disabled={isUpdating}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {isUpdating ? 'Enregistrement...' : 'Enregistrer'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Actions entreprises */}
              {caseItem.actions_taken && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <CheckCircle className="w-5 h-5" />
                      Actions entreprises
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-700 whitespace-pre-wrap">{caseItem.actions_taken}</p>
                  </CardContent>
                </Card>
              )}

              {/* Notes confidentielles */}
              {caseItem.notes && (
                <Card className="border-pink-200 bg-pink-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-base">
                      <FileText className="w-5 h-5 text-pink-600" />
                      Notes confidentielles
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-slate-700 whitespace-pre-wrap">{caseItem.notes}</p>
                  </CardContent>
                </Card>
              )}

              {/* Suivi */}
              {caseItem.follow_up_needed && (
                <Card className="border-orange-200 bg-orange-50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-orange-600 mt-0.5" />
                      <div>
                        <p className="font-semibold text-orange-900">Suivi requis</p>
                        {caseItem.next_follow_up_date && (
                          <p className="text-sm text-orange-700 mt-1">
                            Prochain suivi prévu le {format(new Date(caseItem.next_follow_up_date), 'dd/MM/yyyy', { locale: fr })}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t mt-6">
          <Button onClick={onClose} variant="outline">
            Fermer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}