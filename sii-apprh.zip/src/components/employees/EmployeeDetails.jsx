import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { 
  Mail, Phone, MapPin, Calendar, DollarSign, Edit, AlertCircle, Trash2, 
  User, Briefcase, Award, GraduationCap, History, AlertTriangle,
  Home, Globe, Heart, Building2, CreditCard, FileText
} from "lucide-react";
import { format, differenceInYears, differenceInMonths } from "date-fns";
import { fr } from "date-fns/locale";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  on_leave: "bg-yellow-100 text-yellow-800 border-yellow-200",
  terminated: "bg-red-100 text-red-800 border-red-200",
};

const statusLabels = {
  active: "Actif",
  on_leave: "En congé",
  terminated: "Terminé",
};

export default function EmployeeDetails({ employee, onClose, onEdit, onDelete }) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [activeTab, setActiveTab] = useState("personal");

  // Récupérer l'historique des postes
  const { data: jobHistory = [] } = useQuery({
    queryKey: ['jobHistory', employee.id],
    queryFn: () => base44.entities.JobHistory.filter({ employee_id: employee.id }),
  });

  // Récupérer les évaluations de performance
  const { data: reviews = [] } = useQuery({
    queryKey: ['employeeReviews', employee.email],
    queryFn: () => base44.entities.PerformanceReview.filter({ employee_email: employee.email }),
  });

  // Récupérer les formations
  const { data: allTrainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
  });

  // Récupérer les compétences
  const { data: skills = [] } = useQuery({
    queryKey: ['employeeSkills', employee.email],
    queryFn: () => base44.entities.Skill.filter({ employee_email: employee.email }),
  });

  // Filtrer les formations où l'employé est inscrit
  const employeeTrainings = allTrainings.filter(training => 
    training.enrolled_employees?.includes(employee.email) ||
    training.completed_employees?.includes(employee.email)
  );

  const handleDelete = () => {
    onDelete(employee.id);
    setShowDeleteDialog(false);
  };

  // Calculer l'ancienneté
  const yearsOfService = employee.hire_date 
    ? differenceInYears(new Date(), new Date(employee.hire_date))
    : 0;
  const monthsOfService = employee.hire_date 
    ? differenceInMonths(new Date(), new Date(employee.hire_date)) % 12
    : 0;

  // Trier l'historique par date
  const sortedJobHistory = [...jobHistory].sort((a, b) => 
    new Date(b.start_date) - new Date(a.start_date)
  );

  // Trier les reviews par date
  const sortedReviews = [...reviews].sort((a, b) => 
    new Date(b.review_date) - new Date(a.review_date)
  );

  const maritalStatusLabels = {
    single: "Célibataire",
    married: "Marié(e)",
    divorced: "Divorcé(e)",
    widowed: "Veuf/Veuve"
  };

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-lg">
                  <span className="text-3xl font-bold text-white">
                    {employee.full_name?.charAt(0) || 'E'}
                  </span>
                </div>
                <div>
                  <DialogTitle className="text-2xl">{employee.full_name}</DialogTitle>
                  <p className="text-blue-600 font-medium text-lg">{employee.position}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge className={`${statusColors[employee.status]} border`}>
                      {statusLabels[employee.status]}
                    </Badge>
                    {employee.employee_id && (
                      <Badge variant="outline">ID: {employee.employee_id}</Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="personal">Informations</TabsTrigger>
              <TabsTrigger value="job">Poste</TabsTrigger>
              <TabsTrigger value="history">Historique</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="training">Formation</TabsTrigger>
            </TabsList>

            {/* Informations personnelles */}
            <TabsContent value="personal" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5" />
                    Coordonnées
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                      <Mail className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <p className="text-xs text-slate-500 mb-1">Email professionnel</p>
                        <p className="text-sm font-medium text-slate-900">{employee.email}</p>
                      </div>
                    </div>

                    {employee.phone && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Phone className="w-5 h-5 text-green-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Téléphone professionnel</p>
                          <p className="text-sm font-medium text-slate-900">{employee.phone}</p>
                        </div>
                      </div>
                    )}

                    {employee.personal_phone && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Phone className="w-5 h-5 text-purple-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Téléphone personnel</p>
                          <p className="text-sm font-medium text-slate-900">{employee.personal_phone}</p>
                        </div>
                      </div>
                    )}

                    {employee.date_of_birth && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Calendar className="w-5 h-5 text-orange-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Date de naissance</p>
                          <p className="text-sm font-medium text-slate-900">
                            {format(new Date(employee.date_of_birth), 'dd MMMM yyyy', { locale: fr })}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Home className="w-5 h-5" />
                    Adresse
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {employee.address && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50 md:col-span-2">
                        <MapPin className="w-5 h-5 text-red-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Adresse complète</p>
                          <p className="text-sm font-medium text-slate-900">{employee.address}</p>
                          {(employee.city || employee.postal_code) && (
                            <p className="text-sm text-slate-600 mt-1">
                              {employee.postal_code} {employee.city}
                              {employee.country && `, ${employee.country}`}
                            </p>
                          )}
                        </div>
                      </div>
                    )}

                    {employee.nationality && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Globe className="w-5 h-5 text-indigo-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Nationalité</p>
                          <p className="text-sm font-medium text-slate-900">{employee.nationality}</p>
                        </div>
                      </div>
                    )}

                    {employee.marital_status && (
                      <div className="flex items-start gap-3 p-3 rounded-lg bg-slate-50">
                        <Heart className="w-5 h-5 text-pink-600 mt-0.5" />
                        <div>
                          <p className="text-xs text-slate-500 mb-1">Situation familiale</p>
                          <p className="text-sm font-medium text-slate-900">
                            {maritalStatusLabels[employee.marital_status] || employee.marital_status}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5" />
                    Contacts d'urgence
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {employee.emergency_contact_name && (
                      <div className="p-4 rounded-lg bg-orange-50 border border-orange-200">
                        <p className="font-semibold text-slate-900 mb-2">Contact d'urgence principal</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <p className="text-xs text-slate-600">Nom</p>
                            <p className="font-medium">{employee.emergency_contact_name}</p>
                          </div>
                          {employee.emergency_contact_relationship && (
                            <div>
                              <p className="text-xs text-slate-600">Relation</p>
                              <p className="font-medium">{employee.emergency_contact_relationship}</p>
                            </div>
                          )}
                          {employee.emergency_contact_phone && (
                            <div>
                              <p className="text-xs text-slate-600">Téléphone</p>
                              <p className="font-medium">{employee.emergency_contact_phone}</p>
                            </div>
                          )}
                          {employee.emergency_contact_email && (
                            <div>
                              <p className="text-xs text-slate-600">Email</p>
                              <p className="font-medium">{employee.emergency_contact_email}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {employee.secondary_emergency_contact_name && (
                      <div className="p-4 rounded-lg bg-slate-50 border border-slate-200">
                        <p className="font-semibold text-slate-900 mb-2">Contact d'urgence secondaire</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <div>
                            <p className="text-xs text-slate-600">Nom</p>
                            <p className="font-medium">{employee.secondary_emergency_contact_name}</p>
                          </div>
                          {employee.secondary_emergency_contact_phone && (
                            <div>
                              <p className="text-xs text-slate-600">Téléphone</p>
                              <p className="font-medium">{employee.secondary_emergency_contact_phone}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    )}

                    {!employee.emergency_contact_name && (
                      <p className="text-sm text-slate-500 italic">Aucun contact d'urgence enregistré</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Informations sur le poste */}
            <TabsContent value="job" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Briefcase className="w-5 h-5" />
                    Poste actuel
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Poste</p>
                      <p className="font-semibold text-lg">{employee.position}</p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Département</p>
                      <p className="font-semibold text-lg">{employee.department}</p>
                    </div>

                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Date d'embauche</p>
                      <p className="font-medium">{format(new Date(employee.hire_date), 'dd/MM/yyyy')}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        {yearsOfService > 0 && `${yearsOfService} an${yearsOfService > 1 ? 's' : ''} `}
                        {monthsOfService > 0 && `${monthsOfService} mois`}
                        {yearsOfService === 0 && monthsOfService === 0 && 'Moins d\'un mois'}
                      </p>
                    </div>

                    {employee.salary && (
                      <div className="p-3 rounded-lg bg-slate-50">
                        <p className="text-xs text-slate-600 mb-1">Salaire annuel</p>
                        <p className="font-semibold text-lg">{employee.salary.toLocaleString()} FCFA</p>
                      </div>
                    )}

                    <div className="p-3 rounded-lg bg-slate-50">
                      <p className="text-xs text-slate-600 mb-1">Type d'emploi</p>
                      <p className="font-medium capitalize">{employee.employment_type?.replace('_', ' ')}</p>
                    </div>

                    {employee.work_location && (
                      <div className="p-3 rounded-lg bg-slate-50">
                        <p className="text-xs text-slate-600 mb-1">Lieu de travail</p>
                        <p className="font-medium">{employee.work_location}</p>
                      </div>
                    )}

                    {employee.office_number && (
                      <div className="p-3 rounded-lg bg-slate-50">
                        <p className="text-xs text-slate-600 mb-1">Bureau</p>
                        <p className="font-medium">{employee.office_number}</p>
                      </div>
                    )}

                    {employee.probation_end_date && (
                      <div className="p-3 rounded-lg bg-slate-50">
                        <p className="text-xs text-slate-600 mb-1">Fin de période d'essai</p>
                        <p className="font-medium">{format(new Date(employee.probation_end_date), 'dd/MM/yyyy')}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {employee.manager_name && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5" />
                      Manager direct
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                      <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          {employee.manager_name?.charAt(0) || 'M'}
                        </span>
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900">{employee.manager_name}</p>
                        {employee.manager_email && (
                          <p className="text-sm text-slate-600">{employee.manager_email}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {(employee.skills && employee.skills.length > 0) && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5" />
                      Compétences
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {employee.skills.map((skill, index) => (
                        <Badge key={index} variant="outline" className="bg-blue-50">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {(employee.languages && employee.languages.length > 0) && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="w-5 h-5" />
                      Langues
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {employee.languages.map((lang, index) => (
                        <Badge key={index} variant="outline" className="bg-green-50">
                          {lang}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Historique des postes */}
            <TabsContent value="history" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <History className="w-5 h-5" />
                    Historique des postes dans l'entreprise
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sortedJobHistory.length === 0 ? (
                    <p className="text-sm text-slate-500 italic">Aucun historique disponible</p>
                  ) : (
                    <div className="space-y-4">
                      {sortedJobHistory.map((job, index) => (
                        <div 
                          key={job.id} 
                          className={`p-4 rounded-lg border-2 ${
                            job.is_current ? 'border-blue-500 bg-blue-50' : 'border-slate-200 bg-slate-50'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-semibold text-lg text-slate-900">{job.position}</p>
                              <p className="text-sm text-slate-600">{job.department}</p>
                            </div>
                            {job.is_current && (
                              <Badge className="bg-blue-600">Actuel</Badge>
                            )}
                          </div>
                          
                          <div className="grid grid-cols-2 gap-3 mt-3">
                            <div>
                              <p className="text-xs text-slate-500">Début</p>
                              <p className="text-sm font-medium">
                                {format(new Date(job.start_date), 'MMMM yyyy', { locale: fr })}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-500">Fin</p>
                              <p className="text-sm font-medium">
                                {job.end_date 
                                  ? format(new Date(job.end_date), 'MMMM yyyy', { locale: fr })
                                  : "Aujourd'hui"
                                }
                              </p>
                            </div>
                          </div>

                          {job.reason_for_change && (
                            <div className="mt-3">
                              <p className="text-xs text-slate-500">Raison du changement</p>
                              <Badge variant="outline" className="mt-1">
                                {job.reason_for_change}
                              </Badge>
                            </div>
                          )}

                          {job.notes && (
                            <div className="mt-3 p-2 bg-white rounded border border-slate-200">
                              <p className="text-xs text-slate-700">{job.notes}</p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Performance */}
            <TabsContent value="performance" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="w-5 h-5" />
                    Évaluations de performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {sortedReviews.length === 0 ? (
                    <p className="text-sm text-slate-500 italic">Aucune évaluation enregistrée</p>
                  ) : (
                    <div className="space-y-4">
                      {sortedReviews.map((review) => (
                        <div key={review.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <p className="font-semibold text-slate-900">{review.review_period}</p>
                              <p className="text-sm text-slate-600">
                                {format(new Date(review.review_date), 'dd MMMM yyyy', { locale: fr })}
                              </p>
                            </div>
                            <Badge className="bg-blue-600 text-lg">
                              {review.overall_rating.toFixed(1)} ⭐
                            </Badge>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                            <div className="p-2 bg-white rounded">
                              <p className="text-xs text-slate-600">Technique</p>
                              <p className="font-semibold">{review.technical_skills}/5</p>
                            </div>
                            <div className="p-2 bg-white rounded">
                              <p className="text-xs text-slate-600">Communication</p>
                              <p className="font-semibold">{review.communication}/5</p>
                            </div>
                            <div className="p-2 bg-white rounded">
                              <p className="text-xs text-slate-600">Équipe</p>
                              <p className="font-semibold">{review.teamwork}/5</p>
                            </div>
                            <div className="p-2 bg-white rounded">
                              <p className="text-xs text-slate-600">Leadership</p>
                              <p className="font-semibold">{review.leadership}/5</p>
                            </div>
                          </div>

                          {review.strengths && (
                            <div className="mb-2">
                              <p className="text-xs font-medium text-green-700 mb-1">Points forts</p>
                              <p className="text-sm text-slate-700 bg-white p-2 rounded">{review.strengths}</p>
                            </div>
                          )}

                          {review.areas_for_improvement && (
                            <div>
                              <p className="text-xs font-medium text-orange-700 mb-1">À améliorer</p>
                              <p className="text-sm text-slate-700 bg-white p-2 rounded">{review.areas_for_improvement}</p>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {skills.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5" />
                      Compétences détaillées
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {skills.map((skill) => (
                        <div key={skill.id} className="p-3 rounded-lg border border-slate-200">
                          <div className="flex items-start justify-between mb-2">
                            <p className="font-semibold text-slate-900">{skill.skill_name}</p>
                            {skill.certified && (
                              <Badge className="bg-purple-600 gap-1">
                                <Award className="w-3 h-3" />
                                Certifié
                              </Badge>
                            )}
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {skill.proficiency_level}
                          </Badge>
                          {skill.years_of_experience && (
                            <p className="text-xs text-slate-600 mt-2">
                              {skill.years_of_experience} ans d'expérience
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Formation */}
            <TabsContent value="training" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5" />
                    Formations suivies
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {employeeTrainings.length === 0 ? (
                    <p className="text-sm text-slate-500 italic">Aucune formation enregistrée</p>
                  ) : (
                    <div className="space-y-3">
                      {employeeTrainings.map((training) => {
                        const isCompleted = training.completed_employees?.includes(employee.email);
                        
                        return (
                          <div key={training.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <p className="font-semibold text-slate-900">{training.title}</p>
                                <p className="text-sm text-slate-600">{training.category}</p>
                              </div>
                              <Badge className={isCompleted ? 'bg-green-600' : 'bg-blue-600'}>
                                {isCompleted ? 'Terminé' : 'En cours'}
                              </Badge>
                            </div>

                            <div className="grid grid-cols-2 gap-3 mt-3">
                              <div>
                                <p className="text-xs text-slate-500">Date</p>
                                <p className="text-sm font-medium">
                                  {format(new Date(training.training_date), 'dd/MM/yyyy')}
                                </p>
                              </div>
                              <div>
                                <p className="text-xs text-slate-500">Durée</p>
                                <p className="text-sm font-medium">{training.duration_hours}h</p>
                              </div>
                            </div>

                            {training.certification && (
                              <div className="mt-3">
                                <Badge variant="outline" className="bg-purple-50 text-purple-700">
                                  <Award className="w-3 h-3 mr-1" />
                                  Certification délivrée
                                </Badge>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-between gap-3 pt-4 border-t">
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(true)}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Supprimer
            </Button>
            <div className="flex gap-3">
              <Button variant="outline" onClick={onClose}>
                Fermer
              </Button>
              <Button onClick={onEdit} className="bg-blue-600 hover:bg-blue-700">
                <Edit className="w-4 h-4 mr-2" />
                Modifier
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer le profil de <strong>{employee.full_name}</strong> ?
              Cette action est irréversible et supprimera toutes les données associées à cet employé.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Supprimer définitivement
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}