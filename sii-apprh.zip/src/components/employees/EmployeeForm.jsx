import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Sparkles, User, Briefcase, AlertTriangle, FileText } from "lucide-react";

export default function EmployeeForm({ employee, departments, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState(employee || {
    full_name: "",
    email: "",
    phone: "",
    personal_phone: "",
    department: "",
    position: "",
    employment_type: "full_time",
    hire_date: "",
    salary: "",
    status: "active",
    address: "",
    city: "",
    postal_code: "",
    country: "",
    date_of_birth: "",
    nationality: "",
    marital_status: "",
    emergency_contact_name: "",
    emergency_contact_relationship: "",
    emergency_contact_phone: "",
    emergency_contact_email: "",
    secondary_emergency_contact_name: "",
    secondary_emergency_contact_phone: "",
    manager_email: "",
    manager_name: "",
    work_location: "",
    office_number: "",
    probation_end_date: "",
    contract_end_date: "",
    employee_id: "",
    skills: [],
    languages: [],
    notes: "",
  });

  const [generateWorkflow, setGenerateWorkflow] = useState(!employee);
  const [activeTab, setActiveTab] = useState("basic");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData, generateWorkflow);
  };

  const isNewEmployee = !employee;

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{employee ? 'Modifier l\'employé' : 'Nouvel employé'}</DialogTitle>
        </DialogHeader>

        {isNewEmployee && (
          <Alert className="bg-blue-50 border-blue-200">
            <Sparkles className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="generateWorkflow"
                  checked={generateWorkflow}
                  onCheckedChange={setGenerateWorkflow}
                />
                <label htmlFor="generateWorkflow" className="text-sm font-medium cursor-pointer">
                  Générer automatiquement le workflow d'intégration
                </label>
              </div>
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="basic" className="gap-2">
                <User className="w-4 h-4" />
                Base
              </TabsTrigger>
              <TabsTrigger value="job" className="gap-2">
                <Briefcase className="w-4 h-4" />
                Poste
              </TabsTrigger>
              <TabsTrigger value="emergency" className="gap-2">
                <AlertTriangle className="w-4 h-4" />
                Urgence
              </TabsTrigger>
              <TabsTrigger value="other" className="gap-2">
                <FileText className="w-4 h-4" />
                Autre
              </TabsTrigger>
            </TabsList>

            <div className="mt-6 space-y-4">
              {/* Informations de base */}
              <TabsContent value="basic" className="space-y-4 mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="full_name">Nom complet *</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="employee_id">Numéro d'employé</Label>
                    <Input
                      id="employee_id"
                      value={formData.employee_id}
                      onChange={(e) => setFormData({...formData, employee_id: e.target.value})}
                      placeholder="ex: EMP-2025-001"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email professionnel *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Téléphone professionnel</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="personal_phone">Téléphone personnel</Label>
                    <Input
                      id="personal_phone"
                      value={formData.personal_phone}
                      onChange={(e) => setFormData({...formData, personal_phone: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date_of_birth">Date de naissance</Label>
                    <Input
                      id="date_of_birth"
                      type="date"
                      value={formData.date_of_birth}
                      onChange={(e) => setFormData({...formData, date_of_birth: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nationality">Nationalité</Label>
                    <Input
                      id="nationality"
                      value={formData.nationality}
                      onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="marital_status">Situation familiale</Label>
                    <Select
                      value={formData.marital_status}
                      onValueChange={(value) => setFormData({...formData, marital_status: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="single">Célibataire</SelectItem>
                        <SelectItem value="married">Marié(e)</SelectItem>
                        <SelectItem value="divorced">Divorcé(e)</SelectItem>
                        <SelectItem value="widowed">Veuf/Veuve</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Adresse complète</Label>
                  <Textarea
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({...formData, address: e.target.value})}
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ville</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData({...formData, city: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="postal_code">Code postal</Label>
                    <Input
                      id="postal_code"
                      value={formData.postal_code}
                      onChange={(e) => setFormData({...formData, postal_code: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="country">Pays</Label>
                    <Input
                      id="country"
                      value={formData.country}
                      onChange={(e) => setFormData({...formData, country: e.target.value})}
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Informations sur le poste */}
              <TabsContent value="job" className="space-y-4 mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="position">Poste *</Label>
                    <Input
                      id="position"
                      value={formData.position}
                      onChange={(e) => setFormData({...formData, position: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="department">Département *</Label>
                    <Select
                      value={formData.department}
                      onValueChange={(value) => setFormData({...formData, department: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionner un département" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map(dept => (
                          <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="employment_type">Type d'emploi</Label>
                    <Select
                      value={formData.employment_type}
                      onValueChange={(value) => setFormData({...formData, employment_type: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full_time">Temps plein</SelectItem>
                        <SelectItem value="part_time">Temps partiel</SelectItem>
                        <SelectItem value="contract">Contrat</SelectItem>
                        <SelectItem value="intern">Stage</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="hire_date">Date d'embauche *</Label>
                    <Input
                      id="hire_date"
                      type="date"
                      value={formData.hire_date}
                      onChange={(e) => setFormData({...formData, hire_date: e.target.value})}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="salary">Salaire annuel (FCFA)</Label>
                    <Input
                      id="salary"
                      type="number"
                      value={formData.salary}
                      onChange={(e) => setFormData({...formData, salary: parseFloat(e.target.value)})}
                      placeholder="ex: 3000000"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="status">Statut</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => setFormData({...formData, status: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Actif</SelectItem>
                        <SelectItem value="on_leave">En congé</SelectItem>
                        <SelectItem value="terminated">Terminé</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="work_location">Lieu de travail</Label>
                    <Input
                      id="work_location"
                      value={formData.work_location}
                      onChange={(e) => setFormData({...formData, work_location: e.target.value})}
                      placeholder="ex: Dakar, Bureau principal"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="office_number">Numéro de bureau</Label>
                    <Input
                      id="office_number"
                      value={formData.office_number}
                      onChange={(e) => setFormData({...formData, office_number: e.target.value})}
                      placeholder="ex: B-204"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="probation_end_date">Fin de période d'essai</Label>
                    <Input
                      id="probation_end_date"
                      type="date"
                      value={formData.probation_end_date}
                      onChange={(e) => setFormData({...formData, probation_end_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contract_end_date">Fin de contrat (si CDD)</Label>
                    <Input
                      id="contract_end_date"
                      type="date"
                      value={formData.contract_end_date}
                      onChange={(e) => setFormData({...formData, contract_end_date: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="manager_name">Manager direct</Label>
                    <Input
                      id="manager_name"
                      value={formData.manager_name}
                      onChange={(e) => setFormData({...formData, manager_name: e.target.value})}
                      placeholder="Nom du manager"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="manager_email">Email du manager</Label>
                    <Input
                      id="manager_email"
                      type="email"
                      value={formData.manager_email}
                      onChange={(e) => setFormData({...formData, manager_email: e.target.value})}
                      placeholder="email@exemple.com"
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Contacts d'urgence */}
              <TabsContent value="emergency" className="space-y-6 mt-0">
                <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <h3 className="font-semibold text-slate-900 mb-4">Contact d'urgence principal</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_name">Nom complet</Label>
                      <Input
                        id="emergency_contact_name"
                        value={formData.emergency_contact_name}
                        onChange={(e) => setFormData({...formData, emergency_contact_name: e.target.value})}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_relationship">Lien de parenté</Label>
                      <Input
                        id="emergency_contact_relationship"
                        value={formData.emergency_contact_relationship}
                        onChange={(e) => setFormData({...formData, emergency_contact_relationship: e.target.value})}
                        placeholder="ex: Époux/Épouse, Parent, Frère/Sœur"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_phone">Téléphone</Label>
                      <Input
                        id="emergency_contact_phone"
                        value={formData.emergency_contact_phone}
                        onChange={(e) => setFormData({...formData, emergency_contact_phone: e.target.value})}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_email">Email</Label>
                      <Input
                        id="emergency_contact_email"
                        type="email"
                        value={formData.emergency_contact_email}
                        onChange={(e) => setFormData({...formData, emergency_contact_email: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                  <h3 className="font-semibold text-slate-900 mb-4">Contact d'urgence secondaire</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="secondary_emergency_contact_name">Nom complet</Label>
                      <Input
                        id="secondary_emergency_contact_name"
                        value={formData.secondary_emergency_contact_name}
                        onChange={(e) => setFormData({...formData, secondary_emergency_contact_name: e.target.value})}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="secondary_emergency_contact_phone">Téléphone</Label>
                      <Input
                        id="secondary_emergency_contact_phone"
                        value={formData.secondary_emergency_contact_phone}
                        onChange={(e) => setFormData({...formData, secondary_emergency_contact_phone: e.target.value})}
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Autres informations */}
              <TabsContent value="other" className="space-y-4 mt-0">
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    rows={3}
                    placeholder="Notes additionnelles..."
                  />
                </div>
              </TabsContent>
            </div>
          </Tabs>

          <div className="flex justify-end gap-3 pt-6 border-t mt-6">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Enregistrement...' : employee ? 'Mettre à jour' : 'Ajouter'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}