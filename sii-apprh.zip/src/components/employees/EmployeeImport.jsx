import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Upload, Download, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function EmployeeImport({ onClose, onSuccess }) {
  const [uploading, setUploading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);

  const downloadTemplate = () => {
    const template = `full_name,email,phone,department,position,employment_type,hire_date,salary,status,address,emergency_contact_name,emergency_contact_phone
Jean Dupont,jean.dupont@example.com,+33612345678,IT,Développeur,full_time,2024-01-15,45000,active,"123 Rue de Paris",Marie Dupont,+33698765432
Sophie Martin,sophie.martin@example.com,+33623456789,RH,Responsable RH,full_time,2023-06-01,55000,active,"456 Avenue Victor Hugo",Pierre Martin,+33687654321`;

    const blob = new Blob([template], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'modele_employes.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setError(null);
    setResults(null);

    try {
      // Upload du fichier
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      // Schema pour UN employé (pas un tableau)
      const employeeSchema = {
        type: "object",
        properties: {
          full_name: { type: "string" },
          email: { type: "string" },
          phone: { type: "string" },
          department: { type: "string" },
          position: { type: "string" },
          employment_type: { type: "string" },
          hire_date: { type: "string" },
          salary: { type: "number" },
          status: { type: "string" },
          address: { type: "string" },
          city: { type: "string" },
          country: { type: "string" },
          postal_code: { type: "string" },
          emergency_contact_name: { type: "string" },
          emergency_contact_phone: { type: "string" },
          emergency_contact_relationship: { type: "string" },
          manager_email: { type: "string" },
          manager_name: { type: "string" },
          work_location: { type: "string" }
        }
      };
      
      // Extraire directement un ARRAY d'employés (pas un objet avec employees dedans)
      const extractResult = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url,
        json_schema: {
          type: "array",
          items: employeeSchema
        }
      });

      console.log("Extract result:", extractResult);

      if (extractResult.status === "error") {
        throw new Error(extractResult.details || "Échec de l'extraction des données du fichier CSV");
      }

      // La sortie est directement un tableau
      const employees = Array.isArray(extractResult.output) ? extractResult.output : [];
      
      if (employees.length === 0) {
        throw new Error("Aucune donnée d'employé trouvée dans le fichier. Assurez-vous que le fichier CSV contient des lignes de données et respecte le format du modèle.");
      }

      const importResults = {
        total: employees.length,
        success: 0,
        failed: 0,
        errors: []
      };

      // Importer chaque employé
      for (const employee of employees) {
        try {
          // Nettoyer les données
          const cleanEmployee = {
            full_name: employee.full_name,
            email: employee.email,
            phone: employee.phone || null,
            department: employee.department,
            position: employee.position,
            employment_type: employee.employment_type || 'full_time',
            hire_date: employee.hire_date || new Date().toISOString().split('T')[0],
            salary: employee.salary ? Number(employee.salary) : null,
            status: employee.status || 'active',
            address: employee.address || null,
            city: employee.city || null,
            country: employee.country || null,
            postal_code: employee.postal_code || null,
            emergency_contact_name: employee.emergency_contact_name || null,
            emergency_contact_phone: employee.emergency_contact_phone || null,
            emergency_contact_relationship: employee.emergency_contact_relationship || null,
            manager_email: employee.manager_email || null,
            manager_name: employee.manager_name || null,
            work_location: employee.work_location || null
          };

          await base44.entities.Employee.create(cleanEmployee);
          importResults.success++;
        } catch (err) {
          importResults.failed++;
          importResults.errors.push({
            employee: employee.full_name || employee.email || 'Employé inconnu',
            error: err.message
          });
        }
      }

      setResults(importResults);
      
      if (importResults.success > 0) {
        setTimeout(() => {
          onSuccess();
        }, 2000);
      }
    } catch (err) {
      console.error("Import error:", err);
      setError(err.message || "Échec de l'importation du fichier");
    }

    setUploading(false);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Importer des employés depuis CSV/Excel</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <p className="font-semibold mb-2">Comment importer vos employés :</p>
              <ol className="text-sm space-y-1 list-decimal list-inside">
                <li>Téléchargez le modèle CSV ci-dessous</li>
                <li>Remplissez-le avec les données de vos employés (utilisez Excel, Google Sheets, etc.)</li>
                <li>Enregistrez au format CSV</li>
                <li>Importez le fichier ici</li>
              </ol>
            </AlertDescription>
          </Alert>

          <Button
            onClick={downloadTemplate}
            variant="outline"
            className="w-full"
          >
            <Download className="w-4 h-4 mr-2" />
            📥 Télécharger le modèle CSV
          </Button>

          <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
            <input
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileUpload}
              className="hidden"
              id="file-upload"
              disabled={uploading}
            />
            <label htmlFor="file-upload" className="cursor-pointer">
              <Upload className="w-12 h-12 mx-auto mb-4 text-slate-400" />
              {uploading ? (
                <>
                  <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  <p className="text-sm text-slate-600 font-medium">Importation en cours...</p>
                  <p className="text-xs text-slate-500 mt-1">Analyse et création des employés</p>
                </>
              ) : (
                <>
                  <p className="text-sm text-slate-600 mb-2 font-medium">
                    📄 Cliquez pour sélectionner votre fichier
                  </p>
                  <p className="text-xs text-slate-500">
                    Formats supportés : CSV, XLSX, XLS
                  </p>
                </>
              )}
            </label>
          </div>

          {error && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                <p className="font-semibold mb-1">Erreur d'importation</p>
                <p className="text-sm">{error}</p>
              </AlertDescription>
            </Alert>
          )}

          {results && (
            <div className="space-y-4">
              <Alert className={results.failed === 0 ? "border-green-200 bg-green-50" : "border-orange-200 bg-orange-50"}>
                <CheckCircle className={`h-4 w-4 ${results.failed === 0 ? 'text-green-600' : 'text-orange-600'}`} />
                <AlertDescription>
                  <p className="font-semibold mb-2">
                    {results.failed === 0 ? '✅ Importation réussie !' : '⚠️ Importation partielle'}
                  </p>
                  <ul className="text-sm space-y-1">
                    <li><strong>Total:</strong> {results.total} employés dans le fichier</li>
                    <li className="text-green-600"><strong>✓ Réussis:</strong> {results.success} créés</li>
                    {results.failed > 0 && (
                      <li className="text-red-600"><strong>✗ Échecs:</strong> {results.failed} non créés</li>
                    )}
                  </ul>
                </AlertDescription>
              </Alert>

              {results.errors.length > 0 && (
                <div className="max-h-48 overflow-y-auto p-4 bg-red-50 rounded-lg border border-red-200">
                  <p className="font-semibold text-sm text-red-900 mb-2">❌ Erreurs détaillées:</p>
                  <ul className="text-xs space-y-2 text-red-700">
                    {results.errors.map((err, i) => (
                      <li key={i} className="border-b border-red-200 pb-1">
                        <strong>{err.employee}:</strong> {err.error}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Fermer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}