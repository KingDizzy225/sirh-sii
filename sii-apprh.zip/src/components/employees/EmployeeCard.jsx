import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Phone, Edit, Eye, Trash2 } from "lucide-react";

const statusColors = {
  active: "bg-green-100 text-green-800 border-green-200",
  on_leave: "bg-yellow-100 text-yellow-800 border-yellow-200",
  terminated: "bg-red-100 text-red-800 border-red-200",
};

export default function EmployeeCard({ employee, onEdit, onView, onDelete }) {
  return (
    <Card className="hover:shadow-xl transition-all duration-300 border-none shadow-lg overflow-hidden group">
      <div className="h-24 bg-gradient-to-r from-blue-500 to-blue-600" />
      <CardContent className="p-6 -mt-12">
        <div className="flex items-start justify-between mb-4">
          <div className="w-20 h-20 rounded-full border-4 border-white shadow-lg bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
            <span className="text-2xl font-bold text-white">
              {employee.full_name?.charAt(0) || 'E'}
            </span>
          </div>
          <Badge className={`${statusColors[employee.status]} border`}>
            {employee.status?.replace('_', ' ')}
          </Badge>
        </div>

        <h3 className="font-bold text-lg text-slate-900 mb-1">{employee.full_name}</h3>
        <p className="text-sm text-blue-600 font-medium mb-1">{employee.position}</p>
        <p className="text-xs text-slate-500 mb-4">{employee.department}</p>

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Mail className="w-4 h-4 text-slate-400" />
            <span className="truncate">{employee.email}</span>
          </div>
          {employee.phone && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Phone className="w-4 h-4 text-slate-400" />
              <span>{employee.phone}</span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onView(employee)}
            className="flex-1"
          >
            <Eye className="w-4 h-4 mr-1" />
            Voir
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(employee)}
            className="flex-1"
          >
            <Edit className="w-4 h-4 mr-1" />
            Modifier
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              if (onDelete) onDelete(employee);
            }}
            className="text-red-600 hover:text-white hover:bg-red-600 border-red-300 hover:border-red-600"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}