import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Briefcase, MapPin, DollarSign, Calendar, Upload } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";

export default function EmployeeJobApplications({ user, jobPostings, onApply, isSubmitting }) {
  const [selectedJob, setSelectedJob] = useState(null);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [formData, setFormData] = useState({
    cover_letter: "",
    resume_url: "",
    phone: "",
    experience_years: "",
    salary_expectation: "",
    availability: "",
  });
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, resume_url: file_url });
    } catch (error) {
      alert("Échec du téléchargement du fichier");
    }
    setUploading(false);
  };

  const handleApply = (e) => {
    e.preventDefault();
    
    onApply({
      full_name: user.full_name || user.email,
      email: user.email,
      phone: formData.phone,
      job_posting_id: selectedJob.id,
      job_title: selectedJob.title,
      resume_url: formData.resume_url,
      cover_letter: formData.cover_letter,
      application_date: format(new Date(), 'yyyy-MM-dd'),
      status: "new",
      experience_years: formData.experience_years ? parseInt(formData.experience_years) : null,
      salary_expectation: formData.salary_expectation,
      availability: formData.availability,
      source: "internal",
    });

    setShowApplicationForm(false);
    setSelectedJob(null);
    setFormData({
      cover_letter: "",
      resume_url: "",
      phone: "",
      experience_years: "",
      salary_expectation: "",
      availability: "",
    });
  };

  const typeLabels = {
    full_time: "Temps plein",
    part_time: "Temps partiel",
    contract: "Contrat",
    intern: "Stage",
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg bg-gradient-to-r from-purple-50 to-purple-100">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Briefcase className="w-5 h-5" />
            Opportunités internes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-700">
            Explorez les opportunités de carrière au sein de l'entreprise. 
            Postulez directement depuis ce portail.
          </p>
        </CardContent>
      </Card>

      {jobPostings.length === 0 ? (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center">
            <Briefcase className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-500">Aucune offre d'emploi disponible pour le moment</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {jobPostings.map((job) => (
            <Card key={job.id} className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="border-b border-slate-100">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl mb-2">{job.title}</CardTitle>
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline">{typeLabels[job.employment_type]}</Badge>
                      <Badge className="bg-purple-100 text-purple-800">Interne</Badge>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Briefcase className="w-4 h-4" />
                    <span>{job.department}</span>
                  </div>
                  {job.location && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <MapPin className="w-4 h-4" />
                      <span>{job.location}</span>
                    </div>
                  )}
                  {job.salary_range && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <DollarSign className="w-4 h-4" />
                      <span>{job.salary_range}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Calendar className="w-4 h-4" />
                    <span>Publié le {format(new Date(job.posted_date || job.created_date), 'dd/MM/yyyy')}</span>
                  </div>
                </div>

                <p className="text-sm text-slate-700 line-clamp-3">{job.description}</p>

                <Button
                  onClick={() => {
                    setSelectedJob(job);
                    setShowApplicationForm(true);
                  }}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  Postuler à cette offre
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showApplicationForm && selectedJob && (
        <Dialog open={true} onOpenChange={() => {
          setShowApplicationForm(false);
          setSelectedJob(null);
        }}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Postuler pour {selectedJob.title}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleApply} className="space-y-4">
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-800">
                  Vos informations de base (nom, email) sont automatiquement renseignées.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Téléphone *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="experience_years">Années d'expérience</Label>
                  <Input
                    id="experience_years"
                    type="number"
                    value={formData.experience_years}
                    onChange={(e) => setFormData({...formData, experience_years: e.target.value})}
                    min="0"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="availability">Disponibilité</Label>
                  <Input
                    id="availability"
                    value={formData.availability}
                    onChange={(e) => setFormData({...formData, availability: e.target.value})}
                    placeholder="Ex: Immédiate, 1 mois"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="salary_expectation">Prétentions salariales</Label>
                <Input
                  id="salary_expectation"
                  value={formData.salary_expectation}
                  onChange={(e) => setFormData({...formData, salary_expectation: e.target.value})}
                  placeholder="Ex: 500,000 - 600,000 FCFA"
                />
              </div>

              <div className="space-y-2">
                <Label>CV (optionnel)</Label>
                <div className="border-2 border-dashed border-slate-200 rounded-lg p-6 text-center">
                  <Input
                    type="file"
                    onChange={handleFileUpload}
                    className="hidden"
                    id="cv-upload"
                    disabled={uploading}
                  />
                  <label htmlFor="cv-upload" className="cursor-pointer">
                    <Upload className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                    {uploading ? (
                      <p className="text-sm text-slate-600">Téléchargement...</p>
                    ) : formData.resume_url ? (
                      <p className="text-sm text-green-600">✓ CV téléchargé</p>
                    ) : (
                      <p className="text-sm text-slate-600">Cliquez pour télécharger votre CV</p>
                    )}
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="cover_letter">Lettre de motivation *</Label>
                <Textarea
                  id="cover_letter"
                  value={formData.cover_letter}
                  onChange={(e) => setFormData({...formData, cover_letter: e.target.value})}
                  rows={6}
                  placeholder="Expliquez pourquoi vous êtes intéressé(e) par ce poste et pourquoi vous êtes le/la candidat(e) idéal(e)..."
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowApplicationForm(false);
                    setSelectedJob(null);
                  }}
                >
                  Annuler
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting || uploading}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  {isSubmitting ? 'Envoi en cours...' : 'Soumettre ma candidature'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}