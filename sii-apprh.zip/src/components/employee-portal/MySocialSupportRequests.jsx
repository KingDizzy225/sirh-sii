import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Calendar, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusColors = {
  nouveau: "bg-orange-100 text-orange-800",
  en_cours: "bg-blue-100 text-blue-800",
  en_attente: "bg-yellow-100 text-yellow-800",
  resolu: "bg-green-100 text-green-800",
  cloture: "bg-gray-100 text-gray-800",
};

const statusLabels = {
  nouveau: "Nouveau",
  en_cours: "En cours de traitement",
  en_attente: "En attente",
  resolu: "Résolu",
  cloture: "Clôturé",
};

const caseTypeLabels = {
  soutien_personnel: "💙 Soutien personnel",
  aide_administrative: "📋 Aide administrative",
  conflit: "⚖️ Gestion de conflit",
  conseil: "💬 Conseil",
  urgence_sociale: "🚨 Urgence sociale",
  accompagnement_familial: "👨‍👩‍👧‍👦 Accompagnement familial",
  sante_mentale: "🧠 Santé mentale",
  autre: "📁 Autre",
};

export default function MySocialSupportRequests({ cases }) {
  // Gestion sécurisée des props
  const requests = Array.isArray(cases) ? cases : [];

  if (requests.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardContent className="p-12 text-center text-slate-500">
          <Heart className="w-16 h-16 mx-auto mb-4 text-slate-300" />
          <p className="text-lg font-medium mb-2">Aucune demande d'accompagnement</p>
          <p className="text-sm">Vous n'avez pas encore fait de demande de soutien social</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {requests.map((request) => {
        const status = request.status || 'nouveau';
        const isResolved = status === 'resolu' || status === 'cloture';

        return (
          <Card 
            key={request.id} 
            className={`border-2 ${
              isResolved 
                ? 'border-green-200 bg-green-50' 
                : status === 'nouveau'
                ? 'border-orange-200 bg-orange-50'
                : 'border-blue-200 bg-blue-50'
            }`}
          >
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <Badge className={statusColors[status] || "bg-gray-100 text-gray-800"}>
                      {isResolved ? <CheckCircle className="w-3 h-3 mr-1" /> : <Clock className="w-3 h-3 mr-1" />}
                      {statusLabels[status] || status}
                    </Badge>
                    <Badge variant="outline" className="bg-white">
                      {caseTypeLabels[request.case_type] || request.case_type}
                    </Badge>
                  </div>
                  <h4 className="font-semibold text-slate-900 text-lg mb-1">
                    {request.subject || "Demande de soutien"}
                  </h4>
                  {request.description && (
                    <p className="text-sm text-slate-700 line-clamp-2">{request.description}</p>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 mt-3 pt-3 border-t border-slate-200">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  <span>
                    Demandé le {format(new Date(request.created_date || new Date()), 'dd/MM/yyyy', { locale: fr })}
                  </span>
                </div>

                {request.assigned_to_social_worker_name && (
                  <div className="flex items-center gap-1">
                    <Heart className="w-3 h-3 text-pink-600" />
                    <span>Pris en charge par <strong>{request.assigned_to_social_worker_name}</strong></span>
                  </div>
                )}
              </div>

              {request.actions_taken && (
                <div className="mt-4 p-3 bg-white rounded-lg border border-slate-200">
                  <p className="text-xs font-medium text-slate-700 mb-1">Actions entreprises :</p>
                  <p className="text-sm text-slate-600">{request.actions_taken}</p>
                </div>
              )}

              {isResolved && (
                <div className="mt-3 p-3 bg-green-100 rounded-lg border border-green-300">
                  <div className="flex items-center gap-2 text-sm text-green-800">
                    <CheckCircle className="w-4 h-4" />
                    <span className="font-medium">Dossier résolu</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}