import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Heart, Send, Shield } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function EmployeeSocialSupportRequest({ onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    case_type: "soutien_personnel",
    subject: "",
    description: "",
    priority: "moyenne",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      case_type: formData.case_type,
      subject: formData.subject,
      description: formData.description,
      priority: formData.priority,
      status: "nouveau",
      is_confidential: true,
    });
  };

  const caseTypes = [
    { value: "soutien_personnel", label: "💙 Soutien personnel", description: "Besoin d'écoute ou de soutien psychologique" },
    { value: "aide_administrative", label: "📋 Aide administrative", description: "Aide pour des démarches administratives" },
    { value: "conseil", label: "💬 Conseil", description: "Demande de conseil sur une situation" },
    { value: "urgence_sociale", label: "🚨 Urgence sociale", description: "Situation urgente nécessitant une intervention rapide" },
    { value: "accompagnement_familial", label: "👨‍👩‍👧‍👦 Accompagnement familial", description: "Questions liées à la vie familiale" },
    { value: "sante_mentale", label: "🧠 Santé mentale", description: "Soutien pour la santé mentale et le bien-être" },
    { value: "autre", label: "📁 Autre", description: "Autre type de demande" },
  ];

  const selectedType = caseTypes.find(t => t.value === formData.case_type);

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-600" />
            Contacter l'Assistante Sociale
          </DialogTitle>
        </DialogHeader>
        <div className="p-2">
        <Alert className="mb-6 bg-pink-50 border-pink-200">
          <Shield className="w-4 h-4 text-pink-600" />
          <AlertDescription className="text-pink-800 text-sm">
            <strong>Confidentialité garantie :</strong> Vos échanges avec l'assistante sociale sont strictement confidentiels. 
            Seule l'assistante sociale et les administrateurs RH autorisés y ont accès.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Type de demande */}
          <div className="space-y-2">
            <Label htmlFor="case_type">Type de demande *</Label>
            <Select
              value={formData.case_type}
              onValueChange={(value) => setFormData({...formData, case_type: value})}
              required
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {caseTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-medium">{type.label}</span>
                      <span className="text-xs text-slate-500">{type.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedType && (
              <p className="text-xs text-slate-500 italic mt-1">
                {selectedType.description}
              </p>
            )}
          </div>

          {/* Sujet */}
          <div className="space-y-2">
            <Label htmlFor="subject">Sujet de votre demande *</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({...formData, subject: e.target.value})}
              placeholder="ex: Besoin d'accompagnement pour une situation personnelle"
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={6}
              placeholder="Décrivez votre situation en détail. Plus vous serez précis, mieux l'assistante sociale pourra vous accompagner..."
              required
            />
            <p className="text-xs text-slate-500">
              Prenez le temps d'expliquer votre situation. Vos informations sont sécurisées.
            </p>
          </div>

          {/* Priorité */}
          <div className="space-y-2">
            <Label htmlFor="priority">Urgence de votre demande</Label>
            <Select
              value={formData.priority}
              onValueChange={(value) => setFormData({...formData, priority: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="faible">Non urgent - Je peux attendre</SelectItem>
                <SelectItem value="moyenne">Moyennement urgent - Dans la semaine</SelectItem>
                <SelectItem value="elevee">Urgent - Dans les 2-3 jours</SelectItem>
                <SelectItem value="urgente">⚠️ Très urgent - Besoin d'aide immédiate</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Que se passe-t-il ensuite ?</strong>
              <br />
              • L'assistante sociale recevra votre demande immédiatement
              <br />
              • Elle vous contactera dans les plus brefs délais selon l'urgence
              <br />
              • Vous pourrez suivre l'état de votre demande dans votre portail
            </p>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="flex-1 bg-pink-600 hover:bg-pink-700 gap-2"
            >
              <Send className="w-4 h-4" />
              {isSubmitting ? 'Envoi...' : 'Envoyer'}
            </Button>
          </div>
        </form>
        </div>
      </DialogContent>
    </Dialog>
  );
}