import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText } from "lucide-react";

export default function EmployeeDocumentRequestForm({ onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    document_type: "Attestation de travail",
    reason: "",
    priority: "normal",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      document_type: formData.document_type,
      reason: formData.reason,
      priority: formData.priority,
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            Demander un document
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="document_type">Type de document</Label>
            <Select
              value={formData.document_type}
              onValueChange={(value) => setFormData({...formData, document_type: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Attestation de travail">Attestation de travail</SelectItem>
                <SelectItem value="Certificat de salaire">Certificat de salaire</SelectItem>
                <SelectItem value="Fiche de paie">Fiche de paie</SelectItem>
                <SelectItem value="Attestation fiscale">Attestation fiscale</SelectItem>
                <SelectItem value="Autre">Autre</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Raison de la demande</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => setFormData({...formData, reason: e.target.value})}
              rows={3}
              placeholder="Expliquez pourquoi vous avez besoin de ce document..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="priority">Priorité</Label>
            <Select
              value={formData.priority}
              onValueChange={(value) => setFormData({...formData, priority: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Basse</SelectItem>
                <SelectItem value="normal">Normale</SelectItem>
                <SelectItem value="high">Haute</SelectItem>
                <SelectItem value="urgent">Urgente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="flex-1 bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Envoi...' : 'Soumettre'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}