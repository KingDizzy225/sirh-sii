import React from "react";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
};

const statusLabels = {
  pending: "En attente",
  approved: "Approuvé",
  rejected: "Rejeté",
};

const leaveTypeLabels = {
  vacation: "Congé annuel",
  sick: "Congé maladie",
  personal: "Congé personnel",
  maternity: "Congé maternité",
  paternity: "Congé paternité",
  unpaid: "Congé sans solde",
};

export default function MyLeaveRequests({ requests }) {
  if (requests.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500">
        <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
        <p>Aucune demande de congé</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {requests.map((request) => (
        <div key={request.id} className="p-4 rounded-lg border border-slate-200 hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-green-600" />
                <h4 className="font-semibold text-slate-900 capitalize">
                  {leaveTypeLabels[request.leave_type]}
                </h4>
              </div>
              <p className="text-sm text-slate-600">{request.reason}</p>
            </div>
            <Badge className={statusColors[request.status]}>
              {statusLabels[request.status]}
            </Badge>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-600 mt-3">
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>
                {format(new Date(request.start_date), 'dd/MM/yyyy')} - {format(new Date(request.end_date), 'dd/MM/yyyy')}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{request.days_count} jour{request.days_count > 1 ? 's' : ''}</span>
            </div>
          </div>

          {request.review_notes && (
            <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-200">
              <p className="text-xs font-medium text-blue-700 mb-1">
                Notes du manager{request.reviewed_by ? ` (${request.reviewed_by})` : ''}
              </p>
              <p className="text-xs text-slate-700">{request.review_notes}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}