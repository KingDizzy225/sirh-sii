import React from "react";
import { Badge } from "@/components/ui/badge";
import { FileText, Calendar, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800",
  processing: "bg-blue-100 text-blue-800",
  completed: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
};

const statusLabels = {
  pending: "En attente",
  processing: "En cours",
  completed: "Terminée",
  rejected: "Rejetée",
};

export default function MyDocumentRequests({ requests }) {
  if (requests.length === 0) {
    return (
      <div className="text-center py-8 text-slate-500">
        <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
        <p>Aucune demande de document</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {requests.map((request) => (
        <div key={request.id} className="p-4 rounded-lg border border-slate-200 hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-4 h-4 text-blue-600" />
                <h4 className="font-semibold text-slate-900">{request.document_type}</h4>
              </div>
              <p className="text-sm text-slate-600">{request.reason}</p>
            </div>
            <Badge className={statusColors[request.status]}>
              {statusLabels[request.status]}
            </Badge>
          </div>

          <div className="flex items-center gap-4 text-xs text-slate-500 mt-3">
            <div className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              <span>{format(new Date(request.created_date), 'dd/MM/yyyy')}</span>
            </div>
          </div>

          {request.response_notes && (
            <div className="mt-3 p-2 bg-blue-50 rounded border border-blue-200">
              <p className="text-xs font-medium text-blue-700 mb-1">Réponse RH</p>
              <p className="text-xs text-slate-700">{request.response_notes}</p>
            </div>
          )}

          {request.document_url && request.status === 'completed' && (
            <Button
              size="sm"
              variant="outline"
              className="mt-3 w-full"
              onClick={() => window.open(request.document_url, '_blank')}
            >
              <Download className="w-4 h-4 mr-2" />
              Télécharger le document
            </Button>
          )}
        </div>
      ))}
    </div>
  );
}