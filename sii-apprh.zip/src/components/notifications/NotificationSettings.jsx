import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Mail, Save } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const NOTIFICATION_PREFERENCES = [
  {
    id: 'leave_notifications',
    label: 'Demandes de congés',
    description: 'Notifications pour les nouvelles demandes et approbations',
    category: 'Congés'
  },
  {
    id: 'performance_notifications',
    label: 'Évaluations de performance',
    description: 'Rappels et nouvelles évaluations',
    category: 'Performance'
  },
  {
    id: 'training_notifications',
    label: 'Formations',
    description: 'Nouvelles formations et inscriptions',
    category: 'Formation'
  },
  {
    id: 'document_notifications',
    label: 'Documents',
    description: 'Nouveaux documents et partages',
    category: 'Documents'
  },
  {
    id: 'task_notifications',
    label: 'Tâches',
    description: 'Assignations et rappels de tâches',
    category: 'Tâches'
  },
  {
    id: 'message_notifications',
    label: 'Messages',
    description: 'Nouveaux messages et mentions',
    category: 'Communication'
  },
  {
    id: 'system_notifications',
    label: 'Notifications système',
    description: 'Mises à jour importantes du système',
    category: 'Système'
  }
];

export default function NotificationSettings({ user }) {
  const [inAppPreferences, setInAppPreferences] = useState({});
  const [emailPreferences, setEmailPreferences] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadPreferences();
  }, [user]);

  const loadPreferences = async () => {
    try {
      const currentUser = await base44.auth.me();
      const prefs = currentUser.notification_preferences || {};
      
      // Initialiser avec toutes les notifications activées par défaut
      const defaultPrefs = NOTIFICATION_PREFERENCES.reduce((acc, pref) => {
        acc[pref.id] = true;
        return acc;
      }, {});

      setInAppPreferences(prefs.inApp || defaultPrefs);
      setEmailPreferences(prefs.email || {
        ...defaultPrefs,
        message_notifications: false, // Messages désactivés par défaut pour email
        system_notifications: false,
      });
    } catch (error) {
      console.error("Erreur chargement préférences:", error);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await base44.auth.updateMe({
        notification_preferences: {
          inApp: inAppPreferences,
          email: emailPreferences
        }
      });

      toast({
        title: "Préférences sauvegardées",
        description: "Vos préférences de notification ont été mises à jour.",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur sauvegarde préférences:", error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder vos préférences.",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-blue-600" />
            Préférences de Notifications
          </CardTitle>
          <p className="text-sm text-slate-600 mt-1">
            Choisissez comment vous souhaitez recevoir vos notifications
          </p>
        </CardHeader>
        <CardContent className="space-y-6">
          {NOTIFICATION_PREFERENCES.map((pref) => (
            <div key={pref.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50">
              <div className="mb-3">
                <h4 className="font-semibold text-slate-900">{pref.label}</h4>
                <p className="text-xs text-slate-600">{pref.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-3 bg-white rounded border border-slate-200">
                  <div className="flex items-center gap-2">
                    <Bell className="w-4 h-4 text-blue-600" />
                    <Label htmlFor={`inapp-${pref.id}`} className="cursor-pointer">
                      In-App
                    </Label>
                  </div>
                  <Switch
                    id={`inapp-${pref.id}`}
                    checked={inAppPreferences[pref.id] || false}
                    onCheckedChange={(checked) => 
                      setInAppPreferences({...inAppPreferences, [pref.id]: checked})
                    }
                  />
                </div>

                <div className="flex items-center justify-between p-3 bg-white rounded border border-slate-200">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-green-600" />
                    <Label htmlFor={`email-${pref.id}`} className="cursor-pointer">
                      Email
                    </Label>
                  </div>
                  <Switch
                    id={`email-${pref.id}`}
                    checked={emailPreferences[pref.id] || false}
                    onCheckedChange={(checked) => 
                      setEmailPreferences({...emailPreferences, [pref.id]: checked})
                    }
                  />
                </div>
              </div>
            </div>
          ))}

          <div className="flex justify-end pt-4 border-t">
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Enregistrement...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Sauvegarder les préférences
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Bell className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-blue-900 mb-1">
                💡 À propos des notifications
              </p>
              <p className="text-xs text-blue-700 leading-relaxed">
                Les notifications <strong>in-app</strong> apparaissent dans le centre de notifications (icône cloche).<br/>
                Les notifications <strong>email</strong> sont envoyées à votre adresse professionnelle.<br/>
                Les notifications urgentes sont toujours envoyées, quelle que soit votre configuration.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}