import { base44 } from "@/api/base44Client";
import { format, addDays } from "date-fns";
import { fr } from "date-fns/locale";

/**
 * Système de déclenchement automatique des notifications
 */

/**
 * Notifie lors de l'approbation/rejet d'un congé
 */
export async function notifyLeaveStatus(leaveRequest, status, reviewNotes = "") {
  try {
    const isApproved = status === 'approved';
    
    // Notification pour l'employé
    await base44.entities.Notification.create({
      user_email: leaveRequest.employee_email,
      user_name: leaveRequest.employee_name,
      notification_type: isApproved ? "leave_approved" : "leave_rejected",
      title: isApproved ? "Congé approuvé ✅" : "Congé refusé ❌",
      message: isApproved
        ? `Votre demande de congé du ${format(new Date(leaveRequest.start_date), 'd MMM', { locale: fr })} au ${format(new Date(leaveRequest.end_date), 'd MMM', { locale: fr })} a été approuvée.`
        : `Votre demande de congé a été refusée. ${reviewNotes ? 'Raison: ' + reviewNotes : ''}`,
      priority: "high",
      action_url: "/EmployeePortal?tab=leaves",
      action_label: "Voir mes congés",
      related_id: leaveRequest.id,
      related_type: "LeaveRequest",
      sender_email: leaveRequest.reviewed_by,
      icon: isApproved ? "check-circle" : "x-circle"
    });

    // Email notification
    if (isApproved) {
      await base44.integrations.Core.SendEmail({
        to: leaveRequest.employee_email,
        subject: "Votre demande de congé a été approuvée",
        body: `
Bonjour ${leaveRequest.employee_name},

Votre demande de congé a été approuvée :

📅 Du : ${format(new Date(leaveRequest.start_date), 'd MMMM yyyy', { locale: fr })}
📅 Au : ${format(new Date(leaveRequest.end_date), 'd MMMM yyyy', { locale: fr })}
🏖️ Type : ${leaveRequest.leave_type}
📊 Durée : ${leaveRequest.days_count} jour(s)

Bon repos !

L'équipe RH
        `
      });
    }

    return true;
  } catch (error) {
    console.error("Erreur notification congé:", error);
    return false;
  }
}

/**
 * Notifie lors d'une nouvelle demande de congé (pour le manager/RH)
 */
export async function notifyNewLeaveRequest(leaveRequest, managerEmail) {
  try {
    if (!managerEmail) return;

    await base44.entities.Notification.create({
      user_email: managerEmail,
      user_name: managerEmail,
      notification_type: "leave_request",
      title: "Nouvelle demande de congé",
      message: `${leaveRequest.employee_name} a demandé un congé du ${format(new Date(leaveRequest.start_date), 'd MMM', { locale: fr })} au ${format(new Date(leaveRequest.end_date), 'd MMM', { locale: fr })} (${leaveRequest.days_count} jours).`,
      priority: "medium",
      action_url: "/LeaveManagement",
      action_label: "Traiter la demande",
      related_id: leaveRequest.id,
      related_type: "LeaveRequest",
      sender_email: leaveRequest.employee_email,
      sender_name: leaveRequest.employee_name,
      icon: "calendar"
    });

    return true;
  } catch (error) {
    console.error("Erreur notification nouvelle demande congé:", error);
    return false;
  }
}

/**
 * Notifie lors de la création d'une évaluation de performance
 */
export async function notifyPerformanceReview(review, employeeEmail) {
  try {
    await base44.entities.Notification.create({
      user_email: employeeEmail,
      user_name: review.employee_name,
      notification_type: "performance_review",
      title: "Nouvelle évaluation de performance",
      message: `Votre évaluation pour la période ${review.review_period} est disponible. Note globale: ${review.overall_rating}/5`,
      priority: "high",
      action_url: "/EmployeePortal?tab=performance",
      action_label: "Consulter l'évaluation",
      related_id: review.id,
      related_type: "PerformanceReview",
      sender_email: review.reviewer_email,
      icon: "award"
    });

    // Email notification
    await base44.integrations.Core.SendEmail({
      to: employeeEmail,
      subject: "Votre évaluation de performance est disponible",
      body: `
Bonjour ${review.employee_name},

Votre évaluation de performance pour la période ${review.review_period} est maintenant disponible.

📊 Note globale : ${review.overall_rating}/5
🎯 Compétences techniques : ${review.technical_skills}/5
💬 Communication : ${review.communication}/5
👥 Travail d'équipe : ${review.teamwork}/5
⭐ Leadership : ${review.leadership}/5

Connectez-vous au portail employé pour consulter les détails complets.

Cordialement,
L'équipe RH
      `
    });

    return true;
  } catch (error) {
    console.error("Erreur notification évaluation:", error);
    return false;
  }
}

/**
 * Notifie lors du partage d'un document
 */
export async function notifyDocumentShared(documentShare) {
  try {
    await base44.entities.Notification.create({
      user_email: documentShare.shared_with_value,
      user_name: documentShare.shared_with_name,
      notification_type: "document_shared",
      title: "Document partagé avec vous",
      message: `${documentShare.shared_by_name} a partagé "${documentShare.document_title}" avec vous (${documentShare.permission_level}).`,
      priority: "medium",
      action_url: "/Documents",
      action_label: "Consulter le document",
      related_id: documentShare.document_id,
      related_type: "Document",
      sender_email: documentShare.shared_by,
      sender_name: documentShare.shared_by_name,
      icon: "file-text"
    });

    return true;
  } catch (error) {
    console.error("Erreur notification partage document:", error);
    return false;
  }
}

/**
 * Notifie lors de l'upload d'un nouveau document
 */
export async function notifyDocumentUploaded(document, recipientEmails = []) {
  try {
    const notifications = recipientEmails.map(email => 
      base44.entities.Notification.create({
        user_email: email,
        user_name: email,
        notification_type: "document_uploaded",
        title: "Nouveau document disponible",
        message: `Le document "${document.title}" (${document.document_type}) a été ajouté.`,
        priority: "low",
        action_url: "/Documents",
        action_label: "Voir le document",
        related_id: document.id,
        related_type: "Document",
        sender_email: document.uploaded_by,
        icon: "file-text"
      })
    );

    await Promise.all(notifications);
    return true;
  } catch (error) {
    console.error("Erreur notification document uploadé:", error);
    return false;
  }
}

/**
 * Notifie lors de l'assignation à une formation
 */
export async function notifyTrainingAssignment(training, employeeEmail, employeeName) {
  try {
    await base44.entities.Notification.create({
      user_email: employeeEmail,
      user_name: employeeName,
      notification_type: "training_assigned",
      title: "Formation assignée 📚",
      message: `Vous avez été inscrit(e) à la formation "${training.title}" prévue le ${format(new Date(training.training_date), 'd MMMM yyyy', { locale: fr })}.`,
      priority: "medium",
      action_url: "/TrainingManagement",
      action_label: "Voir la formation",
      related_id: training.id,
      related_type: "Training",
      icon: "graduation-cap"
    });

    // Email notification
    await base44.integrations.Core.SendEmail({
      to: employeeEmail,
      subject: `Formation assignée: ${training.title}`,
      body: `
Bonjour ${employeeName},

Vous avez été inscrit(e) à une nouvelle formation :

📚 Formation : ${training.title}
📅 Date : ${format(new Date(training.training_date), 'd MMMM yyyy', { locale: fr })}
⏰ Durée : ${training.duration_hours} heures
📍 Lieu : ${training.location || 'À déterminer'}
${training.training_type ? `💻 Format : ${training.training_type}` : ''}

${training.description || ''}

Connectez-vous au portail pour plus de détails.

Cordialement,
L'équipe RH
      `
    });

    return true;
  } catch (error) {
    console.error("Erreur notification formation:", error);
    return false;
  }
}

/**
 * Notifie lors de la publication d'une nouvelle offre d'emploi
 */
export async function notifyNewJobPosting(jobPosting, targetEmployees = []) {
  try {
    const notifications = targetEmployees.map(employee => 
      base44.entities.Notification.create({
        user_email: employee.email,
        user_name: employee.full_name,
        notification_type: "system",
        title: "Nouvelle opportunité interne 🎯",
        message: `Un nouveau poste est disponible: ${jobPosting.title} (${jobPosting.department})`,
        priority: "medium",
        action_url: "/EmployeePortal?tab=jobs",
        action_label: "Voir le poste",
        related_id: jobPosting.id,
        related_type: "JobPosting",
        icon: "briefcase"
      })
    );

    await Promise.all(notifications);
    return true;
  } catch (error) {
    console.error("Erreur notification nouveau poste:", error);
    return false;
  }
}

/**
 * Notifie un candidat du changement de statut de sa candidature
 */
export async function notifyCandidateStatusChange(candidate, oldStatus, newStatus) {
  try {
    const statusMessages = {
      screening: "Votre candidature est en cours d'examen",
      interview: "Vous avez été sélectionné(e) pour un entretien !",
      offer: "Félicitations ! Une offre vous a été envoyée",
      hired: "Bienvenue dans l'équipe ! Votre candidature a été acceptée",
      rejected: "Votre candidature n'a pas été retenue pour cette fois"
    };

    const message = statusMessages[newStatus] || `Votre candidature a été mise à jour: ${newStatus}`;
    const priority = newStatus === 'hired' || newStatus === 'offer' ? 'urgent' : 
                    newStatus === 'interview' ? 'high' : 'medium';

    // Email notification
    await base44.integrations.Core.SendEmail({
      to: candidate.email,
      subject: `Mise à jour de votre candidature - ${candidate.job_title}`,
      body: `
Bonjour ${candidate.full_name},

${message}

Poste : ${candidate.job_title}
Statut : ${newStatus}

${newStatus === 'interview' ? 'Notre équipe vous contactera prochainement pour planifier un entretien.' : ''}
${newStatus === 'offer' ? 'Veuillez consulter votre email pour les détails de l\'offre.' : ''}
${newStatus === 'hired' ? 'Nous sommes ravis de vous accueillir dans notre équipe !' : ''}

Cordialement,
L'équipe Recrutement
      `
    });

    return true;
  } catch (error) {
    console.error("Erreur notification candidat:", error);
    return false;
  }
}

/**
 * Rappels automatiques pour les évaluations de performance à venir
 */
export async function sendPerformanceReviewReminders() {
  try {
    // Cette fonction peut être appelée périodiquement (cron job)
    const employees = await base44.entities.Employee.filter({ status: 'active' });
    const today = new Date();
    
    for (const employee of employees) {
      // Vérifier si une évaluation est due (exemple: tous les 6 mois)
      const lastReviews = await base44.entities.PerformanceReview.filter({
        employee_email: employee.email
      });

      if (lastReviews.length === 0 || shouldSendReviewReminder(lastReviews[0])) {
        // Notifier le manager
        if (employee.manager_email) {
          await base44.entities.Notification.create({
            user_email: employee.manager_email,
            user_name: employee.manager_name,
            notification_type: "performance_review",
            title: "Évaluation de performance à planifier",
            message: `L'évaluation de ${employee.full_name} doit être réalisée prochainement.`,
            priority: "medium",
            action_url: "/Performance",
            action_label: "Créer l'évaluation",
            related_id: employee.id,
            related_type: "Employee",
            icon: "award"
          });
        }
      }
    }

    return true;
  } catch (error) {
    console.error("Erreur envoi rappels évaluations:", error);
    return false;
  }
}

function shouldSendReviewReminder(lastReview) {
  if (!lastReview?.review_date) return true;
  
  const lastReviewDate = new Date(lastReview.review_date);
  const monthsSinceLastReview = Math.floor(
    (new Date() - lastReviewDate) / (1000 * 60 * 60 * 24 * 30)
  );
  
  return monthsSinceLastReview >= 6; // Rappel tous les 6 mois
}

/**
 * Notifie lors de l'assignation d'une tâche
 */
export async function notifyTaskAssigned(task) {
  try {
    await base44.entities.Notification.create({
      user_email: task.assigned_to,
      user_name: task.assigned_to,
      notification_type: "task_assigned",
      title: "Nouvelle tâche assignée",
      message: `${task.title} - Échéance: ${format(new Date(task.due_date), 'd MMMM', { locale: fr })}`,
      priority: task.priority === 'critical' ? 'urgent' : task.priority,
      action_url: "/Onboarding",
      action_label: "Voir la tâche",
      related_id: task.id,
      related_type: "OnboardingTask",
      icon: "check-circle"
    });

    return true;
  } catch (error) {
    console.error("Erreur notification tâche:", error);
    return false;
  }
}

/**
 * Rappels pour les tâches approchant de leur échéance
 */
export async function sendTaskDeadlineReminders() {
  try {
    const tasks = await base44.entities.OnboardingTask.filter({
      status: 'pending'
    });

    const tomorrow = addDays(new Date(), 1);
    const in3Days = addDays(new Date(), 3);

    for (const task of tasks) {
      const dueDate = new Date(task.due_date);
      
      // Rappel 3 jours avant
      if (dueDate <= in3Days && dueDate > tomorrow) {
        await base44.entities.Notification.create({
          user_email: task.assigned_to,
          user_name: task.assigned_to,
          notification_type: "deadline_reminder",
          title: "⏰ Tâche à compléter bientôt",
          message: `"${task.title}" doit être terminée dans ${Math.ceil((dueDate - new Date()) / (1000 * 60 * 60 * 24))} jour(s).`,
          priority: "medium",
          action_url: "/Onboarding",
          action_label: "Voir la tâche",
          related_id: task.id,
          related_type: "OnboardingTask",
          icon: "clock"
        });
      }

      // Rappel urgent le jour même
      if (dueDate <= tomorrow) {
        await base44.entities.Notification.create({
          user_email: task.assigned_to,
          user_name: task.assigned_to,
          notification_type: "deadline_reminder",
          title: "🚨 Échéance URGENTE",
          message: `"${task.title}" pour ${task.employee_name} doit être terminée aujourd'hui !`,
          priority: "urgent",
          action_url: "/Onboarding",
          action_label: "Compléter maintenant",
          related_id: task.id,
          related_type: "OnboardingTask",
          icon: "alert-triangle"
        });
      }
    }

    return true;
  } catch (error) {
    console.error("Erreur rappels échéances:", error);
    return false;
  }
}

/**
 * Notifie lors d'une demande de document
 */
export async function notifyDocumentRequest(documentRequest) {
  try {
    // Notifier les RH
    const rhUsers = await base44.entities.UserRole.filter({
      role_type: 'rh_manager',
      is_active: true
    });

    for (const rhUser of rhUsers) {
      await base44.entities.Notification.create({
        user_email: rhUser.user_email,
        user_name: rhUser.user_name,
        notification_type: "system",
        title: "Nouvelle demande de document",
        message: `${documentRequest.employee_name} demande: ${documentRequest.document_type}`,
        priority: "medium",
        action_url: "/Documents",
        action_label: "Traiter la demande",
        related_id: documentRequest.id,
        related_type: "DocumentRequest",
        sender_email: documentRequest.employee_email,
        sender_name: documentRequest.employee_name,
        icon: "file-text"
      });
    }

    return true;
  } catch (error) {
    console.error("Erreur notification demande document:", error);
    return false;
  }
}

/**
 * Notifie l'employé lorsque sa demande de document est traitée
 */
export async function notifyDocumentRequestStatus(documentRequest, status) {
  try {
    const isCompleted = status === 'completed';
    
    await base44.entities.Notification.create({
      user_email: documentRequest.employee_email,
      user_name: documentRequest.employee_name,
      notification_type: isCompleted ? "document_uploaded" : "system",
      title: isCompleted ? "Document prêt ✅" : "Demande traitée",
      message: isCompleted
        ? `Votre demande de ${documentRequest.document_type} a été traitée. Le document est disponible.`
        : `Votre demande de ${documentRequest.document_type} est ${status === 'processing' ? 'en cours de traitement' : 'rejetée'}.`,
      priority: isCompleted ? "high" : "medium",
      action_url: "/Documents",
      action_label: "Télécharger",
      related_id: documentRequest.id,
      related_type: "DocumentRequest",
      icon: "file-text"
    });

    if (isCompleted && documentRequest.document_url) {
      await base44.integrations.Core.SendEmail({
        to: documentRequest.employee_email,
        subject: "Votre document est prêt",
        body: `
Bonjour ${documentRequest.employee_name},

Votre demande de document a été traitée avec succès.

📄 Type de document : ${documentRequest.document_type}
✅ Statut : Prêt à télécharger

Connectez-vous au portail RH pour accéder à votre document.

Cordialement,
L'équipe RH
        `
      });
    }

    return true;
  } catch (error) {
    console.error("Erreur notification statut demande document:", error);
    return false;
  }
}

/**
 * Notification de bienvenue pour les nouveaux employés
 */
export async function notifyNewEmployee(employee) {
  try {
    await base44.entities.Notification.create({
      user_email: employee.email,
      user_name: employee.full_name,
      notification_type: "system",
      title: `Bienvenue chez nous, ${employee.full_name.split(' ')[0]} ! 🎉`,
      message: `Nous sommes ravis de vous accueillir dans l'équipe ${employee.department}. Votre parcours d'intégration commence aujourd'hui.`,
      priority: "high",
      action_url: "/EmployeePortal",
      action_label: "Accéder au portail",
      icon: "sparkles"
    });

    // Email de bienvenue
    await base44.integrations.Core.SendEmail({
      to: employee.email,
      subject: "Bienvenue dans l'équipe !",
      from_name: "Équipe RH",
      body: `
Bonjour ${employee.full_name},

Bienvenue dans notre entreprise ! 🎉

Nous sommes ravis de vous accueillir au sein du département ${employee.department} en tant que ${employee.position}.

📅 Date de début : ${format(new Date(employee.hire_date), 'd MMMM yyyy', { locale: fr })}
🏢 Département : ${employee.department}
💼 Poste : ${employee.position}
${employee.manager_name ? `👤 Manager : ${employee.manager_name}` : ''}

Votre parcours d'intégration a été préparé. Vous recevrez prochainement toutes les informations nécessaires.

Au plaisir de travailler avec vous !

L'équipe RH
      `
    });

    return true;
  } catch (error) {
    console.error("Erreur notification nouvel employé:", error);
    return false;
  }
}

/**
 * Rappels pour les congés approchant
 */
export async function sendUpcomingLeaveReminders() {
  try {
    const approvedLeaves = await base44.entities.LeaveRequest.filter({
      status: 'approved'
    });

    const in3Days = addDays(new Date(), 3);
    const today = new Date();

    for (const leave of approvedLeaves) {
      const startDate = new Date(leave.start_date);
      
      // Rappel 3 jours avant le congé
      if (startDate > today && startDate <= in3Days) {
        await base44.entities.Notification.create({
          user_email: leave.employee_email,
          user_name: leave.employee_name,
          notification_type: "system",
          title: "Rappel: Congé dans 3 jours",
          message: `Votre congé commence le ${format(startDate, 'd MMMM', { locale: fr })}. Bon repos à venir !`,
          priority: "low",
          icon: "calendar"
        });
      }
    }

    return true;
  } catch (error) {
    console.error("Erreur rappels congés:", error);
    return false;
  }
}

export default {
  notifyLeaveStatus,
  notifyNewLeaveRequest,
  notifyPerformanceReview,
  notifyDocumentShared,
  notifyDocumentUploaded,
  notifyTrainingAssignment,
  notifyNewJobPosting,
  notifyCandidateStatusChange,
  notifyDocumentRequest,
  notifyDocumentRequestStatus,
  notifyNewEmployee,
  sendPerformanceReviewReminders,
  sendTaskDeadlineReminders,
  sendUpcomingLeaveReminders,
};