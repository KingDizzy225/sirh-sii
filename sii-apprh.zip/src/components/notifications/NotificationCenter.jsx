import { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { 
  Bell, 
  Calendar, 
  FileText, 
  Award, 
  MessageSquare,
  CheckCircle,
  XCircle,
  AlertCircle,
  Clock,
  Trash2
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useNavigate } from "react-router-dom";

const NOTIFICATION_ICONS = {
  leave_request: Calendar,
  leave_approved: CheckCircle,
  leave_rejected: XCircle,
  performance_review: Award,
  document_uploaded: FileText,
  document_shared: FileText,
  training_assigned: Award,
  message_received: MessageSquare,
  mention: MessageSquare,
  task_assigned: CheckCircle,
  deadline_reminder: Clock,
  system: AlertCircle,
};

const NOTIFICATION_COLORS = {
  leave_request: "text-blue-600 bg-blue-50",
  leave_approved: "text-green-600 bg-green-50",
  leave_rejected: "text-red-600 bg-red-50",
  performance_review: "text-purple-600 bg-purple-50",
  document_uploaded: "text-indigo-600 bg-indigo-50",
  document_shared: "text-indigo-600 bg-indigo-50",
  training_assigned: "text-orange-600 bg-orange-50",
  message_received: "text-blue-600 bg-blue-50",
  mention: "text-pink-600 bg-pink-50",
  task_assigned: "text-green-600 bg-green-50",
  deadline_reminder: "text-yellow-600 bg-yellow-50",
  system: "text-slate-600 bg-slate-50",
};

export default function NotificationCenter({ user }) {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications', user?.email],
    queryFn: () => base44.entities.Notification.filter({ 
      user_email: user?.email 
    }),
    enabled: !!user,
    refetchInterval: 10000, // Rafraîchir toutes les 10 secondes
  });

  const markAsReadMutation = useMutation({
    mutationFn: ({ id }) => base44.entities.Notification.update(id, {
      is_read: true,
      read_at: new Date().toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Notification.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifs = notifications.filter(n => !n.is_read);
      await Promise.all(
        unreadNotifs.map(n => 
          base44.entities.Notification.update(n.id, {
            is_read: true,
            read_at: new Date().toISOString(),
          })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  const handleNotificationClick = (notification) => {
    if (!notification.is_read) {
      markAsReadMutation.mutate({ id: notification.id });
    }
    
    if (notification.action_url) {
      setIsOpen(false);
      navigate(notification.action_url);
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;
  const sortedNotifications = [...notifications].sort((a, b) => 
    new Date(b.created_date) - new Date(a.created_date)
  );

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-red-500 text-white text-xs">
              {unreadCount > 9 ? '9+' : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="end">
        <div className="bg-white rounded-lg shadow-xl">
          {/* Header */}
          <div className="p-4 border-b border-slate-200">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-slate-900">Notifications</h3>
              {unreadCount > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => markAllAsReadMutation.mutate()}
                  className="text-xs text-blue-600 hover:text-blue-700"
                >
                  Tout marquer comme lu
                </Button>
              )}
            </div>
          </div>

          {/* Liste des notifications */}
          <div className="max-h-96 overflow-y-auto">
            {sortedNotifications.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                <Bell className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p className="text-sm">Aucune notification</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {sortedNotifications.map((notification) => {
                  const Icon = NOTIFICATION_ICONS[notification.notification_type] || Bell;
                  const colorClass = NOTIFICATION_COLORS[notification.notification_type] || "text-slate-600 bg-slate-50";
                  
                  return (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-slate-50 cursor-pointer transition-colors group ${
                        !notification.is_read ? 'bg-blue-50/30' : ''
                      }`}
                      onClick={() => handleNotificationClick(notification)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${colorClass}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className={`text-sm font-medium ${!notification.is_read ? 'text-slate-900' : 'text-slate-600'}`}>
                              {notification.title}
                            </p>
                            {!notification.is_read && (
                              <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-1" />
                            )}
                          </div>
                          
                          <p className="text-xs text-slate-600 mt-1">
                            {notification.message}
                          </p>
                          
                          <div className="flex items-center justify-between mt-2">
                            <p className="text-xs text-slate-400">
                              {format(new Date(notification.created_date), "d MMM 'à' HH:mm", { locale: fr })}
                            </p>
                            
                            {notification.action_label && (
                              <span className="text-xs text-blue-600 font-medium">
                                {notification.action_label} →
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteMutation.mutate(notification.id);
                          }}
                          className="opacity-0 hover:opacity-100 transition-opacity p-1 hover:bg-slate-200 rounded"
                        >
                          <Trash2 className="w-4 h-4 text-slate-400" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="p-3 border-t border-slate-200 text-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setIsOpen(false);
                  navigate('/notifications');
                }}
                className="text-sm text-blue-600 hover:text-blue-700"
              >
                Voir toutes les notifications
              </Button>
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

// Fonction utilitaire pour créer des notifications
export async function createNotification(data) {
  try {
    await base44.entities.Notification.create({
      ...data,
      created_date: new Date().toISOString(),
    });
  } catch (error) {
    console.error("Error creating notification:", error);
  }
}

// Templates de notifications
export const NOTIFICATION_TEMPLATES = {
  leaveApproved: (employeeName, startDate, endDate) => ({
    notification_type: "leave_approved",
    title: "Congé approuvé ✅",
    message: `Votre demande de congé du ${format(new Date(startDate), 'd MMM', { locale: fr })} au ${format(new Date(endDate), 'd MMM', { locale: fr })} a été approuvée.`,
    priority: "high",
    icon: "check-circle",
  }),

  leaveRejected: (employeeName, startDate, endDate, reason) => ({
    notification_type: "leave_rejected",
    title: "Congé refusé ❌",
    message: `Votre demande de congé du ${format(new Date(startDate), 'd MMM', { locale: fr })} au ${format(new Date(endDate), 'd MMM', { locale: fr })} a été refusée. Raison: ${reason}`,
    priority: "high",
    icon: "x-circle",
  }),

  performanceReviewDue: (employeeName, dueDate) => ({
    notification_type: "performance_review",
    title: "Évaluation de performance à venir",
    message: `Votre évaluation de performance est prévue pour le ${format(new Date(dueDate), 'd MMMM yyyy', { locale: fr })}.`,
    priority: "medium",
    action_label: "Voir l'évaluation",
    action_url: "/performance",
  }),

  documentUploaded: (documentTitle, uploaderName) => ({
    notification_type: "document_uploaded",
    title: "Nouveau document disponible",
    message: `${uploaderName} a ajouté le document "${documentTitle}".`,
    priority: "low",
    action_label: "Voir le document",
    action_url: "/documents",
  }),

  documentShared: (documentTitle, sharedBy) => ({
    notification_type: "document_shared",
    title: "Document partagé avec vous",
    message: `${sharedBy} a partagé le document "${documentTitle}" avec vous.`,
    priority: "medium",
    action_label: "Consulter",
    action_url: "/documents",
  }),

  trainingAssigned: (trainingTitle, trainingDate) => ({
    notification_type: "training_assigned",
    title: "Nouvelle formation assignée",
    message: `Vous avez été inscrit(e) à la formation "${trainingTitle}" prévue le ${format(new Date(trainingDate), 'd MMMM', { locale: fr })}.`,
    priority: "medium",
    action_label: "Voir la formation",
    action_url: "/training-management",
  }),

  messageReceived: (senderName) => ({
    notification_type: "message_received",
    title: "Nouveau message",
    message: `${senderName} vous a envoyé un message.`,
    priority: "low",
    action_label: "Lire",
    action_url: "/chat",
  }),

  deadlineReminder: (taskTitle, dueDate) => ({
    notification_type: "deadline_reminder",
    title: "Rappel de date limite",
    message: `La tâche "${taskTitle}" doit être terminée avant le ${format(new Date(dueDate), 'd MMMM', { locale: fr })}.`,
    priority: "high",
  }),
};