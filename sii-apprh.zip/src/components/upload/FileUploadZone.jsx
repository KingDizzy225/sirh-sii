import React, { useState, useRef, useEffect } from "react";
import { UploadIcon, Camera, Smartphone, FileText, ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function FileUploadZone({ onFileSelect, onCameraCapture, dragActive }) {
  const [showCameraDialog, setShowCameraDialog] = useState(false);
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [isMobile] = useState(/iPhone|iPad|iPod|Android/i.test(navigator.userAgent));
  const fileInputRef = useRef(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: isMobile ? 'environment' : 'user' },
        audio: false 
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraReady(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraReady(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !isCameraReady) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoRef.current, 0, 0);

    canvas.toBlob((blob) => {
      const file = new File([blob], `invoice-${Date.now()}.jpg`, { type: 'image/jpeg' });
      onCameraCapture(file);
      setShowCameraDialog(false);
    }, 'image/jpeg', 0.8);
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  useEffect(() => {
    if (showCameraDialog) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [showCameraDialog]);

  return (
    <>
      <div className={`transition-colors ${dragActive ? "bg-blue-50" : "bg-white"}`}>
        <div className="p-8">
          <div className="max-w-3xl mx-auto">
            <div className="grid md:grid-cols-2 gap-6">
              <div
                className={`relative border-2 border-dashed rounded-xl p-6 transition-all duration-200 ${
                  dragActive 
                    ? "border-blue-400 bg-blue-50" 
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept=".pdf,.png,.jpg,.jpeg"
                  onChange={onFileSelect}
                  className="hidden"
                />
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gray-50 rounded-full flex items-center justify-center">
                    <FileText className="w-8 h-8 text-blue-500" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Télécharger des fichiers</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Glissez-déposez vos factures ici
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleBrowseClick}
                    className="gap-2"
                  >
                    <UploadIcon className="w-4 h-4" />
                    Parcourir les fichiers
                  </Button>
                  <p className="text-xs text-gray-400 mt-4">
                    Supporté: PDF, PNG, JPEG
                  </p>
                </div>
              </div>

              <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 hover:border-gray-300 transition-all duration-200">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gray-50 rounded-full flex items-center justify-center">
                    {isMobile ? (
                      <Smartphone className="w-8 h-8 text-purple-500" />
                    ) : (
                      <Camera className="w-8 h-8 text-purple-500" />
                    )}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">
                    {isMobile ? 'Utiliser l\'appareil photo' : 'Utiliser la webcam'}
                  </h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Prendre une photo de votre facture
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowCameraDialog(true)}
                    className="gap-2"
                  >
                    <ImageIcon className="w-4 h-4" />
                    {isMobile ? 'Ouvrir l\'appareil photo' : 'Démarrer la webcam'}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={showCameraDialog} onOpenChange={setShowCameraDialog}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Prendre une photo de votre facture
            </DialogTitle>
          </DialogHeader>
          <div className="relative aspect-[4/3] bg-black rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="absolute inset-0 w-full h-full object-cover"
            />
            {!isCameraReady && (
              <div className="absolute inset-0 flex items-center justify-center text-white">
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white" />
                  Chargement de la caméra...
                </div>
              </div>
            )}
          </div>
          <div className="flex justify-end gap-3 mt-4">
            <Button
              variant="outline"
              onClick={() => setShowCameraDialog(false)}
            >
              Annuler
            </Button>
            <Button
              onClick={capturePhoto}
              disabled={!isCameraReady}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Capturer la photo
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}