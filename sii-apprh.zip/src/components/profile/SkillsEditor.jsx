import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Award, Plus, Trash2, Edit, Star } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";

const proficiencyLevels = [
  { value: "beginner", label: "Débutant", color: "bg-gray-100 text-gray-800" },
  { value: "intermediate", label: "Intermédiaire", color: "bg-blue-100 text-blue-800" },
  { value: "advanced", label: "Avancé", color: "bg-green-100 text-green-800" },
  { value: "expert", label: "Expert", color: "bg-purple-100 text-purple-800" },
];

const categories = [
  "Technique", "Communication", "Management", "Langues", "Outils", "Soft Skills", "Autre"
];

export default function SkillsEditor({ skills, employee, editable = true }) {
  const [showForm, setShowForm] = useState(false);
  const [editingSkill, setEditingSkill] = useState(null);
  const [formData, setFormData] = useState({
    skill_name: "",
    category: "Technique",
    proficiency_level: "intermediate",
    years_of_experience: "",
    certified: false,
    certification_name: "",
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Skill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySkills'] });
      setShowForm(false);
      resetForm();
      toast({ title: "Compétence ajoutée ✅" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Skill.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySkills'] });
      setShowForm(false);
      setEditingSkill(null);
      resetForm();
      toast({ title: "Compétence mise à jour ✅" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Skill.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mySkills'] });
      toast({ title: "Compétence supprimée" });
    },
  });

  const resetForm = () => {
    setFormData({
      skill_name: "",
      category: "Technique",
      proficiency_level: "intermediate",
      years_of_experience: "",
      certified: false,
      certification_name: "",
    });
  };

  const handleEdit = (skill) => {
    setEditingSkill(skill);
    setFormData({
      skill_name: skill.skill_name,
      category: skill.category || "Technique",
      proficiency_level: skill.proficiency_level,
      years_of_experience: skill.years_of_experience || "",
      certified: skill.certified || false,
      certification_name: skill.certification_name || "",
    });
    setShowForm(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = {
      ...formData,
      employee_email: employee.email,
      employee_name: employee.full_name,
      years_of_experience: formData.years_of_experience ? Number(formData.years_of_experience) : null,
    };

    if (editingSkill) {
      updateMutation.mutate({ id: editingSkill.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const getProficiencyInfo = (level) => proficiencyLevels.find(p => p.value === level) || proficiencyLevels[1];

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Award className="w-5 h-5 text-green-600" />
          Mes compétences ({skills.length})
        </CardTitle>
        {editable && (
          <Button size="sm" onClick={() => { resetForm(); setEditingSkill(null); setShowForm(true); }}>
            <Plus className="w-4 h-4 mr-2" />
            Ajouter
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {skills.length === 0 ? (
          <p className="text-sm text-slate-500 italic text-center py-8">
            Aucune compétence enregistrée. {editable && "Cliquez sur 'Ajouter' pour commencer."}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {skills.map((skill) => {
              const proficiency = getProficiencyInfo(skill.proficiency_level);
              return (
                <div key={skill.id} className="p-4 rounded-lg border border-slate-200 bg-slate-50 hover:border-blue-300 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="font-semibold text-slate-900">{skill.skill_name}</p>
                      {skill.category && (
                        <p className="text-xs text-slate-500">{skill.category}</p>
                      )}
                    </div>
                    {editable && (
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" onClick={() => handleEdit(skill)}>
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-red-600" onClick={() => deleteMutation.mutate(skill.id)}>
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <Badge className={proficiency.color}>{proficiency.label}</Badge>
                    {skill.certified && (
                      <Badge className="bg-purple-600">
                        <Star className="w-3 h-3 mr-1" />
                        Certifié
                      </Badge>
                    )}
                  </div>
                  
                  {skill.years_of_experience && (
                    <p className="text-xs text-slate-600 mt-2">
                      {skill.years_of_experience} an{skill.years_of_experience > 1 ? 's' : ''} d'expérience
                    </p>
                  )}
                  {skill.certification_name && (
                    <p className="text-xs text-purple-600 mt-1">{skill.certification_name}</p>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {showForm && (
          <Dialog open={true} onOpenChange={() => { setShowForm(false); setEditingSkill(null); }}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingSkill ? "Modifier" : "Ajouter"} une compétence</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label>Nom de la compétence *</Label>
                  <Input
                    value={formData.skill_name}
                    onChange={(e) => setFormData({...formData, skill_name: e.target.value})}
                    placeholder="Ex: React, Gestion de projet..."
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Catégorie</Label>
                    <Select value={formData.category} onValueChange={(v) => setFormData({...formData, category: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Niveau</Label>
                    <Select value={formData.proficiency_level} onValueChange={(v) => setFormData({...formData, proficiency_level: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {proficiencyLevels.map(l => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Années d'expérience</Label>
                  <Input
                    type="number"
                    min="0"
                    value={formData.years_of_experience}
                    onChange={(e) => setFormData({...formData, years_of_experience: e.target.value})}
                  />
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="certified"
                    checked={formData.certified}
                    onChange={(e) => setFormData({...formData, certified: e.target.checked})}
                    className="rounded"
                  />
                  <Label htmlFor="certified">Compétence certifiée</Label>
                </div>

                {formData.certified && (
                  <div className="space-y-2">
                    <Label>Nom de la certification</Label>
                    <Input
                      value={formData.certification_name}
                      onChange={(e) => setFormData({...formData, certification_name: e.target.value})}
                      placeholder="Ex: AWS Certified, PMP..."
                    />
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => { setShowForm(false); setEditingSkill(null); }} className="flex-1">
                    Annuler
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} className="flex-1">
                    {editingSkill ? "Mettre à jour" : "Ajouter"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
}