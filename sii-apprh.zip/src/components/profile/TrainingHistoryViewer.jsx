import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Calendar, Clock, MapPin, Award, CheckCircle, PlayCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const trainingTypeLabels = {
  in_person: "Présentiel",
  online: "En ligne",
  hybrid: "Hybride",
  self_paced: "Auto-formation"
};

const levelColors = {
  beginner: "bg-green-100 text-green-800",
  intermediate: "bg-blue-100 text-blue-800",
  advanced: "bg-orange-100 text-orange-800",
  expert: "bg-purple-100 text-purple-800"
};

export default function TrainingHistoryViewer({ trainings, employeeEmail }) {
  if (!trainings || trainings.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-purple-600" />
            Historique des formations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500 italic text-center py-8">
            Aucune formation suivie
          </p>
        </CardContent>
      </Card>
    );
  }

  // Séparer formations terminées et en cours
  const completedTrainings = trainings.filter(t => t.completed_employees?.includes(employeeEmail));
  const ongoingTrainings = trainings.filter(t => 
    t.enrolled_employees?.includes(employeeEmail) && !t.completed_employees?.includes(employeeEmail)
  );

  const totalHours = trainings.reduce((acc, t) => acc + (t.duration_hours || 0), 0);

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-purple-600" />
            Historique des formations
          </span>
          <Badge variant="outline" className="text-sm">
            {totalHours}h de formation
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Formations en cours */}
        {ongoingTrainings.length > 0 && (
          <div>
            <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <PlayCircle className="w-4 h-4 text-blue-600" />
              En cours ({ongoingTrainings.length})
            </h3>
            <div className="space-y-3">
              {ongoingTrainings.map((training) => (
                <TrainingCard key={training.id} training={training} isCompleted={false} />
              ))}
            </div>
          </div>
        )}

        {/* Formations terminées */}
        {completedTrainings.length > 0 && (
          <div>
            <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              Terminées ({completedTrainings.length})
            </h3>
            <div className="space-y-3">
              {completedTrainings.map((training) => (
                <TrainingCard key={training.id} training={training} isCompleted={true} />
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TrainingCard({ training, isCompleted }) {
  return (
    <div className={`p-4 rounded-lg border ${isCompleted ? 'border-green-200 bg-green-50' : 'border-blue-200 bg-blue-50'}`}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1">
          <h4 className="font-semibold text-slate-900">{training.title}</h4>
          {training.category && (
            <p className="text-sm text-slate-600">{training.category}</p>
          )}
        </div>
        <div className="flex gap-2">
          <Badge className={isCompleted ? 'bg-green-600' : 'bg-blue-600'}>
            {isCompleted ? 'Terminé' : 'En cours'}
          </Badge>
          {training.level && (
            <Badge className={levelColors[training.level] || 'bg-gray-100'}>
              {training.level}
            </Badge>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mt-3">
        <div className="flex items-center gap-2 text-slate-600">
          <Calendar className="w-4 h-4" />
          <span>{format(new Date(training.training_date), 'dd/MM/yyyy', { locale: fr })}</span>
        </div>
        
        <div className="flex items-center gap-2 text-slate-600">
          <Clock className="w-4 h-4" />
          <span>{training.duration_hours}h</span>
        </div>

        {training.location && (
          <div className="flex items-center gap-2 text-slate-600">
            <MapPin className="w-4 h-4" />
            <span>{training.location}</span>
          </div>
        )}

        {training.training_type && (
          <Badge variant="outline" className="w-fit">
            {trainingTypeLabels[training.training_type] || training.training_type}
          </Badge>
        )}
      </div>

      {training.skills_taught && training.skills_taught.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1">
          {training.skills_taught.map((skill, idx) => (
            <Badge key={idx} variant="outline" className="text-xs bg-white">{skill}</Badge>
          ))}
        </div>
      )}

      {training.certification && (
        <div className="mt-3">
          <Badge className="bg-purple-600">
            <Award className="w-3 h-3 mr-1" />
            {training.certification_name || "Certification délivrée"}
          </Badge>
        </div>
      )}
    </div>
  );
}