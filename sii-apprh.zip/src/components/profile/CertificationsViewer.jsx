import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Award, Calendar, ExternalLink, Building2, CheckCircle, AlertCircle } from "lucide-react";
import { format, isPast, addDays } from "date-fns";
import { fr } from "date-fns/locale";

export default function CertificationsViewer({ certificates }) {
  if (!certificates || certificates.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-600" />
            Mes certifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-slate-500 italic text-center py-8">
            Aucune certification enregistrée
          </p>
        </CardContent>
      </Card>
    );
  }

  const getStatusInfo = (cert) => {
    if (cert.status === 'expired' || (cert.expiry_date && isPast(new Date(cert.expiry_date)))) {
      return { label: "Expiré", color: "bg-red-100 text-red-800", icon: AlertCircle };
    }
    if (cert.expiry_date) {
      const daysUntilExpiry = Math.ceil((new Date(cert.expiry_date) - new Date()) / (1000 * 60 * 60 * 24));
      if (daysUntilExpiry <= 30) {
        return { label: `Expire dans ${daysUntilExpiry}j`, color: "bg-orange-100 text-orange-800", icon: AlertCircle };
      }
    }
    return { label: "Valide", color: "bg-green-100 text-green-800", icon: CheckCircle };
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="w-5 h-5 text-purple-600" />
          Mes certifications ({certificates.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {certificates.map((cert) => {
            const status = getStatusInfo(cert);
            const StatusIcon = status.icon;
            
            return (
              <div 
                key={cert.id} 
                className={`p-4 rounded-lg border-2 ${
                  status.label === "Expiré" ? "border-red-200 bg-red-50" : 
                  status.label.includes("Expire") ? "border-orange-200 bg-orange-50" :
                  "border-green-200 bg-green-50"
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="font-semibold text-slate-900 text-lg">{cert.certificate_name}</h4>
                    {cert.training_title && (
                      <p className="text-sm text-slate-600">Formation: {cert.training_title}</p>
                    )}
                  </div>
                  <Badge className={status.color}>
                    <StatusIcon className="w-3 h-3 mr-1" />
                    {status.label}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                  {cert.issuing_organization && (
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-slate-400" />
                      <span>{cert.issuing_organization}</span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    <span>Obtenu le {format(new Date(cert.issue_date), 'dd/MM/yyyy', { locale: fr })}</span>
                  </div>
                  
                  {cert.expiry_date && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-slate-400" />
                      <span>Expire le {format(new Date(cert.expiry_date), 'dd/MM/yyyy', { locale: fr })}</span>
                    </div>
                  )}
                </div>

                {cert.skills_acquired && cert.skills_acquired.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {cert.skills_acquired.map((skill, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs">{skill}</Badge>
                    ))}
                  </div>
                )}

                <div className="flex gap-2 mt-3">
                  {cert.certificate_url && (
                    <Button size="sm" variant="outline" onClick={() => window.open(cert.certificate_url, '_blank')}>
                      <ExternalLink className="w-3 h-3 mr-1" />
                      Voir le certificat
                    </Button>
                  )}
                  {cert.verification_url && (
                    <Button size="sm" variant="ghost" onClick={() => window.open(cert.verification_url, '_blank')}>
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Vérifier
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}