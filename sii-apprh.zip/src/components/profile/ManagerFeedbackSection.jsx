import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  MessageSquare, 
  Plus, 
  ThumbsUp, 
  AlertCircle, 
  Target, 
  Calendar,
  User,
  CheckCircle
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const feedbackTypes = [
  { value: "appreciation", label: "Appréciation", icon: ThumbsUp, color: "bg-green-100 text-green-800" },
  { value: "constructive", label: "Constructif", icon: Target, color: "bg-blue-100 text-blue-800" },
  { value: "observation", label: "Observation", icon: MessageSquare, color: "bg-gray-100 text-gray-800" },
  { value: "request", label: "Demande", icon: AlertCircle, color: "bg-orange-100 text-orange-800" },
];

const categoryLabels = {
  technical: "Technique",
  communication: "Communication",
  teamwork: "Travail d'équipe",
  leadership: "Leadership",
  attitude: "Attitude",
  productivity: "Productivité",
  other: "Autre"
};

export default function ManagerFeedbackSection({ employee, isManager = false, currentUserEmail }) {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    feedback_type: "appreciation",
    category: "other",
    content: "",
    context: "",
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Feedback reçu par l'employé
  const { data: receivedFeedback = [] } = useQuery({
    queryKey: ['employeeFeedback', employee?.email],
    queryFn: () => base44.entities.ContinuousFeedback.filter({ 
      receiver_email: employee.email,
      visibility: 'manager' // ou public
    }),
    enabled: !!employee?.email,
  });

  // Feedback donné par le manager à cet employé
  const { data: givenFeedback = [] } = useQuery({
    queryKey: ['managerFeedbackGiven', employee?.email, currentUserEmail],
    queryFn: () => base44.entities.ContinuousFeedback.filter({ 
      receiver_email: employee.email,
      giver_email: currentUserEmail
    }),
    enabled: !!employee?.email && !!currentUserEmail && isManager,
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const user = await base44.auth.me();
      return base44.entities.ContinuousFeedback.create({
        ...data,
        giver_email: user.email,
        giver_name: user.full_name || user.email,
        receiver_email: employee.email,
        receiver_name: employee.full_name,
        visibility: "manager", // Visible par l'employé, manager et RH
        status: "sent",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employeeFeedback'] });
      queryClient.invalidateQueries({ queryKey: ['managerFeedbackGiven'] });
      setShowForm(false);
      setFormData({ feedback_type: "appreciation", category: "other", content: "", context: "" });
      toast({ title: "Feedback envoyé ✅", description: "L'employé peut maintenant le consulter." });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const getFeedbackTypeInfo = (type) => feedbackTypes.find(f => f.value === type) || feedbackTypes[2];

  // Combiner les feedbacks pour l'affichage
  const allFeedback = [...receivedFeedback].sort((a, b) => 
    new Date(b.created_date) - new Date(a.created_date)
  );

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-blue-600" />
          Feedback de performance
        </CardTitle>
        {isManager && (
          <Button size="sm" onClick={() => setShowForm(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Donner un feedback
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {allFeedback.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-sm text-slate-500 italic">
              {isManager 
                ? "Aucun feedback donné. Cliquez sur 'Donner un feedback' pour commencer."
                : "Aucun feedback reçu pour le moment."
              }
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {allFeedback.map((feedback) => {
              const typeInfo = getFeedbackTypeInfo(feedback.feedback_type);
              const TypeIcon = typeInfo.icon;
              
              return (
                <div 
                  key={feedback.id} 
                  className={`p-4 rounded-lg border-l-4 ${
                    feedback.feedback_type === 'appreciation' ? 'border-l-green-500 bg-green-50' :
                    feedback.feedback_type === 'constructive' ? 'border-l-blue-500 bg-blue-50' :
                    feedback.feedback_type === 'request' ? 'border-l-orange-500 bg-orange-50' :
                    'border-l-gray-400 bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Badge className={typeInfo.color}>
                        <TypeIcon className="w-3 h-3 mr-1" />
                        {typeInfo.label}
                      </Badge>
                      {feedback.category && (
                        <Badge variant="outline">{categoryLabels[feedback.category] || feedback.category}</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Calendar className="w-3 h-3" />
                      {format(new Date(feedback.created_date), 'dd MMM yyyy', { locale: fr })}
                    </div>
                  </div>

                  <p className="text-slate-800 mb-3">{feedback.content}</p>

                  {feedback.context && (
                    <div className="text-sm text-slate-600 bg-white/50 rounded p-2 mb-3">
                      <span className="font-medium">Contexte:</span> {feedback.context}
                    </div>
                  )}

                  <div className="flex items-center gap-2 text-xs text-slate-600">
                    <User className="w-3 h-3" />
                    <span>
                      {feedback.is_anonymous ? "Anonyme" : feedback.giver_name}
                    </span>
                  </div>

                  {feedback.status === 'acknowledged' && (
                    <div className="mt-2 flex items-center gap-1 text-xs text-green-600">
                      <CheckCircle className="w-3 h-3" />
                      <span>Accusé de réception</span>
                    </div>
                  )}

                  {feedback.response && (
                    <div className="mt-3 p-3 bg-white rounded border border-slate-200">
                      <p className="text-xs font-medium text-slate-600 mb-1">Réponse:</p>
                      <p className="text-sm text-slate-700">{feedback.response}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Form Dialog */}
        {showForm && (
          <Dialog open={true} onOpenChange={() => setShowForm(false)}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                  Feedback pour {employee.full_name}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type de feedback *</Label>
                    <Select value={formData.feedback_type} onValueChange={(v) => setFormData({...formData, feedback_type: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {feedbackTypes.map(t => (
                          <SelectItem key={t.value} value={t.value}>
                            <span className="flex items-center gap-2">
                              <t.icon className="w-4 h-4" />
                              {t.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Catégorie</Label>
                    <Select value={formData.category} onValueChange={(v) => setFormData({...formData, category: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(categoryLabels).map(([k, v]) => (
                          <SelectItem key={k} value={k}>{v}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Feedback *</Label>
                  <Textarea
                    value={formData.content}
                    onChange={(e) => setFormData({...formData, content: e.target.value})}
                    rows={4}
                    placeholder="Décrivez votre feedback de manière constructive..."
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label>Contexte (optionnel)</Label>
                  <Textarea
                    value={formData.context}
                    onChange={(e) => setFormData({...formData, context: e.target.value})}
                    rows={2}
                    placeholder="Décrivez la situation ou le projet concerné..."
                  />
                </div>

                <div className="flex gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="flex-1">
                    Annuler
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending} className="flex-1">
                    {createMutation.isPending ? "Envoi..." : "Envoyer le feedback"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </CardContent>
    </Card>
  );
}