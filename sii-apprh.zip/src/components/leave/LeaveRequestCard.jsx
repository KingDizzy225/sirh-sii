
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Calendar, User, Check, X, MessageSquare } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { createNotification, NOTIFICATION_TEMPLATES } from "../notifications/NotificationCenter";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  approved: "bg-green-100 text-green-800 border-green-200",
  rejected: "bg-red-100 text-red-800 border-red-200",
};

const leaveTypeColors = {
  vacation: "from-blue-500 to-blue-600",
  sick: "from-red-500 to-red-600",
  personal: "from-purple-500 to-purple-600",
  maternity: "from-pink-500 to-pink-600",
  paternity: "from-indigo-500 to-indigo-600",
  unpaid: "from-gray-500 to-gray-600",
};

export default function LeaveRequestCard({ request, onStatusUpdate }) {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewNotes, setReviewNotes] = useState("");

  const daysDiff = differenceInDays(new Date(request.end_date), new Date(request.start_date)) + 1;

  const handleApprove = async () => {
    onStatusUpdate(request.id, 'approved', reviewNotes);
    setShowReviewForm(false);
    setReviewNotes("");
    
    // Créer une notification
    await createNotification({
      user_email: request.employee_email,
      user_name: request.employee_name,
      ...NOTIFICATION_TEMPLATES.leaveApproved(
        request.employee_name,
        request.start_date,
        request.end_date
      ),
      action_url: "/employee-portal",
      action_label: "Voir mes congés",
    });
  };

  const handleReject = async () => {
    if (!reviewNotes.trim()) {
      alert("Please provide a reason for rejection");
      return;
    }
    onStatusUpdate(request.id, 'rejected', reviewNotes);
    setShowReviewForm(false);
    setReviewNotes("");
    
    // Créer une notification
    await createNotification({
      user_email: request.employee_email,
      user_name: request.employee_name,
      ...NOTIFICATION_TEMPLATES.leaveRejected(
        request.employee_name,
        request.start_date,
        request.end_date,
        reviewNotes
      ),
      action_url: "/employee-portal",
      action_label: "Voir mes congés",
    });
  };

  return (
    <Card className="shadow-lg border-none overflow-hidden">
      <div className={`h-2 bg-gradient-to-r ${leaveTypeColors[request.leave_type]}`} />
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{request.employee_name}</h3>
              <p className="text-sm text-slate-600 capitalize">{request.leave_type.replace('_', ' ')}</p>
            </div>
          </div>
          <Badge className={`${statusColors[request.status]} border`}>
            {request.status}
          </Badge>
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span>
              {format(new Date(request.start_date), 'MMM d')} - {format(new Date(request.end_date), 'MMM d, yyyy')}
            </span>
            <Badge variant="outline" className="ml-auto">
              {daysDiff} {daysDiff === 1 ? 'day' : 'days'}
            </Badge>
          </div>

          <div className="p-3 rounded-lg bg-slate-50">
            <p className="text-xs text-slate-500 mb-1">Reason:</p>
            <p className="text-sm text-slate-700">{request.reason}</p>
          </div>

          {request.review_notes && (
            <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
              <div className="flex items-center gap-2 mb-1">
                <MessageSquare className="w-4 h-4 text-blue-600" />
                <p className="text-xs text-blue-600 font-medium">Review Notes</p>
              </div>
              <p className="text-sm text-slate-700">{request.review_notes}</p>
              {request.reviewed_by && (
                <p className="text-xs text-slate-500 mt-1">By: {request.reviewed_by}</p>
              )}
            </div>
          )}
        </div>

        {request.status === 'pending' && (
          <div className="space-y-3">
            {!showReviewForm ? (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => setShowReviewForm(true)}
                >
                  <Check className="w-4 h-4 mr-1" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                  onClick={() => setShowReviewForm(true)}
                >
                  <X className="w-4 h-4 mr-1" />
                  Reject
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <Textarea
                  placeholder="Add review notes (optional for approval, required for rejection)..."
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  rows={3}
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={handleApprove}
                  >
                    Confirm Approval
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                    onClick={handleReject}
                  >
                    Confirm Rejection
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setShowReviewForm(false);
                      setReviewNotes("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
