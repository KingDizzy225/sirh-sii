import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Award, Download, Eye, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function CertificatesList() {
  const { data: certificates = [], isLoading } = useQuery({
    queryKey: ['certificates'],
    queryFn: () => base44.entities.TrainingCertificate.list('-issue_date'),
  });

  if (isLoading) {
    return <div>Chargement...</div>;
  }

  const validCerts = certificates.filter(c => c.status === 'valid').length;
  const expiredCerts = certificates.filter(c => c.status === 'expired').length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <p className="text-sm text-blue-700">Total certificats</p>
            <p className="text-3xl font-bold text-blue-900">{certificates.length}</p>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-6">
            <p className="text-sm text-green-700">Valides</p>
            <p className="text-3xl font-bold text-green-900">{validCerts}</p>
          </CardContent>
        </Card>
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6">
            <p className="text-sm text-red-700">Expirés</p>
            <p className="text-3xl font-bold text-red-900">{expiredCerts}</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {certificates.map(cert => {
          const isExpired = cert.expiry_date && new Date(cert.expiry_date) < new Date();
          
          return (
            <Card key={cert.id} className={`border-2 ${isExpired ? 'border-red-200 bg-red-50' : 'border-purple-200'}`}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <Award className={`w-10 h-10 ${isExpired ? 'text-red-600' : 'text-purple-600'}`} />
                  <Badge className={isExpired ? 'bg-red-600' : 'bg-green-600'}>
                    {isExpired ? 'Expiré' : 'Valide'}
                  </Badge>
                </div>

                <h3 className="font-bold text-slate-900 mb-2">{cert.certificate_name}</h3>
                <p className="text-sm text-slate-600 mb-3">{cert.employee_name}</p>

                {cert.issuing_organization && (
                  <p className="text-xs text-slate-500 mb-2">
                    Émis par: {cert.issuing_organization}
                  </p>
                )}

                <div className="space-y-1 text-xs text-slate-600 mb-3">
                  <p>📅 Émis: {format(new Date(cert.issue_date), 'd MMM yyyy', { locale: fr })}</p>
                  {cert.expiry_date && (
                    <p className={isExpired ? 'text-red-600 font-semibold' : ''}>
                      ⏰ Expire: {format(new Date(cert.expiry_date), 'd MMM yyyy', { locale: fr })}
                    </p>
                  )}
                </div>

                {cert.skills_acquired && cert.skills_acquired.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {cert.skills_acquired.slice(0, 3).map((skill, i) => (
                      <Badge key={i} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                    {cert.skills_acquired.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{cert.skills_acquired.length - 3}
                      </Badge>
                    )}
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => window.open(cert.certificate_url, '_blank')}
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    Voir
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => window.open(cert.certificate_url, '_blank')}
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Télécharger
                  </Button>
                </div>

                {isExpired && (
                  <div className="mt-3 p-2 bg-red-100 rounded flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                    <p className="text-xs text-red-700">Renouvellement requis</p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {certificates.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center text-slate-500">
            <Award className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <p className="text-lg font-medium">Aucun certificat enregistré</p>
            <p className="text-sm">Téléchargez le premier certificat de formation</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}