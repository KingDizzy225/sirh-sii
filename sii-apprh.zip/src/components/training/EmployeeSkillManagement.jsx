import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Award, GraduationCap, TrendingUp, User, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EmployeeSkillManagement({ employees, skills, trainings, AIComponent }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [filterDepartment, setFilterDepartment] = useState("all");

  // Grouper compétences par employé
  const employeesWithSkills = employees.map(emp => {
    const empSkills = skills.filter(s => s.employee_email === emp.email);
    const empTrainings = trainings.filter(t => 
      t.enrolled_employees?.includes(emp.email) || 
      t.completed_employees?.includes(emp.email)
    );
    
    return {
      ...emp,
      skills: empSkills,
      trainings: empTrainings,
      skillCount: empSkills.length,
      certifiedCount: empSkills.filter(s => s.certified).length,
      trainingCount: empTrainings.length
    };
  });

  // Départements uniques
  const departments = [...new Set(employees.map(e => e.department).filter(Boolean))];

  // Filtrer
  const filteredEmployees = employeesWithSkills.filter(emp => {
    const matchesSearch = emp.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = filterDepartment === "all" || emp.department === filterDepartment;
    return matchesSearch && matchesDept;
  });

  const proficiencyColors = {
    beginner: "bg-gray-100 text-gray-800",
    intermediate: "bg-blue-100 text-blue-800",
    advanced: "bg-green-100 text-green-800",
    expert: "bg-purple-100 text-purple-800",
  };

  return (
    <div className="space-y-6">
      {/* Filtres */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Département" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les départements</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Liste des employés */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredEmployees.map(emp => (
          <Card 
            key={emp.id} 
            className={`border-none shadow-lg hover:shadow-xl transition-shadow cursor-pointer ${
              selectedEmployee?.id === emp.id ? 'ring-2 ring-purple-500' : ''
            }`}
            onClick={() => setSelectedEmployee(emp)}
          >
            <CardHeader className="border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <span className="text-white font-bold text-lg">
                      {emp.full_name?.charAt(0) || 'E'}
                    </span>
                  </div>
                  <div>
                    <CardTitle className="text-lg">{emp.full_name}</CardTitle>
                    <p className="text-sm text-slate-600">{emp.position} • {emp.department}</p>
                  </div>
                </div>
                {selectedEmployee?.id === emp.id && (
                  <Badge className="bg-purple-600">Sélectionné</Badge>
                )}
              </div>
            </CardHeader>

            <CardContent className="p-6">
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <Award className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-blue-900">{emp.skillCount}</p>
                  <p className="text-xs text-blue-700">Compétences</p>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <TrendingUp className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-purple-900">{emp.certifiedCount}</p>
                  <p className="text-xs text-purple-700">Certifiées</p>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <GraduationCap className="w-5 h-5 text-green-600 mx-auto mb-1" />
                  <p className="text-2xl font-bold text-green-900">{emp.trainingCount}</p>
                  <p className="text-xs text-green-700">Formations</p>
                </div>
              </div>

              {emp.skills.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-slate-600 mb-2">Top compétences:</p>
                  <div className="flex flex-wrap gap-2">
                    {emp.skills.slice(0, 4).map((skill, idx) => (
                      <Badge key={idx} className={proficiencyColors[skill.proficiency_level]}>
                        {skill.skill_name}
                      </Badge>
                    ))}
                    {emp.skills.length > 4 && (
                      <Badge variant="outline">+{emp.skills.length - 4}</Badge>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Recommandations IA pour l'employé sélectionné */}
      {selectedEmployee && AIComponent && (
        <AIComponent
          employee={selectedEmployee}
          skills={skills}
          performanceData={[]}
        />
      )}
    </div>
  );
}