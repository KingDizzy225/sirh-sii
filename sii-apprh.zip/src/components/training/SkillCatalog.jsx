import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Award, Plus, Search, Users, TrendingUp, Trash2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const proficiencyColors = {
  beginner: "bg-gray-100 text-gray-800",
  intermediate: "bg-blue-100 text-blue-800",
  advanced: "bg-green-100 text-green-800",
  expert: "bg-purple-100 text-purple-800",
};

const proficiencyLabels = {
  beginner: "Débutant",
  intermediate: "Intermédiaire",
  advanced: "Avancé",
  expert: "Expert",
};

export default function SkillCatalog({ skills, employees }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState("");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    skill_name: "",
    category: "",
    proficiency_level: "intermediate",
    years_of_experience: 0,
    certified: false,
  });

  const createSkillMutation = useMutation({
    mutationFn: (data) => base44.entities.Skill.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      setShowAddForm(false);
      setFormData({
        skill_name: "",
        category: "",
        proficiency_level: "intermediate",
        years_of_experience: 0,
        certified: false,
      });
      toast({
        title: "Compétence ajoutée",
        description: "La compétence a été ajoutée avec succès.",
      });
    },
  });

  const deleteSkillMutation = useMutation({
    mutationFn: (id) => base44.entities.Skill.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] });
      toast({
        title: "Compétence supprimée",
        description: "La compétence a été supprimée.",
        variant: "destructive",
      });
    },
  });

  const handleAddSkill = (e) => {
    e.preventDefault();
    const employee = employees.find(emp => emp.id === selectedEmployee);
    if (!employee) return;

    createSkillMutation.mutate({
      ...formData,
      employee_email: employee.email,
      employee_name: employee.full_name,
    });
  };

  // Regrouper les compétences par nom
  const skillsByName = skills.reduce((acc, skill) => {
    if (!acc[skill.skill_name]) {
      acc[skill.skill_name] = [];
    }
    acc[skill.skill_name].push(skill);
    return acc;
  }, {});

  // Filtrer
  const filteredSkills = Object.entries(skillsByName).filter(([skillName, skillList]) => {
    const matchesSearch = skillName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || 
      skillList.some(s => s.category === filterCategory);
    return matchesSearch && matchesCategory;
  });

  // Obtenir les catégories uniques
  const categories = [...new Set(skills.map(s => s.category).filter(Boolean))];

  return (
    <div className="space-y-6">
      {/* Header avec recherche et filtres */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher une compétence..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Catégorie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes catégories</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={() => setShowAddForm(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Ajouter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Liste des compétences */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSkills.map(([skillName, skillList]) => {
          const categories = [...new Set(skillList.map(s => s.category).filter(Boolean))];
          const employeesWithSkill = skillList.length;
          const certifiedCount = skillList.filter(s => s.certified).length;
          
          // Calculer les niveaux
          const levelCounts = skillList.reduce((acc, skill) => {
            acc[skill.proficiency_level] = (acc[skill.proficiency_level] || 0) + 1;
            return acc;
          }, {});

          return (
            <Card key={skillName} className="border-none shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="border-b border-slate-100">
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-blue-600" />
                    <span className="text-lg">{skillName}</span>
                  </div>
                  {certifiedCount > 0 && (
                    <Badge className="bg-purple-100 text-purple-800">
                      {certifiedCount} certifié{certifiedCount > 1 ? 's' : ''}
                    </Badge>
                  )}
                </CardTitle>
                {categories.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {categories.map(cat => (
                      <Badge key={cat} variant="outline" className="text-xs">
                        {cat}
                      </Badge>
                    ))}
                  </div>
                )}
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Users className="w-4 h-4" />
                    <span className="font-medium">{employeesWithSkill} employé{employeesWithSkill > 1 ? 's' : ''}</span>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-medium text-slate-600">Répartition par niveau :</p>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(levelCounts).map(([level, count]) => (
                        <Badge key={level} className={proficiencyColors[level]}>
                          {proficiencyLabels[level]}: {count}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="pt-3 border-t">
                    <p className="text-xs text-slate-500 mb-2">Employés avec cette compétence :</p>
                    <div className="flex flex-wrap gap-1">
                      {skillList.slice(0, 3).map((skill, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {skill.employee_name}
                        </Badge>
                      ))}
                      {skillList.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{skillList.length - 3} autres
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredSkills.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center text-slate-500">
            <Award className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <p className="text-lg font-medium mb-2">Aucune compétence trouvée</p>
            <p className="text-sm">
              {searchTerm || filterCategory !== "all"
                ? "Essayez de modifier vos filtres"
                : "Commencez par ajouter des compétences"}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Formulaire d'ajout */}
      {showAddForm && (
        <Dialog open={true} onOpenChange={() => setShowAddForm(false)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-blue-600" />
                Ajouter une compétence
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSkill} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Employé *</Label>
                <Select
                  value={selectedEmployee}
                  onValueChange={setSelectedEmployee}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un employé" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.id}>
                        {emp.full_name} - {emp.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="skill_name">Nom de la compétence *</Label>
                <Input
                  id="skill_name"
                  value={formData.skill_name}
                  onChange={(e) => setFormData({...formData, skill_name: e.target.value})}
                  placeholder="ex: React, Python, Gestion de projet"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Catégorie</Label>
                <Input
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  placeholder="ex: Technique, Management, Soft Skills"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="proficiency_level">Niveau de maîtrise *</Label>
                <Select
                  value={formData.proficiency_level}
                  onValueChange={(value) => setFormData({...formData, proficiency_level: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Débutant</SelectItem>
                    <SelectItem value="intermediate">Intermédiaire</SelectItem>
                    <SelectItem value="advanced">Avancé</SelectItem>
                    <SelectItem value="expert">Expert</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="years_of_experience">Années d'expérience</Label>
                <Input
                  id="years_of_experience"
                  type="number"
                  value={formData.years_of_experience}
                  onChange={(e) => setFormData({...formData, years_of_experience: parseInt(e.target.value)})}
                  min="0"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                  Annuler
                </Button>
                <Button 
                  type="submit" 
                  disabled={createSkillMutation.isPending || !selectedEmployee}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createSkillMutation.isPending ? 'Ajout...' : 'Ajouter'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}