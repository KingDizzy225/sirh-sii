import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, X } from "lucide-react";
import { format } from "date-fns";

export default function TrainingForm({ onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    instructor: "",
    instructor_email: "",
    duration_hours: "",
    training_date: format(new Date(), 'yyyy-MM-dd'),
    end_date: "",
    location: "",
    training_type: "in_person",
    level: "beginner",
    prerequisites: [],
    skills_taught: [],
    max_participants: "",
    status: "draft",
    certification: false,
    certification_name: "",
    cost: "",
    external_provider: "",
    registration_deadline: "",
    materials_url: "",
    is_mandatory: false,
    target_departments: [],
    target_positions: [],
  });

  const [newPrerequisite, setNewPrerequisite] = useState("");
  const [newSkill, setNewSkill] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addPrerequisite = () => {
    if (newPrerequisite.trim()) {
      setFormData({
        ...formData,
        prerequisites: [...formData.prerequisites, newPrerequisite.trim()]
      });
      setNewPrerequisite("");
    }
  };

  const removePrerequisite = (index) => {
    setFormData({
      ...formData,
      prerequisites: formData.prerequisites.filter((_, i) => i !== index)
    });
  };

  const addSkill = () => {
    if (newSkill.trim()) {
      setFormData({
        ...formData,
        skills_taught: [...formData.skills_taught, newSkill.trim()]
      });
      setNewSkill("");
    }
  };

  const removeSkill = (index) => {
    setFormData({
      ...formData,
      skills_taught: formData.skills_taught.filter((_, i) => i !== index)
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nouvelle formation</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Informations de base */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Informations de base</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="title">Titre de la formation *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Catégorie</Label>
                <Input
                  id="category"
                  value={formData.category}
                  onChange={(e) => setFormData({...formData, category: e.target.value})}
                  placeholder="ex: Technique, Management"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="level">Niveau *</Label>
                <Select value={formData.level} onValueChange={(value) => setFormData({...formData, level: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">Débutant</SelectItem>
                    <SelectItem value="intermediate">Intermédiaire</SelectItem>
                    <SelectItem value="advanced">Avancé</SelectItem>
                    <SelectItem value="expert">Expert</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="training_type">Type de formation *</Label>
                <Select value={formData.training_type} onValueChange={(value) => setFormData({...formData, training_type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="in_person">Présentiel</SelectItem>
                    <SelectItem value="online">En ligne</SelectItem>
                    <SelectItem value="hybrid">Hybride</SelectItem>
                    <SelectItem value="self_paced">Auto-rythmé</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Statut *</Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Brouillon</SelectItem>
                    <SelectItem value="published">Publié</SelectItem>
                    <SelectItem value="ongoing">En cours</SelectItem>
                    <SelectItem value="completed">Terminé</SelectItem>
                    <SelectItem value="cancelled">Annulé</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Dates et durée */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Dates et durée</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="training_date">Date de début *</Label>
                <Input
                  id="training_date"
                  type="date"
                  value={formData.training_date}
                  onChange={(e) => setFormData({...formData, training_date: e.target.value})}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="end_date">Date de fin</Label>
                <Input
                  id="end_date"
                  type="date"
                  value={formData.end_date}
                  onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="duration_hours">Durée (heures) *</Label>
                <Input
                  id="duration_hours"
                  type="number"
                  value={formData.duration_hours}
                  onChange={(e) => setFormData({...formData, duration_hours: parseFloat(e.target.value)})}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="registration_deadline">Date limite d'inscription</Label>
                <Input
                  id="registration_deadline"
                  type="date"
                  value={formData.registration_deadline}
                  onChange={(e) => setFormData({...formData, registration_deadline: e.target.value})}
                />
              </div>
            </div>
          </div>

          {/* Formateur et lieu */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Formateur et lieu</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="instructor">Formateur</Label>
                <Input
                  id="instructor"
                  value={formData.instructor}
                  onChange={(e) => setFormData({...formData, instructor: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="instructor_email">Email du formateur</Label>
                <Input
                  id="instructor_email"
                  type="email"
                  value={formData.instructor_email}
                  onChange={(e) => setFormData({...formData, instructor_email: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Lieu</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({...formData, location: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="max_participants">Nombre max de participants</Label>
                <Input
                  id="max_participants"
                  type="number"
                  value={formData.max_participants}
                  onChange={(e) => setFormData({...formData, max_participants: parseInt(e.target.value)})}
                />
              </div>
            </div>
          </div>

          {/* Prérequis */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Prérequis</h3>
            <div className="flex gap-2">
              <Input
                value={newPrerequisite}
                onChange={(e) => setNewPrerequisite(e.target.value)}
                placeholder="Ajouter un prérequis"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addPrerequisite())}
              />
              <Button type="button" onClick={addPrerequisite}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.prerequisites.map((prereq, index) => (
                <Badge key={index} variant="outline" className="gap-2">
                  {prereq}
                  <button type="button" onClick={() => removePrerequisite(index)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Compétences enseignées */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Compétences enseignées</h3>
            <div className="flex gap-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Ajouter une compétence"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
              />
              <Button type="button" onClick={addSkill}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.skills_taught.map((skill, index) => (
                <Badge key={index} variant="outline" className="gap-2 bg-blue-50">
                  {skill}
                  <button type="button" onClick={() => removeSkill(index)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Certification et coût */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Certification et coût</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="certification"
                  checked={formData.certification}
                  onCheckedChange={(checked) => setFormData({...formData, certification: checked})}
                />
                <Label htmlFor="certification" className="cursor-pointer">
                  Cette formation délivre une certification
                </Label>
              </div>

              {formData.certification && (
                <div className="space-y-2">
                  <Label htmlFor="certification_name">Nom de la certification</Label>
                  <Input
                    id="certification_name"
                    value={formData.certification_name}
                    onChange={(e) => setFormData({...formData, certification_name: e.target.value})}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="cost">Coût (FCFA)</Label>
                <Input
                  id="cost"
                  type="number"
                  value={formData.cost}
                  onChange={(e) => setFormData({...formData, cost: parseFloat(e.target.value)})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="external_provider">Fournisseur externe</Label>
                <Input
                  id="external_provider"
                  value={formData.external_provider}
                  onChange={(e) => setFormData({...formData, external_provider: e.target.value})}
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="materials_url">Lien vers les supports</Label>
                <Input
                  id="materials_url"
                  type="url"
                  value={formData.materials_url}
                  onChange={(e) => setFormData({...formData, materials_url: e.target.value})}
                  placeholder="https://..."
                />
              </div>
            </div>
          </div>

          {/* Options */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="is_mandatory"
              checked={formData.is_mandatory}
              onCheckedChange={(checked) => setFormData({...formData, is_mandatory: checked})}
            />
            <Label htmlFor="is_mandatory" className="cursor-pointer">
              Formation obligatoire
            </Label>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Création...' : 'Créer la formation'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}