import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { TrendingUp, Users, Award, GraduationCap, DollarSign } from "lucide-react";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function TrainingAnalytics({ trainings, skills, employees }) {
  // Formations par catégorie
  const trainingsByCategory = trainings.reduce((acc, training) => {
    const category = training.category || 'Non catégorisé';
    acc[category] = (acc[category] || 0) + 1;
    return acc;
  }, {});

  const categoryData = Object.entries(trainingsByCategory).map(([name, value]) => ({
    name,
    value,
  }));

  // Formations par statut
  const trainingsByStatus = trainings.reduce((acc, training) => {
    acc[training.status] = (acc[training.status] || 0) + 1;
    return acc;
  }, {});

  const statusLabels = {
    planned: 'Planifiée',
    ongoing: 'En cours',
    completed: 'Terminée',
    cancelled: 'Annulée',
  };

  const statusData = Object.entries(trainingsByStatus).map(([status, count]) => ({
    name: statusLabels[status] || status,
    value: count,
  }));

  // Compétences par niveau
  const skillsByLevel = skills.reduce((acc, skill) => {
    acc[skill.proficiency_level] = (acc[skill.proficiency_level] || 0) + 1;
    return acc;
  }, {});

  const levelLabels = {
    beginner: 'Débutant',
    intermediate: 'Intermédiaire',
    advanced: 'Avancé',
    expert: 'Expert',
  };

  const levelData = Object.entries(skillsByLevel).map(([level, count]) => ({
    name: levelLabels[level] || level,
    count,
  }));

  // Top 10 compétences les plus fréquentes
  const skillCounts = skills.reduce((acc, skill) => {
    acc[skill.skill_name] = (acc[skill.skill_name] || 0) + 1;
    return acc;
  }, {});

  const topSkills = Object.entries(skillCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([name, count]) => ({ name, count }));

  // Statistiques globales
  const totalParticipants = trainings.reduce((sum, t) => 
    sum + (t.enrolled_employees?.length || 0), 0
  );

  const totalCompleted = trainings.reduce((sum, t) => 
    sum + (t.completed_employees?.length || 0), 0
  );

  const completionRate = totalParticipants > 0 
    ? Math.round((totalCompleted / totalParticipants) * 100)
    : 0;

  const totalHours = trainings.reduce((sum, t) => sum + (t.duration_hours || 0), 0);

  const certifiedEmployees = [...new Set(
    skills.filter(s => s.certified).map(s => s.employee_email)
  )].length;

  const avgSkillsPerEmployee = employees.length > 0
    ? (skills.length / employees.length).toFixed(1)
    : 0;

  return (
    <div className="space-y-6">
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Taux de complétion</p>
                <p className="text-3xl font-bold text-slate-900">{completionRate}%</p>
                <p className="text-xs text-slate-500 mt-1">{totalCompleted}/{totalParticipants} participants</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Heures de formation</p>
                <p className="text-3xl font-bold text-slate-900">{totalHours}h</p>
                <p className="text-xs text-slate-500 mt-1">Total cumulé</p>
              </div>
              <GraduationCap className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Employés certifiés</p>
                <p className="text-3xl font-bold text-slate-900">{certifiedEmployees}</p>
                <p className="text-xs text-slate-500 mt-1">Au moins 1 certification</p>
              </div>
              <Award className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Compétences moyennes</p>
                <p className="text-3xl font-bold text-slate-900">{avgSkillsPerEmployee}</p>
                <p className="text-xs text-slate-500 mt-1">Par employé</p>
              </div>
              <Users className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Formations par catégorie */}
        {categoryData.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Formations par catégorie</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Formations par statut */}
        {statusData.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Statut des formations</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Top 10 compétences */}
        {topSkills.length > 0 && (
          <Card className="border-none shadow-lg lg:col-span-2">
            <CardHeader>
              <CardTitle>Top 10 des compétences les plus fréquentes</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={topSkills}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" name="Nombre d'employés" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Répartition par niveau de compétence */}
        {levelData.length > 0 && (
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Niveaux de compétence</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={levelData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" name="Nombre" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Insights */}
        <Card className="border-none shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle>Insights et Recommandations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {completionRate < 70 && completionRate > 0 && (
              <div className="p-3 bg-orange-100 rounded-lg border border-orange-200">
                <p className="text-sm text-orange-800">
                  ⚠️ Le taux de complétion des formations ({completionRate}%) est en dessous de 70%. 
                  Considérez des suivis plus réguliers.
                </p>
              </div>
            )}

            {avgSkillsPerEmployee < 3 && employees.length > 0 && (
              <div className="p-3 bg-blue-100 rounded-lg border border-blue-200">
                <p className="text-sm text-blue-800">
                  💡 Moyenne de {avgSkillsPerEmployee} compétences par employé. 
                  Encouragez la documentation des compétences.
                </p>
              </div>
            )}

            {employees.length > 0 && certifiedEmployees < employees.length * 0.5 && (
              <div className="p-3 bg-purple-100 rounded-lg border border-purple-200">
                <p className="text-sm text-purple-800">
                  🎓 Seulement {Math.round((certifiedEmployees / employees.length) * 100)}% des employés ont une certification. 
                  Proposez plus de formations certifiantes.
                </p>
              </div>
            )}

            {trainingsByStatus.planned > 0 && trainingsByStatus.planned > (trainingsByStatus.completed || 0) && (
              <div className="p-3 bg-green-100 rounded-lg border border-green-200">
                <p className="text-sm text-green-800">
                  ✅ {trainingsByStatus.planned} formations planifiées. 
                  Bonne dynamique de développement des compétences !
                </p>
              </div>
            )}

            {trainings.length === 0 && (
              <div className="p-3 bg-slate-100 rounded-lg border border-slate-200">
                <p className="text-sm text-slate-700">
                  📊 Aucune donnée disponible pour l'instant. Commencez par ajouter des formations et des compétences.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}