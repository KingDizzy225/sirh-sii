import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Users, Award } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  planned: "bg-blue-100 text-blue-800",
  ongoing: "bg-orange-100 text-orange-800",
  completed: "bg-green-100 text-green-800",
  cancelled: "bg-red-100 text-red-800",
};

const statusLabels = {
  planned: "Planifiée",
  ongoing: "En cours",
  completed: "Terminée",
  cancelled: "Annulée",
};

export default function TrainingCard({ training }) {
  const enrolledCount = training.enrolled_employees?.length || 0;
  const completedCount = training.completed_employees?.length || 0;

  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={statusColors[training.status]}>
                {statusLabels[training.status]}
              </Badge>
              {training.certification && (
                <Badge className="bg-purple-100 text-purple-800">
                  <Award className="w-3 h-3 mr-1" />
                  Certification
                </Badge>
              )}
            </div>
            <CardTitle className="text-xl">{training.title}</CardTitle>
            {training.category && (
              <p className="text-sm text-slate-600 mt-1">{training.category}</p>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <p className="text-sm text-slate-700">{training.description}</p>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(training.training_date), 'dd/MM/yyyy')}</span>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Clock className="w-4 h-4" />
            <span>{training.duration_hours}h</span>
          </div>

          {training.location && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <MapPin className="w-4 h-4" />
              <span>{training.location}</span>
            </div>
          )}

          {training.instructor && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Users className="w-4 h-4" />
              <span>{training.instructor}</span>
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-slate-100">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-600">Participants inscrits:</span>
            <span className="font-semibold text-slate-900">
              {enrolledCount}{training.max_participants ? `/${training.max_participants}` : ''}
            </span>
          </div>
          {completedCount > 0 && (
            <div className="flex items-center justify-between text-sm mt-1">
              <span className="text-slate-600">Formation terminée:</span>
              <span className="font-semibold text-green-600">{completedCount}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}