import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Award, Upload, CheckCircle, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Progress } from "@/components/ui/progress";

export default function TrainingCertificateUpload({ employee, training, onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    employee_email: employee?.email || "",
    employee_name: employee?.full_name || "",
    training_id: training?.id || "",
    training_title: training?.title || "",
    certificate_name: "",
    certificate_url: "",
    issue_date: new Date().toISOString().split('T')[0],
    expiry_date: "",
    issuing_organization: "",
    certificate_number: "",
    skills_acquired: [],
    verification_url: "",
    status: "valid",
    notes: ""
  });
  
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedSkill, setSelectedSkill] = useState("");
  const [availableSkills, setAvailableSkills] = useState([]);

  useEffect(() => {
    loadSkills();
  }, []);

  const loadSkills = async () => {
    if (training?.skills_taught) {
      setAvailableSkills(training.skills_taught);
    } else {
      const allSkills = await base44.entities.Skill.list();
      const uniqueSkills = [...new Set(allSkills.map(s => s.skill_name))];
      setAvailableSkills(uniqueSkills);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadProgress(0);

    try {
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => prev >= 90 ? prev : prev + 10);
      }, 200);

      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setFormData({ ...formData, certificate_url: file_url });
    } catch (error) {
      console.error("Erreur upload:", error);
      alert("Échec du téléchargement");
    } finally {
      setUploading(false);
    }
  };

  const addSkill = () => {
    if (selectedSkill && !formData.skills_acquired.includes(selectedSkill)) {
      setFormData({
        ...formData,
        skills_acquired: [...formData.skills_acquired, selectedSkill]
      });
      setSelectedSkill("");
    }
  };

  const removeSkill = (skill) => {
    setFormData({
      ...formData,
      skills_acquired: formData.skills_acquired.filter(s => s !== skill)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const user = await base44.auth.me();
    await base44.entities.TrainingCertificate.create({
      ...formData,
      uploaded_by: user.email
    });

    // Mettre à jour les compétences de l'employé
    for (const skill of formData.skills_acquired) {
      const existingSkills = await base44.entities.Skill.filter({
        employee_email: formData.employee_email,
        skill_name: skill
      });

      if (existingSkills.length === 0) {
        await base44.entities.Skill.create({
          employee_email: formData.employee_email,
          employee_name: formData.employee_name,
          skill_name: skill,
          proficiency_level: "intermediate",
          certified: true,
          certification_name: formData.certificate_name
        });
      } else {
        await base44.entities.Skill.update(existingSkills[0].id, {
          certified: true,
          certification_name: formData.certificate_name
        });
      }
    }

    onSuccess();
    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-600" />
            Télécharger un Certificat de Formation
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Employé</Label>
              <Input value={formData.employee_name} disabled />
            </div>
            <div className="space-y-2">
              <Label>Formation</Label>
              <Input value={formData.training_title} disabled />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Nom du certificat *</Label>
            <Input
              value={formData.certificate_name}
              onChange={(e) => setFormData({...formData, certificate_name: e.target.value})}
              placeholder="ex: Certificat AWS Solutions Architect"
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Fichier du certificat *</Label>
            <div className="border-2 border-dashed rounded-lg p-6 text-center">
              <Input
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                id="cert-upload"
                accept=".pdf,.jpg,.jpeg,.png"
              />
              
              {!formData.certificate_url ? (
                <label htmlFor="cert-upload" className="cursor-pointer">
                  <Upload className="w-12 h-12 mx-auto mb-2 text-slate-400" />
                  {uploading ? (
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600">Téléchargement...</p>
                      <Progress value={uploadProgress} />
                    </div>
                  ) : (
                    <p className="text-sm text-slate-600">Cliquez pour uploader</p>
                  )}
                </label>
              ) : (
                <div className="space-y-2">
                  <CheckCircle className="w-12 h-12 mx-auto text-green-600" />
                  <p className="text-sm text-green-600">✓ Fichier uploadé</p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setFormData({...formData, certificate_url: ""})}
                  >
                    Changer
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Date d'émission *</Label>
              <Input
                type="date"
                value={formData.issue_date}
                onChange={(e) => setFormData({...formData, issue_date: e.target.value})}
                required
              />
            </div>
            <div className="space-y-2">
              <Label>Date d'expiration</Label>
              <Input
                type="date"
                value={formData.expiry_date}
                onChange={(e) => setFormData({...formData, expiry_date: e.target.value})}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Organisme émetteur</Label>
              <Input
                value={formData.issuing_organization}
                onChange={(e) => setFormData({...formData, issuing_organization: e.target.value})}
                placeholder="ex: AWS, Google, Microsoft"
              />
            </div>
            <div className="space-y-2">
              <Label>Numéro du certificat</Label>
              <Input
                value={formData.certificate_number}
                onChange={(e) => setFormData({...formData, certificate_number: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Compétences acquises</Label>
            <div className="flex gap-2">
              <Select value={selectedSkill} onValueChange={setSelectedSkill}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Sélectionner une compétence" />
                </SelectTrigger>
                <SelectContent className="max-h-[200px]">
                  {availableSkills.map(skill => (
                    <SelectItem key={skill} value={skill}>{skill}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button type="button" onClick={addSkill}>Ajouter</Button>
            </div>
            
            {formData.skills_acquired.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.skills_acquired.map(skill => (
                  <Badge key={skill} className="bg-purple-600">
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="ml-2"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>URL de vérification</Label>
            <Input
              value={formData.verification_url}
              onChange={(e) => setFormData({...formData, verification_url: e.target.value})}
              placeholder="Lien pour vérifier l'authenticité"
            />
          </div>

          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit" disabled={uploading || !formData.certificate_url}>
              Enregistrer le certificat
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}