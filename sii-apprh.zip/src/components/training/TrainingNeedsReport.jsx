import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Users, 
  TrendingUp, 
  Award,
  Download,
  Calendar
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

export default function TrainingNeedsReport() {
  const [reportData, setReportData] = useState(null);

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
  });

  const { data: certificates = [] } = useQuery({
    queryKey: ['certificates'],
    queryFn: () => base44.entities.TrainingCertificate.list(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews'],
    queryFn: () => base44.entities.PerformanceReview.list(),
  });

  useEffect(() => {
    if (employees.length > 0) {
      generateReport();
    }
  }, [employees, skills, trainings, certificates, reviews]);

  const generateReport = () => {
    // Besoins par département
    const departmentNeeds = {};
    employees.forEach(emp => {
      if (!departmentNeeds[emp.department]) {
        departmentNeeds[emp.department] = {
          name: emp.department,
          employees: 0,
          avgSkills: 0,
          certificates: 0,
          lowPerformers: 0,
          trainingBudget: 0
        };
      }
      departmentNeeds[emp.department].employees++;
    });

    // Compétences moyennes par département
    const skillsByDept = {};
    skills.forEach(skill => {
      const emp = employees.find(e => e.email === skill.employee_email);
      if (emp && emp.department) {
        if (!skillsByDept[emp.department]) skillsByDept[emp.department] = [];
        skillsByDept[emp.department].push(skill);
      }
    });

    Object.keys(departmentNeeds).forEach(dept => {
      const deptSkills = skillsByDept[dept] || [];
      departmentNeeds[dept].avgSkills = departmentNeeds[dept].employees > 0
        ? Math.round(deptSkills.length / departmentNeeds[dept].employees)
        : 0;
    });

    // Certificats par département
    certificates.forEach(cert => {
      const emp = employees.find(e => e.email === cert.employee_email);
      if (emp && departmentNeeds[emp.department]) {
        departmentNeeds[emp.department].certificates++;
      }
    });

    // Performances basses nécessitant formation
    reviews.forEach(review => {
      if (review.overall_rating < 3) {
        const emp = employees.find(e => e.email === review.employee_email);
        if (emp && departmentNeeds[emp.department]) {
          departmentNeeds[emp.department].lowPerformers++;
        }
      }
    });

    // Calcul budget formation estimé (par employé ayant besoin)
    Object.keys(departmentNeeds).forEach(dept => {
      const needs = departmentNeeds[dept].lowPerformers + 
                   Math.max(0, departmentNeeds[dept].employees - departmentNeeds[dept].certificates);
      departmentNeeds[dept].trainingBudget = needs * 50000; // 50k FCFA par formation
    });

    // Compétences les plus demandées
    const skillDemand = {};
    skills.forEach(skill => {
      skillDemand[skill.skill_name] = (skillDemand[skill.skill_name] || 0) + 1;
    });

    const topSkills = Object.entries(skillDemand)
      .map(([name, count]) => ({ name, value: count }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 6);

    // Formations récentes
    const recentTrainings = trainings
      .filter(t => new Date(t.training_date) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000))
      .length;

    // Certifications expirées
    const expiredCertificates = certificates.filter(c => 
      c.expiry_date && new Date(c.expiry_date) < new Date()
    ).length;

    // Stats globales
    const totalTrainingNeeds = Object.values(departmentNeeds).reduce((sum, d) => 
      sum + d.lowPerformers + Math.max(0, d.employees - d.certificates), 0
    );
    
    const totalBudget = Object.values(departmentNeeds).reduce((sum, d) => 
      sum + d.trainingBudget, 0
    );

    setReportData({
      departments: Object.values(departmentNeeds),
      topSkills,
      totalEmployees: employees.length,
      totalTrainingNeeds,
      totalBudget,
      recentTrainings,
      expiredCertificates,
      avgCertificatesPerEmployee: employees.length > 0 
        ? (certificates.length / employees.length).toFixed(1)
        : 0
    });
  };

  const exportReport = () => {
    if (!reportData) return;

    const content = `
RAPPORT DES BESOINS EN FORMATION
Généré le: ${new Date().toLocaleDateString('fr-FR')}

STATISTIQUES GLOBALES:
- Nombre d'employés: ${reportData.totalEmployees}
- Besoins en formation totaux: ${reportData.totalTrainingNeeds}
- Budget estimé: ${reportData.totalBudget.toLocaleString()} FCFA
- Formations récentes (90j): ${reportData.recentTrainings}
- Certificats expirés: ${reportData.expiredCertificates}
- Moyenne certificats/employé: ${reportData.avgCertificatesPerEmployee}

BESOINS PAR DÉPARTEMENT:
${reportData.departments.map(dept => `
${dept.name}:
  - Employés: ${dept.employees}
  - Compétences moyennes: ${dept.avgSkills}
  - Certificats obtenus: ${dept.certificates}
  - Besoins en formation: ${dept.lowPerformers + Math.max(0, dept.employees - dept.certificates)}
  - Budget estimé: ${dept.trainingBudget.toLocaleString()} FCFA
`).join('\n')}

COMPÉTENCES LES PLUS DEMANDÉES:
${reportData.topSkills.map((skill, i) => `${i + 1}. ${skill.name}: ${skill.value} employés`).join('\n')}

RECOMMANDATIONS:
${reportData.departments
  .filter(d => d.lowPerformers > 0 || d.certificates < d.employees * 0.5)
  .map(d => `- ${d.name}: Prévoir formations pour ${d.lowPerformers + Math.max(0, d.employees - d.certificates)} employés`)
  .join('\n')}
`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Rapport_Besoins_Formation_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (!reportData) {
    return <div>Génération du rapport...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Stats globales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Employés</p>
                <p className="text-3xl font-bold text-blue-900">{reportData.totalEmployees}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Besoins formation</p>
                <p className="text-3xl font-bold text-orange-900">{reportData.totalTrainingNeeds}</p>
              </div>
              <BookOpen className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Budget estimé</p>
                <p className="text-2xl font-bold text-green-900">
                  {(reportData.totalBudget / 1000000).toFixed(1)}M
                </p>
                <p className="text-xs text-green-600">FCFA</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Moy. certificats</p>
                <p className="text-3xl font-bold text-purple-900">{reportData.avgCertificatesPerEmployee}</p>
                <p className="text-xs text-purple-600">par employé</p>
              </div>
              <Award className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex justify-end">
        <Button onClick={exportReport} className="bg-blue-600">
          <Download className="w-4 h-4 mr-2" />
          Exporter le rapport complet
        </Button>
      </div>

      {/* Graphique compétences */}
      <Card>
        <CardHeader>
          <CardTitle>Top 6 des Compétences Demandées</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={reportData.topSkills}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry) => entry.name}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {reportData.topSkills.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Besoins par département */}
      <Card>
        <CardHeader>
          <CardTitle>Besoins en Formation par Département</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {reportData.departments
            .sort((a, b) => b.trainingBudget - a.trainingBudget)
            .map((dept, index) => {
              const trainingNeeds = dept.lowPerformers + Math.max(0, dept.employees - dept.certificates);
              const priority = trainingNeeds > dept.employees * 0.3 ? 'high' : 
                             trainingNeeds > dept.employees * 0.1 ? 'medium' : 'low';

              return (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-bold text-slate-900">{dept.name}</h4>
                        {priority === 'high' && <Badge className="bg-red-600">Priorité haute</Badge>}
                        {priority === 'medium' && <Badge className="bg-orange-600">Priorité moyenne</Badge>}
                      </div>
                      <p className="text-sm text-slate-600">
                        {dept.employees} employés • {dept.certificates} certificats
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-slate-900">{trainingNeeds}</p>
                      <p className="text-xs text-slate-600">besoins formation</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div className="p-2 bg-slate-50 rounded">
                      <p className="text-slate-600">Compétences moy.</p>
                      <p className="font-semibold">{dept.avgSkills}</p>
                    </div>
                    <div className="p-2 bg-slate-50 rounded">
                      <p className="text-slate-600">Perf. basses</p>
                      <p className="font-semibold">{dept.lowPerformers}</p>
                    </div>
                    <div className="p-2 bg-slate-50 rounded">
                      <p className="text-slate-600">Sans certificat</p>
                      <p className="font-semibold">{Math.max(0, dept.employees - dept.certificates)}</p>
                    </div>
                    <div className="p-2 bg-green-50 rounded">
                      <p className="text-green-700">Budget estimé</p>
                      <p className="font-semibold text-green-900">
                        {(dept.trainingBudget / 1000).toFixed(0)}k FCFA
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
        </CardContent>
      </Card>

      {/* Alertes */}
      {reportData.expiredCertificates > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Calendar className="w-6 h-6 text-red-600" />
              <div>
                <p className="font-semibold text-red-900">
                  ⚠️ {reportData.expiredCertificates} certificat(s) expiré(s)
                </p>
                <p className="text-sm text-red-700">
                  Des employés doivent renouveler leurs certifications
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}