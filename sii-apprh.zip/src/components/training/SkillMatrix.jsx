import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Award, Grid3x3, List, Download, Search, Filter, Users, TrendingUp, Star } from "lucide-react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const proficiencyColors = {
  beginner: "bg-gray-100 text-gray-800",
  intermediate: "bg-blue-100 text-blue-800",
  advanced: "bg-green-100 text-green-800",
  expert: "bg-purple-100 text-purple-800",
};

const proficiencyLabels = {
  beginner: "Débutant",
  intermediate: "Intermédiaire",
  advanced: "Avancé",
  expert: "Expert",
};

const proficiencyScores = {
  beginner: 1,
  intermediate: 2,
  advanced: 3,
  expert: 4,
};

export default function SkillMatrix({ skills, employees }) {
  const [viewMode, setViewMode] = useState("list"); // "list" ou "grid"
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterProficiency, setFilterProficiency] = useState("all");
  const [sortBy, setSortBy] = useState("name"); // "name", "skills", "score"

  // Regrouper les compétences par employé
  const groupedSkills = skills.reduce((acc, skill) => {
    if (!acc[skill.employee_name]) {
      acc[skill.employee_name] = {
        name: skill.employee_name,
        email: skill.employee_email,
        skills: []
      };
    }
    acc[skill.employee_name].skills.push(skill);
    return acc;
  }, {});

  // Calculer le score moyen de chaque employé
  const employeesWithScores = Object.values(groupedSkills).map(emp => {
    const totalScore = emp.skills.reduce((sum, skill) => 
      sum + (proficiencyScores[skill.proficiency_level] || 0), 0
    );
    const avgScore = emp.skills.length > 0 ? totalScore / emp.skills.length : 0;
    const certifiedCount = emp.skills.filter(s => s.certified).length;
    
    return {
      ...emp,
      avgScore,
      totalScore,
      certifiedCount
    };
  });

  // Extraire les catégories uniques
  const categories = [...new Set(skills.map(s => s.category).filter(Boolean))];

  // Filtrer les employés
  const filteredEmployees = employeesWithScores.filter(emp => {
    const matchesSearch = emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         emp.email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = filterCategory === "all" || 
                           emp.skills.some(s => s.category === filterCategory);
    
    const matchesProficiency = filterProficiency === "all" ||
                               emp.skills.some(s => s.proficiency_level === filterProficiency);
    
    return matchesSearch && matchesCategory && matchesProficiency;
  });

  // Trier les employés
  const sortedEmployees = [...filteredEmployees].sort((a, b) => {
    if (sortBy === "name") return a.name.localeCompare(b.name);
    if (sortBy === "skills") return b.skills.length - a.skills.length;
    if (sortBy === "score") return b.avgScore - a.avgScore;
    return 0;
  });

  // Statistiques globales
  const totalEmployees = Object.keys(groupedSkills).length;
  const totalSkills = skills.length;
  const avgSkillsPerEmployee = totalEmployees > 0 ? (totalSkills / totalEmployees).toFixed(1) : 0;
  const totalCertified = skills.filter(s => s.certified).length;

  // Export CSV
  const exportToCSV = () => {
    const headers = ["Employé", "Email", "Compétence", "Catégorie", "Niveau", "Expérience (ans)", "Certifié"];
    const rows = skills.map(skill => [
      skill.employee_name,
      skill.employee_email,
      skill.skill_name,
      skill.category || "",
      proficiencyLabels[skill.proficiency_level],
      skill.years_of_experience || 0,
      skill.certified ? "Oui" : "Non"
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `matrice_competences_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-6">
      {/* Stats globales */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Employés</p>
                <p className="text-3xl font-bold text-blue-900">{totalEmployees}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Compétences totales</p>
                <p className="text-3xl font-bold text-green-900">{totalSkills}</p>
              </div>
              <Award className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Moy. / employé</p>
                <p className="text-3xl font-bold text-purple-900">{avgSkillsPerEmployee}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-700 mb-1">Certifications</p>
                <p className="text-3xl font-bold text-orange-900">{totalCertified}</p>
              </div>
              <Star className="w-10 h-10 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtres et contrôles */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Recherche */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
              <Input
                placeholder="Rechercher un employé..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Filtres */}
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-full md:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Catégorie" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes les catégories</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterProficiency} onValueChange={setFilterProficiency}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Niveau" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les niveaux</SelectItem>
                <SelectItem value="beginner">Débutant</SelectItem>
                <SelectItem value="intermediate">Intermédiaire</SelectItem>
                <SelectItem value="advanced">Avancé</SelectItem>
                <SelectItem value="expert">Expert</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Trier par" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nom</SelectItem>
                <SelectItem value="skills">Nb. compétences</SelectItem>
                <SelectItem value="score">Score moyen</SelectItem>
              </SelectContent>
            </Select>

            {/* Mode d'affichage */}
            <div className="flex gap-2">
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("list")}
              >
                <List className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="icon"
                onClick={() => setViewMode("grid")}
              >
                <Grid3x3 className="w-4 h-4" />
              </Button>
            </div>

            {/* Export */}
            <Button onClick={exportToCSV} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Affichage des compétences */}
      {sortedEmployees.length === 0 ? (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center text-slate-500">
            <Award className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <p className="text-lg font-medium mb-2">Aucune compétence trouvée</p>
            <p className="text-sm">Ajustez vos filtres ou ajoutez des compétences</p>
          </CardContent>
        </Card>
      ) : viewMode === "list" ? (
        // Vue en liste
        <div className="space-y-6">
          {sortedEmployees.map((emp) => (
            <Card key={emp.name} className="shadow-lg border-none">
              <CardHeader className="border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        {emp.name.charAt(0)}
                      </span>
                    </div>
                    <div>
                      <CardTitle className="text-xl">{emp.name}</CardTitle>
                      <p className="text-sm text-slate-600">{emp.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-2xl font-bold text-slate-900">{emp.skills.length}</p>
                      <p className="text-xs text-slate-500">compétences</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-600">{emp.avgScore.toFixed(1)}</p>
                      <p className="text-xs text-slate-500">score moyen</p>
                    </div>
                    {emp.certifiedCount > 0 && (
                      <Badge className="bg-purple-600">
                        <Star className="w-3 h-3 mr-1" />
                        {emp.certifiedCount} certif.
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {emp.skills.map((skill, index) => (
                    <div
                      key={index}
                      className="p-4 rounded-lg border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-slate-900">{skill.skill_name}</h4>
                        {skill.certified && (
                          <Award className="w-4 h-4 text-purple-600" />
                        )}
                      </div>
                      {skill.category && (
                        <p className="text-xs text-slate-500 mb-2">{skill.category}</p>
                      )}
                      <div className="flex items-center justify-between">
                        <Badge className={proficiencyColors[skill.proficiency_level]}>
                          {proficiencyLabels[skill.proficiency_level]}
                        </Badge>
                        {skill.years_of_experience && (
                          <span className="text-xs text-slate-600">
                            {skill.years_of_experience} ans
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        // Vue en grille (tableau)
        <Card className="border-none shadow-lg overflow-hidden">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b-2 border-slate-200">
                  <tr>
                    <th className="text-left p-4 font-semibold text-slate-700">Employé</th>
                    <th className="text-center p-4 font-semibold text-slate-700">Compétences</th>
                    <th className="text-center p-4 font-semibold text-slate-700">Score moyen</th>
                    <th className="text-center p-4 font-semibold text-slate-700">Certifications</th>
                    <th className="text-left p-4 font-semibold text-slate-700">Top compétences</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedEmployees.map((emp, idx) => (
                    <tr key={emp.name} className={`border-b border-slate-100 hover:bg-slate-50 ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-25'}`}>
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                            <span className="text-white font-semibold">
                              {emp.name.charAt(0)}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-slate-900">{emp.name}</p>
                            <p className="text-xs text-slate-500">{emp.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        <span className="text-2xl font-bold text-slate-900">{emp.skills.length}</span>
                      </td>
                      <td className="p-4 text-center">
                        <div className="inline-flex items-center gap-1">
                          <span className="text-2xl font-bold text-blue-600">{emp.avgScore.toFixed(1)}</span>
                          <span className="text-xs text-slate-500">/4</span>
                        </div>
                      </td>
                      <td className="p-4 text-center">
                        {emp.certifiedCount > 0 ? (
                          <Badge className="bg-purple-600">
                            <Star className="w-3 h-3 mr-1" />
                            {emp.certifiedCount}
                          </Badge>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="flex flex-wrap gap-2">
                          {emp.skills
                            .sort((a, b) => proficiencyScores[b.proficiency_level] - proficiencyScores[a.proficiency_level])
                            .slice(0, 3)
                            .map((skill, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {skill.skill_name}
                              </Badge>
                            ))}
                          {emp.skills.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{emp.skills.length - 3}
                            </Badge>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}