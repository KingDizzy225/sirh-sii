import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target, 
  TrendingUp, 
  AlertTriangle, 
  Users,
  Award,
  Download,
  Filter
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function SkillGapAnalysis() {
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedPosition, setSelectedPosition] = useState("all");
  const [analysisData, setAnalysisData] = useState(null);

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  useEffect(() => {
    analyzeSkillGaps();
  }, [selectedDepartment, selectedPosition, employees, skills, trainings]);

  const analyzeSkillGaps = () => {
    // Filtrer les employés
    let filteredEmployees = employees;
    if (selectedDepartment !== "all") {
      filteredEmployees = filteredEmployees.filter(e => e.department === selectedDepartment);
    }
    if (selectedPosition !== "all") {
      filteredEmployees = filteredEmployees.filter(e => e.position === selectedPosition);
    }

    // Compétences requises par formation disponible
    const requiredSkills = {};
    trainings.forEach(training => {
      if (training.skills_taught) {
        training.skills_taught.forEach(skill => {
          if (!requiredSkills[skill]) {
            requiredSkills[skill] = {
              name: skill,
              required: 0,
              available: 0,
              gap: 0,
              employees: []
            };
          }
          requiredSkills[skill].required++;
        });
      }
    });

    // Compétences actuelles des employés
    const employeeSkillsMap = {};
    skills.forEach(skill => {
      if (!employeeSkillsMap[skill.employee_email]) {
        employeeSkillsMap[skill.employee_email] = [];
      }
      employeeSkillsMap[skill.employee_email].push(skill.skill_name);
    });

    // Analyser les gaps
    filteredEmployees.forEach(emp => {
      const empSkills = employeeSkillsMap[emp.email] || [];
      
      Object.keys(requiredSkills).forEach(skillName => {
        if (empSkills.includes(skillName)) {
          requiredSkills[skillName].available++;
          requiredSkills[skillName].employees.push({
            name: emp.full_name,
            email: emp.email,
            hasSkill: true
          });
        } else {
          requiredSkills[skillName].employees.push({
            name: emp.full_name,
            email: emp.email,
            hasSkill: false
          });
        }
      });
    });

    // Calculer les gaps
    Object.values(requiredSkills).forEach(skill => {
      skill.gap = filteredEmployees.length - skill.available;
      skill.gapPercentage = filteredEmployees.length > 0 
        ? Math.round((skill.gap / filteredEmployees.length) * 100)
        : 0;
      skill.coveragePercentage = filteredEmployees.length > 0
        ? Math.round((skill.available / filteredEmployees.length) * 100)
        : 0;
    });

    // Trier par gap le plus important
    const sortedGaps = Object.values(requiredSkills)
      .sort((a, b) => b.gap - a.gap)
      .slice(0, 10);

    // Stats globales
    const totalSkills = Object.keys(requiredSkills).length;
    const criticalGaps = sortedGaps.filter(s => s.gapPercentage >= 70).length;
    const averageCoverage = sortedGaps.length > 0
      ? Math.round(sortedGaps.reduce((sum, s) => sum + s.coveragePercentage, 0) / sortedGaps.length)
      : 0;

    setAnalysisData({
      gaps: sortedGaps,
      totalSkills,
      criticalGaps,
      averageCoverage,
      employeeCount: filteredEmployees.length
    });
  };

  const exportReport = () => {
    if (!analysisData) return;

    const reportContent = `
RAPPORT D'ANALYSE DES GAPS DE COMPÉTENCES
Généré le: ${new Date().toLocaleDateString('fr-FR')}

${selectedDepartment !== "all" ? `Département: ${selectedDepartment}` : "Tous les départements"}
${selectedPosition !== "all" ? `Poste: ${selectedPosition}` : "Tous les postes"}

STATISTIQUES GLOBALES:
- Nombre d'employés analysés: ${analysisData.employeeCount}
- Compétences suivies: ${analysisData.totalSkills}
- Gaps critiques (>70%): ${analysisData.criticalGaps}
- Couverture moyenne: ${analysisData.averageCoverage}%

TOP 10 DES GAPS DE COMPÉTENCES:
${analysisData.gaps.map((gap, i) => `
${i + 1}. ${gap.name}
   - Disponible: ${gap.available}/${analysisData.employeeCount} (${gap.coveragePercentage}%)
   - Gap: ${gap.gap} employés (${gap.gapPercentage}%)
`).join('\n')}

RECOMMANDATIONS:
${analysisData.gaps
  .filter(g => g.gapPercentage >= 50)
  .map(gap => `- Former ${gap.gap} employés en ${gap.name}`)
  .join('\n')}
`;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Analyse_Gaps_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (!analysisData) {
    return <div>Chargement...</div>;
  }

  const chartData = analysisData.gaps.map(gap => ({
    name: gap.name.length > 20 ? gap.name.substring(0, 20) + '...' : gap.name,
    'Disponible': gap.available,
    'Gap': gap.gap
  }));

  return (
    <div className="space-y-6">
      {/* Filtres */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <Filter className="w-5 h-5 text-slate-500" />
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les départements</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept.id} value={dept.name}>{dept.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedPosition} onValueChange={setSelectedPosition}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les postes</SelectItem>
                {[...new Set(employees.map(e => e.position))].map(pos => (
                  <SelectItem key={pos} value={pos}>{pos}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button onClick={exportReport} className="ml-auto" variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Exporter le rapport
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-700 mb-1">Employés analysés</p>
                <p className="text-3xl font-bold text-blue-900">{analysisData.employeeCount}</p>
              </div>
              <Users className="w-10 h-10 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-700 mb-1">Compétences suivies</p>
                <p className="text-3xl font-bold text-purple-900">{analysisData.totalSkills}</p>
              </div>
              <Target className="w-10 h-10 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-700 mb-1">Gaps critiques</p>
                <p className="text-3xl font-bold text-red-900">{analysisData.criticalGaps}</p>
                <p className="text-xs text-red-600">&gt;70% manquant</p>
              </div>
              <AlertTriangle className="w-10 h-10 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-700 mb-1">Couverture moyenne</p>
                <p className="text-3xl font-bold text-green-900">{analysisData.averageCoverage}%</p>
              </div>
              <TrendingUp className="w-10 h-10 text-green-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphique */}
      <Card>
        <CardHeader>
          <CardTitle>Top 10 des Gaps de Compétences</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Disponible" fill="#10b981" />
              <Bar dataKey="Gap" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Liste détaillée */}
      <Card>
        <CardHeader>
          <CardTitle>Analyse Détaillée des Gaps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {analysisData.gaps.map((gap, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-semibold text-slate-900">{gap.name}</h4>
                    {gap.gapPercentage >= 70 && (
                      <Badge className="bg-red-600">Critique</Badge>
                    )}
                    {gap.gapPercentage >= 40 && gap.gapPercentage < 70 && (
                      <Badge className="bg-orange-600">Important</Badge>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600">
                        Couverture: {gap.available}/{analysisData.employeeCount} employés
                      </span>
                      <span className="font-semibold text-slate-900">
                        {gap.coveragePercentage}%
                      </span>
                    </div>
                    <Progress value={gap.coveragePercentage} className="h-2" />
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-red-600">
                        Gap: {gap.gap} employés à former
                      </span>
                      <span className="font-semibold text-red-600">
                        {gap.gapPercentage}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {gap.gapPercentage >= 40 && (
                <div className="mt-3 p-3 bg-blue-50 rounded border border-blue-200">
                  <p className="text-sm text-blue-900">
                    <strong>💡 Recommandation:</strong> Planifier une formation en {gap.name} pour {gap.gap} employés
                  </p>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}