import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, GraduationCap, Zap, TrendingUp, Target } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AITrainingRecommender({ employee, skills, performanceData }) {
  const [recommendations, setRecommendations] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateRecommendations = async () => {
    setIsLoading(true);
    try {
      const employeeSkills = skills.filter(s => s.employee_email === employee.email);
      const skillList = employeeSkills.map(s => 
        `${s.skill_name} (${s.proficiency_level})`
      ).join(', ');

      const avgPerformance = performanceData.length > 0
        ? (performanceData.reduce((sum, p) => sum + p.overall_rating, 0) / performanceData.length).toFixed(1)
        : 'N/A';

      const prompt = `En tant qu'expert en formation et développement RH, recommande un plan de formation personnalisé.

**Profil de l'employé:**
Nom: ${employee.full_name}
Poste: ${employee.position}
Département: ${employee.department}
Compétences actuelles: ${skillList || 'Aucune enregistrée'}
Performance moyenne: ${avgPerformance}/5

**Mission:**
Recommande 3-5 formations spécifiques qui:
1. Comblent les gaps de compétences pour son poste
2. Préparent à une évolution de carrière
3. Améliorent sa performance
4. Sont alignées avec les besoins du département

Fournis un plan structuré au format JSON:
{
  "learningPath": "description du parcours global recommandé",
  "trainings": [
    {
      "title": "titre formation",
      "category": "catégorie",
      "priority": "high" | "medium" | "low",
      "objective": "objectif de cette formation",
      "expectedImpact": "impact attendu",
      "timeline": "délai recommandé",
      "prerequisites": "prérequis éventuels"
    }
  ],
  "skillsToAcquire": ["compétence 1", "compétence 2"],
  "careerImpact": "impact sur l'évolution de carrière"
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            learningPath: { type: "string" },
            trainings: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  category: { type: "string" },
                  priority: { type: "string" },
                  objective: { type: "string" },
                  expectedImpact: { type: "string" },
                  timeline: { type: "string" },
                  prerequisites: { type: "string" }
                }
              }
            },
            skillsToAcquire: { type: "array", items: { type: "string" } },
            careerImpact: { type: "string" }
          }
        }
      });

      setRecommendations(response);
    } catch (error) {
      console.error("Erreur recommandations IA:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-600';
      case 'medium': return 'bg-orange-600';
      case 'low': return 'bg-blue-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Recommandations IA - Plan de Formation Personnalisé
          </CardTitle>
          <Button
            onClick={generateRecommendations}
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isLoading ? (
              <>
                <Zap className="w-4 h-4 mr-2 animate-pulse" />
                Analyse...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Générer le plan
              </>
            )}
          </Button>
        </div>
      </CardHeader>

      {recommendations && (
        <CardContent className="p-6 space-y-6">
          {/* Parcours d'apprentissage */}
          <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border-2 border-purple-200">
            <h4 className="font-semibold text-purple-900 mb-2 flex items-center gap-2">
              <Target className="w-5 h-5" />
              Parcours d'Apprentissage Recommandé
            </h4>
            <p className="text-sm text-purple-800">{recommendations.learningPath}</p>
          </div>

          {/* Formations recommandées */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-blue-600" />
              Formations Recommandées ({recommendations.trainings.length})
            </h4>
            <div className="space-y-3">
              {recommendations.trainings.map((training, index) => (
                <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h5 className="font-bold text-slate-900">{training.title}</h5>
                          <Badge className={`${getPriorityColor(training.priority)} text-white`}>
                            {training.priority === 'high' ? '🔴 Prioritaire' :
                             training.priority === 'medium' ? '🟡 Recommandé' :
                             '🔵 Optionnel'}
                          </Badge>
                        </div>
                        <Badge variant="outline" className="text-xs">{training.category}</Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="p-3 bg-blue-50 rounded border border-blue-200">
                        <p className="text-xs font-medium text-blue-700">🎯 Objectif</p>
                        <p className="text-sm text-blue-900">{training.objective}</p>
                      </div>

                      <div className="p-3 bg-green-50 rounded border border-green-200">
                        <p className="text-xs font-medium text-green-700">💡 Impact Attendu</p>
                        <p className="text-sm text-green-900">{training.expectedImpact}</p>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 bg-slate-50 rounded text-center">
                          <p className="text-xs text-slate-600">Timeline</p>
                          <p className="font-medium text-sm">{training.timeline}</p>
                        </div>
                        {training.prerequisites && training.prerequisites !== 'Aucun' && (
                          <div className="p-2 bg-orange-50 rounded text-center">
                            <p className="text-xs text-orange-600">Prérequis</p>
                            <p className="font-medium text-sm text-orange-900">{training.prerequisites}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Compétences à acquérir */}
          <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
            <h4 className="font-semibold text-green-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Compétences Clés à Acquérir
            </h4>
            <div className="flex flex-wrap gap-2">
              {recommendations.skillsToAcquire.map((skill, index) => (
                <Badge key={index} className="bg-green-600 text-white">
                  ✓ {skill}
                </Badge>
              ))}
            </div>
          </div>

          {/* Impact carrière */}
          <div className="p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              Impact sur l'Évolution de Carrière
            </h4>
            <p className="text-sm text-blue-800">{recommendations.careerImpact}</p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}