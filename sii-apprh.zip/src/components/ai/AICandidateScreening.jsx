import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, CheckCircle, XCircle, AlertCircle, TrendingUp } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AICandidateScreening({ candidates = [], jobPosting, onScreeningComplete }) {
  const [isScreening, setIsScreening] = useState(false);
  const [results, setResults] = useState(null);
  const { toast } = useToast();

  const screenCandidates = async () => {
    setIsScreening(true);
    try {
      const prompt = `Tu es un expert en recrutement. Évalue et classe les candidats pour ce poste.

POSTE: ${jobPosting.title}
DÉPARTEMENT: ${jobPosting.department}
TYPE: ${jobPosting.employment_type}

DESCRIPTION DU POSTE:
${jobPosting.description}

EXIGENCES:
${jobPosting.requirements || 'Non spécifié'}

CANDIDATS À ÉVALUER (${candidates.length}):
${candidates.map((c, i) => `
${i + 1}. ${c.full_name}
Email: ${c.email}
Expérience: ${c.experience_years || 'N/A'} ans
Compétences: ${c.skills?.join(', ') || 'Non spécifié'}
Statut: ${c.status}
Note: ${c.rating || 'N/A'}/5
Notes du recruteur: ${c.notes || 'Aucune'}
`).join('\n')}

Fournis une évaluation détaillée et un classement.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            candidats_evalues: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  nom: { type: "string" },
                  email: { type: "string" },
                  score_global: { type: "number" },
                  decision_recommandee: {
                    type: "string",
                    enum: ["accepter", "entretien", "rejeter", "liste_attente"]
                  },
                  forces: {
                    type: "array",
                    items: { type: "string" }
                  },
                  faiblesses: {
                    type: "array",
                    items: { type: "string" }
                  },
                  competences_correspondantes: {
                    type: "array",
                    items: { type: "string" }
                  },
                  competences_manquantes: {
                    type: "array",
                    items: { type: "string" }
                  },
                  justification: { type: "string" },
                  questions_entretien_suggerees: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            },
            top_3_candidats: {
              type: "array",
              items: { type: "string" }
            },
            statistiques: {
              type: "object",
              properties: {
                acceptes: { type: "number" },
                entretiens: { type: "number" },
                rejetes: { type: "number" },
                liste_attente: { type: "number" }
              }
            },
            recommandations_globales: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setResults(result);

      toast({
        title: "Tri terminé ✨",
        description: `${candidates.length} candidatures analysées`,
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur screening:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'analyser les candidatures",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsScreening(false);
    }
  };

  const applyScreeningResults = async () => {
    try {
      const updates = results.candidats_evalues.map(async (evaluation) => {
        const candidate = candidates.find(c => c.email === evaluation.email);
        if (!candidate) return;

        const statusMap = {
          accepter: "offer",
          entretien: "interview",
          rejeter: "rejected",
          liste_attente: "screening"
        };

        const newStatus = statusMap[evaluation.decision_recommandee];
        const aiNotes = `
🤖 ÉVALUATION IA (Score: ${evaluation.score_global}/100)

✅ FORCES:
${evaluation.forces.map(f => `• ${f}`).join('\n')}

⚠️ FAIBLESSES:
${evaluation.faiblesses.map(f => `• ${f}`).join('\n')}

✓ Compétences correspondantes: ${evaluation.competences_correspondantes.join(', ')}
✗ Compétences manquantes: ${evaluation.competences_manquantes.join(', ')}

💡 JUSTIFICATION:
${evaluation.justification}

${evaluation.questions_entretien_suggerees.length > 0 ? `
❓ QUESTIONS D'ENTRETIEN SUGGÉRÉES:
${evaluation.questions_entretien_suggerees.map((q, i) => `${i + 1}. ${q}`).join('\n')}
` : ''}
---
${candidate.notes || ''}`;

        await base44.entities.Candidate.update(candidate.id, {
          status: newStatus,
          notes: aiNotes,
          overall_score: evaluation.score_global
        });
      });

      await Promise.all(updates);

      toast({
        title: "Résultats appliqués ✅",
        description: "Les candidatures ont été mises à jour",
        duration: 5000,
      });

      if (onScreeningComplete) {
        onScreeningComplete();
      }
    } catch (error) {
      console.error("Erreur application:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'appliquer les résultats",
        variant: "destructive",
        duration: 5000,
      });
    }
  };

  const getDecisionColor = (decision) => {
    switch (decision) {
      case "accepter": return "bg-green-600";
      case "entretien": return "bg-blue-600";
      case "liste_attente": return "bg-yellow-600";
      case "rejeter": return "bg-red-600";
      default: return "bg-gray-600";
    }
  };

  const getDecisionIcon = (decision) => {
    switch (decision) {
      case "accepter": return <CheckCircle className="w-5 h-5" />;
      case "entretien": return <AlertCircle className="w-5 h-5" />;
      case "rejeter": return <XCircle className="w-5 h-5" />;
      default: return <TrendingUp className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-1">
                Tri Automatique IA des Candidatures
              </h3>
              <p className="text-sm text-purple-700">
                L'IA analyse et classe les {candidates.length} candidatures pour {jobPosting.title}
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={screenCandidates}
              disabled={isScreening || candidates.length === 0}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isScreening ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyse en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Lancer le tri IA
                </>
              )}
            </Button>

            {results && (
              <Button
                onClick={applyScreeningResults}
                className="bg-green-600 hover:bg-green-700"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Appliquer les résultats
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {results && (
        <>
          {/* Statistiques */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="border-green-200 bg-green-50">
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-green-900">
                  {results.statistiques.acceptes}
                </p>
                <p className="text-sm text-green-700">À accepter</p>
              </CardContent>
            </Card>

            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-blue-900">
                  {results.statistiques.entretiens}
                </p>
                <p className="text-sm text-blue-700">Entretiens</p>
              </CardContent>
            </Card>

            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-yellow-900">
                  {results.statistiques.liste_attente}
                </p>
                <p className="text-sm text-yellow-700">Liste d'attente</p>
              </CardContent>
            </Card>

            <Card className="border-red-200 bg-red-50">
              <CardContent className="p-4 text-center">
                <p className="text-3xl font-bold text-red-900">
                  {results.statistiques.rejetes}
                </p>
                <p className="text-sm text-red-700">À rejeter</p>
              </CardContent>
            </Card>
          </div>

          {/* Top 3 */}
          <Card className="border-gold bg-yellow-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-900">
                🏆 Top 3 Candidats Recommandés
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2">
                {results.top_3_candidats.map((nom, i) => (
                  <li key={i} className="flex items-center gap-3 p-3 bg-white rounded-lg border border-yellow-200">
                    <span className="text-2xl font-bold text-yellow-600">#{i + 1}</span>
                    <span className="font-semibold text-yellow-900">{nom}</span>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>

          {/* Résultats détaillés */}
          <Card>
            <CardHeader>
              <CardTitle>Évaluations Détaillées ({results.candidats_evalues.length})</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {results.candidats_evalues
                .sort((a, b) => b.score_global - a.score_global)
                .map((candidateEval, i) => (
                  <Card key={i} className="border-2">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="font-bold text-lg">{candidateEval.nom}</h4>
                            <Badge className="text-lg bg-purple-600">
                              {candidateEval.score_global}/100
                            </Badge>
                          </div>
                          <p className="text-sm text-slate-600">{candidateEval.email}</p>
                        </div>
                        <Badge className={`${getDecisionColor(candidateEval.decision_recommandee)} flex items-center gap-2`}>
                          {getDecisionIcon(candidateEval.decision_recommandee)}
                          {candidateEval.decision_recommandee === 'accepter' ? 'Accepter' :
                           candidateEval.decision_recommandee === 'entretien' ? 'Entretien' :
                           candidateEval.decision_recommandee === 'liste_attente' ? 'Liste d\'attente' :
                           'Rejeter'}
                        </Badge>
                      </div>

                      <div className="grid md:grid-cols-2 gap-3 mb-3">
                        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                          <p className="text-xs font-medium text-green-700 mb-2">✅ Forces</p>
                          <ul className="space-y-1">
                            {candidateEval.forces.map((f, j) => (
                              <li key={j} className="text-sm text-green-900">• {f}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                          <p className="text-xs font-medium text-orange-700 mb-2">⚠️ Faiblesses</p>
                          <ul className="space-y-1">
                            {candidateEval.faiblesses.map((f, j) => (
                              <li key={j} className="text-sm text-orange-900">• {f}</li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200 mb-3">
                        <p className="text-xs font-medium text-blue-700 mb-1">💡 Justification</p>
                        <p className="text-sm text-blue-900">{candidateEval.justification}</p>
                      </div>

                      <div className="grid md:grid-cols-2 gap-3">
                        <div>
                          <p className="text-xs font-medium text-slate-700 mb-1">✓ Compétences correspondantes</p>
                          <div className="flex flex-wrap gap-1">
                            {candidateEval.competences_correspondantes.map((c, j) => (
                              <Badge key={j} variant="outline" className="text-xs bg-green-50">
                                {c}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <p className="text-xs font-medium text-slate-700 mb-1">✗ Compétences manquantes</p>
                          <div className="flex flex-wrap gap-1">
                            {candidateEval.competences_manquantes.map((c, j) => (
                              <Badge key={j} variant="outline" className="text-xs bg-red-50">
                                {c}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      {candidateEval.questions_entretien_suggerees.length > 0 && (
                        <div className="mt-3 p-3 bg-purple-50 rounded-lg border border-purple-200">
                          <p className="text-xs font-medium text-purple-700 mb-2">❓ Questions d'entretien suggérées</p>
                          <ol className="space-y-1">
                            {candidateEval.questions_entretien_suggerees.map((q, j) => (
                              <li key={j} className="text-sm text-purple-900">{j + 1}. {q}</li>
                            ))}
                          </ol>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
            </CardContent>
          </Card>

          {/* Recommandations globales */}
          <Card className="border-indigo-200 bg-indigo-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-900">
                💡 Recommandations Globales
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {results.recommandations_globales.map((rec, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-indigo-200">
                  <p className="text-sm text-indigo-900">{rec}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}