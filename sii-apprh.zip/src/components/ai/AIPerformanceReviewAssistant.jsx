import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Copy, Download, Target, TrendingUp, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function AIPerformanceReviewAssistant({ 
  employees, 
  continuousFeedbacks, 
  peerFeedbacks, 
  selfAssessments,
  performanceGoals,
  onUseReview 
}) {
  const [selectedEmployee, setSelectedEmployee] = useState("");
  const [reviewPeriod, setReviewPeriod] = useState("");
  const [synthesis, setSynthesis] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const generateReviewSynthesis = async () => {
    if (!selectedEmployee) {
      toast({
        title: "Sélection requise",
        description: "Veuillez sélectionner un employé",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    try {
      const employee = employees.find(e => e.email === selectedEmployee);

      // Filtrer tous les feedbacks de cet employé
      const employeeContinuousFeedbacks = continuousFeedbacks.filter(
        f => f.receiver_email === selectedEmployee
      );
      const employeePeerFeedbacks = peerFeedbacks.filter(
        f => f.reviewed_employee_email === selectedEmployee
      );
      const employeeSelfAssessments = selfAssessments.filter(
        f => f.employee_email === selectedEmployee
      );
      const employeeGoals = performanceGoals.filter(
        g => g.employee_email === selectedEmployee
      );

      const prompt = `Tu es un expert RH. Synthétise toutes les données de performance pour créer une évaluation complète et équilibrée.

EMPLOYÉ: ${employee.full_name}
POSTE: ${employee.position}
DÉPARTEMENT: ${employee.department}
PÉRIODE: ${reviewPeriod || "Année en cours"}

=== FEEDBACKS CONTINUS (${employeeContinuousFeedbacks.length}) ===
${employeeContinuousFeedbacks.slice(0, 50).map((f, i) => `
${i + 1}. [${f.feedback_type}] ${f.category}
De: ${f.is_anonymous ? 'Anonyme' : f.giver_name}
Date: ${f.created_date}
Impact: ${f.impact_level}
Contenu: ${f.content}
${f.context ? `Contexte: ${f.context}` : ''}
`).join('\n')}

=== FEEDBACKS PAIRS (${employeePeerFeedbacks.length}) ===
${employeePeerFeedbacks.slice(0, 20).map((f, i) => `
${i + 1}. De: ${f.is_anonymous ? 'Anonyme' : f.reviewer_name}
Communication: ${f.communication_rating}/5
Collaboration: ${f.collaboration_rating}/5
Qualité: ${f.quality_rating}/5
Fiabilité: ${f.reliability_rating}/5
Commentaires: ${f.detailed_feedback}
`).join('\n')}

=== AUTO-ÉVALUATIONS (${employeeSelfAssessments.length}) ===
${employeeSelfAssessments.slice(0, 5).map((s, i) => `
${i + 1}. Période: ${s.review_period}
Note globale: ${s.overall_rating}/5
Réalisations: ${s.key_achievements}
Défis: ${s.challenges_faced}
Objectifs: ${s.career_goals}
`).join('\n')}

=== OBJECTIFS (${employeeGoals.length}) ===
${employeeGoals.map((g, i) => `
${i + 1}. ${g.goal_title}
Catégorie: ${g.category}
Statut: ${g.status}
Progrès: ${g.progress_percentage}%
Notes: ${g.notes || 'N/A'}
`).join('\n')}

Crée une synthèse complète pour l'évaluation annuelle avec des recommandations actionnables et des objectifs SMART.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            resume_executif: {
              type: "string",
              description: "Résumé exécutif en 2-3 phrases"
            },
            note_globale_suggeree: {
              type: "number",
              description: "Note suggérée sur 5"
            },
            forces_principales: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  force: { type: "string" },
                  preuves: { 
                    type: "array",
                    items: { type: "string" }
                  },
                  impact: { type: "string" }
                }
              }
            },
            axes_amelioration: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  domaine: { type: "string" },
                  observations: { 
                    type: "array",
                    items: { type: "string" }
                  },
                  recommandations: { 
                    type: "array",
                    items: { type: "string" }
                  },
                  priorite: { type: "string" }
                }
              }
            },
            competences_techniques: {
              type: "object",
              properties: {
                note: { type: "number" },
                commentaire: { type: "string" },
                points_forts: { type: "array", items: { type: "string" } },
                points_ameliorer: { type: "array", items: { type: "string" } }
              }
            },
            communication: {
              type: "object",
              properties: {
                note: { type: "number" },
                commentaire: { type: "string" }
              }
            },
            travail_equipe: {
              type: "object",
              properties: {
                note: { type: "number" },
                commentaire: { type: "string" }
              }
            },
            leadership: {
              type: "object",
              properties: {
                note: { type: "number" },
                commentaire: { type: "string" }
              }
            },
            realisations_majeures: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  titre: { type: "string" },
                  description: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            defis_surmontes: {
              type: "array",
              items: { type: "string" }
            },
            objectifs_smart_suggeres: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  titre: { type: "string" },
                  description: { type: "string" },
                  mesurable: { type: "string" },
                  echeance: { type: "string" },
                  categorie: { type: "string" },
                  priorite: { type: "string" }
                }
              }
            },
            recommandations_developpement: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  action: { type: "string" },
                  benefices: { type: "string" }
                }
              }
            },
            commentaires_manager: {
              type: "string",
              description: "Brouillon de commentaires pour le manager"
            },
            points_discussion: {
              type: "array",
              items: { type: "string" },
              description: "Points clés à discuter lors de l'entretien"
            },
            alertes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  type: { type: "string" },
                  message: { type: "string" }
                }
              }
            }
          }
        }
      });

      setSynthesis(result);

      toast({
        title: "Synthèse générée ✨",
        description: "L'analyse complète est prête",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur génération:", error);
      toast({
        title: "Erreur",
        description: "Impossible de générer la synthèse",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copié !", duration: 2000 });
  };

  const exportReport = () => {
    if (!synthesis) return;

    const employee = employees.find(e => e.email === selectedEmployee);
    
    const content = `
ÉVALUATION DE PERFORMANCE - ${employee.full_name}
Poste: ${employee.position}
Département: ${employee.department}
Période: ${reviewPeriod || "Année en cours"}
Généré le: ${new Date().toLocaleDateString('fr-FR')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RÉSUMÉ EXÉCUTIF
${synthesis.resume_executif}

NOTE GLOBALE SUGGÉRÉE: ${synthesis.note_globale_suggeree}/5

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FORCES PRINCIPALES
${synthesis.forces_principales.map((f, i) => `
${i + 1}. ${f.force}
   Impact: ${f.impact}
   Preuves:
   ${f.preuves.map(p => `   • ${p}`).join('\n')}
`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

AXES D'AMÉLIORATION
${synthesis.axes_amelioration.map((a, i) => `
${i + 1}. ${a.domaine} (Priorité: ${a.priorite})
   Observations:
   ${a.observations.map(o => `   • ${o}`).join('\n')}
   
   Recommandations:
   ${a.recommandations.map(r => `   ✓ ${r}`).join('\n')}
`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ÉVALUATION PAR DOMAINE

📌 COMPÉTENCES TECHNIQUES (${synthesis.competences_techniques.note}/5)
${synthesis.competences_techniques.commentaire}
Points forts: ${synthesis.competences_techniques.points_forts.join(', ')}
À améliorer: ${synthesis.competences_techniques.points_ameliorer.join(', ')}

💬 COMMUNICATION (${synthesis.communication.note}/5)
${synthesis.communication.commentaire}

👥 TRAVAIL D'ÉQUIPE (${synthesis.travail_equipe.note}/5)
${synthesis.travail_equipe.commentaire}

⭐ LEADERSHIP (${synthesis.leadership.note}/5)
${synthesis.leadership.commentaire}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

RÉALISATIONS MAJEURES
${synthesis.realisations_majeures.map((r, i) => `
${i + 1}. ${r.titre}
   ${r.description}
   Impact: ${r.impact}
`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

OBJECTIFS SMART POUR LA PROCHAINE PÉRIODE
${synthesis.objectifs_smart_suggeres.map((o, i) => `
${i + 1}. ${o.titre} (${o.categorie} - ${o.priorite})
   Description: ${o.description}
   Mesurable: ${o.mesurable}
   Échéance: ${o.echeance}
`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PLAN DE DÉVELOPPEMENT
${synthesis.recommandations_developpement.map((r, i) => `
${i + 1}. ${r.type}: ${r.action}
   Bénéfices: ${r.benefices}
`).join('\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMENTAIRES DU MANAGER
${synthesis.commentaires_manager}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

POINTS DE DISCUSSION
${synthesis.points_discussion.map((p, i) => `${i + 1}. ${p}`).join('\n')}
`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Evaluation_${employee.full_name.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const useForReview = () => {
    if (!synthesis || !onUseReview) return;

    const reviewData = {
      employee_email: selectedEmployee,
      employee_name: employees.find(e => e.email === selectedEmployee)?.full_name,
      review_period: reviewPeriod,
      overall_rating: Math.round(synthesis.note_globale_suggeree),
      technical_skills: synthesis.competences_techniques.note,
      communication: synthesis.communication.note,
      teamwork: synthesis.travail_equipe.note,
      leadership: synthesis.leadership.note,
      strengths: synthesis.forces_principales.map(f => f.force).join('\n'),
      areas_for_improvement: synthesis.axes_amelioration.map(a => a.domaine).join('\n'),
      goals: synthesis.objectifs_smart_suggeres.map(o => o.titre).join('\n'),
      comments: synthesis.commentaires_manager
    };

    onUseReview(reviewData);
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-8 h-8 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-bold text-purple-900 text-lg mb-1">
                Assistant IA d'Évaluation de Performance
              </h3>
              <p className="text-sm text-purple-700">
                Synthétise automatiquement tous les feedbacks pour créer une évaluation complète
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mb-4">
            <div>
              <Label>Employé à évaluer *</Label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un employé" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(e => (
                    <SelectItem key={e.id} value={e.email}>
                      {e.full_name} - {e.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Période d'évaluation</Label>
              <Select value={reviewPeriod} onValueChange={setReviewPeriod}>
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner une période" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Q4 2024">Q4 2024</SelectItem>
                  <SelectItem value="Q1 2025">Q1 2025</SelectItem>
                  <SelectItem value="H1 2025">H1 2025</SelectItem>
                  <SelectItem value="H2 2025">H2 2025</SelectItem>
                  <SelectItem value="2024">Année 2024</SelectItem>
                  <SelectItem value="2025">Année 2025</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={generateReviewSynthesis}
            disabled={isGenerating || !selectedEmployee}
            className="w-full bg-purple-600 hover:bg-purple-700"
            size="lg"
          >
            {isGenerating ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Génération en cours...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Générer la synthèse complète
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {synthesis && (
        <>
          {/* Actions */}
          <div className="flex gap-3 flex-wrap">
            <Button onClick={exportReport} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Exporter le rapport
            </Button>
            {onUseReview && (
              <Button onClick={useForReview} className="bg-green-600 hover:bg-green-700">
                <Target className="w-4 h-4 mr-2" />
                Utiliser pour créer l'évaluation
              </Button>
            )}
          </div>

          {/* Alertes */}
          {synthesis.alertes && synthesis.alertes.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-900">
                  <AlertCircle className="w-5 h-5" />
                  Alertes Importantes
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {synthesis.alertes.map((alert, i) => (
                  <div key={i} className="p-3 bg-white border-2 border-red-300 rounded-lg">
                    <Badge className="bg-red-600 mb-2">{alert.type}</Badge>
                    <p className="text-sm text-red-900">{alert.message}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Résumé exécutif */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-blue-900">📋 Résumé Exécutif</CardTitle>
                <Badge className="text-xl bg-blue-600">
                  Note: {synthesis.note_globale_suggeree}/5
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-blue-900 leading-relaxed">{synthesis.resume_executif}</p>
            </CardContent>
          </Card>

          {/* Forces principales */}
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <TrendingUp className="w-5 h-5" />
                Forces Principales
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {synthesis.forces_principales.map((force, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-green-200">
                  <h4 className="font-bold text-green-900 mb-2">{force.force}</h4>
                  <p className="text-sm text-green-800 mb-3 italic">{force.impact}</p>
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-green-700">Preuves:</p>
                    {force.preuves.map((preuve, j) => (
                      <p key={j} className="text-xs text-green-700">• {preuve}</p>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Axes d'amélioration */}
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-900">
                <Target className="w-5 h-5" />
                Axes d'Amélioration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {synthesis.axes_amelioration.map((axe, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-orange-200">
                  <div className="flex items-start justify-between mb-3">
                    <h4 className="font-bold text-orange-900">{axe.domaine}</h4>
                    <Badge className={
                      axe.priorite === 'haute' ? 'bg-red-600' :
                      axe.priorite === 'moyenne' ? 'bg-orange-600' :
                      'bg-yellow-600'
                    }>
                      {axe.priorite}
                    </Badge>
                  </div>
                  
                  <div className="mb-3">
                    <p className="text-xs font-medium text-orange-700 mb-1">Observations:</p>
                    {axe.observations.map((obs, j) => (
                      <p key={j} className="text-xs text-orange-800">• {obs}</p>
                    ))}
                  </div>

                  <div className="p-3 bg-orange-50 rounded">
                    <p className="text-xs font-medium text-orange-700 mb-1">Recommandations:</p>
                    {axe.recommandations.map((rec, j) => (
                      <p key={j} className="text-xs text-orange-800">✓ {rec}</p>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Évaluations par domaine */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>💻 Compétences Techniques ({synthesis.competences_techniques.note}/5)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-slate-700">{synthesis.competences_techniques.commentaire}</p>
                <div>
                  <p className="text-xs font-medium text-green-700 mb-1">Points forts:</p>
                  {synthesis.competences_techniques.points_forts.map((p, i) => (
                    <Badge key={i} className="bg-green-600 mr-1 mb-1">{p}</Badge>
                  ))}
                </div>
                <div>
                  <p className="text-xs font-medium text-orange-700 mb-1">À améliorer:</p>
                  {synthesis.competences_techniques.points_ameliorer.map((p, i) => (
                    <Badge key={i} className="bg-orange-600 mr-1 mb-1">{p}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>💬 Communication ({synthesis.communication.note}/5)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-700">{synthesis.communication.commentaire}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>👥 Travail d'équipe ({synthesis.travail_equipe.note}/5)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-700">{synthesis.travail_equipe.commentaire}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>⭐ Leadership ({synthesis.leadership.note}/5)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-700">{synthesis.leadership.commentaire}</p>
              </CardContent>
            </Card>
          </div>

          {/* Réalisations majeures */}
          <Card>
            <CardHeader>
              <CardTitle className="text-purple-900">🏆 Réalisations Majeures</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {synthesis.realisations_majeures.map((real, i) => (
                <div key={i} className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <h4 className="font-bold text-purple-900 mb-2">{real.titre}</h4>
                  <p className="text-sm text-purple-800 mb-2">{real.description}</p>
                  <Badge className="bg-purple-600">Impact: {real.impact}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Objectifs SMART */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                <Target className="w-5 h-5" />
                Objectifs SMART Suggérés pour la Prochaine Période
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {synthesis.objectifs_smart_suggeres.map((obj, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-blue-200">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-blue-900">{obj.titre}</h4>
                    <div className="flex gap-2">
                      <Badge className="bg-blue-600">{obj.categorie}</Badge>
                      <Badge className={
                        obj.priorite === 'haute' ? 'bg-red-600' :
                        obj.priorite === 'moyenne' ? 'bg-orange-600' :
                        'bg-green-600'
                      }>
                        {obj.priorite}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-blue-800 mb-2">{obj.description}</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-medium">Mesurable:</span> {obj.mesurable}
                    </div>
                    <div>
                      <span className="font-medium">Échéance:</span> {obj.echeance}
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-2"
                    onClick={() => copyToClipboard(`${obj.titre}\n${obj.description}\nMesurable: ${obj.mesurable}\nÉchéance: ${obj.echeance}`)}
                  >
                    <Copy className="w-3 h-3 mr-1" />
                    Copier
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Plan de développement */}
          <Card>
            <CardHeader>
              <CardTitle className="text-indigo-900">📈 Plan de Développement</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {synthesis.recommandations_developpement.map((rec, i) => (
                <div key={i} className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                  <div className="flex items-start gap-3">
                    <Badge className="bg-indigo-600">{rec.type}</Badge>
                    <div className="flex-1">
                      <p className="font-medium text-indigo-900 mb-1">{rec.action}</p>
                      <p className="text-xs text-indigo-700">{rec.benefices}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Commentaires manager */}
          <Card className="border-slate-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>💬 Brouillon de Commentaires du Manager</CardTitle>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyToClipboard(synthesis.commentaires_manager)}
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copier
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                value={synthesis.commentaires_manager}
                readOnly
                rows={8}
                className="bg-slate-50"
              />
            </CardContent>
          </Card>

          {/* Points de discussion */}
          <Card className="border-yellow-200 bg-yellow-50">
            <CardHeader>
              <CardTitle className="text-yellow-900">💭 Points Clés à Discuter</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {synthesis.points_discussion.map((point, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-yellow-200">
                  <p className="text-sm text-yellow-900">{i + 1}. {point}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}