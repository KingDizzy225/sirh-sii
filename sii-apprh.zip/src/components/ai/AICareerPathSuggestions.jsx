import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Target, GraduationCap, Users, ArrowRight, Award, CheckCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useQuery } from "@tanstack/react-query";

export default function AICareerPathSuggestions() {
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [careerPaths, setCareerPaths] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['performanceReviews'],
    queryFn: () => base44.entities.PerformanceReview.list(),
  });

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
  });

  const { data: jobPostings = [] } = useQuery({
    queryKey: ['jobPostings'],
    queryFn: () => base44.entities.JobPosting.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const analyzeCareerPath = async () => {
    if (!selectedEmployee) return;

    setIsAnalyzing(true);
    try {
      const employee = employees.find(e => e.id === selectedEmployee);
      const employeeSkills = skills.filter(s => s.employee_email === employee.email);
      const employeeReviews = reviews.filter(r => r.employee_email === employee.email);
      
      const lastReview = employeeReviews.length > 0 
        ? employeeReviews.sort((a, b) => new Date(b.review_date) - new Date(a.review_date))[0]
        : null;

      // Analyser les postes disponibles et les compétences requises
      const availableRoles = jobPostings.map(j => ({
        title: j.title,
        department: j.department,
        requirements: j.requirements,
        description: j.description
      }));

      const prompt = `Tu es un expert en développement de carrière RH. Analyse le profil et suggère des parcours de carrière personnalisés.

EMPLOYÉ: ${employee.full_name}
POSTE ACTUEL: ${employee.position}
DÉPARTEMENT: ${employee.department}
ANCIENNETÉ: ${employee.hire_date ? Math.floor((new Date() - new Date(employee.hire_date)) / (365.25 * 24 * 60 * 60 * 1000)) : 'N/A'} ans

COMPÉTENCES ACTUELLES:
${employeeSkills.map(s => `- ${s.skill_name} (${s.proficiency_level})${s.certified ? ' ✓ Certifié' : ''}`).join('\n')}

PERFORMANCE:
${lastReview ? `Note globale: ${lastReview.overall_rating}/5
- Technique: ${lastReview.technical_skills}/5
- Communication: ${lastReview.communication}/5
- Leadership: ${lastReview.leadership}/5
Points forts: ${lastReview.strengths || 'N/A'}
Axes d'amélioration: ${lastReview.areas_for_improvement || 'N/A'}` : 'Pas encore évalué'}

RÔLES DISPONIBLES DANS L'ENTREPRISE:
${availableRoles.slice(0, 10).map(r => `- ${r.title} (${r.department})`).join('\n')}

FORMATIONS DISPONIBLES:
${trainings.slice(0, 15).map(t => `- ${t.title}${t.skills_taught?.length ? ` (${t.skills_taught.join(', ')})` : ''}`).join('\n')}

Fournis des recommandations de carrière stratégiques et personnalisées.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            parcours_recommandes: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  titre_cible: { type: "string" },
                  departement: { type: "string" },
                  niveau: { type: "string" },
                  delai_estime: { type: "string" },
                  probabilite_succes: { type: "number" },
                  raison: { type: "string" },
                  competences_manquantes: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        competence: { type: "string" },
                        niveau_requis: { type: "string" },
                        priorite: { type: "string" }
                      }
                    }
                  },
                  formations_recommandees: {
                    type: "array",
                    items: { type: "string" }
                  },
                  etapes_progression: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        etape: { type: "string" },
                        duree: { type: "string" },
                        actions: {
                          type: "array",
                          items: { type: "string" }
                        }
                      }
                    }
                  }
                }
              }
            },
            points_forts_cles: {
              type: "array",
              items: { type: "string" }
            },
            opportunites_immediates: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  opportunite: { type: "string" },
                  action: { type: "string" }
                }
              }
            },
            recommandations_developpement: {
              type: "array",
              items: { type: "string" }
            },
            risques_stagnation: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setCareerPaths(result);

      toast({
        title: "Analyse terminée ✨",
        description: "Parcours de carrière générés avec succès",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur analyse:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'analyser le parcours de carrière",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getProbabilityColor = (prob) => {
    if (prob >= 80) return "bg-green-600";
    if (prob >= 60) return "bg-blue-600";
    if (prob >= 40) return "bg-orange-600";
    return "bg-red-600";
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-1">
                Suggestions IA de Parcours de Carrière
              </h3>
              <p className="text-sm text-purple-700">
                L'IA analyse les compétences, performances et opportunités pour suggérer des évolutions
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-[300px]">
                <SelectValue placeholder="Sélectionner un employé" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(e => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.full_name} - {e.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={analyzeCareerPath}
              disabled={!selectedEmployee || isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyse...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyser le parcours
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {careerPaths && (
        <>
          {/* Points forts */}
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <Award className="w-5 h-5" />
                Points Forts Clés
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {careerPaths.points_forts_cles.map((point, i) => (
                <div key={i} className="flex items-start gap-2 p-3 bg-white rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-green-900">{point}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Opportunités immédiates */}
          {careerPaths.opportunites_immediates?.length > 0 && (
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-900">
                  <Target className="w-5 h-5" />
                  Opportunités Immédiates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {careerPaths.opportunites_immediates.map((opp, i) => (
                  <div key={i} className="p-4 bg-white rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">{opp.opportunite}</h4>
                    <p className="text-sm text-blue-700">💡 {opp.action}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Parcours recommandés */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-purple-600" />
              Parcours de Carrière Recommandés
            </h3>

            {careerPaths.parcours_recommandes.map((parcours, i) => (
              <Card key={i} className="border-2 border-purple-200 shadow-lg">
                <CardHeader className="bg-purple-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-purple-900">
                          {parcours.titre_cible}
                        </h3>
                        <Badge className={getProbabilityColor(parcours.probabilite_succes)}>
                          {parcours.probabilite_succes}% de succès
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-purple-700">
                        <span>📍 {parcours.departement}</span>
                        <span>📊 {parcours.niveau}</span>
                        <span>⏱️ {parcours.delai_estime}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-purple-800 mt-2">
                    {parcours.raison}
                  </p>
                </CardHeader>

                <CardContent className="p-6 space-y-6">
                  {/* Compétences manquantes */}
                  {parcours.competences_manquantes?.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                        <Target className="w-4 h-4 text-orange-600" />
                        Compétences à Développer
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {parcours.competences_manquantes.map((comp, j) => (
                          <div key={j} className="p-3 border rounded-lg bg-orange-50 border-orange-200">
                            <div className="flex items-start justify-between mb-1">
                              <p className="font-medium text-orange-900">{comp.competence}</p>
                              <Badge className={
                                comp.priorite === 'haute' ? 'bg-red-600' :
                                comp.priorite === 'moyenne' ? 'bg-orange-600' :
                                'bg-blue-600'
                              }>
                                {comp.priorite}
                              </Badge>
                            </div>
                            <p className="text-xs text-orange-700">Niveau requis: {comp.niveau_requis}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Formations recommandées */}
                  {parcours.formations_recommandees?.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                        <GraduationCap className="w-4 h-4 text-blue-600" />
                        Formations Recommandées
                      </h4>
                      <div className="space-y-2">
                        {parcours.formations_recommandees.map((formation, j) => (
                          <div key={j} className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                            <CheckCircle className="w-4 h-4 text-blue-600" />
                            <p className="text-sm text-blue-900">{formation}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Étapes de progression */}
                  {parcours.etapes_progression?.length > 0 && (
                    <div>
                      <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                        <ArrowRight className="w-4 h-4 text-green-600" />
                        Plan de Progression ({parcours.etapes_progression.length} étapes)
                      </h4>
                      <div className="space-y-4">
                        {parcours.etapes_progression.map((etape, j) => (
                          <div key={j} className="relative pl-8 pb-4">
                            {j < parcours.etapes_progression.length - 1 && (
                              <div className="absolute left-3 top-8 bottom-0 w-0.5 bg-green-200"></div>
                            )}
                            <div className="absolute left-0 top-1 w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
                              {j + 1}
                            </div>
                            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                              <div className="flex items-center justify-between mb-2">
                                <h5 className="font-semibold text-green-900">{etape.etape}</h5>
                                <Badge variant="outline" className="text-green-700">
                                  {etape.duree}
                                </Badge>
                              </div>
                              <ul className="space-y-1">
                                {etape.actions.map((action, k) => (
                                  <li key={k} className="text-sm text-green-800 flex items-start gap-2">
                                    <span className="text-green-600">•</span>
                                    <span>{action}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Recommandations de développement */}
          <Card className="border-indigo-200 bg-indigo-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-indigo-900">
                💡 Recommandations de Développement
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {careerPaths.recommandations_developpement.map((rec, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-indigo-200">
                  <p className="text-sm text-indigo-900">{rec}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Risques de stagnation */}
          {careerPaths.risques_stagnation?.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-900">
                  ⚠️ Risques de Stagnation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {careerPaths.risques_stagnation.map((risque, i) => (
                  <div key={i} className="p-3 bg-white rounded-lg border border-red-200">
                    <p className="text-sm text-red-900">{risque}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </>
      )}

      {!careerPaths && (
        <Card>
          <CardContent className="p-12 text-center text-slate-500">
            <Users className="w-16 h-16 mx-auto mb-4 text-purple-300" />
            <p className="text-lg font-medium mb-2">Parcours de Carrière Personnalisés</p>
            <p className="text-sm">
              Sélectionnez un employé et lancez l'analyse pour découvrir ses opportunités d'évolution
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}