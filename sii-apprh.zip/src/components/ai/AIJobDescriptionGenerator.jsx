import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Copy, Download, Briefcase, RefreshCw } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AIJobDescriptionGenerator({ onClose, onGenerated, departments = [] }) {
  const [jobInfo, setJobInfo] = useState({
    title: "",
    department: "",
    level: "intermediate",
    employment_type: "full_time",
    key_skills: "",
    team_size: "",
    experience_years: ""
  });
  
  const [generatedDescription, setGeneratedDescription] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!jobInfo.title || !jobInfo.department) {
      toast({
        title: "Information manquante",
        description: "Veuillez renseigner au minimum le titre et le département",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    setIsGenerating(true);
    try {
      const prompt = `Tu es un expert RH. Génère une description de poste complète et professionnelle en français pour:

Titre du poste: ${jobInfo.title}
Département: ${jobInfo.department}
Niveau: ${jobInfo.level}
Type d'emploi: ${jobInfo.employment_type}
${jobInfo.key_skills ? `Compétences clés recherchées: ${jobInfo.key_skills}` : ''}
${jobInfo.team_size ? `Taille de l'équipe: ${jobInfo.team_size} personnes` : ''}
${jobInfo.experience_years ? `Expérience requise: ${jobInfo.experience_years} ans` : ''}

La description doit inclure:
1. Un résumé du poste attractif
2. Les missions et responsabilités principales (5-7 points)
3. Les compétences techniques requises
4. Les compétences comportementales souhaitées
5. Les qualifications et expérience
6. Ce que nous offrons (avantages)

Sois précis, professionnel et attractif pour les candidats.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            resume: { type: "string" },
            missions: { 
              type: "array", 
              items: { type: "string" }
            },
            competences_techniques: {
              type: "array",
              items: { type: "string" }
            },
            competences_comportementales: {
              type: "array",
              items: { type: "string" }
            },
            qualifications: {
              type: "array",
              items: { type: "string" }
            },
            avantages: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setGeneratedDescription(result);

      toast({
        title: "Description générée ✨",
        description: "La description du poste a été créée avec succès",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur génération:", error);
      toast({
        title: "Erreur",
        description: "Impossible de générer la description",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    const text = formatDescription();
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié !",
      description: "Description copiée dans le presse-papier",
      duration: 3000,
    });
  };

  const downloadDescription = () => {
    const content = formatDescription();
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Description_Poste_${jobInfo.title.replace(/\s/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const formatDescription = () => {
    if (!generatedDescription) return "";

    return `
${jobInfo.title}
${jobInfo.department} • ${jobInfo.employment_type}

${generatedDescription.resume}

MISSIONS ET RESPONSABILITÉS:
${generatedDescription.missions.map((m, i) => `${i + 1}. ${m}`).join('\n')}

COMPÉTENCES TECHNIQUES REQUISES:
${generatedDescription.competences_techniques.map(c => `• ${c}`).join('\n')}

COMPÉTENCES COMPORTEMENTALES:
${generatedDescription.competences_comportementales.map(c => `• ${c}`).join('\n')}

QUALIFICATIONS ET EXPÉRIENCE:
${generatedDescription.qualifications.map(q => `• ${q}`).join('\n')}

CE QUE NOUS OFFRONS:
${generatedDescription.avantages.map(a => `• ${a}`).join('\n')}
`;
  };

  const handleUseForPosting = () => {
    if (onGenerated) {
      onGenerated({
        title: jobInfo.title,
        department: jobInfo.department,
        employment_type: jobInfo.employment_type,
        description: formatDescription(),
        requirements: generatedDescription.competences_techniques.concat(
          generatedDescription.qualifications
        ).join('\n'),
      });
    }
    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Générateur IA de Description de Poste
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration */}
          <div className="space-y-4">
            <Card className="border-purple-200 bg-purple-50">
              <CardContent className="p-4 space-y-4">
                <div className="space-y-2">
                  <Label>Titre du poste *</Label>
                  <Input
                    value={jobInfo.title}
                    onChange={(e) => setJobInfo({...jobInfo, title: e.target.value})}
                    placeholder="ex: Développeur Full Stack Senior"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Département *</Label>
                  <Select value={jobInfo.department} onValueChange={(v) => setJobInfo({...jobInfo, department: v})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map(d => (
                        <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Niveau</Label>
                    <Select value={jobInfo.level} onValueChange={(v) => setJobInfo({...jobInfo, level: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="junior">Junior</SelectItem>
                        <SelectItem value="intermediate">Intermédiaire</SelectItem>
                        <SelectItem value="senior">Senior</SelectItem>
                        <SelectItem value="lead">Lead/Manager</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Type d'emploi</Label>
                    <Select value={jobInfo.employment_type} onValueChange={(v) => setJobInfo({...jobInfo, employment_type: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full_time">Temps plein</SelectItem>
                        <SelectItem value="part_time">Temps partiel</SelectItem>
                        <SelectItem value="contract">Contrat</SelectItem>
                        <SelectItem value="intern">Stage</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Compétences clés recherchées</Label>
                  <Textarea
                    value={jobInfo.key_skills}
                    onChange={(e) => setJobInfo({...jobInfo, key_skills: e.target.value})}
                    placeholder="ex: React, Node.js, TypeScript, MongoDB..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Taille de l'équipe</Label>
                    <Input
                      type="number"
                      value={jobInfo.team_size}
                      onChange={(e) => setJobInfo({...jobInfo, team_size: e.target.value})}
                      placeholder="ex: 5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Années d'expérience</Label>
                    <Input
                      type="number"
                      value={jobInfo.experience_years}
                      onChange={(e) => setJobInfo({...jobInfo, experience_years: e.target.value})}
                      placeholder="ex: 3"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating || !jobInfo.title || !jobInfo.department}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                      Génération en cours...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Générer avec l'IA
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Aperçu */}
          <div className="space-y-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-slate-900">Description générée</h3>
                  {generatedDescription && (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={copyToClipboard}>
                        <Copy className="w-4 h-4 mr-1" />
                        Copier
                      </Button>
                      <Button size="sm" variant="outline" onClick={downloadDescription}>
                        <Download className="w-4 h-4 mr-1" />
                        Télécharger
                      </Button>
                    </div>
                  )}
                </div>

                {!generatedDescription ? (
                  <div className="text-center py-12 text-slate-400">
                    <Briefcase className="w-16 h-16 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm">Remplissez les informations et cliquez sur "Générer"</p>
                  </div>
                ) : (
                  <div className="space-y-6 max-h-[600px] overflow-y-auto pr-2">
                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">📝 Résumé du poste</h4>
                      <p className="text-sm text-slate-700 leading-relaxed">
                        {generatedDescription.resume}
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">🎯 Missions et Responsabilités</h4>
                      <ul className="space-y-1">
                        {generatedDescription.missions.map((mission, i) => (
                          <li key={i} className="text-sm text-slate-700 flex items-start gap-2">
                            <span className="text-purple-600 font-bold">{i + 1}.</span>
                            <span>{mission}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">💻 Compétences Techniques</h4>
                      <div className="flex flex-wrap gap-2">
                        {generatedDescription.competences_techniques.map((comp, i) => (
                          <Badge key={i} className="bg-blue-600">{comp}</Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">🤝 Compétences Comportementales</h4>
                      <div className="flex flex-wrap gap-2">
                        {generatedDescription.competences_comportementales.map((comp, i) => (
                          <Badge key={i} className="bg-green-600">{comp}</Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">🎓 Qualifications</h4>
                      <ul className="space-y-1">
                        {generatedDescription.qualifications.map((qual, i) => (
                          <li key={i} className="text-sm text-slate-700 flex items-start gap-2">
                            <span className="text-purple-600">•</span>
                            <span>{qual}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-purple-900 mb-2">🎁 Ce que nous offrons</h4>
                      <ul className="space-y-1">
                        {generatedDescription.avantages.map((avantage, i) => (
                          <li key={i} className="text-sm text-slate-700 flex items-start gap-2">
                            <span className="text-purple-600">•</span>
                            <span>{avantage}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
          {generatedDescription && (
            <>
              <Button
                variant="outline"
                onClick={() => {
                  setGeneratedDescription(null);
                  handleGenerate();
                }}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Régénérer
              </Button>
              <Button
                onClick={handleUseForPosting}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Briefcase className="w-4 h-4 mr-2" />
                Utiliser pour créer l'offre
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}