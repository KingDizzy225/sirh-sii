import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Target, TrendingUp, CheckCircle, Copy } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AISmartGoalGenerator({ employee, onGoalCreated }) {
  const [aspirations, setAspirations] = useState("");
  const [timeframe, setTimeframe] = useState("6_months");
  const [focusArea, setFocusArea] = useState("career");
  const [goals, setGoals] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const [skills, setSkills] = useState([]);
  const [performanceReviews, setPerformanceReviews] = useState([]);
  const [jobPostings, setJobPostings] = useState([]);
  const [careerPaths, setCareerPaths] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      if (!employee) return;

      const [skillsData, reviewsData, jobsData, pathsData] = await Promise.all([
        base44.entities.Skill.filter({ employee_email: employee.email }),
        base44.entities.PerformanceReview.filter({ employee_email: employee.email }),
        base44.entities.JobPosting.filter({ status: 'active' }),
        base44.entities.CareerPath.filter({ employee_email: employee.email })
      ]);

      setSkills(skillsData);
      setPerformanceReviews(reviewsData);
      setJobPostings(jobsData);
      setCareerPaths(pathsData);
    };

    loadData();
  }, [employee]);

  const generateSmartGoals = async () => {
    if (!employee) return;

    setIsGenerating(true);
    try {
      const latestReview = performanceReviews[0];

      const prompt = `Tu es un expert en développement de carrière RH. Aide ${employee.full_name} à définir des objectifs SMART personnalisés.

PROFIL EMPLOYÉ:
Nom: ${employee.full_name}
Poste actuel: ${employee.position}
Département: ${employee.department}
Ancienneté: ${employee.hire_date ? `Depuis ${new Date(employee.hire_date).getFullYear()}` : 'N/A'}

COMPÉTENCES ACTUELLES:
${skills.slice(0, 20).map(s => `- ${s.skill_name} (${s.proficiency_level}) ${s.certified ? '✓ Certifié' : ''}`).join('\n')}

DERNIÈRE ÉVALUATION:
${latestReview ? `
Note globale: ${latestReview.overall_rating}/5
Forces: ${latestReview.strengths}
Axes d'amélioration: ${latestReview.areas_for_improvement}
` : 'Pas d\'évaluation récente'}

CHEMINS DE CARRIÈRE IDENTIFIÉS:
${careerPaths.slice(0, 5).map(cp => `- ${cp.target_role} (${cp.timeframe})`).join('\n') || 'Aucun chemin défini'}

OPPORTUNITÉS INTERNES:
${jobPostings.slice(0, 10).map(j => `- ${j.title} (${j.department})`).join('\n')}

ASPIRATIONS DE L'EMPLOYÉ:
${aspirations || 'Pas d\'aspirations spécifiques mentionnées'}

PÉRIODE CIBLÉE: ${timeframe === '3_months' ? '3 mois' : timeframe === '6_months' ? '6 mois' : '12 mois'}
DOMAINE PRIORITAIRE: ${
  focusArea === 'career' ? 'Évolution de carrière' :
  focusArea === 'technical' ? 'Compétences techniques' :
  focusArea === 'leadership' ? 'Leadership' :
  'Performance globale'
}

Génère 4-5 objectifs SMART pertinents avec métriques précises et actions concrètes.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            objectifs_smart: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  titre: { type: "string" },
                  description: { type: "string" },
                  specifique: { type: "string" },
                  mesurable: {
                    type: "object",
                    properties: {
                      metriques: { type: "array", items: { type: "string" } },
                      cible_quantitative: { type: "string" }
                    }
                  },
                  atteignable: { type: "string" },
                  realiste: { type: "string" },
                  temporel: {
                    type: "object",
                    properties: {
                      echeance: { type: "string" },
                      jalons: { type: "array", items: { type: "object", properties: { date: { type: "string" }, action: { type: "string" } } } }
                    }
                  },
                  actions_concretes: {
                    type: "array",
                    items: { type: "object", properties: { action: { type: "string" }, ressources_necessaires: { type: "string" }, temps_estime: { type: "string" } } }
                  },
                  competences_developpees: { type: "array", items: { type: "string" } },
                  lien_carriere: { type: "string" },
                  valeur_entreprise: { type: "string" },
                  categorie: { type: "string" },
                  priorite: { type: "string" },
                  support_requis: { type: "array", items: { type: "string" } }
                }
              }
            },
            synthese_personnalisee: { type: "string" },
            recommandations_developpement: {
              type: "array",
              items: { type: "object", properties: { titre: { type: "string" }, description: { type: "string" }, benefices: { type: "string" } } }
            },
            opportunites_court_terme: { type: "array", items: { type: "string" } }
          }
        }
      });

      setGoals(result);
      toast({ title: "Objectifs générés ✨", description: `${result.objectifs_smart.length} objectifs SMART personnalisés créés`, duration: 5000 });
    } catch (error) {
      console.error("Erreur génération:", error);
      toast({ title: "Erreur", description: "Impossible de générer les objectifs", variant: "destructive" });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyGoal = (goal) => {
    const text = `${goal.titre}\n\n${goal.description}\n\nSMART:\n- Spécifique: ${goal.specifique}\n- Mesurable: ${goal.mesurable.cible_quantitative}\n- Atteignable: ${goal.atteignable}\n- Réaliste: ${goal.realiste}\n- Temporel: ${goal.temporel.echeance}`;
    navigator.clipboard.writeText(text);
    toast({ title: "Copié !", duration: 2000 });
  };

  const createGoal = (smartGoal) => {
    if (!onGoalCreated) return;
    onGoalCreated({
      employee_email: employee.email,
      employee_name: employee.full_name,
      goal_title: smartGoal.titre,
      goal_description: `${smartGoal.description}\n\n${smartGoal.specifique}`,
      category: smartGoal.categorie || 'development',
      target_date: smartGoal.temporel.echeance,
      status: 'not_started',
      priority: smartGoal.priorite || 'medium',
      progress_percentage: 0,
      notes: `Généré par IA\n\nActions:\n${smartGoal.actions_concretes.map(a => `- ${a.action}`).join('\n')}`
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Target className="w-8 h-8 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-bold text-purple-900 text-lg mb-1">Générateur d'Objectifs SMART IA</h3>
              <p className="text-sm text-purple-700">Créez des objectifs personnalisés basés sur vos compétences et aspirations</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <Label>Vos aspirations de carrière</Label>
              <Textarea value={aspirations} onChange={(e) => setAspirations(e.target.value)} placeholder="Ex: Je souhaite évoluer vers un poste de chef de projet..." rows={3} />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Période ciblée</Label>
                <Select value={timeframe} onValueChange={setTimeframe}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3_months">3 mois</SelectItem>
                    <SelectItem value="6_months">6 mois</SelectItem>
                    <SelectItem value="12_months">12 mois</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Domaine prioritaire</Label>
                <Select value={focusArea} onValueChange={setFocusArea}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="career">Évolution de carrière</SelectItem>
                    <SelectItem value="technical">Compétences techniques</SelectItem>
                    <SelectItem value="leadership">Leadership</SelectItem>
                    <SelectItem value="performance">Performance globale</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button onClick={generateSmartGoals} disabled={isGenerating || !employee} className="w-full bg-purple-600 hover:bg-purple-700" size="lg">
              {isGenerating ? <><div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>Génération...</> : <><Sparkles className="w-5 h-5 mr-2" />Générer mes objectifs SMART</>}
            </Button>
          </div>
        </CardContent>
      </Card>

      {goals && (
        <>
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader><CardTitle className="text-blue-900">💡 Synthèse Personnalisée</CardTitle></CardHeader>
            <CardContent><p className="text-blue-900 leading-relaxed">{goals.synthese_personnalisee}</p></CardContent>
          </Card>

          {goals.opportunites_court_terme?.length > 0 && (
            <Card className="border-green-200 bg-green-50">
              <CardHeader><CardTitle className="text-green-900">🎯 Opportunités Court Terme</CardTitle></CardHeader>
              <CardContent><div className="space-y-2">{goals.opportunites_court_terme.map((opp, i) => <div key={i} className="p-3 bg-white rounded-lg border border-green-200"><p className="text-sm text-green-900">✓ {opp}</p></div>)}</div></CardContent>
            </Card>
          )}

          <div className="space-y-6">
            {goals.objectifs_smart.map((goal, i) => (
              <Card key={i} className="border-2 border-purple-200">
                <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-purple-900 mb-2">{goal.titre}</CardTitle>
                      <p className="text-sm text-purple-800">{goal.description}</p>
                      <div className="flex gap-2 mt-3">
                        <Badge className="bg-purple-600">{goal.categorie}</Badge>
                        <Badge className={goal.priorite === 'haute' ? 'bg-red-600' : goal.priorite === 'moyenne' ? 'bg-orange-600' : 'bg-blue-600'}>{goal.priorite}</Badge>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => copyGoal(goal)}><Copy className="w-4 h-4" /></Button>
                      {onGoalCreated && <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => createGoal(goal)}><CheckCircle className="w-4 h-4 mr-1" />Créer</Button>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4 pt-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-3 bg-blue-50 rounded-lg border border-blue-200"><p className="font-bold text-blue-900 text-sm mb-1">✓ Spécifique</p><p className="text-xs text-blue-800">{goal.specifique}</p></div>
                    <div className="p-3 bg-green-50 rounded-lg border border-green-200"><p className="font-bold text-green-900 text-sm mb-2">📊 Mesurable</p><p className="text-xs text-green-800 mb-2 font-medium">{goal.mesurable.cible_quantitative}</p><div className="space-y-1">{goal.mesurable.metriques.map((m, j) => <Badge key={j} variant="outline" className="text-xs mr-1">{m}</Badge>)}</div></div>
                    <div className="p-3 bg-purple-50 rounded-lg border border-purple-200"><p className="font-bold text-purple-900 text-sm mb-1">💪 Atteignable</p><p className="text-xs text-purple-800">{goal.atteignable}</p></div>
                    <div className="p-3 bg-orange-50 rounded-lg border border-orange-200"><p className="font-bold text-orange-900 text-sm mb-1">🎯 Réaliste</p><p className="text-xs text-orange-800">{goal.realiste}</p></div>
                  </div>
                  <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                    <p className="font-bold text-indigo-900 mb-3">⏰ Temporel: {goal.temporel.echeance}</p>
                    <div className="space-y-2"><p className="text-xs font-medium text-indigo-800">Jalons clés:</p>{goal.temporel.jalons.map((jalon, j) => <div key={j} className="flex items-start gap-2 text-xs text-indigo-700"><span className="font-medium">{jalon.date}:</span><span>{jalon.action}</span></div>)}</div>
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <p className="font-bold text-yellow-900 mb-3">⚡ Actions Concrètes</p>
                    <div className="space-y-3">{goal.actions_concretes.map((action, j) => <div key={j} className="p-3 bg-white rounded border border-yellow-200"><p className="text-sm font-medium text-yellow-900 mb-2">{j + 1}. {action.action}</p><div className="flex gap-4 text-xs text-yellow-700"><span>📦 {action.ressources_necessaires}</span><span>⏱️ {action.temps_estime}</span></div></div>)}</div>
                  </div>
                  <div className="p-3 bg-teal-50 rounded-lg border border-teal-200"><p className="font-bold text-teal-900 text-sm mb-2">🎓 Compétences Développées</p><div className="flex flex-wrap gap-2">{goal.competences_developpees.map((comp, j) => <Badge key={j} className="bg-teal-600">{comp}</Badge>)}</div></div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-3 bg-pink-50 rounded-lg border border-pink-200"><p className="font-bold text-pink-900 text-sm mb-1">🚀 Lien Carrière</p><p className="text-xs text-pink-800">{goal.lien_carriere}</p></div>
                    <div className="p-3 bg-cyan-50 rounded-lg border border-cyan-200"><p className="font-bold text-cyan-900 text-sm mb-1">💼 Valeur Entreprise</p><p className="text-xs text-cyan-800">{goal.valeur_entreprise}</p></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {goals.recommandations_developpement?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5 text-indigo-600" />Recommandations de Développement</CardTitle></CardHeader>
              <CardContent className="space-y-3">{goals.recommandations_developpement.map((rec, i) => <div key={i} className="p-4 bg-indigo-50 rounded-lg border border-indigo-200"><h4 className="font-bold text-indigo-900 mb-2">{rec.titre}</h4><p className="text-sm text-indigo-800 mb-2">{rec.description}</p><p className="text-xs text-indigo-700 italic">✨ {rec.benefices}</p></div>)}</CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}