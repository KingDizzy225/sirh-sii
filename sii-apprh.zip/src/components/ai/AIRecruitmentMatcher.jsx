import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Sparkles, TrendingUp, AlertCircle, CheckCircle, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AIRecruitmentMatcher({ candidate, jobPosting }) {
  const [analysis, setAnalysis] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const analyzeMatch = async () => {
    setIsLoading(true);
    try {
      const prompt = `Analyse ce candidat par rapport à l'offre d'emploi et donne un matching détaillé.

**Offre d'emploi:**
Titre: ${jobPosting.title}
Département: ${jobPosting.department}
Type: ${jobPosting.employment_type}
Description: ${jobPosting.description}
Exigences: ${jobPosting.requirements}

**Candidat:**
Nom: ${candidate.full_name}
Email: ${candidate.email}
Expérience: ${candidate.experience_years || 'Non spécifié'} ans
Compétences: ${candidate.skills?.join(', ') || 'Non spécifié'}
Notes: ${candidate.notes || 'Aucune'}

Fournis une analyse structurée au format JSON avec:
{
  "matchScore": number (0-100),
  "strengths": ["point fort 1", "point fort 2", ...],
  "weaknesses": ["point faible 1", "point faible 2", ...],
  "recommendation": "RECOMMEND" ou "MAYBE" ou "NOT_RECOMMEND",
  "summary": "résumé en 2-3 phrases",
  "suggestedQuestions": ["question 1", "question 2", "question 3"]
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            matchScore: { type: "number" },
            strengths: { type: "array", items: { type: "string" } },
            weaknesses: { type: "array", items: { type: "string" } },
            recommendation: { type: "string" },
            summary: { type: "string" },
            suggestedQuestions: { type: "array", items: { type: "string" } }
          }
        }
      });

      setAnalysis(response);
    } catch (error) {
      console.error("Erreur analyse IA:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation) {
      case 'RECOMMEND': return 'bg-green-100 text-green-800 border-green-300';
      case 'MAYBE': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'NOT_RECOMMEND': return 'bg-red-100 text-red-800 border-red-300';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRecommendationLabel = (recommendation) => {
    switch (recommendation) {
      case 'RECOMMEND': return '✅ Fortement recommandé';
      case 'MAYBE': return '⚠️ À considérer';
      case 'NOT_RECOMMEND': return '❌ Non recommandé';
      default: return 'Analyse en cours';
    }
  };

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Analyse IA du candidat
          </CardTitle>
          {!analysis && (
            <Button
              onClick={analyzeMatch}
              disabled={isLoading}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isLoading ? (
                <>
                  <Zap className="w-4 h-4 mr-2 animate-pulse" />
                  Analyse en cours...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyser avec l'IA
                </>
              )}
            </Button>
          )}
        </div>
      </CardHeader>

      {analysis && (
        <CardContent className="p-6 space-y-6">
          {/* Score de matching */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-slate-900">Score de correspondance</span>
              <span className="text-3xl font-bold text-purple-600">{analysis.matchScore}%</span>
            </div>
            <Progress value={analysis.matchScore} className="h-3" />
          </div>

          {/* Recommandation */}
          <div className={`p-4 rounded-lg border-2 ${getRecommendationColor(analysis.recommendation)}`}>
            <p className="font-bold text-lg mb-2">{getRecommendationLabel(analysis.recommendation)}</p>
            <p className="text-sm">{analysis.summary}</p>
          </div>

          {/* Points forts */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Points forts
            </h4>
            <div className="space-y-2">
              {analysis.strengths.map((strength, index) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-green-50 rounded-lg border border-green-200">
                  <span className="text-green-600 font-bold">✓</span>
                  <p className="text-sm text-green-900">{strength}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Points faibles */}
          {analysis.weaknesses.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                Points d'attention
              </h4>
              <div className="space-y-2">
                {analysis.weaknesses.map((weakness, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <span className="text-orange-600 font-bold">!</span>
                    <p className="text-sm text-orange-900">{weakness}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Questions suggérées */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Questions d'entretien suggérées
            </h4>
            <div className="space-y-2">
              {analysis.suggestedQuestions.map((question, index) => (
                <div key={index} className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-900">
                    <span className="font-semibold">Q{index + 1}:</span> {question}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Réanalyser */}
          <Button
            onClick={analyzeMatch}
            disabled={isLoading}
            variant="outline"
            className="w-full"
          >
            Réanalyser
          </Button>
        </CardContent>
      )}
    </Card>
  );
}