import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, TrendingUp, AlertTriangle, Users, Target, Brain, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AIGPECInsights({ employees, performanceReviews, skills, talentPool }) {
  const [insights, setInsights] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateInsights = async () => {
    setIsLoading(true);
    try {
      // Préparer les données pour l'IA
      const employeeStats = {
        total: employees.length,
        departments: [...new Set(employees.map(e => e.department))],
        avgTenure: employees.filter(e => e.hire_date).length
      };

      const performanceStats = {
        totalReviews: performanceReviews.length,
        avgRating: performanceReviews.length > 0 
          ? (performanceReviews.reduce((sum, r) => sum + r.overall_rating, 0) / performanceReviews.length).toFixed(2)
          : 0,
        highPerformers: performanceReviews.filter(r => r.overall_rating >= 4).length
      };

      const skillStats = {
        totalSkills: [...new Set(skills.map(s => s.skill_name))].length,
        criticalGaps: skills.filter(s => s.proficiency_level === 'beginner').length
      };

      const talentStats = {
        totalTalents: talentPool.length,
        highPotential: talentPool.filter(t => t.talent_category === 'high_potential').length,
        retentionRisk: talentPool.filter(t => t.retention_risk === 'high' || t.retention_risk === 'critical').length
      };

      const prompt = `En tant qu'expert RH et consultant GPEC, analyse ces données et fournis des insights stratégiques actionnables.

**Données:**
- Employés: ${employeeStats.total} (Départements: ${employeeStats.departments.join(', ')})
- Performance moyenne: ${performanceStats.avgRating}/5 (${performanceStats.totalReviews} évaluations, ${performanceStats.highPerformers} hautes performances)
- Compétences: ${skillStats.totalSkills} compétences distinctes
- Vivier de talents: ${talentStats.totalTalents} talents (${talentStats.highPotential} hauts potentiels, ${talentStats.retentionRisk} à risque de départ)

Fournis une analyse au format JSON avec:
{
  "turnoverRisk": {
    "level": "low" | "medium" | "high" | "critical",
    "percentage": number,
    "reasoning": "explication"
  },
  "talentActions": [
    {
      "priority": "high" | "medium" | "low",
      "action": "description de l'action",
      "impact": "impact attendu",
      "timeline": "délai suggéré"
    }
  ],
  "successorGaps": {
    "criticalPositions": number,
    "recommendations": ["recommandation 1", "recommandation 2"]
  },
  "skillDevelopment": {
    "priorities": ["compétence 1", "compétence 2", "compétence 3"],
    "strategy": "stratégie globale"
  },
  "retentionStrategy": [
    "action de rétention 1",
    "action de rétention 2"
  ],
  "keyInsights": [
    "insight stratégique 1",
    "insight stratégique 2",
    "insight stratégique 3"
  ]
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            turnoverRisk: {
              type: "object",
              properties: {
                level: { type: "string" },
                percentage: { type: "number" },
                reasoning: { type: "string" }
              }
            },
            talentActions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  priority: { type: "string" },
                  action: { type: "string" },
                  impact: { type: "string" },
                  timeline: { type: "string" }
                }
              }
            },
            successorGaps: {
              type: "object",
              properties: {
                criticalPositions: { type: "number" },
                recommendations: { type: "array", items: { type: "string" } }
              }
            },
            skillDevelopment: {
              type: "object",
              properties: {
                priorities: { type: "array", items: { type: "string" } },
                strategy: { type: "string" }
              }
            },
            retentionStrategy: {
              type: "array",
              items: { type: "string" }
            },
            keyInsights: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setInsights(response);
    } catch (error) {
      console.error("Erreur analyse IA GPEC:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRiskColor = (level) => {
    switch (level) {
      case 'critical': return 'bg-red-100 text-red-800 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-800 border-green-300';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-600';
      case 'medium': return 'bg-orange-600';
      case 'low': return 'bg-blue-600';
      default: return 'bg-gray-600';
    }
  };

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-600" />
            Insights IA - Analyse Prédictive GPEC
          </CardTitle>
          <Button
            onClick={generateInsights}
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isLoading ? (
              <>
                <Zap className="w-4 h-4 mr-2 animate-pulse" />
                Analyse en cours...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Générer les insights
              </>
            )}
          </Button>
        </div>
      </CardHeader>

      {insights && (
        <CardContent className="p-6 space-y-6">
          {/* Risque de turnover */}
          <div className={`p-4 rounded-lg border-2 ${getRiskColor(insights.turnoverRisk.level)}`}>
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-lg">Prédiction Turnover</h4>
              <Badge className={`${getPriorityColor(insights.turnoverRisk.level)} text-white`}>
                {insights.turnoverRisk.level === 'critical' ? '🔴 Critique' :
                 insights.turnoverRisk.level === 'high' ? '🟠 Élevé' :
                 insights.turnoverRisk.level === 'medium' ? '🟡 Moyen' :
                 '🟢 Faible'}
              </Badge>
            </div>
            <p className="text-2xl font-bold mb-2">~{insights.turnoverRisk.percentage}% de risque</p>
            <p className="text-sm">{insights.turnoverRisk.reasoning}</p>
          </div>

          {/* Insights stratégiques clés */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Insights Stratégiques Clés
            </h4>
            <div className="space-y-2">
              {insights.keyInsights.map((insight, index) => (
                <Alert key={index} className="bg-blue-50 border-blue-200">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="ml-2 text-blue-900">
                    {insight}
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </div>

          {/* Actions prioritaires sur les talents */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-600" />
              Actions Prioritaires - Gestion des Talents
            </h4>
            <div className="space-y-3">
              {insights.talentActions.map((action, index) => (
                <Card key={index} className="border-2 hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <Badge className={`${getPriorityColor(action.priority)} text-white mt-1`}>
                        {action.priority === 'high' ? 'Haute' :
                         action.priority === 'medium' ? 'Moyenne' :
                         'Basse'}
                      </Badge>
                      <div className="flex-1">
                        <p className="font-semibold text-slate-900 mb-1">{action.action}</p>
                        <p className="text-sm text-slate-600 mb-2">
                          <strong>Impact:</strong> {action.impact}
                        </p>
                        <p className="text-xs text-slate-500">
                          ⏱️ Timeline: {action.timeline}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Plans de succession */}
          <div className="p-4 bg-orange-50 rounded-lg border-2 border-orange-200">
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-600" />
              Gaps de Succession Détectés
            </h4>
            <p className="text-2xl font-bold text-orange-900 mb-3">
              {insights.successorGaps.criticalPositions} positions critiques sans successeur
            </p>
            <div className="space-y-2">
              {insights.successorGaps.recommendations.map((rec, index) => (
                <div key={index} className="flex items-start gap-2 p-2 bg-white rounded">
                  <span className="text-orange-600 font-bold mt-0.5">→</span>
                  <p className="text-sm text-slate-900">{rec}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Développement des compétences */}
          <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Users className="w-5 h-5 text-green-600" />
              Stratégie de Développement des Compétences
            </h4>
            <p className="text-sm text-slate-700 mb-3 italic">{insights.skillDevelopment.strategy}</p>
            <div className="space-y-2">
              <p className="font-medium text-sm text-green-900">Compétences prioritaires à développer:</p>
              <div className="flex flex-wrap gap-2">
                {insights.skillDevelopment.priorities.map((skill, index) => (
                  <Badge key={index} className="bg-green-600 text-white">
                    {index + 1}. {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Stratégie de rétention */}
          <div className="p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Stratégie de Rétention des Talents
            </h4>
            <div className="space-y-2">
              {insights.retentionStrategy.map((strategy, index) => (
                <div key={index} className="flex items-start gap-2 p-3 bg-white rounded-lg">
                  <span className="text-purple-600 font-bold text-lg">✓</span>
                  <p className="text-sm text-slate-900">{strategy}</p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}