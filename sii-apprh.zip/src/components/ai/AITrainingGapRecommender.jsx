import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, Users, Target, Calendar, Download } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { useQuery } from "@tanstack/react-query";

export default function AITrainingGapRecommender() {
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [recommendations, setRecommendations] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: skills = [] } = useQuery({
    queryKey: ['skills'],
    queryFn: () => base44.entities.Skill.list(),
  });

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const analyzeGapsAndRecommend = async () => {
    setIsAnalyzing(true);
    try {
      const filteredEmployees = selectedDepartment === "all"
        ? employees
        : employees.filter(e => e.department === selectedDepartment);

      const employeeSkills = {};
      skills.forEach(skill => {
        if (!employeeSkills[skill.employee_email]) {
          employeeSkills[skill.employee_email] = [];
        }
        employeeSkills[skill.employee_email].push({
          name: skill.skill_name,
          level: skill.proficiency_level,
          certified: skill.certified
        });
      });

      const skillDistribution = skills.reduce((acc, skill) => {
        const emp = employees.find(e => e.email === skill.employee_email);
        if (emp && (selectedDepartment === "all" || emp.department === selectedDepartment)) {
          acc[skill.skill_name] = (acc[skill.skill_name] || 0) + 1;
        }
        return acc;
      }, {});

      const prompt = `Tu es un expert en développement RH. Analyse les données et recommande un plan de formation stratégique:

DÉPARTEMENT: ${selectedDepartment}
NOMBRE D'EMPLOYÉS: ${filteredEmployees.length}

COMPÉTENCES ACTUELLES:
${Object.entries(skillDistribution).slice(0, 30).map(([skill, count]) => 
  `- ${skill}: ${count} employés (${Math.round(count/filteredEmployees.length*100)}%)`
).join('\n')}

FORMATIONS DISPONIBLES:
${trainings.slice(0, 20).map(t => `- ${t.title} (${t.skills_taught?.join(', ') || 'N/A'})`).join('\n')}

Fournis des recommandations stratégiques détaillées.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            gaps_critiques: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  competence: { type: "string" },
                  impact: { type: "string" },
                  employes_a_former: { type: "number" }
                }
              }
            },
            formations_prioritaires: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  titre: { type: "string" },
                  competences_ciblees: { 
                    type: "array",
                    items: { type: "string" }
                  },
                  nombre_participants: { type: "number" },
                  duree_estimee: { type: "string" },
                  priorite: { type: "string" }
                }
              }
            },
            budget_total_estime: { type: "number" },
            calendrier_6mois: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  mois: { type: "string" },
                  formations: { 
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            },
            quick_wins: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  formation: { type: "string" },
                  raison: { type: "string" }
                }
              }
            },
            recommandations_strategiques: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setRecommendations(result);

      toast({
        title: "Analyse terminée ✨",
        description: "Recommandations générées avec succès",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur analyse:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'analyser les gaps",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const exportReport = () => {
    if (!recommendations) return;

    const content = `
RECOMMANDATIONS IA - PLAN DE FORMATION
Généré le: ${new Date().toLocaleDateString('fr-FR')}
Département: ${selectedDepartment}

BUDGET TOTAL ESTIMÉ: ${recommendations.budget_total_estime.toLocaleString()} FCFA

GAPS CRITIQUES:
${recommendations.gaps_critiques.map((g, i) => 
  `${i+1}. ${g.competence} - ${g.employes_a_former} employés\n   Impact: ${g.impact}`
).join('\n\n')}

FORMATIONS PRIORITAIRES:
${recommendations.formations_prioritaires.map((f, i) => 
  `${i+1}. ${f.titre} (Priorité ${f.priorite})
   Compétences: ${f.competences_ciblees.join(', ')}
   Participants: ${f.nombre_participants}
   Durée: ${f.duree_estimee}`
).join('\n\n')}

QUICK WINS:
${recommendations.quick_wins.map((w, i) => `${i+1}. ${w.formation}\n   ${w.raison}`).join('\n\n')}

CALENDRIER 6 MOIS:
${recommendations.calendrier_6mois.map(m => 
  `${m.mois}:\n${m.formations.map(f => `  - ${f}`).join('\n')}`
).join('\n\n')}

RECOMMANDATIONS STRATÉGIQUES:
${recommendations.recommandations_strategiques.map((r, i) => `${i+1}. ${r}`).join('\n')}
`;

    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Recommandations_Formation_IA_${new Date().toISOString().split('T')[0]}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-1">
                Recommandations IA de Formation
              </h3>
              <p className="text-sm text-purple-700">
                L'IA analyse les gaps et suggère un plan de formation optimal
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-[250px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toute l'entreprise</SelectItem>
                {departments.map(d => (
                  <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={analyzeGapsAndRecommend}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyse...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyser et recommander
                </>
              )}
            </Button>

            {recommendations && (
              <Button variant="outline" onClick={exportReport}>
                <Download className="w-4 h-4 mr-2" />
                Exporter
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {recommendations && (
        <>
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-700 mb-1">Budget Formation Estimé</p>
                  <p className="text-4xl font-bold text-green-900">
                    {(recommendations.budget_total_estime / 1000000).toFixed(1)}M FCFA
                  </p>
                </div>
                <TrendingUp className="w-12 h-12 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-red-600" />
                Gaps Critiques Identifiés
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recommendations.gaps_critiques.map((gap, i) => (
                <div key={i} className="p-4 border-2 border-red-200 bg-red-50 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-red-900">{gap.competence}</h4>
                    <Badge className="bg-red-600">{gap.employes_a_former} employés</Badge>
                  </div>
                  <p className="text-sm text-red-700">{gap.impact}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Formations Prioritaires Recommandées
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recommendations.formations_prioritaires.map((formation, i) => (
                <div key={i} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-slate-900">{formation.titre}</h4>
                        <Badge className={
                          formation.priorite === 'haute' ? 'bg-red-600' :
                          formation.priorite === 'moyenne' ? 'bg-orange-600' :
                          'bg-blue-600'
                        }>
                          {formation.priorite}
                        </Badge>
                      </div>
                      
                      <div className="flex flex-wrap gap-2 mb-2">
                        {formation.competences_ciblees.map((comp, j) => (
                          <Badge key={j} variant="outline" className="text-xs">
                            {comp}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center gap-4 text-sm text-slate-600">
                        <span>👥 {formation.nombre_participants} participants</span>
                        <span>⏱️ {formation.duree_estimee}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                ⚡ Quick Wins - Actions Rapides
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recommendations.quick_wins.map((win, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-green-200">
                  <p className="font-semibold text-green-900 mb-1">{win.formation}</p>
                  <p className="text-sm text-green-700">{win.raison}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-purple-600" />
                Calendrier de Formation sur 6 Mois
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recommendations.calendrier_6mois.map((month, i) => (
                <div key={i} className="border-l-4 border-purple-600 pl-4">
                  <h4 className="font-semibold text-purple-900 mb-2">{month.mois}</h4>
                  <ul className="space-y-1">
                    {month.formations.map((f, j) => (
                      <li key={j} className="text-sm text-slate-700">• {f}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                💡 Recommandations Stratégiques
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {recommendations.recommandations_strategiques.map((rec, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-900">{rec}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      )}

      {!recommendations && (
        <Card>
          <CardContent className="p-12 text-center text-slate-500">
            <Sparkles className="w-16 h-16 mx-auto mb-4 text-purple-300" />
            <p className="text-lg font-medium mb-2">Recommandations IA de Formation</p>
            <p className="text-sm">
              Sélectionnez un département et lancez l'analyse pour obtenir des recommandations personnalisées
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}