import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Sparkles, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  SmilePlus,
  Frown,
  Meh,
  BarChart3
} from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";

const SENTIMENT_COLORS = {
  'Très positif': '#10b981',
  'Positif': '#84cc16',
  'Neutre': '#f59e0b',
  'Négatif': '#f97316',
  'Très négatif': '#ef4444'
};

export default function AIPerformanceSentimentAnalysis() {
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews'],
    queryFn: () => base44.entities.PerformanceReview.list(),
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
  });

  const analyzeSentiment = async () => {
    setIsAnalyzing(true);
    try {
      // Filtrer les reviews
      let filteredReviews = reviews;
      
      if (selectedDepartment !== "all") {
        const deptEmployees = employees.filter(e => e.department === selectedDepartment);
        const deptEmails = deptEmployees.map(e => e.email);
        filteredReviews = filteredReviews.filter(r => deptEmails.includes(r.employee_email));
      }

      if (selectedPeriod !== "all") {
        filteredReviews = filteredReviews.filter(r => r.review_period === selectedPeriod);
      }

      if (filteredReviews.length === 0) {
        toast({
          title: "Pas de données",
          description: "Aucune évaluation trouvée pour ces filtres",
          variant: "destructive",
          duration: 5000,
        });
        setIsAnalyzing(false);
        return;
      }

      // Préparer les données pour l'IA
      const reviewsData = filteredReviews.map(r => ({
        employee: r.employee_name,
        period: r.review_period,
        rating: r.overall_rating,
        strengths: r.strengths,
        improvements: r.areas_for_improvement,
        comments: r.comments,
        technical: r.technical_skills,
        communication: r.communication,
        teamwork: r.teamwork,
        leadership: r.leadership
      }));

      const prompt = `Tu es un expert en analyse RH. Analyse le sentiment et les tendances des évaluations de performance suivantes:

${selectedDepartment !== "all" ? `DÉPARTEMENT: ${selectedDepartment}` : 'TOUTE L\'ENTREPRISE'}
${selectedPeriod !== "all" ? `PÉRIODE: ${selectedPeriod}` : ''}
NOMBRE D'ÉVALUATIONS: ${filteredReviews.length}

DONNÉES D'ÉVALUATIONS:
${reviewsData.slice(0, 20).map((r, i) => `
${i + 1}. ${r.employee} (${r.period})
   Note globale: ${r.rating}/5
   Points forts: ${r.strengths || 'N/A'}
   Axes d'amélioration: ${r.improvements || 'N/A'}
   Commentaires: ${r.comments || 'N/A'}
`).join('\n')}

Fournis une analyse complète:
1. Distribution du sentiment (Très positif, Positif, Neutre, Négatif, Très négatif) avec pourcentages
2. Tendances identifiées (patterns récurrents dans strengths et improvements)
3. Points forts de l'équipe (top 5 forces récurrentes)
4. Zones de préoccupation (top 5 faiblesses récurrentes)
5. Recommandations d'actions RH concrètes
6. Risque de turnover (faible/moyen/élevé) avec explication
7. Score de moral global (0-100)`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            distribution_sentiment: {
              type: "object",
              properties: {
                "Très positif": { type: "number" },
                "Positif": { type: "number" },
                "Neutre": { type: "number" },
                "Négatif": { type: "number" },
                "Très négatif": { type: "number" }
              }
            },
            tendances: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  tendance: { type: "string" },
                  frequence: { type: "string" },
                  impact: { type: "string" }
                }
              }
            },
            points_forts_equipe: {
              type: "array",
              items: { type: "string" }
            },
            zones_preoccupation: {
              type: "array",
              items: { type: "string" }
            },
            recommandations_actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  action: { type: "string" },
                  priorite: { type: "string" },
                  impact_attendu: { type: "string" }
                }
              }
            },
            risque_turnover: {
              type: "object",
              properties: {
                niveau: { type: "string" },
                explication: { type: "string" }
              }
            },
            score_moral_global: { type: "number" }
          }
        }
      });

      setAnalysis(result);

      toast({
        title: "Analyse terminée ✨",
        description: "Sentiment et tendances analysés avec succès",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur analyse sentiment:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'analyser le sentiment",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const pieData = analysis ? Object.entries(analysis.distribution_sentiment).map(([name, value]) => ({
    name,
    value,
    color: SENTIMENT_COLORS[name]
  })) : [];

  return (
    <div className="space-y-6">
      {/* Contrôles */}
      <Card className="border-purple-200 bg-purple-50">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-4">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-1">
                Analyse IA du Sentiment des Évaluations
              </h3>
              <p className="text-sm text-purple-700">
                Identifie les tendances, le moral et les risques dans les évaluations
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous départements</SelectItem>
                {departments.map(d => (
                  <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toutes périodes</SelectItem>
                <SelectItem value="Q1 2025">Q1 2025</SelectItem>
                <SelectItem value="Q2 2025">Q2 2025</SelectItem>
                <SelectItem value="Q3 2025">Q3 2025</SelectItem>
                <SelectItem value="Q4 2025">Q4 2025</SelectItem>
              </SelectContent>
            </Select>

            <Button
              onClick={analyzeSentiment}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyse...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyser le sentiment
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {analysis && (
        <>
          {/* Score de Moral Global */}
          <Card className="border-none shadow-lg">
            <CardContent className="p-8">
              <div className="text-center">
                <p className="text-sm text-slate-600 mb-2">Score de Moral Global</p>
                <div className="relative inline-block">
                  <div className="text-6xl font-bold text-purple-600">
                    {analysis.score_moral_global}
                  </div>
                  <span className="text-2xl text-slate-500">/100</span>
                </div>
                <Progress value={analysis.score_moral_global} className="h-3 mt-4" />
                <p className="text-sm text-slate-600 mt-2">
                  {analysis.score_moral_global >= 80 ? '😊 Excellent moral d\'équipe' :
                   analysis.score_moral_global >= 60 ? '😐 Moral satisfaisant' :
                   analysis.score_moral_global >= 40 ? '😟 Moral à améliorer' :
                   '😔 Moral préoccupant'}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Distribution Sentiment */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribution du Sentiment</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.name} (${entry.value}%)`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Risque Turnover */}
            <Card className={
              analysis.risque_turnover.niveau === 'élevé' ? 'border-red-200 bg-red-50' :
              analysis.risque_turnover.niveau === 'moyen' ? 'border-orange-200 bg-orange-50' :
              'border-green-200 bg-green-50'
            }>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className={`w-5 h-5 ${
                    analysis.risque_turnover.niveau === 'élevé' ? 'text-red-600' :
                    analysis.risque_turnover.niveau === 'moyen' ? 'text-orange-600' :
                    'text-green-600'
                  }`} />
                  Risque de Turnover
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Badge className={`text-lg px-4 py-2 ${
                  analysis.risque_turnover.niveau === 'élevé' ? 'bg-red-600' :
                  analysis.risque_turnover.niveau === 'moyen' ? 'bg-orange-600' :
                  'bg-green-600'
                }`}>
                  {analysis.risque_turnover.niveau.toUpperCase()}
                </Badge>
                <p className="text-sm text-slate-700 mt-4 leading-relaxed">
                  {analysis.risque_turnover.explication}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Tendances */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Tendances Identifiées
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {analysis.tendances.map((t, i) => (
                <div key={i} className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-slate-900">{t.tendance}</h4>
                    <Badge variant="outline">{t.frequence}</Badge>
                  </div>
                  <p className="text-sm text-slate-600">{t.impact}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Points forts vs Préoccupations */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-900">
                  <SmilePlus className="w-5 h-5" />
                  Points Forts de l'Équipe
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {analysis.points_forts_equipe.map((point, i) => (
                  <div key={i} className="p-3 bg-white rounded-lg border border-green-200">
                    <div className="flex items-start gap-2">
                      <span className="text-green-600 font-bold">{i + 1}.</span>
                      <p className="text-sm text-green-900">{point}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-900">
                  <Frown className="w-5 h-5" />
                  Zones de Préoccupation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {analysis.zones_preoccupation.map((zone, i) => (
                  <div key={i} className="p-3 bg-white rounded-lg border border-red-200">
                    <div className="flex items-start gap-2">
                      <span className="text-red-600 font-bold">{i + 1}.</span>
                      <p className="text-sm text-red-900">{zone}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Recommandations d'Actions */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                💡 Plan d'Action Recommandé
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {analysis.recommandations_actions.map((rec, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-blue-200">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-blue-900">{rec.action}</h4>
                    <Badge className={
                      rec.priorite === 'haute' ? 'bg-red-600' :
                      rec.priorite === 'moyenne' ? 'bg-orange-600' :
                      'bg-blue-600'
                    }>
                      Priorité {rec.priorite}
                    </Badge>
                  </div>
                  <p className="text-sm text-blue-700">
                    <strong>Impact attendu:</strong> {rec.impact_attendu}
                  </p>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      )}

      {!analysis && (
        <Card>
          <CardContent className="p-12 text-center text-slate-500">
            <BarChart3 className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <p className="text-lg font-medium mb-2">Analyse IA du Sentiment</p>
            <p className="text-sm">
              Sélectionnez les filtres et lancez l'analyse pour découvrir les tendances
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}