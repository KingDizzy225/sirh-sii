
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, Brain, Zap, Network, AlertCircle, Check, Loader } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AIOrganigrammeBuilder({ employees, onApplyChanges }) {
  const [suggestions, setSuggestions] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedChanges, setSelectedChanges] = useState(new Set());
  const { toast } = useToast();

  const generateHierarchy = async () => {
    setIsLoading(true);
    try {
      // Préparer les données pour l'IA
      const employeesList = employees.map(emp => ({
        id: emp.id,
        name: emp.full_name,
        email: emp.email,
        position: emp.position,
        department: emp.department,
        current_manager: emp.manager_name || null
      }));

      const prompt = `En tant qu'expert en organisation RH, analyse ces employés et crée une structure hiérarchique logique basée sur leurs intitulés de poste.

**Employés (${employees.length}):**
${employeesList.map(e => `- ${e.name} : ${e.position} (Département: ${e.department})`).join('\n')}

**Instructions:**
1. Identifie les postes de direction (CEO, Directeur, Director, etc.)
2. Identifie les managers (Manager, Chef, Responsable, Lead, etc.)
3. Identifie les employés juniors/assistants
4. Crée une hiérarchie logique basée sur les titres de poste
5. Groupe les employés par département quand c'est pertinent
6. Assure-toi qu'aucun employé n'est son propre manager
7. Évite les boucles hiérarchiques

**Format de réponse JSON:**
{
  "hierarchy": [
    {
      "employee_email": "email@example.com",
      "employee_name": "Nom Complet",
      "suggested_manager_email": "manager@example.com" ou null,
      "suggested_manager_name": "Nom Manager" ou null,
      "reasoning": "Explication du choix",
      "confidence": "high" | "medium" | "low",
      "level": 1-5 (1 = top, 5 = junior)
    }
  ],
  "organization_insights": [
    "Insight stratégique 1",
    "Insight stratégique 2"
  ],
  "potential_issues": [
    {
      "issue": "Description du problème potentiel",
      "affected_employees": ["email1", "email2"],
      "recommendation": "Recommandation pour résoudre"
    }
  ],
  "statistics": {
    "suggested_top_level": number,
    "suggested_managers": number,
    "average_team_size": number,
    "departments_analyzed": number
  }
}`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            hierarchy: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  employee_email: { type: "string" },
                  employee_name: { type: "string" },
                  suggested_manager_email: { type: ["string", "null"] },
                  suggested_manager_name: { type: ["string", "null"] },
                  reasoning: { type: "string" },
                  confidence: { type: "string" },
                  level: { type: "number" }
                }
              }
            },
            organization_insights: {
              type: "array",
              items: { type: "string" }
            },
            potential_issues: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  issue: { type: "string" },
                  affected_employees: { type: "array", items: { type: "string" } },
                  recommendation: { type: "string" }
                }
              }
            },
            statistics: {
              type: "object",
              properties: {
                suggested_top_level: { type: "number" },
                suggested_managers: { type: "number" },
                average_team_size: { type: "number" },
                departments_analyzed: { type: "number" }
              }
            }
          }
        }
      });

      setSuggestions(response);
      
      // Sélectionner toutes les suggestions par défaut
      const allEmails = new Set(response.hierarchy.map(h => h.employee_email));
      setSelectedChanges(allEmails);

      toast({
        title: "✨ Analyse IA terminée",
        description: `${response.hierarchy.length} suggestions hiérarchiques générées`,
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur analyse IA organigramme:", error);
      toast({
        title: "Erreur",
        description: "Impossible de générer la hiérarchie",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSelection = (email) => {
    setSelectedChanges(prev => {
      const newSet = new Set(prev);
      if (newSet.has(email)) {
        newSet.delete(email);
      } else {
        newSet.add(email);
      }
      return newSet;
    });
  };

  const selectAll = () => {
    const allEmails = new Set(suggestions.hierarchy.map(h => h.employee_email));
    setSelectedChanges(allEmails);
  };

  const deselectAll = () => {
    setSelectedChanges(new Set());
  };

  const applyChanges = async () => {
    if (selectedChanges.size === 0) {
      toast({
        title: "Aucune sélection",
        description: "Sélectionnez au moins une suggestion à appliquer",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    const changesToApply = suggestions.hierarchy.filter(h => selectedChanges.has(h.employee_email));
    
    if (onApplyChanges) {
      await onApplyChanges(changesToApply);
    }
  };

  const getConfidenceColor = (confidence) => {
    switch (confidence) {
      case 'high': return 'bg-green-100 text-green-800 border-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low': return 'bg-orange-100 text-orange-800 border-orange-300';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getLevelColor = (level) => {
    const colors = [
      'bg-purple-600',
      'bg-blue-600',
      'bg-green-600',
      'bg-yellow-600',
      'bg-gray-600'
    ];
    return colors[level - 1] || colors[4];
  };

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-purple-600" />
            IA - Générateur d'Organigramme Intelligent
          </CardTitle>
          <Button
            onClick={generateHierarchy}
            disabled={isLoading || employees.length === 0}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isLoading ? (
              <>
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                Analyse en cours...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Générer la hiérarchie
              </>
            )}
          </Button>
        </div>
        <p className="text-sm text-slate-600 mt-2">
          L'IA analyse les intitulés de poste et propose une structure hiérarchique logique
        </p>
      </CardHeader>

      {suggestions && (
        <CardContent className="p-6 space-y-6">
          {/* Statistiques */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <p className="text-xs text-purple-700 mb-1">Top niveau</p>
              <p className="text-2xl font-bold text-purple-900">{suggestions.statistics.suggested_top_level}</p>
            </div>
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-xs text-blue-700 mb-1">Managers</p>
              <p className="text-2xl font-bold text-blue-900">{suggestions.statistics.suggested_managers}</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <p className="text-xs text-green-700 mb-1">Taille équipe moy.</p>
              <p className="text-2xl font-bold text-green-900">{suggestions.statistics.average_team_size.toFixed(1)}</p>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-xs text-orange-700 mb-1">Départements</p>
              <p className="text-2xl font-bold text-orange-900">{suggestions.statistics.departments_analyzed}</p>
            </div>
          </div>

          {/* Insights stratégiques */}
          {suggestions.organization_insights.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-purple-600" />
                Insights Organisationnels
              </h4>
              <div className="space-y-2">
                {suggestions.organization_insights.map((insight, index) => (
                  <Alert key={index} className="bg-purple-50 border-purple-200">
                    <Zap className="w-4 h-4 text-purple-600" />
                    <AlertDescription className="ml-2 text-purple-900">
                      {insight}
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            </div>
          )}

          {/* Problèmes potentiels */}
          {suggestions.potential_issues && suggestions.potential_issues.length > 0 && (
            <div>
              <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                Points d'Attention
              </h4>
              <div className="space-y-3">
                {suggestions.potential_issues.map((issue, index) => (
                  <Card key={index} className="border-orange-200 bg-orange-50">
                    <CardContent className="p-4">
                      <p className="font-semibold text-orange-900 mb-2">{issue.issue}</p>
                      <p className="text-sm text-orange-800 mb-2">
                        <strong>Concerné(s):</strong> {issue.affected_employees.join(', ')}
                      </p>
                      <p className="text-sm text-orange-700">
                        <strong>Recommandation:</strong> {issue.recommendation}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Actions de sélection */}
          <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg border border-slate-200">
            <div>
              <p className="font-semibold text-slate-900">
                {selectedChanges.size} suggestion{selectedChanges.size > 1 ? 's' : ''} sélectionnée{selectedChanges.size > 1 ? 's' : ''}
              </p>
              <p className="text-sm text-slate-600">
                Choisissez les modifications à appliquer
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={selectAll}>
                Tout sélectionner
              </Button>
              <Button variant="outline" size="sm" onClick={deselectAll}>
                Tout désélectionner
              </Button>
            </div>
          </div>

          {/* Suggestions hiérarchiques */}
          <div>
            <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Network className="w-5 h-5 text-blue-600" />
              Suggestions Hiérarchiques ({suggestions.hierarchy.length})
            </h4>
            <div className="space-y-3 max-h-[600px] overflow-y-auto">
              {suggestions.hierarchy.map((suggestion, index) => {
                const isSelected = selectedChanges.has(suggestion.employee_email);
                const employee = employees.find(e => e.email === suggestion.employee_email);
                const currentManager = employee?.manager_name;
                const hasChange = currentManager !== suggestion.suggested_manager_name;

                return (
                  <Card 
                    key={index} 
                    className={`border-2 transition-all cursor-pointer ${
                      isSelected 
                        ? 'border-purple-400 bg-purple-50' 
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                    onClick={() => toggleSelection(suggestion.employee_email)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        {/* Checkbox visuel */}
                        <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 mt-1 ${
                          isSelected 
                            ? 'bg-purple-600 border-purple-600' 
                            : 'border-slate-300'
                        }`}>
                          {isSelected && <Check className="w-3 h-3 text-white" />}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <h5 className="font-bold text-slate-900">{suggestion.employee_name}</h5>
                            <Badge className={getConfidenceColor(suggestion.confidence)}>
                              {suggestion.confidence === 'high' ? '✅ Haute confiance' :
                               suggestion.confidence === 'medium' ? '⚠️ Confiance moyenne' :
                               '⚡ Faible confiance'}
                            </Badge>
                            <Badge className={`${getLevelColor(suggestion.level)} text-white`}>
                              Niveau {suggestion.level}
                            </Badge>
                            {hasChange && (
                              <Badge className="bg-orange-100 text-orange-800">
                                ⚡ Changement
                              </Badge>
                            )}
                          </div>

                          {/* Manager suggéré */}
                          <div className="mb-2">
                            {suggestion.suggested_manager_name ? (
                              <div className="flex items-center gap-2 text-sm">
                                <span className="text-slate-600">Manager suggéré:</span>
                                <span className="font-semibold text-blue-600">
                                  {suggestion.suggested_manager_name}
                                </span>
                              </div>
                            ) : (
                              <div className="text-sm text-purple-600 font-medium">
                                🔝 Suggéré au top niveau (sans manager)
                              </div>
                            )}
                          </div>

                          {/* Manager actuel si différent */}
                          {hasChange && currentManager && (
                            <div className="mb-2 p-2 bg-orange-50 rounded border border-orange-200">
                              <p className="text-xs text-orange-700">
                                <strong>Manager actuel:</strong> {currentManager}
                              </p>
                            </div>
                          )}

                          {/* Raisonnement */}
                          <div className="p-3 bg-slate-50 rounded text-sm text-slate-700">
                            <p className="font-medium text-slate-900 mb-1">💡 Raisonnement:</p>
                            <p>{suggestion.reasoning}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Bouton d'application */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => {
                setSuggestions(null);
                setSelectedChanges(new Set());
              }}
            >
              Annuler
            </Button>
            <Button
              onClick={applyChanges}
              disabled={selectedChanges.size === 0}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Check className="w-4 h-4 mr-2" />
              Appliquer {selectedChanges.size} suggestion{selectedChanges.size > 1 ? 's' : ''}
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
