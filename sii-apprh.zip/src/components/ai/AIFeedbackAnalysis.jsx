import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Sparkles, TrendingUp, AlertTriangle, CheckCircle, Target } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AIFeedbackAnalysis({ feedbacks, employees }) {
  const [selectedEmployee, setSelectedEmployee] = useState("all");
  const [analysis, setAnalysis] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const { toast } = useToast();

  const analyzeFeedbacks = async () => {
    setIsAnalyzing(true);
    try {
      const filteredFeedbacks = selectedEmployee === "all"
        ? feedbacks
        : feedbacks.filter(f => f.receiver_email === selectedEmployee);

      if (filteredFeedbacks.length === 0) {
        toast({
          title: "Pas de données",
          description: "Aucun feedback à analyser",
          variant: "destructive",
        });
        setIsAnalyzing(false);
        return;
      }

      const employeeName = selectedEmployee === "all" 
        ? "Toute l'équipe"
        : employees.find(e => e.email === selectedEmployee)?.full_name || selectedEmployee;

      const prompt = `Tu es un expert en analyse RH. Analyse ces feedbacks continus et fournis des insights actionnables.

SCOPE: ${employeeName}
NOMBRE DE FEEDBACKS: ${filteredFeedbacks.length}

FEEDBACKS À ANALYSER:
${filteredFeedbacks.map((f, i) => `
${i + 1}. ${f.feedback_type.toUpperCase()} - ${f.category}
De: ${f.is_anonymous ? 'Anonyme' : f.giver_name}
À: ${f.receiver_name}
Contenu: ${f.content}
Contexte: ${f.context || 'N/A'}
Impact: ${f.impact_level}
Date: ${f.created_date}
`).join('\n---\n')}

Fournis une analyse complète et des recommandations.`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            resume_global: {
              type: "object",
              properties: {
                total_feedbacks: { type: "number" },
                sentiment_general: { type: "string" },
                themes_recurrents: {
                  type: "array",
                  items: { type: "string" }
                }
              }
            },
            tendances_positives: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  theme: { type: "string" },
                  description: { type: "string" },
                  frequence: { type: "number" },
                  exemples: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            },
            zones_amelioration: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  theme: { type: "string" },
                  description: { type: "string" },
                  priorite: { type: "string" },
                  actions_suggerees: {
                    type: "array",
                    items: { type: "string" }
                  }
                }
              }
            },
            competences_fortes: {
              type: "array",
              items: { type: "string" }
            },
            competences_a_developper: {
              type: "array",
              items: { type: "string" }
            },
            recommandations_manager: {
              type: "array",
              items: { type: "string" }
            },
            points_discussion_evaluation: {
              type: "array",
              items: { type: "string" }
            },
            risques_identifies: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risque: { type: "string" },
                  niveau: { type: "string" },
                  action_immediate: { type: "string" }
                }
              }
            },
            evolution_sentiment: {
              type: "object",
              properties: {
                tendance: { type: "string" },
                explication: { type: "string" }
              }
            }
          }
        }
      });

      setAnalysis(result);

      toast({
        title: "Analyse terminée ✨",
        description: `${filteredFeedbacks.length} feedbacks analysés`,
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur analyse:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'analyser les feedbacks",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-purple-200 bg-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-4">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <div className="flex-1">
              <h3 className="font-semibold text-purple-900 mb-1">
                Analyse IA des Feedbacks Continus
              </h3>
              <p className="text-sm text-purple-700">
                L'IA identifie les tendances, forces et zones d'amélioration
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-[300px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toute l'équipe</SelectItem>
                {employees.map(e => (
                  <SelectItem key={e.id} value={e.email}>
                    {e.full_name} - {e.position}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              onClick={analyzeFeedbacks}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyse...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyser les feedbacks
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {analysis && (
        <>
          {/* Résumé */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                📊 Résumé Global
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="p-4 bg-white rounded-lg">
                  <p className="text-sm text-blue-700 mb-1">Total feedbacks</p>
                  <p className="text-3xl font-bold text-blue-900">{analysis.resume_global.total_feedbacks}</p>
                </div>
                <div className="p-4 bg-white rounded-lg">
                  <p className="text-sm text-blue-700 mb-1">Sentiment général</p>
                  <p className="text-xl font-bold text-blue-900">{analysis.resume_global.sentiment_general}</p>
                </div>
                <div className="p-4 bg-white rounded-lg">
                  <p className="text-sm text-blue-700 mb-1">Thèmes récurrents</p>
                  <p className="text-xl font-bold text-blue-900">{analysis.resume_global.themes_recurrents.length}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {analysis.resume_global.themes_recurrents.map((theme, i) => (
                  <Badge key={i} className="bg-blue-600">{theme}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Évolution du sentiment */}
          {analysis.evolution_sentiment && (
            <Card className="border-indigo-200 bg-indigo-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-indigo-900">
                  <TrendingUp className="w-5 h-5" />
                  Évolution du Sentiment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="p-4 bg-white rounded-lg">
                  <p className="font-semibold text-indigo-900 mb-2">
                    Tendance: {analysis.evolution_sentiment.tendance}
                  </p>
                  <p className="text-sm text-indigo-800">{analysis.evolution_sentiment.explication}</p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Tendances positives */}
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-green-900">
                <CheckCircle className="w-5 h-5" />
                Tendances Positives
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {analysis.tendances_positives.map((trend, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-green-200">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-green-900">{trend.theme}</h4>
                    <Badge className="bg-green-600">
                      {trend.frequence} mention{trend.frequence > 1 ? 's' : ''}
                    </Badge>
                  </div>
                  <p className="text-sm text-green-800 mb-3">{trend.description}</p>
                  {trend.exemples.length > 0 && (
                    <div className="space-y-1">
                      <p className="text-xs font-medium text-green-700">Exemples:</p>
                      {trend.exemples.map((ex, j) => (
                        <p key={j} className="text-xs text-green-700 italic">• {ex}</p>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Zones d'amélioration */}
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-900">
                <Target className="w-5 h-5" />
                Zones d'Amélioration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {analysis.zones_amelioration.map((zone, i) => (
                <div key={i} className="p-4 bg-white rounded-lg border border-orange-200">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-bold text-orange-900">{zone.theme}</h4>
                    <Badge className={
                      zone.priorite === 'haute' ? 'bg-red-600' :
                      zone.priorite === 'moyenne' ? 'bg-orange-600' :
                      'bg-yellow-600'
                    }>
                      Priorité {zone.priorite}
                    </Badge>
                  </div>
                  <p className="text-sm text-orange-800 mb-3">{zone.description}</p>
                  <div className="p-3 bg-orange-50 rounded">
                    <p className="text-xs font-medium text-orange-700 mb-2">Actions suggérées:</p>
                    <ul className="space-y-1">
                      {zone.actions_suggerees.map((action, j) => (
                        <li key={j} className="text-xs text-orange-800">✓ {action}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Risques */}
          {analysis.risques_identifies.length > 0 && (
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-900">
                  <AlertTriangle className="w-5 h-5" />
                  Risques Identifiés
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {analysis.risques_identifies.map((risque, i) => (
                  <div key={i} className="p-4 bg-white rounded-lg border-2 border-red-300">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-bold text-red-900">{risque.risque}</h4>
                      <Badge className={
                        risque.niveau === 'critique' ? 'bg-red-600' :
                        risque.niveau === 'élevé' ? 'bg-orange-600' :
                        'bg-yellow-600'
                      }>
                        {risque.niveau}
                      </Badge>
                    </div>
                    <div className="p-3 bg-red-50 rounded">
                      <p className="text-xs font-medium text-red-700 mb-1">⚡ Action immédiate:</p>
                      <p className="text-sm text-red-800">{risque.action_immediate}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Compétences */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-green-900">✅ Compétences Fortes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {analysis.competences_fortes.map((comp, i) => (
                    <Badge key={i} className="bg-green-600">{comp}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-orange-900">📈 À Développer</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {analysis.competences_a_developper.map((comp, i) => (
                    <Badge key={i} className="bg-orange-600">{comp}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Points de discussion */}
          <Card className="border-purple-200 bg-purple-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-900">
                💬 Points pour l'Évaluation Annuelle
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {analysis.points_discussion_evaluation.map((point, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-purple-200">
                  <p className="text-sm text-purple-900">{i + 1}. {point}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Recommandations manager */}
          <Card className="border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900">
                💡 Recommandations pour le Manager
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {analysis.recommandations_manager.map((rec, i) => (
                <div key={i} className="p-3 bg-white rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-900">{rec}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}