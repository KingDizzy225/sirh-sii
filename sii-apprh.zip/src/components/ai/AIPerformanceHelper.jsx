import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Target, TrendingUp, Lightbulb, Zap } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function AIPerformanceHelper({ type = "goals", employeeData }) {
  const [input, setInput] = useState("");
  const [suggestions, setSuggestions] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const generateSuggestions = async () => {
    if (!input.trim() && type !== 'feedback') return;
    
    setIsLoading(true);
    try {
      let prompt = "";
      let schema = {};

      if (type === "goals") {
        prompt = `En tant qu'expert en gestion de la performance, génère 3 objectifs SMART (Spécifiques, Mesurables, Atteignables, Réalistes, Temporels) basés sur ce contexte:

Employé: ${employeeData?.name || 'Employé'}
Poste: ${employeeData?.position || 'Non spécifié'}
Département: ${employeeData?.department || 'Non spécifié'}
Contexte: ${input}

Fournis 3 objectifs SMART structurés.`;

        schema = {
          type: "object",
          properties: {
            goals: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  title: { type: "string" },
                  description: { type: "string" },
                  category: { type: "string" },
                  timeline: { type: "string" },
                  measurementCriteria: { type: "string" }
                }
              }
            }
          }
        };
      } else if (type === "feedback") {
        prompt = `En tant qu'expert RH, analyse ces performances et fournis des recommandations d'amélioration constructives:

Employé: ${employeeData?.name || 'Employé'}
Performance actuelle: ${employeeData?.performanceRating || 'Non évalué'}/5
Points forts: ${employeeData?.strengths || 'Non spécifié'}
Domaines d'amélioration: ${employeeData?.weaknesses || 'Non spécifié'}
${input ? `Contexte additionnel: ${input}` : ''}

Fournis des recommandations actionnables et bienveillantes.`;

        schema = {
          type: "object",
          properties: {
            overallAssessment: { type: "string" },
            recommendations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  area: { type: "string" },
                  suggestion: { type: "string" },
                  expectedImpact: { type: "string" },
                  priority: { type: "string" }
                }
              }
            },
            developmentPlan: { type: "string" }
          }
        };
      } else if (type === "review") {
        prompt = `En tant qu'expert en évaluation des performances, aide à rédiger une évaluation constructive basée sur:

Employé: ${employeeData?.name || 'Employé'}
Poste: ${employeeData?.position || 'Non spécifié'}
Période: ${employeeData?.period || 'Dernière période'}
Réalisations: ${input}

Fournis une évaluation équilibrée avec points forts et axes d'amélioration.`;

        schema = {
          type: "object",
          properties: {
            summary: { type: "string" },
            strengths: { type: "array", items: { type: "string" } },
            improvements: { type: "array", items: { type: "string" } },
            suggestedRating: { type: "number" },
            nextSteps: { type: "array", items: { type: "string" } }
          }
        };
      }

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: schema
      });

      setSuggestions(response);
    } catch (error) {
      console.error("Erreur suggestions IA:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getTypeConfig = () => {
    switch (type) {
      case 'goals':
        return {
          title: "Générateur d'Objectifs SMART",
          icon: <Target className="w-5 h-5 text-purple-600" />,
          placeholder: "Décrivez le contexte, les aspirations de l'employé, ou les objectifs du département...",
          buttonText: "Générer des objectifs SMART"
        };
      case 'feedback':
        return {
          title: "Assistant Feedback & Recommandations",
          icon: <TrendingUp className="w-5 h-5 text-blue-600" />,
          placeholder: "Contexte additionnel (optionnel)...",
          buttonText: "Générer des recommandations"
        };
      case 'review':
        return {
          title: "Assistant Rédaction d'Évaluation",
          icon: <Lightbulb className="w-5 h-5 text-orange-600" />,
          placeholder: "Décrivez les réalisations, projets menés, compétences démontrées...",
          buttonText: "Générer l'évaluation"
        };
      default:
        return {};
    }
  };

  const config = getTypeConfig();

  return (
    <Card className="border-2 border-purple-200 shadow-lg">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
        <CardTitle className="flex items-center gap-2">
          {config.icon}
          {config.title}
        </CardTitle>
      </CardHeader>

      <CardContent className="p-6 space-y-4">
        <div className="space-y-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={config.placeholder}
            rows={4}
            className="resize-none"
          />
        </div>

        <Button
          onClick={generateSuggestions}
          disabled={isLoading || (!input.trim() && type !== 'feedback')}
          className="w-full bg-purple-600 hover:bg-purple-700"
        >
          {isLoading ? (
            <>
              <Zap className="w-4 h-4 mr-2 animate-pulse" />
              Génération en cours...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              {config.buttonText}
            </>
          )}
        </Button>

        {/* Résultats - Objectifs SMART */}
        {suggestions && type === "goals" && (
          <div className="space-y-4 mt-6">
            <h4 className="font-semibold text-slate-900">Objectifs SMART générés:</h4>
            {suggestions.goals.map((goal, index) => (
              <Card key={index} className="border-2 border-green-200">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-bold text-slate-900">{goal.title}</h5>
                    <Badge className="bg-green-600">{goal.category}</Badge>
                  </div>
                  <p className="text-sm text-slate-700 mb-2">{goal.description}</p>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 bg-slate-50 rounded">
                      <p className="font-medium text-slate-600">Timeline</p>
                      <p className="text-slate-900">{goal.timeline}</p>
                    </div>
                    <div className="p-2 bg-slate-50 rounded">
                      <p className="font-medium text-slate-600">Mesure</p>
                      <p className="text-slate-900">{goal.measurementCriteria}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Résultats - Feedback */}
        {suggestions && type === "feedback" && (
          <div className="space-y-4 mt-6">
            <div className="p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
              <h4 className="font-semibold text-blue-900 mb-2">Évaluation Globale</h4>
              <p className="text-sm text-blue-800">{suggestions.overallAssessment}</p>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-3">Recommandations:</h4>
              <div className="space-y-3">
                {suggestions.recommendations.map((rec, index) => (
                  <Card key={index} className="border-2">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h5 className="font-bold text-slate-900">{rec.area}</h5>
                        <Badge className={
                          rec.priority === 'high' ? 'bg-red-600' :
                          rec.priority === 'medium' ? 'bg-orange-600' :
                          'bg-blue-600'
                        }>
                          {rec.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-700 mb-2">{rec.suggestion}</p>
                      <p className="text-xs text-green-700 bg-green-50 p-2 rounded">
                        <strong>Impact attendu:</strong> {rec.expectedImpact}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="p-4 bg-green-50 rounded-lg border-2 border-green-200">
              <h4 className="font-semibold text-green-900 mb-2">Plan de Développement</h4>
              <p className="text-sm text-green-800">{suggestions.developmentPlan}</p>
            </div>
          </div>
        )}

        {/* Résultats - Évaluation */}
        {suggestions && type === "review" && (
          <div className="space-y-4 mt-6">
            <div className="p-4 bg-purple-50 rounded-lg border-2 border-purple-200">
              <h4 className="font-semibold text-purple-900 mb-2">Résumé de l'évaluation</h4>
              <p className="text-sm text-purple-800">{suggestions.summary}</p>
            </div>

            <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
              <span className="font-semibold text-blue-900">Note suggérée</span>
              <Badge className="bg-blue-600 text-2xl py-2 px-4">
                {suggestions.suggestedRating}/5 ⭐
              </Badge>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Points forts identifiés:</h4>
              <div className="space-y-2">
                {suggestions.strengths.map((strength, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-green-50 rounded-lg border border-green-200">
                    <span className="text-green-600 font-bold">✓</span>
                    <p className="text-sm text-green-900">{strength}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Axes d'amélioration:</h4>
              <div className="space-y-2">
                {suggestions.improvements.map((improvement, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
                    <span className="text-orange-600 font-bold">→</span>
                    <p className="text-sm text-orange-900">{improvement}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Prochaines étapes recommandées:</h4>
              <div className="space-y-2">
                {suggestions.nextSteps.map((step, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="text-blue-600 font-bold">{index + 1}.</span>
                    <p className="text-sm text-blue-900">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}