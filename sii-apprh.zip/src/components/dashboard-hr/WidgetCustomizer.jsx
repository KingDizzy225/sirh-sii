import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  Clock, 
  Network, 
  Users, 
  DollarSign, 
  Users as UsersIcon,
  Building2,
  Award,
  RefreshCw
} from "lucide-react";

const WIDGETS = [
  { id: 'turnover', name: 'Taux de Roulement', icon: TrendingUp, description: 'Analyse des départs sur 12 mois' },
  { id: 'timeToHire', name: 'Temps d\'Embauche', icon: Clock, description: 'Délai moyen de recrutement' },
  { id: 'lineStaff', name: 'Répartition Line/Staff', icon: Network, description: 'Distribution des postes' },
  { id: 'diversity', name: 'Diversité des Équipes', icon: Users, description: 'Genre, âge, nationalité' },
  { id: 'costPerHire', name: 'Coût par Embauche', icon: DollarSign, description: 'Estimation détaillée' },
  { id: 'headcount', name: 'Évolution Effectifs', icon: UsersIcon, description: 'Tendance sur 12 mois' },
  { id: 'departments', name: 'Départements', icon: Building2, description: 'Répartition départementale' },
  { id: 'performance', name: 'Performance', icon: Award, description: 'Aperçu des évaluations' },
];

export default function WidgetCustomizer({ isOpen, onClose, visibleWidgets, onToggleWidget, onReset }) {
  const visibleCount = Object.values(visibleWidgets).filter(Boolean).length;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl">Personnaliser les widgets</DialogTitle>
          <p className="text-sm text-slate-600 mt-1">
            Choisissez les indicateurs à afficher sur votre tableau de bord
          </p>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
            <div>
              <p className="text-sm font-medium text-blue-900">
                {visibleCount} widget{visibleCount > 1 ? 's' : ''} affiché{visibleCount > 1 ? 's' : ''}
              </p>
              <p className="text-xs text-blue-700">
                {8 - visibleCount} masqué{8 - visibleCount > 1 ? 's' : ''}
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={onReset}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Réinitialiser
            </Button>
          </div>

          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {WIDGETS.map(widget => {
              const Icon = widget.icon;
              const isVisible = visibleWidgets[widget.id];

              return (
                <div 
                  key={widget.id}
                  className={`flex items-center justify-between p-4 rounded-lg border-2 transition-all ${
                    isVisible 
                      ? 'border-blue-300 bg-blue-50' 
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isVisible ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                    }`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">{widget.name}</h4>
                        {isVisible && (
                          <Badge className="bg-blue-600 text-xs">Actif</Badge>
                        )}
                      </div>
                      <p className="text-xs text-slate-600">{widget.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={isVisible}
                    onCheckedChange={() => onToggleWidget(widget.id)}
                  />
                </div>
              );
            })}
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Fermer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}