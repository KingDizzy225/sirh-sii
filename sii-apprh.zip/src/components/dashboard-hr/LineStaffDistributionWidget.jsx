import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Network, Users } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

export default function LineStaffDistributionWidget({ employees = [] }) {
  const lineEmployees = employees.filter(e => e.position_type === 'line' && e.status === 'active');
  const staffEmployees = employees.filter(e => e.position_type === 'staff' && e.status === 'active');
  const unspecified = employees.filter(e => !e.position_type && e.status === 'active');

  const data = [
    { name: 'Line (Hiérarchique)', value: lineEmployees.length, color: '#3b82f6' },
    { name: 'Staff (Conseil)', value: staffEmployees.length, color: '#8b5cf6' },
  ];

  if (unspecified.length > 0) {
    data.push({ name: 'Non spécifié', value: unspecified.length, color: '#94a3b8' });
  }

  const total = lineEmployees.length + staffEmployees.length + unspecified.length;
  const linePercentage = total > 0 ? ((lineEmployees.length / total) * 100).toFixed(1) : 0;
  const staffPercentage = total > 0 ? ((staffEmployees.length / total) * 100).toFixed(1) : 0;

  // Ratio line/staff optimal est généralement 4:1 à 7:1
  const ratio = staffEmployees.length > 0 ? (lineEmployees.length / staffEmployees.length).toFixed(1) : 'N/A';
  const isBalanced = ratio >= 4 && ratio <= 7;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <CardTitle className="flex items-center gap-2">
          <Network className="w-5 h-5 text-purple-600" />
          Répartition Line / Staff
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-4">
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend 
                verticalAlign="bottom" 
                height={36}
                formatter={(value, entry) => `${value}: ${entry.payload.value}`}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
              <span className="text-sm font-medium text-slate-900">Line (Hiérarchique)</span>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-blue-900">{lineEmployees.length}</p>
              <p className="text-xs text-blue-700">{linePercentage}%</p>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-purple-600 rounded-full"></div>
              <span className="text-sm font-medium text-slate-900">Staff (Conseil)</span>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-purple-900">{staffEmployees.length}</p>
              <p className="text-xs text-purple-700">{staffPercentage}%</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-slate-600">Ratio Line:Staff</span>
              <span className="text-lg font-bold text-slate-900">{ratio}:1</span>
            </div>
            <div className={`text-xs ${isBalanced ? 'text-green-600' : 'text-orange-600'}`}>
              {isBalanced ? '✓ Ratio équilibré (4:1 à 7:1)' : '⚠️ Ratio à rééquilibrer'}
            </div>
          </div>

          {unspecified.length > 0 && (
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="text-sm text-orange-800">
                ⚠️ <strong>{unspecified.length} employé(s)</strong> sans type de poste spécifié
              </p>
            </div>
          )}

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-xs text-blue-700 leading-relaxed">
              <strong>Line:</strong> Postes hiérarchiques avec autorité directe<br/>
              <strong>Staff:</strong> Postes de conseil/expertise sans autorité hiérarchique
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}