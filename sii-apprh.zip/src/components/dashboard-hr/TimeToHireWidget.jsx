import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { differenceInDays } from "date-fns";

export default function TimeToHireWidget({ candidates = [], jobPostings = [] }) {
  // Candidats embauchés
  const hiredCandidates = candidates.filter(c => c.status === 'hired');

  // Calculer le temps moyen d'embauche
  const timeToHireData = hiredCandidates
    .filter(c => c.application_date)
    .map(c => {
      const appDate = new Date(c.application_date);
      const hireDate = c.updated_date ? new Date(c.updated_date) : new Date();
      return differenceInDays(hireDate, appDate);
    });

  const avgTimeToHire = timeToHireData.length > 0
    ? Math.round(timeToHireData.reduce((sum, days) => sum + days, 0) / timeToHireData.length)
    : 0;

  // Temps min et max
  const minTime = timeToHireData.length > 0 ? Math.min(...timeToHireData) : 0;
  const maxTime = timeToHireData.length > 0 ? Math.max(...timeToHireData) : 0;

  // Pipeline actuel
  const activeCandidates = candidates.filter(c => 
    c.status !== 'rejected' && c.status !== 'hired'
  ).length;

  const candidatesInInterview = candidates.filter(c => c.status === 'interview').length;
  const candidatesWithOffer = candidates.filter(c => c.status === 'offer').length;

  // Benchmark (moyenne industrie ~ 42 jours)
  const industryBenchmark = 42;
  const performanceVsBenchmark = avgTimeToHire - industryBenchmark;
  const isGood = avgTimeToHire <= industryBenchmark;

  // Postes ouverts
  const openPositions = jobPostings.filter(j => j.status === 'active').length;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            Temps d'Embauche
          </CardTitle>
          <Badge className={isGood ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
            {isGood ? 'Performant' : 'À améliorer'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-4xl font-bold text-slate-900">{avgTimeToHire}</span>
            <span className="text-sm text-slate-600">jours en moyenne</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm mb-4">
            {isGood ? (
              <span className="text-green-600 font-medium">
                ⚡ {Math.abs(performanceVsBenchmark)} jours plus rapide que la moyenne
              </span>
            ) : (
              <span className="text-orange-600 font-medium">
                {Math.abs(performanceVsBenchmark)} jours plus lent que la moyenne
              </span>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="p-3 bg-blue-50 rounded-lg text-center">
              <p className="text-xs text-blue-700 mb-1">Min</p>
              <p className="text-lg font-semibold text-blue-900">{minTime}j</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg text-center">
              <p className="text-xs text-purple-700 mb-1">Moy.</p>
              <p className="text-lg font-semibold text-purple-900">{avgTimeToHire}j</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg text-center">
              <p className="text-xs text-orange-700 mb-1">Max</p>
              <p className="text-lg font-semibold text-orange-900">{maxTime}j</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="border-t pt-4">
            <h4 className="text-sm font-semibold text-slate-900 mb-3">Pipeline actuel</h4>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="text-sm text-slate-600">Postes ouverts</span>
                <Badge variant="outline">{openPositions}</Badge>
              </div>
              
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="text-sm text-slate-600">Candidats actifs</span>
                <Badge className="bg-blue-100 text-blue-800">{activeCandidates}</Badge>
              </div>
              
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="text-sm text-slate-600">En entretien</span>
                <Badge className="bg-purple-100 text-purple-800">{candidatesInInterview}</Badge>
              </div>
              
              <div className="flex items-center justify-between p-2 bg-slate-50 rounded">
                <span className="text-sm text-slate-600">Offres envoyées</span>
                <Badge className="bg-green-100 text-green-800">{candidatesWithOffer}</Badge>
              </div>
            </div>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-xs text-blue-700">
              💡 <strong>Benchmark industrie:</strong> {industryBenchmark} jours en moyenne
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}