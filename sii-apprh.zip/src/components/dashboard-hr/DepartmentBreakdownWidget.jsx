import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

export default function DepartmentBreakdownWidget({ employees = [], departments = [] }) {
  const activeEmployees = employees.filter(e => e.status === 'active');

  // Calculer la répartition par département
  const deptData = departments
    .map(dept => {
      const deptEmployees = activeEmployees.filter(e => e.department === dept.name);
      return {
        name: dept.name,
        count: deptEmployees.length,
        percentage: activeEmployees.length > 0 
          ? ((deptEmployees.length / activeEmployees.length) * 100).toFixed(1)
          : 0
      };
    })
    .filter(d => d.count > 0)
    .sort((a, b) => b.count - a.count);

  const largestDept = deptData[0];
  const smallestDept = deptData[deptData.length - 1];
  const avgSize = deptData.length > 0
    ? Math.round(deptData.reduce((sum, d) => sum + d.count, 0) / deptData.length)
    : 0;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-indigo-600" />
          Répartition Départementale
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-4">
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div className="p-3 bg-blue-50 rounded-lg text-center">
              <p className="text-xs text-blue-700 mb-1">Plus grand</p>
              <p className="text-lg font-semibold text-blue-900">{largestDept?.count || 0}</p>
              <p className="text-xs text-blue-600 truncate">{largestDept?.name}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg text-center">
              <p className="text-xs text-purple-700 mb-1">Moyenne</p>
              <p className="text-lg font-semibold text-purple-900">{avgSize}</p>
              <p className="text-xs text-purple-600">par dépt.</p>
            </div>
            <div className="p-3 bg-green-50 rounded-lg text-center">
              <p className="text-xs text-green-700 mb-1">Plus petit</p>
              <p className="text-lg font-semibold text-green-900">{smallestDept?.count || 0}</p>
              <p className="text-xs text-green-600 truncate">{smallestDept?.name}</p>
            </div>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={250}>
          <BarChart 
            data={deptData} 
            layout="vertical"
            margin={{ top: 5, right: 30, left: 100, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis type="number" stroke="#64748b" fontSize={12} />
            <YAxis 
              dataKey="name" 
              type="category" 
              stroke="#64748b" 
              fontSize={11}
              width={90}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0',
                borderRadius: '8px'
              }}
              formatter={(value, name, props) => [
                `${value} (${props.payload.percentage}%)`, 
                'Employés'
              ]}
            />
            <Bar dataKey="count" radius={[0, 8, 8, 0]}>
              {deptData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        <div className="mt-4 space-y-2">
          <h4 className="text-sm font-semibold text-slate-900">Top départements</h4>
          {deptData.slice(0, 5).map((dept, idx) => (
            <div key={dept.name} className="flex items-center justify-between p-2 bg-slate-50 rounded">
              <div className="flex items-center gap-3">
                <div 
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                />
                <span className="text-sm text-slate-700">{dept.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-slate-900">{dept.count}</span>
                <span className="text-xs text-slate-500">({dept.percentage}%)</span>
              </div>
            </div>
          ))}
        </div>

        {deptData.length > 5 && (
          <p className="text-xs text-slate-500 mt-2 text-center">
            +{deptData.length - 5} autres départements
          </p>
        )}
      </CardContent>
    </Card>
  );
}