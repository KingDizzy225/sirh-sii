import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Award, Star, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function PerformanceOverviewWidget({ reviews = [], employees = [] }) {
  if (!reviews || reviews.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b">
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-600" />
            Aperçu Performance
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="text-center py-8 text-slate-500">
            <Award className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-sm">Aucune évaluation disponible</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculs de performance
  const avgOverall = (reviews.reduce((sum, r) => sum + (r.overall_rating || 0), 0) / reviews.length).toFixed(1);
  const avgTechnical = (reviews.reduce((sum, r) => sum + (r.technical_skills || 0), 0) / reviews.length).toFixed(1);
  const avgCommunication = (reviews.reduce((sum, r) => sum + (r.communication || 0), 0) / reviews.length).toFixed(1);
  const avgTeamwork = (reviews.reduce((sum, r) => sum + (r.teamwork || 0), 0) / reviews.length).toFixed(1);
  const avgLeadership = (reviews.reduce((sum, r) => sum + (r.leadership || 0), 0) / reviews.length).toFixed(1);

  // Top performers (rating >= 4.5)
  const topPerformers = reviews
    .filter(r => r.overall_rating >= 4.5)
    .map(r => ({
      name: r.employee_name,
      rating: r.overall_rating,
      period: r.review_period
    }))
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 5);

  // Répartition des notes
  const ratingDistribution = {
    excellent: reviews.filter(r => r.overall_rating >= 4.5).length,
    good: reviews.filter(r => r.overall_rating >= 3.5 && r.overall_rating < 4.5).length,
    average: reviews.filter(r => r.overall_rating >= 2.5 && r.overall_rating < 3.5).length,
    low: reviews.filter(r => r.overall_rating < 2.5).length,
  };

  const excellentPercentage = ((ratingDistribution.excellent / reviews.length) * 100).toFixed(0);
  const goodPercentage = ((ratingDistribution.good / reviews.length) * 100).toFixed(0);

  const performanceLevel = avgOverall >= 4.5 ? 'Excellent' :
                          avgOverall >= 3.5 ? 'Bon' :
                          avgOverall >= 2.5 ? 'Moyen' : 'À améliorer';

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-yellow-600" />
            Aperçu Performance
          </CardTitle>
          <Badge className={
            avgOverall >= 4.5 ? 'bg-green-100 text-green-800' :
            avgOverall >= 3.5 ? 'bg-blue-100 text-blue-800' :
            avgOverall >= 2.5 ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }>
            {performanceLevel}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-4xl font-bold text-slate-900">{avgOverall}</span>
            <span className="text-sm text-slate-600">/ 5 en moyenne</span>
          </div>
          
          <div className="flex items-center gap-2 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-5 h-5 ${
                  i < Math.round(avgOverall) ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'
                }`}
              />
            ))}
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3 bg-green-50 rounded-lg">
              <p className="text-xs text-green-700 mb-1">Excellent (≥4.5)</p>
              <p className="text-lg font-semibold text-green-900">
                {ratingDistribution.excellent} ({excellentPercentage}%)
              </p>
            </div>
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700 mb-1">Bon (3.5-4.4)</p>
              <p className="text-lg font-semibold text-blue-900">
                {ratingDistribution.good} ({goodPercentage}%)
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-slate-900">Moyennes par catégorie</h4>
          
          {[
            { label: 'Technique', value: avgTechnical, color: 'blue' },
            { label: 'Communication', value: avgCommunication, color: 'green' },
            { label: 'Travail d\'équipe', value: avgTeamwork, color: 'purple' },
            { label: 'Leadership', value: avgLeadership, color: 'orange' },
          ].map(({ label, value, color }) => (
            <div key={label} className="space-y-1">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">{label}</span>
                <span className="font-semibold text-slate-900">{value}/5</span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full bg-${color}-500`}
                  style={{ width: `${(value / 5) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {topPerformers.length > 0 && (
          <div className="mt-6 border-t pt-4">
            <h4 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-600" />
              Top Performers
            </h4>
            <div className="space-y-2">
              {topPerformers.map((performer, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 bg-gradient-to-r from-yellow-50 to-orange-50 rounded border border-yellow-200">
                  <div className="flex items-center gap-2">
                    <Badge className="bg-yellow-600">#{idx + 1}</Badge>
                    <span className="text-sm font-medium text-slate-900">{performer.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-yellow-700">{performer.rating.toFixed(1)}</span>
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-xs text-blue-700">
            📊 Basé sur {reviews.length} évaluation{reviews.length > 1 ? 's' : ''} de performance
          </p>
        </div>
      </CardContent>
    </Card>
  );
}