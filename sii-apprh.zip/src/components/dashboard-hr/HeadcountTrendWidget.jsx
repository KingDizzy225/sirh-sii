import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { Badge } from "@/components/ui/badge";
import { subMonths, format, endOfMonth } from "date-fns";
import { fr } from "date-fns/locale";

export default function HeadcountTrendWidget({ employees = [] }) {
  // Générer les 12 derniers mois
  const getLast12Months = () => {
    const months = [];
    for (let i = 11; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      months.push({
        month: format(date, 'MMM yy', { locale: fr }),
        fullDate: date,
        endOfMonth: endOfMonth(date)
      });
    }
    return months;
  };

  const last12Months = getLast12Months();

  // Calculer l'effectif pour chaque mois
  const headcountData = last12Months.map(({ month, endOfMonth }) => {
    const activeAtDate = employees.filter(emp => {
      const hireDate = emp.hire_date ? new Date(emp.hire_date) : null;
      if (!hireDate || hireDate > endOfMonth) return false;
      
      // Si terminated, vérifier la date de départ (approximation via updated_date)
      if (emp.status === 'terminated') {
        const departureDate = emp.updated_date ? new Date(emp.updated_date) : new Date();
        return departureDate > endOfMonth;
      }
      
      return true;
    }).length;

    return {
      month,
      count: activeAtDate
    };
  });

  const currentHeadcount = headcountData[headcountData.length - 1].count;
  const previousMonthHeadcount = headcountData[headcountData.length - 2].count;
  const yearAgoHeadcount = headcountData[0].count;

  const monthChange = currentHeadcount - previousMonthHeadcount;
  const yearChange = currentHeadcount - yearAgoHeadcount;
  const yearChangePercent = yearAgoHeadcount > 0 
    ? ((yearChange / yearAgoHeadcount) * 100).toFixed(1)
    : 0;

  const isGrowing = monthChange > 0;
  const growthRate = previousMonthHeadcount > 0
    ? ((monthChange / previousMonthHeadcount) * 100).toFixed(1)
    : 0;

  // Calcul de la tendance
  const avgGrowth = headcountData.length > 1
    ? headcountData.reduce((sum, item, idx) => {
        if (idx === 0) return 0;
        return sum + (item.count - headcountData[idx - 1].count);
      }, 0) / (headcountData.length - 1)
    : 0;

  const trendLabel = avgGrowth > 1 ? 'Forte croissance' :
                     avgGrowth > 0 ? 'Croissance' :
                     avgGrowth > -1 ? 'Stable' :
                     'Décroissance';

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            Évolution des Effectifs
          </CardTitle>
          <Badge className={
            avgGrowth > 0 ? 'bg-green-100 text-green-800' :
            avgGrowth < 0 ? 'bg-red-100 text-red-800' :
            'bg-slate-100 text-slate-800'
          }>
            {trendLabel}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-4xl font-bold text-slate-900">{currentHeadcount}</span>
            <span className="text-sm text-slate-600">employés actuellement</span>
          </div>
          
          <div className="flex items-center gap-4 text-sm">
            <div className={`flex items-center gap-1 ${isGrowing ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className={`w-4 h-4 ${!isGrowing && 'rotate-180'}`} />
              <span className="font-medium">{Math.abs(monthChange)}</span>
              <span className="text-slate-600">vs mois dernier ({growthRate}%)</span>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700 mb-1">Il y a 12 mois</p>
              <p className="text-lg font-semibold text-blue-900">{yearAgoHeadcount}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <p className="text-xs text-purple-700 mb-1">Croissance annuelle</p>
              <p className="text-lg font-semibold text-purple-900">
                {yearChange > 0 && '+'}{yearChange} ({yearChangePercent}%)
              </p>
            </div>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={headcountData}>
            <defs>
              <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="month" 
              stroke="#64748b" 
              fontSize={11}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis stroke="#64748b" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0',
                borderRadius: '8px'
              }}
              formatter={(value) => [value, 'Effectif']}
            />
            <Area
              type="monotone"
              dataKey="count"
              stroke="#3b82f6"
              strokeWidth={3}
              fill="url(#colorCount)"
            />
          </AreaChart>
        </ResponsiveContainer>

        <div className="mt-4 p-3 bg-slate-50 rounded-lg">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-xs text-slate-600 mb-1">Min (12m)</p>
              <p className="text-sm font-semibold text-slate-900">
                {Math.min(...headcountData.map(d => d.count))}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-600 mb-1">Moyenne</p>
              <p className="text-sm font-semibold text-slate-900">
                {Math.round(headcountData.reduce((sum, d) => sum + d.count, 0) / headcountData.length)}
              </p>
            </div>
            <div>
              <p className="text-xs text-slate-600 mb-1">Max (12m)</p>
              <p className="text-sm font-semibold text-slate-900">
                {Math.max(...headcountData.map(d => d.count))}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}