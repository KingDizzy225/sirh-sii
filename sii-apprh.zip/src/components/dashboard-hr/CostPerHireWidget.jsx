import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function CostPerHireWidget({ candidates = [], employees = [] }) {
  // Estimation du coût par embauche (approximation)
  const hiredCandidates = candidates.filter(c => c.status === 'hired');
  
  // Coûts estimés
  const costBreakdown = {
    jobBoards: 500, // Coût moyen des annonces
    recruiting: 1500, // Temps RH
    interviews: 800, // Temps managers + employés
    onboarding: 1200, // Formation initiale
    administrative: 300, // Frais administratifs
  };

  const totalCostPerHire = Object.values(costBreakdown).reduce((sum, cost) => sum + cost, 0);
  
  // Calcul du coût total annuel
  const hiredThisYear = hiredCandidates.filter(c => {
    if (!c.created_date) return false;
    const hireYear = new Date(c.created_date).getFullYear();
    return hireYear === new Date().getFullYear();
  }).length;

  const totalAnnualCost = totalCostPerHire * hiredThisYear;

  // ROI estimé (valeur apportée par employé la première année)
  const avgEmployeeSalary = employees.length > 0
    ? employees
        .filter(e => e.salary)
        .reduce((sum, e) => sum + e.salary, 0) / employees.filter(e => e.salary).length
    : 50000;

  const estimatedProductivity = avgEmployeeSalary * 1.5; // Valeur créée
  const roi = estimatedProductivity > 0 
    ? (((estimatedProductivity - totalCostPerHire) / totalCostPerHire) * 100).toFixed(0)
    : 0;

  // Benchmark industrie (variable selon secteur, moyenne ~4000€)
  const industryBenchmark = 4000;
  const vsIndustry = totalCostPerHire - industryBenchmark;
  const isCompetitive = totalCostPerHire <= industryBenchmark;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-green-600" />
            Coût par Embauche
          </CardTitle>
          <Badge className={isCompetitive ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}>
            {isCompetitive ? 'Compétitif' : 'Au-dessus'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-4xl font-bold text-slate-900">{totalCostPerHire.toLocaleString()}</span>
            <span className="text-sm text-slate-600">€ par embauche</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm mb-4">
            <span className={isCompetitive ? 'text-green-600' : 'text-orange-600'}>
              {isCompetitive ? '✓' : '⚠️'} {Math.abs(vsIndustry)}€ {isCompetitive ? 'en dessous' : 'au-dessus'} de la moyenne
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-700 mb-1">Embauches (année)</p>
              <p className="text-lg font-semibold text-blue-900">{hiredThisYear}</p>
            </div>
            <div className="p-3 bg-purple-50 rounded-lg">
              <p className="text-xs text-purple-700 mb-1">Coût total annuel</p>
              <p className="text-lg font-semibold text-purple-900">{totalAnnualCost.toLocaleString()}€</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-slate-900">Détail des coûts</h4>
          
          {Object.entries(costBreakdown).map(([key, cost]) => {
            const labels = {
              jobBoards: 'Annonces & diffusion',
              recruiting: 'Temps recrutement',
              interviews: 'Entretiens',
              onboarding: 'Intégration',
              administrative: 'Administratif',
            };

            const percentage = ((cost / totalCostPerHire) * 100).toFixed(0);

            return (
              <div key={key} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">{labels[key]}</span>
                  <span className="font-medium text-slate-900">{cost}€ ({percentage}%)</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-1.5">
                  <div 
                    className="bg-green-500 h-1.5 rounded-full"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}

          <div className="border-t pt-3 mt-4">
            <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-green-900">ROI Estimé (1ère année)</span>
                <div className="flex items-center gap-1 text-green-600">
                  <TrendingUp className="w-4 h-4" />
                  <span className="font-bold text-lg">{roi}%</span>
                </div>
              </div>
              <p className="text-xs text-green-700">
                Valeur créée: {estimatedProductivity.toLocaleString()}€ / Coût: {totalCostPerHire.toLocaleString()}€
              </p>
            </div>
          </div>

          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-xs text-blue-700">
              💡 <strong>Benchmark secteur:</strong> {industryBenchmark.toLocaleString()}€ en moyenne
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}