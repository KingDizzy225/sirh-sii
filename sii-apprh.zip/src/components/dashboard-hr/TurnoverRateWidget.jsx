import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, AlertCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Badge } from "@/components/ui/badge";

export default function TurnoverRateWidget({ employees = [] }) {
  // Calculer le taux de roulement sur 12 mois
  const getLast12Months = () => {
    const months = [];
    for (let i = 11; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      months.push({
        month: date.toLocaleString('fr', { month: 'short' }),
        year: date.getFullYear(),
        date: date
      });
    }
    return months;
  };

  const last12Months = getLast12Months();

  const turnoverData = last12Months.map(({ month, year, date }) => {
    const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
    const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);

    const activeAtStart = employees.filter(emp => {
      const hireDate = emp.hire_date ? new Date(emp.hire_date) : null;
      return hireDate && hireDate <= monthStart;
    }).length;

    const departures = employees.filter(emp => {
      if (emp.status !== 'terminated') return false;
      // Approximation: utiliser updated_date pour les départs
      const departureDate = emp.updated_date ? new Date(emp.updated_date) : null;
      return departureDate && departureDate >= monthStart && departureDate <= monthEnd;
    }).length;

    const rate = activeAtStart > 0 ? ((departures / activeAtStart) * 100).toFixed(1) : 0;

    return {
      month: `${month} ${year.toString().slice(2)}`,
      rate: parseFloat(rate),
      departures
    };
  });

  const currentMonthRate = turnoverData[turnoverData.length - 1].rate;
  const previousMonthRate = turnoverData[turnoverData.length - 2].rate;
  const trend = currentMonthRate - previousMonthRate;
  const totalDepartures = turnoverData.reduce((sum, d) => sum + d.departures, 0);
  const avgRate = (turnoverData.reduce((sum, d) => sum + d.rate, 0) / 12).toFixed(1);

  const isHealthy = currentMonthRate < 5;
  const isWarning = currentMonthRate >= 5 && currentMonthRate < 10;
  const isCritical = currentMonthRate >= 10;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-orange-600" />
            Taux de Roulement
          </CardTitle>
          <Badge className={
            isHealthy ? 'bg-green-100 text-green-800' :
            isWarning ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }>
            {isHealthy ? 'Sain' : isWarning ? 'À surveiller' : 'Critique'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="mb-6">
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-4xl font-bold text-slate-900">{currentMonthRate}%</span>
            <span className="text-sm text-slate-600">ce mois</span>
          </div>
          
          <div className="flex items-center gap-4 text-sm">
            <div className={`flex items-center gap-1 ${trend > 0 ? 'text-red-600' : 'text-green-600'}`}>
              {trend > 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span className="font-medium">{Math.abs(trend).toFixed(1)}%</span>
              <span className="text-slate-600">vs mois dernier</span>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-600 mb-1">Moyenne 12 mois</p>
              <p className="text-lg font-semibold text-slate-900">{avgRate}%</p>
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <p className="text-xs text-slate-600 mb-1">Départs totaux</p>
              <p className="text-lg font-semibold text-slate-900">{totalDepartures}</p>
            </div>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={turnoverData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis 
              dataKey="month" 
              stroke="#64748b" 
              fontSize={12}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis stroke="#64748b" fontSize={12} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0',
                borderRadius: '8px'
              }}
              formatter={(value) => [`${value}%`, 'Taux']}
            />
            <Line 
              type="monotone" 
              dataKey="rate" 
              stroke="#f97316" 
              strokeWidth={2}
              dot={{ fill: '#f97316', r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>

        {isCritical && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-900">Taux de roulement élevé</p>
              <p className="text-xs text-red-700 mt-1">
                Le taux dépasse 10%. Recommandé d'analyser les causes des départs.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}