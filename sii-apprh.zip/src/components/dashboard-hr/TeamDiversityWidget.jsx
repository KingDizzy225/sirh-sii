import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Globe } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function TeamDiversityWidget({ employees = [] }) {
  const activeEmployees = employees.filter(e => e.status === 'active');

  // Diversité de genre (basé sur analyse du prénom - approximation)
  const analyzeGender = (name) => {
    if (!name) return 'Non spécifié';
    const feminineEndings = ['a', 'e', 'ie', 'ine', 'elle', 'ette'];
    const lastChars = name.toLowerCase().slice(-3);
    if (feminineEndings.some(ending => lastChars.endsWith(ending))) return 'Femmes';
    return 'Hommes';
  };

  const genderDistribution = activeEmployees.reduce((acc, emp) => {
    const gender = analyzeGender(emp.full_name);
    acc[gender] = (acc[gender] || 0) + 1;
    return acc;
  }, {});

  // Diversité d'âge
  const ageDistribution = activeEmployees.reduce((acc, emp) => {
    if (!emp.date_of_birth) {
      acc['Non spécifié'] = (acc['Non spécifié'] || 0) + 1;
      return acc;
    }
    
    const age = new Date().getFullYear() - new Date(emp.date_of_birth).getFullYear();
    
    if (age < 25) acc['< 25 ans'] = (acc['< 25 ans'] || 0) + 1;
    else if (age < 35) acc['25-34 ans'] = (acc['25-34 ans'] || 0) + 1;
    else if (age < 45) acc['35-44 ans'] = (acc['35-44 ans'] || 0) + 1;
    else if (age < 55) acc['45-54 ans'] = (acc['45-54 ans'] || 0) + 1;
    else acc['55+ ans'] = (acc['55+ ans'] || 0) + 1;
    
    return acc;
  }, {});

  // Diversité de nationalités
  const nationalityDistribution = activeEmployees.reduce((acc, emp) => {
    const nationality = emp.nationality || 'Non spécifié';
    acc[nationality] = (acc[nationality] || 0) + 1;
    return acc;
  }, {});

  const topNationalities = Object.entries(nationalityDistribution)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  // Diversité linguistique
  const languageSet = new Set();
  activeEmployees.forEach(emp => {
    if (emp.languages && Array.isArray(emp.languages)) {
      emp.languages.forEach(lang => languageSet.add(lang));
    }
  });

  const ageData = Object.entries(ageDistribution)
    .filter(([key]) => key !== 'Non spécifié')
    .map(([range, count]) => ({
      range,
      count
    }));

  const genderData = Object.entries(genderDistribution).map(([gender, count]) => ({
    gender,
    count,
    percentage: ((count / activeEmployees.length) * 100).toFixed(1)
  }));

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5 text-green-600" />
          Diversité des Équipes
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Diversité de genre */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900 mb-3">Répartition de genre</h4>
            <div className="space-y-2">
              {genderData.map(({ gender, count, percentage }) => (
                <div key={gender} className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-slate-600">{gender}</span>
                      <span className="text-sm font-medium text-slate-900">{count} ({percentage}%)</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${gender === 'Femmes' ? 'bg-pink-500' : 'bg-blue-500'}`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Diversité d'âge */}
          {ageData.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-slate-900 mb-3">Répartition par âge</h4>
              <ResponsiveContainer width="100%" height={150}>
                <BarChart data={ageData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="range" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white', 
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="count" fill="#10b981" name="Employés" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Top nationalités */}
          <div>
            <h4 className="text-sm font-semibold text-slate-900 mb-3 flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              Top 5 Nationalités
            </h4>
            <div className="space-y-2">
              {topNationalities.map(([nationality, count], idx) => (
                <div key={nationality} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-400">#{idx + 1}</span>
                    <span className="text-sm text-slate-700">{nationality}</span>
                  </div>
                  <span className="text-sm font-semibold text-slate-900">{count}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Langues parlées */}
          {languageSet.size > 0 && (
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-900 mb-2">
                🌍 Langues parlées dans l'équipe
              </p>
              <div className="flex flex-wrap gap-2">
                {Array.from(languageSet).slice(0, 8).map(lang => (
                  <span key={lang} className="px-2 py-1 bg-white text-blue-700 text-xs rounded border border-blue-200">
                    {lang}
                  </span>
                ))}
                {languageSet.size > 8 && (
                  <span className="px-2 py-1 bg-white text-blue-700 text-xs rounded border border-blue-200">
                    +{languageSet.size - 8}
                  </span>
                )}
              </div>
            </div>
          )}

          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-xs text-green-700">
              💡 Une équipe diverse apporte des perspectives variées et favorise l'innovation
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}