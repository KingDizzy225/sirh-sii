import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  Filter, 
  X, 
  Calendar, 
  FileText, 
  Tag,
  User,
  Building2,
  Clock,
  Share2,
  Sparkles
} from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { getTagColor } from "./DocumentTagManager";

export default function AdvancedDocumentSearch({ 
  onSearch, 
  employees = [], 
  departments = [],
  documents = [],
  totalResults = 0 
}) {
  const [searchFilters, setSearchFilters] = useState({
    searchTerm: "",
    documentType: "all",
    employeeEmail: "all",
    department: "all",
    status: "all",
    dateFrom: "",
    dateTo: "",
    tags: "",
    uploadedBy: "all",
    isShared: "all",
    minVersion: "",
    maxVersion: ""
  });

  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectedTags, setSelectedTags] = useState([]);

  // Extraire tous les tags uniques des documents
  const allTags = [...new Set(documents.flatMap(d => d.tags || []))];

  const toggleTag = (tag) => {
    const newTags = selectedTags.includes(tag)
      ? selectedTags.filter(t => t !== tag)
      : [...selectedTags, tag];
    setSelectedTags(newTags);
    setSearchFilters({ ...searchFilters, tags: newTags.join(',') });
  };

  const handleSearch = () => {
    onSearch(searchFilters);
  };

  const clearFilters = () => {
    const cleared = {
      searchTerm: "",
      documentType: "all",
      employeeEmail: "all",
      department: "all",
      status: "all",
      dateFrom: "",
      dateTo: "",
      tags: "",
      uploadedBy: "all",
      isShared: "all",
      minVersion: "",
      maxVersion: ""
    };
    setSearchFilters(cleared);
    setSelectedTags([]);
    onSearch(cleared);
  };

  const activeFiltersCount = Object.entries(searchFilters).filter(([key, value]) => {
    if (key === 'searchTerm' && value) return true;
    if (typeof value === 'string' && value && value !== 'all') return true;
    return false;
  }).length;

  const documentTypes = [
    "Contrat", "Carte d'identité", "CV", "Certificat", 
    "Attestation", "Fiche de paie", "Autre"
  ];

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5 text-blue-600" />
          Recherche Avancée
          {activeFiltersCount > 0 && (
            <Badge className="bg-blue-600">
              {activeFiltersCount} filtre{activeFiltersCount > 1 ? 's' : ''} actif{activeFiltersCount > 1 ? 's' : ''}
            </Badge>
          )}
          {totalResults > 0 && (
            <Badge variant="outline" className="ml-auto">
              {totalResults} résultat{totalResults > 1 ? 's' : ''}
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Recherche principale */}
        <div className="space-y-2">
          <Label>Recherche par mots-clés</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <Input
              placeholder="Titre, description, nom d'employé..."
              value={searchFilters.searchTerm}
              onChange={(e) => setSearchFilters({...searchFilters, searchTerm: e.target.value})}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="pl-10"
            />
          </div>
        </div>

        {/* Filtres de base */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Type de document
            </Label>
            <Select 
              value={searchFilters.documentType} 
              onValueChange={(value) => setSearchFilters({...searchFilters, documentType: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les types</SelectItem>
                {documentTypes.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Employé
            </Label>
            <Select 
              value={searchFilters.employeeEmail} 
              onValueChange={(value) => setSearchFilters({...searchFilters, employeeEmail: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                <SelectItem value="all">Tous les employés</SelectItem>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.email}>
                    {emp.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Statut
            </Label>
            <Select 
              value={searchFilters.status} 
              onValueChange={(value) => setSearchFilters({...searchFilters, status: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="actif">Actif</SelectItem>
                <SelectItem value="brouillon">Brouillon</SelectItem>
                <SelectItem value="archivé">Archivé</SelectItem>
                <SelectItem value="obsolète">Obsolète</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Filtres avancés */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="text-blue-600 hover:text-blue-700"
          >
            <Filter className="w-4 h-4 mr-2" />
            {showAdvanced ? 'Masquer' : 'Afficher'} les filtres avancés
          </Button>

          {showAdvanced && (
            <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Building2 className="w-4 h-4" />
                    Département
                  </Label>
                  <Select 
                    value={searchFilters.department} 
                    onValueChange={(value) => setSearchFilters({...searchFilters, department: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous les départements</SelectItem>
                      {departments.map(dept => (
                        <SelectItem key={dept.id} value={dept.name}>
                          {dept.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Uploadé par
                  </Label>
                  <Select 
                    value={searchFilters.uploadedBy} 
                    onValueChange={(value) => setSearchFilters({...searchFilters, uploadedBy: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      {[...new Set(employees.map(e => e.email))].map(email => {
                        const emp = employees.find(e => e.email === email);
                        return (
                          <SelectItem key={email} value={email}>
                            {emp?.full_name || email}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Date de début
                  </Label>
                  <Input
                    type="date"
                    value={searchFilters.dateFrom}
                    onChange={(e) => setSearchFilters({...searchFilters, dateFrom: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Date de fin
                  </Label>
                  <Input
                    type="date"
                    value={searchFilters.dateTo}
                    onChange={(e) => setSearchFilters({...searchFilters, dateTo: e.target.value})}
                  />
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Share2 className="w-4 h-4" />
                    Partage
                  </Label>
                  <Select 
                    value={searchFilters.isShared} 
                    onValueChange={(value) => setSearchFilters({...searchFilters, isShared: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tous</SelectItem>
                      <SelectItem value="shared">Partagés uniquement</SelectItem>
                      <SelectItem value="not_shared">Non partagés</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    Tags
                  </Label>
                  <Input
                    placeholder="Rechercher par tags..."
                    value={searchFilters.tags}
                    onChange={(e) => setSearchFilters({...searchFilters, tags: e.target.value})}
                  />
                  {allTags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {allTags.slice(0, 15).map((tag) => (
                        <Badge
                          key={tag}
                          className={`cursor-pointer transition-all ${
                            selectedTags.includes(tag) 
                              ? getTagColor(tag) + ' border ring-2 ring-blue-400' 
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                          onClick={() => toggleTag(tag)}
                        >
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t">
          {activeFiltersCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-red-600 hover:text-red-700"
            >
              <X className="w-4 h-4 mr-2" />
              Réinitialiser tous les filtres
            </Button>
          )}
          
          <Button
            onClick={handleSearch}
            className="ml-auto bg-blue-600 hover:bg-blue-700"
          >
            <Search className="w-4 h-4 mr-2" />
            Rechercher
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}