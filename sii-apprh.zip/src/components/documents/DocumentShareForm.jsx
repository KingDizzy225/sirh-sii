import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Share2, Users, User, Building2, Shield, Calendar } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DocumentShareForm({ document, employees, departments, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    shared_with_type: "employee",
    shared_with_value: "",
    shared_with_name: "",
    permission_level: "lecture",
    expiration_date: "",
    message: ""
  });

  const handleTypeChange = (type) => {
    setFormData({
      ...formData,
      shared_with_type: type,
      shared_with_value: "",
      shared_with_name: ""
    });
  };

  const handleEmployeeChange = (employeeId) => {
    const employee = employees.find(e => e.id === employeeId);
    setFormData({
      ...formData,
      shared_with_value: employee?.email || "",
      shared_with_name: employee?.full_name || ""
    });
  };

  const handleDepartmentChange = (deptName) => {
    setFormData({
      ...formData,
      shared_with_value: deptName,
      shared_with_name: deptName
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const permissionIcons = {
    lecture: "👁️",
    lecture_telechargement: "📥",
    lecture_modification: "✏️"
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Partager le document - {document.title}
          </DialogTitle>
        </DialogHeader>

        <Alert className="bg-blue-50 border-blue-200">
          <Shield className="w-4 h-4 text-blue-600" />
          <AlertDescription className="text-blue-800 text-sm">
            Le partage sécurisé permet de contrôler qui peut accéder à ce document et avec quels droits.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Type de partage */}
          <div className="space-y-2">
            <Label>Partager avec *</Label>
            <div className="grid grid-cols-3 gap-3">
              <Button
                type="button"
                variant={formData.shared_with_type === "employee" ? "default" : "outline"}
                onClick={() => handleTypeChange("employee")}
                className="h-auto py-4 flex flex-col items-center gap-2"
              >
                <User className="w-6 h-6" />
                <span className="text-sm">Un employé</span>
              </Button>

              <Button
                type="button"
                variant={formData.shared_with_type === "department" ? "default" : "outline"}
                onClick={() => handleTypeChange("department")}
                className="h-auto py-4 flex flex-col items-center gap-2"
              >
                <Building2 className="w-6 h-6" />
                <span className="text-sm">Un département</span>
              </Button>

              <Button
                type="button"
                variant={formData.shared_with_type === "team" ? "default" : "outline"}
                onClick={() => handleTypeChange("team")}
                className="h-auto py-4 flex flex-col items-center gap-2"
              >
                <Users className="w-6 h-6" />
                <span className="text-sm">Une équipe</span>
              </Button>
            </div>
          </div>

          {/* Sélection employé */}
          {formData.shared_with_type === "employee" && (
            <div className="space-y-2">
              <Label htmlFor="employee">Sélectionner l'employé *</Label>
              <Select onValueChange={handleEmployeeChange} required>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un employé" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{emp.full_name}</span>
                        <span className="text-xs text-slate-500">({emp.position})</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Sélection département */}
          {formData.shared_with_type === "department" && (
            <div className="space-y-2">
              <Label htmlFor="department">Sélectionner le département *</Label>
              <Select onValueChange={handleDepartmentChange} required>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un département" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map(dept => (
                    <SelectItem key={dept.id} value={dept.name}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Nom équipe */}
          {formData.shared_with_type === "team" && (
            <div className="space-y-2">
              <Label htmlFor="team">Nom de l'équipe *</Label>
              <Input
                id="team"
                value={formData.shared_with_value}
                onChange={(e) => setFormData({
                  ...formData,
                  shared_with_value: e.target.value,
                  shared_with_name: e.target.value
                })}
                placeholder="ex: Équipe Marketing"
                required
              />
            </div>
          )}

          {/* Niveau de permission */}
          <div className="space-y-2">
            <Label>Niveau de permission *</Label>
            <div className="grid grid-cols-1 gap-3">
              <button
                type="button"
                onClick={() => setFormData({...formData, permission_level: "lecture"})}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  formData.permission_level === "lecture" 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{permissionIcons.lecture}</span>
                  <div>
                    <p className="font-semibold text-slate-900">Lecture uniquement</p>
                    <p className="text-sm text-slate-600">Peut uniquement visualiser le document</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFormData({...formData, permission_level: "lecture_telechargement"})}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  formData.permission_level === "lecture_telechargement" 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{permissionIcons.lecture_telechargement}</span>
                  <div>
                    <p className="font-semibold text-slate-900">Lecture et téléchargement</p>
                    <p className="text-sm text-slate-600">Peut visualiser et télécharger le document</p>
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFormData({...formData, permission_level: "lecture_modification"})}
                className={`p-4 rounded-lg border-2 text-left transition-all ${
                  formData.permission_level === "lecture_modification" 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{permissionIcons.lecture_modification}</span>
                  <div>
                    <p className="font-semibold text-slate-900">Lecture et modification</p>
                    <p className="text-sm text-slate-600">Peut visualiser, télécharger et uploader de nouvelles versions</p>
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Date d'expiration */}
          <div className="space-y-2">
            <Label htmlFor="expiration_date" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Date d'expiration (optionnel)
            </Label>
            <Input
              id="expiration_date"
              type="date"
              value={formData.expiration_date}
              onChange={(e) => setFormData({...formData, expiration_date: e.target.value})}
              min={new Date().toISOString().split('T')[0]}
            />
            <p className="text-xs text-slate-500">
              Laisser vide pour un partage sans limite de temps
            </p>
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label htmlFor="message">Message (optionnel)</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => setFormData({...formData, message: e.target.value})}
              rows={3}
              placeholder="Ajoutez un message pour expliquer le partage..."
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.shared_with_value}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? 'Partage...' : 'Partager'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}