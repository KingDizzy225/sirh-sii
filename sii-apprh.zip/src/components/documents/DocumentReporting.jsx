import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  BarChart3, 
  PieChart, 
  TrendingUp, 
  Clock, 
  FileText, 
  Users,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Download,
  Filter
} from "lucide-react";
import { format, subDays, subMonths, differenceInHours, differenceInDays } from "date-fns";
import { fr } from "date-fns/locale";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RechartsPie, Pie, Cell, LineChart, Line, Legend } from "recharts";
import { ACTION_LABELS } from "./DocumentAuditService";

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

export default function DocumentReporting({ documents, employees, departments }) {
  const [dateRange, setDateRange] = useState("30");
  const [selectedDepartment, setSelectedDepartment] = useState("all");

  const { data: auditLogs = [] } = useQuery({
    queryKey: ['allAuditLogs'],
    queryFn: () => base44.entities.DocumentAuditLog.list('-created_date', 1000),
  });

  const { data: signatures = [] } = useQuery({
    queryKey: ['allSignatures'],
    queryFn: () => base44.entities.DocumentSignature.list(),
  });

  // Filtrer par période
  const filteredLogs = useMemo(() => {
    const cutoffDate = subDays(new Date(), parseInt(dateRange));
    return auditLogs.filter(log => {
      const logDate = new Date(log.created_date);
      const matchesDate = logDate >= cutoffDate;
      const matchesDept = selectedDepartment === "all" || log.department === selectedDepartment;
      return matchesDate && matchesDept;
    });
  }, [auditLogs, dateRange, selectedDepartment]);

  // Statistiques générales
  const stats = useMemo(() => {
    const docsCreated = filteredLogs.filter(l => l.action === 'created').length;
    const docsShared = filteredLogs.filter(l => l.action === 'shared').length;
    const docsApproved = filteredLogs.filter(l => l.action === 'approved').length;
    const docsSigned = filteredLogs.filter(l => l.action === 'signed').length;
    const docsViewed = filteredLogs.filter(l => l.action === 'viewed').length;
    const docsDownloaded = filteredLogs.filter(l => l.action === 'downloaded').length;

    // Temps moyen d'approbation
    const approvalTimes = [];
    const approvalRequests = filteredLogs.filter(l => l.action === 'approval_requested');
    approvalRequests.forEach(req => {
      const approval = filteredLogs.find(l => 
        l.document_id === req.document_id && 
        l.action === 'approved' && 
        new Date(l.created_date) > new Date(req.created_date)
      );
      if (approval) {
        const hours = differenceInHours(new Date(approval.created_date), new Date(req.created_date));
        approvalTimes.push(hours);
      }
    });
    const avgApprovalTime = approvalTimes.length > 0 
      ? Math.round(approvalTimes.reduce((a, b) => a + b, 0) / approvalTimes.length)
      : 0;

    // Temps moyen de signature
    const signatureTimes = [];
    const signatureRequests = filteredLogs.filter(l => l.action === 'signature_requested');
    signatureRequests.forEach(req => {
      const signed = filteredLogs.find(l => 
        l.document_id === req.document_id && 
        l.action === 'signed' && 
        new Date(l.created_date) > new Date(req.created_date)
      );
      if (signed) {
        const hours = differenceInHours(new Date(signed.created_date), new Date(req.created_date));
        signatureTimes.push(hours);
      }
    });
    const avgSignatureTime = signatureTimes.length > 0 
      ? Math.round(signatureTimes.reduce((a, b) => a + b, 0) / signatureTimes.length)
      : 0;

    // Documents en attente
    const pendingApprovals = documents.filter(d => d.status === 'en_attente_approbation').length;
    const pendingSignatures = signatures.filter(s => s.status === 'pending').length;

    return {
      docsCreated,
      docsShared,
      docsApproved,
      docsSigned,
      docsViewed,
      docsDownloaded,
      avgApprovalTime,
      avgSignatureTime,
      pendingApprovals,
      pendingSignatures,
      totalActions: filteredLogs.length
    };
  }, [filteredLogs, documents, signatures]);

  // Données pour les graphiques
  const documentsByType = useMemo(() => {
    const typeCounts = {};
    documents.forEach(doc => {
      typeCounts[doc.document_type] = (typeCounts[doc.document_type] || 0) + 1;
    });
    return Object.entries(typeCounts).map(([name, value]) => ({ name, value }));
  }, [documents]);

  const actionsByType = useMemo(() => {
    const actionCounts = {};
    filteredLogs.forEach(log => {
      const label = ACTION_LABELS[log.action] || log.action;
      actionCounts[label] = (actionCounts[label] || 0) + 1;
    });
    return Object.entries(actionCounts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [filteredLogs]);

  const activityByDay = useMemo(() => {
    const days = {};
    const cutoff = subDays(new Date(), Math.min(parseInt(dateRange), 30));
    
    for (let d = cutoff; d <= new Date(); d = new Date(d.setDate(d.getDate() + 1))) {
      const key = format(d, 'dd/MM');
      days[key] = { date: key, actions: 0, created: 0, signed: 0 };
    }

    filteredLogs.forEach(log => {
      const key = format(new Date(log.created_date), 'dd/MM');
      if (days[key]) {
        days[key].actions++;
        if (log.action === 'created') days[key].created++;
        if (log.action === 'signed') days[key].signed++;
      }
    });

    return Object.values(days);
  }, [filteredLogs, dateRange]);

  const topUsers = useMemo(() => {
    const userCounts = {};
    filteredLogs.forEach(log => {
      const key = log.actor_email;
      if (!userCounts[key]) {
        userCounts[key] = { email: key, name: log.actor_name, count: 0 };
      }
      userCounts[key].count++;
    });
    return Object.values(userCounts)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [filteredLogs]);

  const complianceStatus = useMemo(() => {
    const total = documents.length;
    const signed = documents.filter(d => d.status === 'signé').length;
    const active = documents.filter(d => d.status === 'actif').length;
    const archived = documents.filter(d => d.status === 'archivé').length;
    const pending = documents.filter(d => d.status === 'en_attente_signature' || d.status === 'en_attente_approbation').length;

    return [
      { name: 'Signés', value: signed, color: '#10B981' },
      { name: 'Actifs', value: active, color: '#3B82F6' },
      { name: 'En attente', value: pending, color: '#F59E0B' },
      { name: 'Archivés', value: archived, color: '#6B7280' },
    ];
  }, [documents]);

  return (
    <div className="space-y-6">
      {/* Filtres */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-medium">Filtres:</span>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-sm">Période:</Label>
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 derniers jours</SelectItem>
                  <SelectItem value="30">30 derniers jours</SelectItem>
                  <SelectItem value="90">3 derniers mois</SelectItem>
                  <SelectItem value="365">12 derniers mois</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-sm">Département:</Label>
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les départements</SelectItem>
                  {departments.map(d => (
                    <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-blue-700">Documents créés</p>
                <p className="text-2xl font-bold text-blue-900">{stats.docsCreated}</p>
              </div>
              <FileText className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-green-700">Signatures</p>
                <p className="text-2xl font-bold text-green-900">{stats.docsSigned}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-purple-700">Partages</p>
                <p className="text-2xl font-bold text-purple-900">{stats.docsShared}</p>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-orange-700">En attente</p>
                <p className="text-2xl font-bold text-orange-900">{stats.pendingSignatures}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-cyan-50 to-cyan-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-cyan-700">Temps appro. moy.</p>
                <p className="text-2xl font-bold text-cyan-900">{stats.avgApprovalTime}h</p>
              </div>
              <Clock className="w-8 h-8 text-cyan-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-pink-50 to-pink-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-pink-700">Temps sign. moy.</p>
                <p className="text-2xl font-bold text-pink-900">{stats.avgSignatureTime}h</p>
              </div>
              <Clock className="w-8 h-8 text-pink-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Graphiques */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activité par jour */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              Activité quotidienne
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={activityByDay}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="actions" name="Actions" stroke="#3B82F6" strokeWidth={2} />
                <Line type="monotone" dataKey="created" name="Créations" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="signed" name="Signatures" stroke="#F59E0B" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Documents par type */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <PieChart className="w-5 h-5 text-purple-600" />
              Documents par type
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <RechartsPie>
                <Pie
                  data={documentsByType}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                >
                  {documentsByType.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPie>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Actions les plus fréquentes */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <BarChart3 className="w-5 h-5 text-green-600" />
              Actions les plus fréquentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={actionsByType} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" fontSize={12} />
                <YAxis type="category" dataKey="name" fontSize={11} width={100} />
                <Tooltip />
                <Bar dataKey="value" fill="#3B82F6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Statut de conformité */}
        <Card className="border-none shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <CheckCircle className="w-5 h-5 text-green-600" />
              Statut de conformité
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <RechartsPie>
                <Pie
                  data={complianceStatus}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {complianceStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </RechartsPie>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top utilisateurs */}
      <Card className="border-none shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="w-5 h-5 text-blue-600" />
            Utilisateurs les plus actifs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topUsers.map((user, idx) => (
              <div key={user.email} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                    idx === 0 ? 'bg-yellow-500' : idx === 1 ? 'bg-gray-400' : idx === 2 ? 'bg-orange-400' : 'bg-blue-500'
                  }`}>
                    {idx + 1}
                  </div>
                  <div>
                    <p className="font-medium">{user.name}</p>
                    <p className="text-xs text-slate-500">{user.email}</p>
                  </div>
                </div>
                <Badge variant="outline">{user.count} actions</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}