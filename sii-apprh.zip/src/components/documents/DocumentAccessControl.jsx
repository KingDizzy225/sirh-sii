import { base44 } from "@/api/base44Client";

/**
 * Système de contrôle d'accès pour les documents
 */

/**
 * Vérifie si un utilisateur peut accéder à un document
 */
export async function canAccessDocument(document, userEmail, userRole = null) {
  try {
    // 1. Super admin et RH manager ont tous les accès
    if (!userRole) {
      const roles = await base44.entities.UserRole.filter({
        user_email: userEmail,
        is_active: true
      });
      userRole = roles[0] || null;
    }

    if (userRole?.role_type === 'super_admin' || userRole?.role_type === 'rh_manager') {
      return { canAccess: true, permission: 'full' };
    }

    // 2. Le propriétaire du document (employé concerné)
    if (document.employee_email === userEmail) {
      return { canAccess: true, permission: 'read' };
    }

    // 3. Manager de l'employé
    const employees = await base44.entities.Employee.filter({ email: document.employee_email });
    if (employees.length > 0 && employees[0].manager_email === userEmail) {
      return { canAccess: true, permission: 'read' };
    }

    // 4. Document partagé avec l'utilisateur
    const shares = await base44.entities.DocumentShare.filter({
      document_id: document.id,
      shared_with_value: userEmail,
      is_active: true
    });

    if (shares.length > 0) {
      return { 
        canAccess: true, 
        permission: shares[0].permission_level || 'lecture'
      };
    }

    // 5. Document partagé avec le département de l'utilisateur
    const userEmployees = await base44.entities.Employee.filter({ email: userEmail });
    if (userEmployees.length > 0) {
      const userDept = userEmployees[0].department;
      const deptShares = await base44.entities.DocumentShare.filter({
        document_id: document.id,
        shared_with_type: 'department',
        shared_with_value: userDept,
        is_active: true
      });

      if (deptShares.length > 0) {
        return { 
          canAccess: true, 
          permission: deptShares[0].permission_level || 'lecture'
        };
      }
    }

    // 6. Rôles spécialisés
    if (userRole) {
      // Document manager peut tout voir
      if (userRole.role_type === 'document_manager') {
        return { canAccess: true, permission: 'full' };
      }

      // Department manager peut voir les docs de son département
      if (userRole.role_type === 'department_manager' && 
          userRole.department_restriction === document.employee_department) {
        return { canAccess: true, permission: 'read' };
      }
    }

    return { canAccess: false, permission: null };
  } catch (error) {
    console.error("Erreur vérification accès:", error);
    return { canAccess: false, permission: null };
  }
}

/**
 * Filtre une liste de documents selon les droits d'accès
 */
export async function filterDocumentsByAccess(documents, userEmail, userRole = null) {
  const accessPromises = documents.map(doc => 
    canAccessDocument(doc, userEmail, userRole)
  );
  
  const accessResults = await Promise.all(accessPromises);
  
  return documents
    .map((doc, index) => ({
      ...doc,
      userPermission: accessResults[index].permission
    }))
    .filter((doc, index) => accessResults[index].canAccess);
}

/**
 * Vérifie si un utilisateur peut modifier un document
 */
export function canEditDocument(document, userEmail, permission) {
  // Super admin, RH manager, document manager, uploadeur
  if (permission === 'full') return true;
  if (document.uploaded_by === userEmail) return true;
  if (permission === 'lecture_modification') return true;
  
  return false;
}

/**
 * Vérifie si un utilisateur peut télécharger un document
 */
export function canDownloadDocument(permission) {
  return permission === 'full' || 
         permission === 'lecture_telechargement' || 
         permission === 'lecture_modification' ||
         permission === 'read';
}

/**
 * Vérifie si un utilisateur peut supprimer un document
 */
export function canDeleteDocument(document, userEmail, userRole) {
  if (userRole?.role_type === 'super_admin') return true;
  if (userRole?.role_type === 'rh_manager') return true;
  if (userRole?.role_type === 'document_manager') return true;
  if (document.uploaded_by === userEmail) return true;
  
  return false;
}

/**
 * Vérifie si un utilisateur peut partager un document
 */
export function canShareDocument(document, userEmail, userRole) {
  if (userRole?.role_type === 'super_admin') return true;
  if (userRole?.role_type === 'rh_manager') return true;
  if (userRole?.role_type === 'document_manager') return true;
  if (document.uploaded_by === userEmail) return true;
  if (document.employee_email === userEmail) return true;
  
  return false;
}

export default {
  canAccessDocument,
  filterDocumentsByAccess,
  canEditDocument,
  canDownloadDocument,
  canDeleteDocument,
  canShareDocument
};