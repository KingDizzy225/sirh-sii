
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, CheckCircle, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Progress } from "@/components/ui/progress";
import { createNotification, NOTIFICATION_TEMPLATES } from "../notifications/NotificationCenter";

export default function DocumentForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_id: "",
    employee_name: "",
    employee_email: "",
    document_type: "Contrat",
    title: "",
    description: "",
    file_url: "",
    upload_date: new Date().toISOString().split('T')[0]
  });
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploader, setUploader] = useState(null); // Renamed from 'user' in outline to 'uploader' to match current code
  const [selectedFile, setSelectedFile] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const user = await base44.auth.me();
        setUploader(user);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleEmployeeChange = (employeeId) => {
    const employee = employees.find(e => e.id === employeeId);
    setFormData({
      ...formData,
      employee_id: employeeId,
      employee_name: employee?.full_name || "",
      employee_email: employee?.email || ""
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setUploading(true);
    setUploadProgress(0);

    try {
      // Simuler une progression
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);

      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setFormData({ ...formData, file_url });
      
      // Auto-remplir le titre si vide
      if (!formData.title) {
        setFormData(prev => ({ ...prev, title: file.name.replace(/\.[^/.]+$/, "") }));
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Échec du téléchargement du fichier");
      setFormData({ ...formData, file_url: "" }); // Clear file_url on error
      setSelectedFile(null); // Clear selected file on error
      setUploadProgress(0); // Reset progress on error
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (uploading || !formData.file_url) { // Changed 'isUploading' to 'uploading' to match state variable
      alert("Veuillez attendre la fin du téléchargement du fichier");
      return;
    }

    const documentData = {
      ...formData,
      uploaded_by: uploader?.email || "", // Used 'uploader' state variable
      upload_date: new Date().toISOString().split('T')[0], // Added this line
    };

    await onSubmit(documentData);
    
    // Créer une notification pour l'employé
    if (formData.employee_email) {
      await createNotification({
        user_email: formData.employee_email,
        user_name: formData.employee_name,
        ...NOTIFICATION_TEMPLATES.documentUploaded(
          formData.title,
          uploader?.full_name || uploader?.email || "RH" // Used 'uploader' state variable
        ),
        related_id: formData.employee_id,
        related_type: "document",
      });
    }
  };

  const getFileSize = (size) => {
    if (size < 1024) return size + ' B';
    if (size < 1024 * 1024) return (size / 1024).toFixed(2) + ' KB';
    return (size / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Télécharger un document
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employee Selection */}
          <div className="space-y-2">
            <Label htmlFor="employee">Employé *</Label>
            <Select
              value={formData.employee_id}
              onValueChange={handleEmployeeChange}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un employé" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{emp.full_name}</span>
                      <span className="text-xs text-slate-500">
                        {emp.position ? `- ${emp.position}` : ''}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Document Type */}
          <div className="space-y-2">
            <Label htmlFor="document_type">Type de document *</Label>
            <Select
              value={formData.document_type}
              onValueChange={(value) => setFormData({...formData, document_type: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Contrat">📄 Contrat de travail</SelectItem>
                <SelectItem value="Carte d'identité">🪪 Carte d'identité</SelectItem>
                <SelectItem value="CV">📋 CV</SelectItem>
                <SelectItem value="Certificat">🎓 Certificat</SelectItem>
                <SelectItem value="Attestation">✅ Attestation</SelectItem>
                <SelectItem value="Fiche de paie">💰 Fiche de paie</SelectItem>
                <SelectItem value="Autre">📁 Autre document</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Titre du document *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({...formData, title: e.target.value})}
              placeholder="ex: Contrat de travail 2025"
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              rows={3}
              placeholder="Brève description du document (optionnel)"
            />
          </div>

          {/* Upload Date */}
          <div className="space-y-2">
            <Label htmlFor="upload_date">Date de téléchargement</Label>
            <Input
              id="upload_date"
              type="date"
              value={formData.upload_date}
              onChange={(e) => setFormData({...formData, upload_date: e.target.value})}
            />
          </div>

          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="file">Fichier *</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <Input
                id="file"
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading}
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              />
              
              {!formData.file_url ? (
                <label htmlFor="file" className="cursor-pointer block">
                  <Upload className="w-12 h-12 mx-auto mb-3 text-slate-400" />
                  {uploading ? (
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600 font-medium">
                        Téléchargement en cours...
                      </p>
                      <Progress value={uploadProgress} className="w-full" />
                      <p className="text-xs text-slate-500">{uploadProgress}%</p>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm text-slate-600 font-medium mb-1">
                        Cliquez pour sélectionner un fichier
                      </p>
                      <p className="text-xs text-slate-500">
                        PDF, Word, Images (Max 10MB)
                      </p>
                    </>
                  )}
                </label>
              ) : (
                <div className="space-y-3">
                  <CheckCircle className="w-12 h-12 mx-auto text-green-600" />
                  <div>
                    <p className="text-sm text-green-600 font-medium mb-1">
                      ✓ Fichier téléchargé avec succès!
                    </p>
                    {selectedFile && (
                      <p className="text-xs text-slate-500">
                        {selectedFile.name} ({getFileSize(selectedFile.size)})
                      </p>
                    )}
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setFormData({...formData, file_url: ""});
                      setSelectedFile(null);
                      setUploadProgress(0);
                    }}
                    className="gap-2"
                  >
                    <X className="w-4 h-4" />
                    Changer de fichier
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || uploading || !formData.file_url} 
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? 'Enregistrement...' : 'Télécharger le document'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
