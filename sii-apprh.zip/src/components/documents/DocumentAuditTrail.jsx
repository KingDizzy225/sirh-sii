import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  History, 
  User, 
  Calendar, 
  FileText,
  Download,
  Eye,
  Share2,
  Trash2,
  CheckCircle,
  XCircle,
  PenTool,
  Tag,
  Upload,
  Archive
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { ACTION_LABELS, ACTION_COLORS } from "./DocumentAuditService";

const actionIcons = {
  created: FileText,
  viewed: Eye,
  downloaded: Download,
  modified: FileText,
  shared: Share2,
  unshared: Share2,
  deleted: Trash2,
  archived: Archive,
  restored: Archive,
  version_added: Upload,
  tags_updated: Tag,
  approval_requested: CheckCircle,
  approved: CheckCircle,
  rejected: XCircle,
  signature_requested: PenTool,
  signed: PenTool,
  signature_declined: XCircle,
};

export default function DocumentAuditTrail({ document, onClose }) {
  const { data: auditLogs = [], isLoading } = useQuery({
    queryKey: ['documentAuditLogs', document?.id],
    queryFn: () => base44.entities.DocumentAuditLog.filter(
      { document_id: document.id },
      '-created_date',
      100
    ),
    enabled: !!document?.id,
  });

  if (!document) return null;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            Audit Trail - {document.title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : auditLogs.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <History className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucune action enregistrée</p>
            </div>
          ) : (
            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-slate-200"></div>

              <div className="space-y-4">
                {auditLogs.map((log, index) => {
                  const Icon = actionIcons[log.action] || FileText;
                  const color = ACTION_COLORS[log.action] || "bg-gray-100 text-gray-800";
                  
                  return (
                    <div key={log.id} className="relative pl-14">
                      {/* Timeline dot */}
                      <div className={`absolute left-4 w-5 h-5 rounded-full ${color} flex items-center justify-center ring-4 ring-white`}>
                        <Icon className="w-3 h-3" />
                      </div>

                      <Card className="border-slate-200">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <Badge className={color}>
                              {ACTION_LABELS[log.action] || log.action}
                            </Badge>
                            <span className="text-xs text-slate-500">
                              {format(new Date(log.created_date), "dd MMM yyyy 'à' HH:mm", { locale: fr })}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-sm text-slate-700 mb-2">
                            <User className="w-4 h-4 text-slate-400" />
                            <span className="font-medium">{log.actor_name}</span>
                            <span className="text-slate-400">({log.actor_email})</span>
                          </div>

                          {log.target_name && (
                            <div className="text-sm text-slate-600 mb-2">
                              → {log.target_name} ({log.target_email})
                            </div>
                          )}

                          {log.details && Object.keys(log.details).length > 0 && (
                            <div className="mt-2 p-2 bg-slate-50 rounded text-xs text-slate-600">
                              {Object.entries(log.details).map(([key, value]) => (
                                <div key={key}>
                                  <span className="font-medium">{key}:</span> {String(value)}
                                </div>
                              ))}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}