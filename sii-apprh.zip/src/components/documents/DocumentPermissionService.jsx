import { base44 } from "@/api/base44Client";

// Définition des rôles et leurs permissions par défaut
export const DOCUMENT_ROLES = {
  viewer: {
    label: "Lecteur",
    description: "Peut consulter les documents",
    color: "bg-gray-100 text-gray-800",
    permissions: {
      can_view: true,
      can_download: false,
      can_edit: false,
      can_delete: false,
      can_share: false,
      can_approve: false,
      can_sign: false,
      can_request_signature: false,
      can_manage_versions: false,
      can_manage_tags: false
    }
  },
  editor: {
    label: "Éditeur",
    description: "Peut modifier et gérer les versions",
    color: "bg-blue-100 text-blue-800",
    permissions: {
      can_view: true,
      can_download: true,
      can_edit: true,
      can_delete: false,
      can_share: true,
      can_approve: false,
      can_sign: false,
      can_request_signature: false,
      can_manage_versions: true,
      can_manage_tags: true
    }
  },
  approver: {
    label: "Approbateur",
    description: "Peut approuver les documents",
    color: "bg-orange-100 text-orange-800",
    permissions: {
      can_view: true,
      can_download: true,
      can_edit: false,
      can_delete: false,
      can_share: true,
      can_approve: true,
      can_sign: false,
      can_request_signature: false,
      can_manage_versions: false,
      can_manage_tags: true
    }
  },
  signer: {
    label: "Signataire",
    description: "Peut signer les documents",
    color: "bg-green-100 text-green-800",
    permissions: {
      can_view: true,
      can_download: true,
      can_edit: false,
      can_delete: false,
      can_share: false,
      can_approve: false,
      can_sign: true,
      can_request_signature: false,
      can_manage_versions: false,
      can_manage_tags: false
    }
  },
  admin: {
    label: "Administrateur",
    description: "Accès complet",
    color: "bg-purple-100 text-purple-800",
    permissions: {
      can_view: true,
      can_download: true,
      can_edit: true,
      can_delete: true,
      can_share: true,
      can_approve: true,
      can_sign: true,
      can_request_signature: true,
      can_manage_versions: true,
      can_manage_tags: true
    }
  }
};

export const PERMISSION_LABELS = {
  can_view: "Consulter",
  can_download: "Télécharger",
  can_edit: "Modifier",
  can_delete: "Supprimer",
  can_share: "Partager",
  can_approve: "Approuver",
  can_sign: "Signer",
  can_request_signature: "Demander signature",
  can_manage_versions: "Gérer versions",
  can_manage_tags: "Gérer tags"
};

/**
 * Récupère les permissions effectives d'un utilisateur pour un document
 */
export async function getEffectivePermissions(document, userEmail, userEmployee = null) {
  try {
    // Récupérer toutes les règles de permission actives
    const allRules = await base44.entities.DocumentPermission.filter({ is_active: true });
    
    // Filtrer les règles applicables
    const applicableRules = allRules.filter(rule => {
      // Vérifier si la règle n'est pas expirée
      if (rule.expires_at && new Date(rule.expires_at) < new Date()) {
        return false;
      }

      // Vérifier le type de permission
      let matchesScope = false;
      switch (rule.permission_type) {
        case 'document':
          matchesScope = rule.document_id === document.id;
          break;
        case 'document_type':
          matchesScope = rule.document_type === document.document_type;
          break;
        case 'department':
          matchesScope = rule.department === document.department || 
                        (userEmployee && rule.department === userEmployee.department);
          break;
        case 'position':
          matchesScope = userEmployee && rule.position === userEmployee.position;
          break;
        case 'global':
          matchesScope = true;
          break;
      }

      if (!matchesScope) return false;

      // Vérifier la cible
      let matchesTarget = false;
      switch (rule.target_type) {
        case 'user':
          matchesTarget = rule.target_email === userEmail;
          break;
        case 'department':
          matchesTarget = userEmployee && rule.target_department === userEmployee.department;
          break;
        case 'position':
          matchesTarget = userEmployee && rule.target_position === userEmployee.position;
          break;
        case 'all':
          matchesTarget = true;
          break;
      }

      return matchesTarget;
    });

    // Trier par priorité (plus élevé = plus prioritaire)
    applicableRules.sort((a, b) => (b.priority || 0) - (a.priority || 0));

    // Fusionner les permissions (OR logic - si une règle autorise, c'est autorisé)
    const effectivePermissions = {
      can_view: false,
      can_download: false,
      can_edit: false,
      can_delete: false,
      can_share: false,
      can_approve: false,
      can_sign: false,
      can_request_signature: false,
      can_manage_versions: false,
      can_manage_tags: false
    };

    applicableRules.forEach(rule => {
      if (rule.permissions) {
        Object.keys(effectivePermissions).forEach(key => {
          if (rule.permissions[key]) {
            effectivePermissions[key] = true;
          }
        });
      } else if (rule.role && DOCUMENT_ROLES[rule.role]) {
        // Utiliser les permissions par défaut du rôle
        const rolePerms = DOCUMENT_ROLES[rule.role].permissions;
        Object.keys(effectivePermissions).forEach(key => {
          if (rolePerms[key]) {
            effectivePermissions[key] = true;
          }
        });
      }
    });

    return {
      permissions: effectivePermissions,
      rules: applicableRules,
      highestRole: applicableRules[0]?.role || null
    };
  } catch (error) {
    console.error("Error getting effective permissions:", error);
    return {
      permissions: { can_view: true }, // Fallback: lecture seule
      rules: [],
      highestRole: 'viewer'
    };
  }
}

/**
 * Vérifie si un utilisateur a une permission spécifique sur un document
 */
export async function hasPermission(document, userEmail, permission, userEmployee = null) {
  const { permissions } = await getEffectivePermissions(document, userEmail, userEmployee);
  return permissions[permission] === true;
}