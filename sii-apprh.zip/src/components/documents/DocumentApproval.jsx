import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, XCircle, Clock, User, FileText, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function DocumentApproval({ document, onClose, onApproved }) {
  const [user, setUser] = useState(null);
  const [approvers, setApprovers] = useState([]);
  const [selectedApprovers, setSelectedApprovers] = useState([]);
  const [approvalNotes, setApprovalNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadData = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      // Charger les approbateurs potentiels (managers, RH)
      const employees = await base44.entities.Employee.filter({ status: 'active' });
      const rhRoles = await base44.entities.UserRole.filter({ 
        role_type: 'rh_manager',
        is_active: true 
      });

      const potentialApprovers = [
        ...employees.filter(e => e.manager_email),
        ...rhRoles.map(r => ({ email: r.user_email, full_name: r.user_name }))
      ];

      setApprovers(potentialApprovers);
    };
    loadData();
  }, []);

  const handleInitiateApproval = async () => {
    if (selectedApprovers.length === 0) {
      toast({
        title: "Erreur",
        description: "Sélectionnez au moins un approbateur",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Mettre à jour le document avec le workflow d'approbation
      await base44.entities.Document.update(document.id, {
        status: "en_attente_approbation",
        tags: [...(document.tags || []), "en_approbation"]
      });

      // Créer des notifications pour chaque approbateur
      for (const approverEmail of selectedApprovers) {
        const approver = approvers.find(a => a.email === approverEmail);
        
        await base44.entities.Notification.create({
          user_email: approverEmail,
          user_name: approver?.full_name || approverEmail,
          notification_type: "system",
          title: "Document à approuver 📋",
          message: `Le document "${document.title}" (${document.document_type}) nécessite votre approbation.`,
          priority: "high",
          action_url: "/Documents",
          action_label: "Approuver",
          related_id: document.id,
          related_type: "Document",
          sender_email: user.email,
          sender_name: user.full_name || user.email
        });
      }

      toast({
        title: "Demande d'approbation envoyée",
        description: `${selectedApprovers.length} personne(s) ont été notifiée(s)`,
        duration: 5000,
      });

      if (onApproved) {
        onApproved();
      }
      onClose();
    } catch (error) {
      console.error("Erreur initiation approbation:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer la demande d'approbation",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            Demande d'Approbation
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Document info */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900">{document.title}</p>
                  <p className="text-sm text-blue-700">{document.document_type}</p>
                  <p className="text-xs text-blue-600 mt-1">
                    Pour: {document.employee_name}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Sélection des approbateurs */}
          <div className="space-y-2">
            <Label>Sélectionner les approbateurs *</Label>
            <Select 
              value={selectedApprovers[0] || ""} 
              onValueChange={(value) => {
                if (!selectedApprovers.includes(value)) {
                  setSelectedApprovers([...selectedApprovers, value]);
                }
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Ajouter un approbateur" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {approvers
                  .filter(a => !selectedApprovers.includes(a.email))
                  .map(approver => (
                    <SelectItem key={approver.email} value={approver.email}>
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {approver.full_name || approver.email}
                      </div>
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>

            {selectedApprovers.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {selectedApprovers.map(email => {
                  const approver = approvers.find(a => a.email === email);
                  return (
                    <Badge key={email} className="bg-blue-600 gap-2">
                      {approver?.full_name || email}
                      <button
                        onClick={() => setSelectedApprovers(selectedApprovers.filter(e => e !== email))}
                        className="ml-1 hover:text-red-200"
                      >
                        ×
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label>Notes (optionnel)</Label>
            <Textarea
              value={approvalNotes}
              onChange={(e) => setApprovalNotes(e.target.value)}
              placeholder="Message pour les approbateurs..."
              rows={3}
            />
          </div>

          {/* Info */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-3">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-orange-700">
                  Le document sera mis en statut "En attente d'approbation" et les personnes sélectionnées recevront une notification.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button
            onClick={handleInitiateApproval}
            disabled={isSubmitting || selectedApprovers.length === 0}
            className="bg-green-600 hover:bg-green-700"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Envoi...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Envoyer pour approbation
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}