import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Clock, Download, Eye, CheckCircle, FileText, Upload, User } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function DocumentVersionHistory({ document, onClose }) {
  const queryClient = useQueryClient();

  const { data: versions = [], isLoading } = useQuery({
    queryKey: ['documentVersions', document.id],
    queryFn: () => base44.entities.DocumentVersion.filter({ document_id: document.id }),
  });

  // Trier par numéro de version décroissant
  const sortedVersions = [...versions].sort((a, b) => b.version_number - a.version_number);

  const restoreVersionMutation = useMutation({
    mutationFn: async (version) => {
      // Marquer toutes les versions comme non-courantes
      await Promise.all(
        versions.map(v => 
          base44.entities.DocumentVersion.update(v.id, { is_current: false })
        )
      );

      // Marquer cette version comme courante
      await base44.entities.DocumentVersion.update(version.id, { is_current: true });

      // Mettre à jour le document principal
      await base44.entities.Document.update(document.id, {
        file_url: version.file_url,
        current_version: version.version_number,
        last_modified_date: new Date().toISOString(),
        last_modified_by: (await base44.auth.me()).email
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      queryClient.invalidateQueries({ queryKey: ['documentVersions', document.id] });
    },
  });

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Historique des versions - {document.title}
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
            <p className="text-slate-600">Chargement de l'historique...</p>
          </div>
        ) : sortedVersions.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <FileText className="w-16 h-16 mx-auto mb-3 text-slate-300" />
            <p>Aucune version trouvée</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sortedVersions.map((version, index) => {
              const isCurrent = version.is_current || version.version_number === document.current_version;
              
              return (
                <Card 
                  key={version.id} 
                  className={`border-2 ${isCurrent ? 'border-blue-500 bg-blue-50' : 'border-slate-200'}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge className={isCurrent ? 'bg-blue-600' : 'bg-slate-600'}>
                            Version {version.version_number}
                          </Badge>
                          {isCurrent && (
                            <Badge className="bg-green-100 text-green-800 gap-1">
                              <CheckCircle className="w-3 h-3" />
                              Actuelle
                            </Badge>
                          )}
                          {index === 0 && !isCurrent && (
                            <Badge variant="outline" className="text-orange-600 border-orange-300">
                              Dernière version
                            </Badge>
                          )}
                        </div>

                        <div className="space-y-2">
                          <div className="flex items-center gap-2 text-sm">
                            <User className="w-4 h-4 text-slate-400" />
                            <span className="font-medium">{version.uploaded_by_name || version.uploaded_by}</span>
                          </div>

                          <div className="flex items-center gap-2 text-sm text-slate-600">
                            <Clock className="w-4 h-4 text-slate-400" />
                            <span>
                              {format(new Date(version.upload_date || version.created_date), "dd MMMM yyyy 'à' HH:mm", { locale: fr })}
                            </span>
                          </div>

                          {version.file_size && (
                            <div className="flex items-center gap-2 text-sm text-slate-600">
                              <FileText className="w-4 h-4 text-slate-400" />
                              <span>{(version.file_size / 1024).toFixed(2)} KB</span>
                            </div>
                          )}

                          {version.change_notes && (
                            <div className="mt-3 p-3 bg-slate-50 rounded-lg">
                              <p className="text-sm text-slate-700">
                                <span className="font-medium">Notes : </span>
                                {version.change_notes}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 ml-4">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => window.open(version.file_url, '_blank')}
                          className="gap-2"
                        >
                          <Eye className="w-4 h-4" />
                          Voir
                        </Button>

                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const link = document.createElement('a');
                            link.href = version.file_url;
                            link.download = `${document.title}_v${version.version_number}`;
                            link.click();
                          }}
                          className="gap-2"
                        >
                          <Download className="w-4 h-4" />
                          Télécharger
                        </Button>

                        {!isCurrent && (
                          <Button
                            size="sm"
                            onClick={() => {
                              if (window.confirm("Restaurer cette version comme version actuelle ?")) {
                                restoreVersionMutation.mutate(version);
                              }
                            }}
                            disabled={restoreVersionMutation.isPending}
                            className="gap-2 bg-green-600 hover:bg-green-700"
                          >
                            <Upload className="w-4 h-4" />
                            Restaurer
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <div className="flex justify-end pt-4 border-t">
          <Button onClick={onClose} variant="outline">
            Fermer
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}