import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, FileText, Upload, Check, X } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  processing: "bg-blue-100 text-blue-800 border-blue-200",
  completed: "bg-green-100 text-green-800 border-green-200",
  rejected: "bg-red-100 text-red-800 border-red-200",
};

const statusLabels = {
  pending: "En attente",
  processing: "En cours",
  completed: "Terminée",
  rejected: "Rejetée",
};

export default function DocumentRequestCard({ request, onStatusUpdate }) {
  const [showResponseForm, setShowResponseForm] = useState(false);
  const [responseNotes, setResponseNotes] = useState("");
  const [uploading, setUploading] = useState(false);
  const [documentUrl, setDocumentUrl] = useState("");

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setDocumentUrl(file_url);
    } catch (error) {
      alert("Échec du téléchargement du fichier");
    }
    setUploading(false);
  };

  const handleComplete = () => {
    if (!documentUrl) {
      alert("Veuillez télécharger le document");
      return;
    }
    onStatusUpdate(request.id, 'completed', responseNotes, documentUrl);
    setShowResponseForm(false);
    setResponseNotes("");
    setDocumentUrl("");
  };

  const handleReject = () => {
    if (!responseNotes.trim()) {
      alert("Veuillez fournir une raison pour le rejet");
      return;
    }
    onStatusUpdate(request.id, 'rejected', responseNotes, "");
    setShowResponseForm(false);
    setResponseNotes("");
  };

  const handleSetProcessing = () => {
    onStatusUpdate(request.id, 'processing', "", "");
  };

  return (
    <Card className="shadow-lg border-none overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{request.employee_name}</h3>
              <p className="text-sm text-slate-600">{request.employee_email}</p>
            </div>
          </div>
          <Badge className={`${statusColors[request.status]} border`}>
            {statusLabels[request.status]}
          </Badge>
        </div>

        <div className="space-y-3 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <FileText className="w-4 h-4 text-slate-400" />
            <span className="font-medium">Type de document:</span>
            <span>{request.document_type}</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-50">
            <p className="text-xs text-slate-500 mb-1">Raison:</p>
            <p className="text-sm text-slate-700">{request.reason}</p>
          </div>

          <p className="text-xs text-slate-500">
            Demandé le {format(new Date(request.created_date), 'dd/MM/yyyy à HH:mm')}
          </p>

          {request.response_notes && (
            <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
              <p className="text-xs font-medium text-blue-700 mb-1">Notes de réponse</p>
              <p className="text-sm text-slate-700">{request.response_notes}</p>
            </div>
          )}

          {request.document_url && (
            <Button
              variant="outline"
              className="w-full"
              onClick={() => window.open(request.document_url, '_blank')}
            >
              Télécharger le document
            </Button>
          )}
        </div>

        {request.status === 'pending' && (
          <div className="space-y-3">
            {!showResponseForm ? (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={handleSetProcessing}
                >
                  Marquer en cours
                </Button>
                <Button
                  size="sm"
                  className="flex-1 bg-green-600 hover:bg-green-700"
                  onClick={() => setShowResponseForm(true)}
                >
                  <Check className="w-4 h-4 mr-1" />
                  Terminer
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                  onClick={() => setShowResponseForm(true)}
                >
                  <X className="w-4 h-4 mr-1" />
                  Rejeter
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Télécharger le document (optionnel pour rejet)</Label>
                  <Input
                    type="file"
                    onChange={handleFileUpload}
                    disabled={uploading}
                  />
                  {uploading && <p className="text-xs text-slate-500">Téléchargement...</p>}
                  {documentUrl && <p className="text-xs text-green-600">✓ Fichier téléchargé</p>}
                </div>
                
                <Textarea
                  placeholder="Ajouter des notes..."
                  value={responseNotes}
                  onChange={(e) => setResponseNotes(e.target.value)}
                  rows={3}
                />
                
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={handleComplete}
                  >
                    Confirmer la complétion
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                    onClick={handleReject}
                  >
                    Confirmer le rejet
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setShowResponseForm(false);
                      setResponseNotes("");
                      setDocumentUrl("");
                    }}
                  >
                    Annuler
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {request.status === 'processing' && (
          <Button
            size="sm"
            className="w-full bg-green-600 hover:bg-green-700"
            onClick={() => setShowResponseForm(true)}
          >
            <Check className="w-4 h-4 mr-2" />
            Marquer comme terminé
          </Button>
        )}
      </CardContent>
    </Card>
  );
}