import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tag, Plus, X, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";

const suggestedTags = [
  "urgent", "confidentiel", "important", "à signer", "validé",
  "en attente", "archiver", "copie", "original", "temporaire",
  "formation", "onboarding", "contrat", "légal", "fiscal"
];

const tagColors = {
  urgent: "bg-red-100 text-red-800 border-red-200",
  confidentiel: "bg-purple-100 text-purple-800 border-purple-200",
  important: "bg-orange-100 text-orange-800 border-orange-200",
  validé: "bg-green-100 text-green-800 border-green-200",
  default: "bg-blue-100 text-blue-800 border-blue-200"
};

export function getTagColor(tag) {
  const lowerTag = tag.toLowerCase();
  return tagColors[lowerTag] || tagColors.default;
}

export default function DocumentTagManager({ document, onClose }) {
  const [tags, setTags] = useState(document.tags || []);
  const [newTag, setNewTag] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: (newTags) => base44.entities.Document.update(document.id, { tags: newTags }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documents'] });
      toast({ title: "Tags mis à jour ✅" });
      onClose();
    },
  });

  const addTag = (tag) => {
    const trimmedTag = tag.trim().toLowerCase();
    if (trimmedTag && !tags.includes(trimmedTag)) {
      setTags([...tags, trimmedTag]);
    }
    setNewTag("");
  };

  const removeTag = (tagToRemove) => {
    setTags(tags.filter(t => t !== tagToRemove));
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag(newTag);
    }
  };

  const handleSave = () => {
    updateMutation.mutate(tags);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5 text-blue-600" />
            Gérer les tags
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-sm text-slate-600">
            Document: <span className="font-medium">{document.title}</span>
          </p>

          {/* Tags actuels */}
          <div>
            <p className="text-sm font-medium mb-2">Tags actuels</p>
            {tags.length === 0 ? (
              <p className="text-sm text-slate-500 italic">Aucun tag</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {tags.map((tag, idx) => (
                  <Badge key={idx} className={`${getTagColor(tag)} border cursor-pointer group`}>
                    {tag}
                    <button
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Ajouter un tag */}
          <div>
            <p className="text-sm font-medium mb-2">Ajouter un tag</p>
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Nouveau tag..."
                className="flex-1"
              />
              <Button onClick={() => addTag(newTag)} disabled={!newTag.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Suggestions */}
          <div>
            <p className="text-sm font-medium mb-2">Suggestions</p>
            <div className="flex flex-wrap gap-1">
              {suggestedTags
                .filter(t => !tags.includes(t))
                .slice(0, 10)
                .map((tag) => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="cursor-pointer hover:bg-blue-50"
                    onClick={() => addTag(tag)}
                  >
                    <Plus className="w-3 h-3 mr-1" />
                    {tag}
                  </Badge>
                ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Annuler
            </Button>
            <Button 
              onClick={handleSave} 
              disabled={updateMutation.isPending}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <Check className="w-4 h-4 mr-2" />
              {updateMutation.isPending ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}