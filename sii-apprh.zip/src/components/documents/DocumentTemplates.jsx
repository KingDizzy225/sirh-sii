import { format } from "date-fns";
import { fr } from "date-fns/locale";

/**
 * Templates de documents RH pour génération automatique
 */

// Logo SII en base64 URL
const COMPANY_LOGO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ff4c7c10dd9052b64d91b1/50328bf82_LogoSII.jpg";

/**
 * Génère l'en-tête HTML avec logo pour les documents
 */
function generateDocumentHeader(company = "SII") {
  return `
    <div style="text-align: center; margin-bottom: 30px; border-bottom: 3px solid #1e40af; padding-bottom: 20px;">
      <img src="${COMPANY_LOGO_URL}" alt="${company}" style="height: 80px; margin-bottom: 10px;" />
      <div style="font-size: 12px; color: #64748b; margin-top: 5px;">
        Ressources Humaines
      </div>
    </div>
  `;
}

/**
 * Génère le pied de page HTML pour les documents
 */
function generateDocumentFooter(company = "SII") {
  return `
    <div style="margin-top: 50px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; font-size: 10px; color: #94a3b8;">
      <p>${company} - Direction des Ressources Humaines</p>
      <p>Document généré automatiquement le ${format(new Date(), "d MMMM yyyy 'à' HH:mm", { locale: fr })}</p>
    </div>
  `;
}

/**
 * Génère un contrat de travail (HTML)
 */
export function generateEmploymentContract(employee, company = "SII") {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });
  const hireDate = format(new Date(employee.hire_date), 'd MMMM yyyy', { locale: fr });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.6; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 18pt; margin-bottom: 30px; }
    h2 { color: #334155; font-size: 12pt; margin-top: 25px; border-bottom: 1px solid #e2e8f0; padding-bottom: 5px; }
    .parties { margin: 20px 0; }
    .signature-block { margin-top: 60px; display: flex; justify-content: space-between; }
    .signature-box { width: 45%; text-align: center; }
    .signature-line { border-top: 1px solid #334155; margin-top: 60px; padding-top: 10px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>CONTRAT DE TRAVAIL À DURÉE INDÉTERMINÉE</h1>
  
  <div class="parties">
    <p><strong>Entre les soussignés :</strong></p>
    <p><strong>${company}</strong><br>
    Représentée par : [Nom du représentant légal]<br>
    Ci-après dénommée « l'Employeur »</p>
    
    <p style="text-align: center; margin: 20px 0;"><em>D'une part,</em></p>
    
    <p><strong>Et :</strong></p>
    <p><strong>${employee.full_name}</strong><br>
    Né(e) le : ${employee.date_of_birth ? format(new Date(employee.date_of_birth), 'd MMMM yyyy', { locale: fr }) : '[Date de naissance]'}<br>
    Nationalité : ${employee.nationality || '[Nationalité]'}<br>
    Adresse : ${employee.address || '[Adresse]'}, ${employee.postal_code || ''} ${employee.city || ''}</p>
    
    <p>Ci-après dénommé(e) « le Salarié »</p>
    <p style="text-align: center; margin: 20px 0;"><em>D'autre part,</em></p>
  </div>
  
  <p style="text-align: center; font-weight: bold; margin: 30px 0;">IL A ÉTÉ CONVENU ET ARRÊTÉ CE QUI SUIT :</p>
  
  <h2>ARTICLE 1 - ENGAGEMENT</h2>
  <p>L'Employeur engage le Salarié qui accepte, en qualité de : <strong>${employee.position}</strong></p>
  
  <h2>ARTICLE 2 - DURÉE DU CONTRAT</h2>
  <p>Le présent contrat est conclu pour une durée indéterminée.<br>
  Il prendra effet le : <strong>${hireDate}</strong></p>
  
  ${employee.probation_end_date ? `
  <h2>ARTICLE 3 - PÉRIODE D'ESSAI</h2>
  <p>Une période d'essai de ${Math.ceil((new Date(employee.probation_end_date) - new Date(employee.hire_date)) / (1000 * 60 * 60 * 24 * 30))} mois est prévue, soit jusqu'au ${format(new Date(employee.probation_end_date), 'd MMMM yyyy', { locale: fr })}.</p>
  ` : ''}
  
  <h2>ARTICLE 4 - FONCTIONS</h2>
  <p>Le Salarié exercera les fonctions de <strong>${employee.position}</strong> au sein du département <strong>${employee.department}</strong>.</p>
  <p>Il sera placé sous l'autorité de ${employee.manager_name || '[Manager]'}.</p>
  
  <h2>ARTICLE 5 - LIEU DE TRAVAIL</h2>
  <p>Le lieu de travail est fixé à : ${employee.work_location || '[Lieu de travail]'}</p>
  
  <h2>ARTICLE 6 - RÉMUNÉRATION</h2>
  <p>La rémunération brute annuelle du Salarié est fixée à <strong>${employee.salary ? employee.salary.toLocaleString() : '[Montant]'} FCFA</strong>.</p>
  <p>Cette rémunération sera versée mensuellement.</p>
  
  <h2>ARTICLE 7 - HORAIRES DE TRAVAIL</h2>
  <p>Le Salarié est soumis à un horaire de ${employee.employment_type === 'full_time' ? '40 heures' : '[X heures]'} par semaine.</p>
  
  <h2>ARTICLE 8 - CONGÉS PAYÉS</h2>
  <p>Le Salarié bénéficiera des congés payés conformément à la législation en vigueur.</p>
  
  <h2>ARTICLE 9 - OBLIGATIONS DU SALARIÉ</h2>
  <p>Le Salarié s'engage à :</p>
  <ul>
    <li>Respecter le règlement intérieur de l'entreprise</li>
    <li>Faire preuve de loyauté et de discrétion professionnelle</li>
    <li>Atteindre les objectifs fixés dans le cadre de ses fonctions</li>
  </ul>
  
  <h2>ARTICLE 10 - CONFIDENTIALITÉ</h2>
  <p>Le Salarié s'engage à garder strictement confidentielle toute information dont il aurait connaissance dans l'exercice de ses fonctions.</p>
  
  <p style="margin-top: 40px;">Fait à [Ville], le ${today}</p>
  <p>En deux exemplaires originaux</p>
  
  <div class="signature-block">
    <div class="signature-box">
      <div class="signature-line">L'Employeur</div>
    </div>
    <div class="signature-box">
      <div class="signature-line">Le Salarié</div>
    </div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère une attestation de travail (HTML)
 */
export function generateWorkCertificate(employee, company = "SII") {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });
  const hireDate = format(new Date(employee.hire_date), 'd MMMM yyyy', { locale: fr });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.8; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 20pt; margin: 40px 0; text-transform: uppercase; letter-spacing: 2px; }
    .content { margin: 30px 0; text-align: justify; }
    .info-box { background: #f8fafc; border-left: 4px solid #1e40af; padding: 15px 20px; margin: 20px 0; }
    .signature-section { margin-top: 60px; }
    .signature-line { border-top: 1px solid #334155; width: 250px; margin-top: 80px; padding-top: 10px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>Attestation de Travail</h1>
  
  <div class="content">
    <p>Nous soussignés, <strong>${company}</strong>, certifions par la présente que :</p>
    
    <div class="info-box">
      <p><strong>Nom et Prénom :</strong> ${employee.full_name}</p>
      <p><strong>Né(e) le :</strong> ${employee.date_of_birth ? format(new Date(employee.date_of_birth), 'd MMMM yyyy', { locale: fr }) : '[Date de naissance]'}</p>
      <p><strong>Nationalité :</strong> ${employee.nationality || '[Nationalité]'}</p>
    </div>
    
    <p>Est employé(e) au sein de notre entreprise depuis le <strong>${hireDate}</strong> en qualité de <strong>${employee.position}</strong>.</p>
    
    <div class="info-box">
      <p><strong>Département :</strong> ${employee.department}</p>
      <p><strong>Poste occupé :</strong> ${employee.position}</p>
      <p><strong>Type de contrat :</strong> ${employee.employment_type === 'full_time' ? 'CDI à temps plein' : 
                     employee.employment_type === 'part_time' ? 'CDI à temps partiel' :
                     employee.employment_type === 'contract' ? 'CDD' : 'Autre'}</p>
    </div>
    
    <p style="margin-top: 30px;">La présente attestation est délivrée à l'intéressé(e) pour servir et valoir ce que de droit.</p>
  </div>
  
  <div class="signature-section">
    <p>Fait à [Ville], le ${today}</p>
    <p style="margin-top: 20px;">Pour <strong>${company}</strong></p>
    <p>Le Directeur des Ressources Humaines</p>
    <div class="signature-line">[Signature et cachet]</div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère un certificat de salaire (HTML)
 */
export function generateSalaryCertificate(employee, company = "SII", year = new Date().getFullYear()) {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.6; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 18pt; margin: 30px 0; }
    h2 { color: #334155; font-size: 14pt; background: #f1f5f9; padding: 10px 15px; margin-top: 25px; }
    table { width: 100%; border-collapse: collapse; margin: 15px 0; }
    td { padding: 10px 15px; border-bottom: 1px solid #e2e8f0; }
    td:first-child { color: #64748b; width: 40%; }
    td:last-child { font-weight: 600; }
    .salary-highlight { background: #dbeafe; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
    .salary-amount { font-size: 24pt; color: #1e40af; font-weight: bold; }
    .signature-line { border-top: 1px solid #334155; width: 250px; margin-top: 80px; padding-top: 10px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>CERTIFICAT DE SALAIRE ${year}</h1>
  
  <h2>📋 Informations Employé</h2>
  <table>
    <tr><td>Nom et Prénom</td><td>${employee.full_name}</td></tr>
    <tr><td>N° Employé</td><td>${employee.employee_id || 'N/A'}</td></tr>
    <tr><td>Département</td><td>${employee.department}</td></tr>
    <tr><td>Poste</td><td>${employee.position}</td></tr>
    <tr><td>Type d'emploi</td><td>${employee.employment_type === 'full_time' ? 'Temps plein' : 
                   employee.employment_type === 'part_time' ? 'Temps partiel' : 'Autre'}</td></tr>
  </table>
  
  <h2>💰 Informations Salariales</h2>
  <div class="salary-highlight">
    <p style="margin: 0; color: #64748b;">Salaire de base annuel</p>
    <p class="salary-amount">${employee.salary ? employee.salary.toLocaleString() : '[Montant]'} FCFA</p>
    <p style="margin: 10px 0 0; color: #64748b;">Soit ${employee.salary ? Math.round(employee.salary / 12).toLocaleString() : '[Montant]'} FCFA / mois</p>
  </div>
  
  <p style="margin-top: 40px;">Ce certificat est délivré pour servir et valoir ce que de droit.</p>
  
  <div style="margin-top: 50px;">
    <p>Fait à [Ville], le ${today}</p>
    <p style="margin-top: 20px;">Le Responsable RH</p>
    <div class="signature-line">[Signature et cachet]</div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère une attestation de présence (HTML)
 */
export function generateAttendanceCertificate(employee, startDate, endDate, company = "SII") {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });
  const start = startDate ? format(new Date(startDate), 'd MMMM yyyy', { locale: fr }) : '[Date de début]';
  const end = endDate ? format(new Date(endDate), 'd MMMM yyyy', { locale: fr }) : '[Date de fin]';

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.8; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 20pt; margin: 40px 0; text-transform: uppercase; }
    .content { margin: 30px 0; text-align: justify; }
    .employee-info { background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 20px; margin: 25px 0; }
    .period-box { background: #dbeafe; border-radius: 8px; padding: 15px 25px; margin: 25px 0; text-align: center; }
    .signature-line { border-top: 1px solid #334155; width: 250px; margin-top: 80px; padding-top: 10px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>Attestation de Présence</h1>
  
  <div class="content">
    <p>Nous soussignés, <strong>${company}</strong>, attestons que :</p>
    
    <div class="employee-info">
      <p><strong>Nom et Prénom :</strong> ${employee.full_name}</p>
      <p><strong>Poste :</strong> ${employee.position}</p>
      <p><strong>Département :</strong> ${employee.department}</p>
    </div>
    
    <p>A été présent(e) et a exercé ses fonctions de manière régulière et satisfaisante durant la période :</p>
    
    <div class="period-box">
      <p style="margin: 0; font-size: 14pt;"><strong>Du ${start} au ${end}</strong></p>
    </div>
    
    <p>Durant cette période, l'employé(e) a rempli ses obligations professionnelles avec assiduité et sérieux.</p>
    
    <p style="margin-top: 30px;">La présente attestation est délivrée à la demande de l'intéressé(e) pour servir et valoir ce que de droit.</p>
  </div>
  
  <div style="margin-top: 50px;">
    <p>Fait à [Ville], le ${today}</p>
    <p style="margin-top: 20px;">Pour <strong>${company}</strong></p>
    <p>Le Responsable RH</p>
    <div class="signature-line">[Signature et cachet]</div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère une lettre de recommandation (HTML)
 */
export function generateRecommendationLetter(employee, manager, company = "SII") {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });
  const hireDate = format(new Date(employee.hire_date), 'd MMMM yyyy', { locale: fr });

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.8; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 18pt; margin: 30px 0; }
    .content { margin: 30px 0; text-align: justify; }
    .qualities-list { background: #fef3c7; border-radius: 8px; padding: 20px 30px; margin: 25px 0; }
    .qualities-list li { margin: 10px 0; }
    .signature-section { margin-top: 50px; }
    .contact-info { background: #f1f5f9; padding: 15px; border-radius: 8px; margin-top: 30px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>Lettre de Recommandation</h1>
  
  <p style="text-align: right; color: #64748b;">${today}</p>
  
  <div class="content">
    <p><strong>À qui de droit,</strong></p>
    
    <p>J'ai le plaisir de recommander <strong>${employee.full_name}</strong> qui a travaillé au sein de notre entreprise en tant que <strong>${employee.position}</strong> dans le département <strong>${employee.department}</strong> depuis le ${hireDate}.</p>
    
    <p>Durant sa collaboration avec notre entreprise, ${employee.full_name} a fait preuve de :</p>
    
    <div class="qualities-list">
      <ul>
        <li>✨ Professionnalisme et rigueur dans l'exécution de ses missions</li>
        <li>🎯 Excellentes compétences techniques dans son domaine</li>
        <li>🤝 Esprit d'équipe et capacités relationnelles remarquables</li>
        <li>📈 Capacité d'adaptation et d'apprentissage</li>
        <li>💪 Engagement et motivation</li>
      </ul>
    </div>
    
    <p>${employee.full_name} a contribué de manière significative aux projets de notre département et a toujours fait preuve d'une grande fiabilité.</p>
    
    <p><strong>Je recommande vivement ${employee.full_name}</strong> pour tout poste dans son domaine d'expertise et je reste à votre disposition pour tout complément d'information.</p>
  </div>
  
  <div class="signature-section">
    <p>Cordialement,</p>
    <p style="margin-top: 40px;">
      <strong>${manager?.full_name || '[Nom du Manager]'}</strong><br>
      ${manager?.position || '[Poste du Manager]'}<br>
      ${company}
    </p>
    
    <div class="contact-info">
      <p style="margin: 5px 0;"><strong>Contact :</strong> ${manager?.email || '[Email]'}</p>
      <p style="margin: 5px 0;"><strong>Téléphone :</strong> ${manager?.phone || '[Téléphone]'}</p>
    </div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère une fiche de poste (HTML)
 */
export function generateJobDescription(employee, company = "SII") {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 11pt; line-height: 1.6; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 18pt; margin: 30px 0; }
    h2 { color: white; background: #1e40af; font-size: 12pt; padding: 8px 15px; margin: 25px 0 15px; border-radius: 4px; }
    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
    td { padding: 8px 12px; border: 1px solid #e2e8f0; }
    td:first-child { background: #f8fafc; width: 35%; font-weight: 600; }
    .skills-grid { display: flex; gap: 20px; margin: 15px 0; }
    .skills-box { flex: 1; background: #f8fafc; border-radius: 8px; padding: 15px; }
    .skills-box h3 { font-size: 11pt; color: #334155; margin: 0 0 10px; }
    ul { margin: 10px 0; padding-left: 20px; }
    li { margin: 5px 0; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>FICHE DE POSTE</h1>
  
  <h2>📋 Identification du Poste</h2>
  <table>
    <tr><td>Intitulé du poste</td><td><strong>${employee.position}</strong></td></tr>
    <tr><td>Département</td><td>${employee.department}</td></tr>
    <tr><td>Lieu de travail</td><td>${employee.work_location || '[Lieu]'}</td></tr>
    <tr><td>Type de contrat</td><td>${employee.employment_type === 'full_time' ? 'CDI - Temps plein' : 
                     employee.employment_type === 'part_time' ? 'CDI - Temps partiel' : 'Autre'}</td></tr>
  </table>
  
  <h2>👤 Rattachement Hiérarchique</h2>
  <table>
    <tr><td>Manager direct</td><td>${employee.manager_name || '[Manager]'}</td></tr>
  </table>
  
  <h2>🎯 Mission Principale</h2>
  <p>[Description de la mission principale du poste]</p>
  
  <h2>📝 Activités et Responsabilités</h2>
  <ul>
    <li>[Activité 1]</li>
    <li>[Activité 2]</li>
    <li>[Activité 3]</li>
    <li>[Activité 4]</li>
    <li>[Activité 5]</li>
  </ul>
  
  <h2>💡 Compétences Requises</h2>
  <div class="skills-grid">
    <div class="skills-box">
      <h3>Compétences techniques</h3>
      <ul>
        ${employee.skills && employee.skills.length > 0 
          ? employee.skills.map(s => `<li>${s}</li>`).join('') 
          : '<li>[Compétence technique 1]</li><li>[Compétence technique 2]</li>'}
      </ul>
    </div>
    <div class="skills-box">
      <h3>Compétences comportementales</h3>
      <ul>
        <li>Travail en équipe</li>
        <li>Communication</li>
        <li>Organisation</li>
        <li>Autonomie</li>
      </ul>
    </div>
  </div>
  
  <h2>🎓 Formation et Expérience</h2>
  <table>
    <tr><td>Formation</td><td>[Niveau de formation requis]</td></tr>
    <tr><td>Expérience</td><td>[Années d'expérience requises]</td></tr>
    ${employee.languages && employee.languages.length > 0 
      ? `<tr><td>Langues</td><td>${employee.languages.join(', ')}</td></tr>` 
      : ''}
  </table>
  
  <h2>⚙️ Conditions de Travail</h2>
  <table>
    <tr><td>Horaires</td><td>${employee.employment_type === 'full_time' ? '40 heures/semaine' : '[Horaires]'}</td></tr>
    <tr><td>Rémunération</td><td>${employee.salary ? employee.salary.toLocaleString() + ' FCFA/an' : '[À définir]'}</td></tr>
  </table>
  
  <p style="margin-top: 30px; color: #64748b; font-size: 10pt;">Date d'établissement : ${format(new Date(), 'd MMMM yyyy', { locale: fr })}</p>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Génère une attestation de fin de contrat (HTML)
 */
export function generateEndOfContractCertificate(employee, endDate, reason, company = "SII") {
  const today = format(new Date(), 'd MMMM yyyy', { locale: fr });
  const hireDate = format(new Date(employee.hire_date), 'd MMMM yyyy', { locale: fr });
  const terminationDate = endDate ? format(new Date(endDate), 'd MMMM yyyy', { locale: fr }) : '[Date de fin]';

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Calibri', Arial, sans-serif; font-size: 12pt; line-height: 1.8; color: #1e293b; margin: 40px; }
    h1 { color: #1e40af; text-align: center; font-size: 18pt; margin: 40px 0; text-transform: uppercase; }
    .content { margin: 30px 0; text-align: justify; }
    .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin: 25px 0; }
    .period-box { background: #fef2f2; border: 1px solid #fca5a5; border-radius: 8px; padding: 15px 25px; margin: 25px 0; }
    .signature-line { border-top: 1px solid #334155; width: 250px; margin-top: 80px; padding-top: 10px; }
  </style>
</head>
<body>
  ${generateDocumentHeader(company)}
  
  <h1>Certificat de Fin de Contrat</h1>
  
  <div class="content">
    <p>Nous soussignés, <strong>${company}</strong>, certifions que :</p>
    
    <div class="info-box">
      <p><strong>Nom et Prénom :</strong> ${employee.full_name}</p>
      <p><strong>Né(e) le :</strong> ${employee.date_of_birth ? format(new Date(employee.date_of_birth), 'd MMMM yyyy', { locale: fr }) : '[Date de naissance]'}</p>
      <p><strong>Nationalité :</strong> ${employee.nationality || '[Nationalité]'}</p>
    </div>
    
    <div class="period-box">
      <p style="margin: 0;"><strong>Période d'emploi :</strong> du ${hireDate} au ${terminationDate}</p>
      <p style="margin: 10px 0 0;"><strong>Motif de fin de contrat :</strong> ${reason || '[À préciser]'}</p>
    </div>
    
    <div class="info-box">
      <p><strong>Poste occupé :</strong> ${employee.position}</p>
      <p><strong>Département :</strong> ${employee.department}</p>
    </div>
    
    <p>Durant sa collaboration, ${employee.full_name} s'est acquitté(e) de ses fonctions de manière satisfaisante.</p>
    
    <p style="margin-top: 30px;">La présente attestation est délivrée pour servir et valoir ce que de droit.</p>
  </div>
  
  <div style="margin-top: 50px;">
    <p>Fait à [Ville], le ${today}</p>
    <p style="margin-top: 20px;">Pour <strong>${company}</strong></p>
    <p>Le Responsable RH</p>
    <div class="signature-line">[Signature et cachet]</div>
  </div>
  
  ${generateDocumentFooter(company)}
</body>
</html>
`;
}

/**
 * Liste de tous les templates disponibles
 */
export const DOCUMENT_TEMPLATES = {
  employment_contract: {
    name: "Contrat de Travail",
    description: "Contrat de travail à durée indéterminée",
    category: "Contrat",
    generator: generateEmploymentContract,
    requiredFields: ['full_name', 'hire_date', 'position', 'department', 'salary']
  },
  work_certificate: {
    name: "Attestation de Travail",
    description: "Attestation confirmant l'emploi actuel",
    category: "Attestation",
    generator: generateWorkCertificate,
    requiredFields: ['full_name', 'hire_date', 'position', 'department']
  },
  salary_certificate: {
    name: "Certificat de Salaire",
    description: "Certificat détaillant la rémunération",
    category: "Certificat",
    generator: generateSalaryCertificate,
    requiredFields: ['full_name', 'employee_id', 'position', 'salary']
  },
  attendance_certificate: {
    name: "Attestation de Présence",
    description: "Attestation de présence pour une période donnée",
    category: "Attestation",
    generator: generateAttendanceCertificate,
    requiredFields: ['full_name', 'position', 'department']
  },
  recommendation_letter: {
    name: "Lettre de Recommandation",
    description: "Lettre de recommandation professionnelle",
    category: "Autre",
    generator: generateRecommendationLetter,
    requiredFields: ['full_name', 'hire_date', 'position', 'department']
  },
  job_description: {
    name: "Fiche de Poste",
    description: "Description détaillée du poste",
    category: "Autre",
    generator: generateJobDescription,
    requiredFields: ['position', 'department']
  },
  end_of_contract: {
    name: "Certificat de Fin de Contrat",
    description: "Certificat de fin de collaboration",
    category: "Certificat",
    generator: generateEndOfContractCertificate,
    requiredFields: ['full_name', 'hire_date', 'position', 'department']
  }
};

/**
 * Génère un document basé sur un template
 */
export async function generateDocumentFromTemplate(templateId, employee, additionalData = {}) {
  const template = DOCUMENT_TEMPLATES[templateId];
  
  if (!template) {
    throw new Error("Template non trouvé");
  }

  // Vérifier les champs requis
  const missingFields = template.requiredFields.filter(field => !employee[field]);
  if (missingFields.length > 0) {
    throw new Error(`Champs manquants: ${missingFields.join(', ')}`);
  }

  // Générer le contenu
  const content = template.generator(employee, additionalData.company, ...Object.values(additionalData));

  return {
    title: `${template.name} - ${employee.full_name}`,
    content,
    category: template.category,
    template_id: templateId
  };
}