import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, Download, User, Calendar, Trash2, Eye, Clock, Share2, Upload, CheckCircle, PenTool, Tag, History } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";
import DocumentTagManager, { getTagColor } from "./DocumentTagManager";

const typeColors = {
  "Contrat": "bg-blue-100 text-blue-800 border-blue-200",
  "Carte d'identité": "bg-green-100 text-green-800 border-green-200",
  "CV": "bg-purple-100 text-purple-800 border-purple-200",
  "Certificat": "bg-orange-100 text-orange-800 border-orange-200",
  "Attestation": "bg-pink-100 text-pink-800 border-pink-200",
  "Fiche de paie": "bg-yellow-100 text-yellow-800 border-yellow-200",
  "Autre": "bg-gray-100 text-gray-800 border-gray-200",
};

const statusColors = {
  "brouillon": "bg-gray-100 text-gray-800",
  "actif": "bg-green-100 text-green-800",
  "archivé": "bg-blue-100 text-blue-800",
  "obsolète": "bg-red-100 text-red-800",
};

const typeIcons = {
  "Contrat": "📄",
  "Carte d'identité": "🪪",
  "CV": "📋",
  "Certificat": "🎓",
  "Attestation": "✅",
  "Fiche de paie": "💰",
  "Autre": "📁",
};

export default function DocumentCard({ 
  document, 
  onDelete, 
  onViewHistory, 
  onShare, 
  onUploadNewVersion,
  onRequestApproval,
  onRequestSignature,
  onViewAuditTrail,
  canDelete = true,
  canShare = true
}) {
  const [showTagManager, setShowTagManager] = useState(false);
  const typeColor = typeColors[document.document_type] || typeColors["Autre"];
  const statusColor = statusColors[document.status] || statusColors["actif"];
  const typeIcon = typeIcons[document.document_type] || typeIcons["Autre"];

  return (
    <Card className="hover:shadow-xl transition-all duration-300 border-none shadow-lg group">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center shadow-md text-2xl">
            {typeIcon}
          </div>
          <div className="flex items-center gap-2">
            <Badge className={`${typeColor} border`}>
              {document.document_type}
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => window.open(document.file_url, '_blank')}>
                  <Eye className="w-4 h-4 mr-2" />
                  Visualiser
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => window.open(document.file_url, '_blank')}>
                  <Download className="w-4 h-4 mr-2" />
                  Télécharger
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => onViewHistory(document)}>
                  <Clock className="w-4 h-4 mr-2" />
                  Historique des versions
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onUploadNewVersion(document)}>
                  <Upload className="w-4 h-4 mr-2" />
                  Nouvelle version
                </DropdownMenuItem>
                {canShare && (
                  <DropdownMenuItem onClick={() => onShare(document)}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Partager
                  </DropdownMenuItem>
                )}
                {onRequestApproval && (
                  <DropdownMenuItem onClick={() => onRequestApproval(document)}>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Demander approbation
                  </DropdownMenuItem>
                )}
                {onRequestSignature && (
                  <DropdownMenuItem onClick={() => onRequestSignature(document)}>
                    <PenTool className="w-4 h-4 mr-2" />
                    Demander signature(s)
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => setShowTagManager(true)}>
                  <Tag className="w-4 h-4 mr-2" />
                  Gérer les tags
                </DropdownMenuItem>
                {onViewAuditTrail && (
                  <DropdownMenuItem onClick={() => onViewAuditTrail(document)}>
                    <History className="w-4 h-4 mr-2" />
                    Audit Trail
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                {canDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(document.id)}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Supprimer
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-2">
          <Badge className={statusColor}>
            {document.status || 'actif'}
          </Badge>
          {document.current_version > 1 && (
            <Badge variant="outline" className="text-xs">
              v{document.current_version}
            </Badge>
          )}
          {document.is_shared && (
            <Badge variant="outline" className="text-xs gap-1 bg-blue-50 text-blue-700 border-blue-200">
              <Share2 className="w-3 h-3" />
              Partagé
            </Badge>
          )}
          {document.status === "en_attente_signature" && (
            <Badge className="bg-yellow-600 text-xs gap-1">
              <PenTool className="w-3 h-3" />
              En attente signature
            </Badge>
          )}
          {document.status === "signé" && (
            <Badge className="bg-green-600 text-xs gap-1">
              <CheckCircle className="w-3 h-3" />
              Signé
            </Badge>
          )}
        </div>

        <h3 className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 min-h-[3.5rem]">
          {document.title}
        </h3>
        
        {document.description && (
          <p className="text-sm text-slate-600 mb-4 line-clamp-2 min-h-[2.5rem]">
            {document.description}
          </p>
        )}

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <User className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span className="truncate">{document.employee_name}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <span>{format(new Date(document.upload_date || document.created_date), 'dd/MM/yyyy', { locale: fr })}</span>
          </div>
          {document.last_modified_date && (
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Clock className="w-4 h-4 text-slate-400 flex-shrink-0" />
              <span className="text-xs">
                Modifié le {format(new Date(document.last_modified_date), "dd/MM/yyyy 'à' HH:mm", { locale: fr })}
              </span>
            </div>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => window.open(document.file_url, '_blank')}
          >
            <Eye className="w-4 h-4 mr-2" />
            Voir
          </Button>
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              const link = document.createElement('a');
              link.href = document.file_url;
              link.download = document.title;
              link.click();
            }}
          >
            <Download className="w-4 h-4 mr-2" />
            Télécharger
          </Button>
        </div>

        {/* Tags section */}
        <div className="mt-4 pt-4 border-t border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500 flex items-center gap-1">
              <Tag className="w-3 h-3" />
              Tags
            </span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-6 text-xs"
              onClick={() => setShowTagManager(true)}
            >
              + Ajouter
            </Button>
          </div>
          {document.tags && document.tags.length > 0 ? (
            <div className="flex flex-wrap gap-1">
              {document.tags.map((tag, index) => (
                <Badge key={index} className={`${getTagColor(tag)} border text-xs`}>
                  {tag}
                </Badge>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 italic">Aucun tag</p>
          )}
        </div>

        {document.uploaded_by && (
          <div className="mt-2 text-xs text-slate-500">
            Téléchargé par: {document.uploaded_by}
          </div>
        )}

        {/* Tag Manager Modal */}
        {showTagManager && (
          <DocumentTagManager
            document={document}
            onClose={() => setShowTagManager(false)}
          />
        )}
      </CardContent>
    </Card>
  );
}