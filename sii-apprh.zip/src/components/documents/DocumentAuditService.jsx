import { base44 } from "@/api/base44Client";

/**
 * Service pour enregistrer les actions d'audit sur les documents
 */
export async function logDocumentAction({
  document,
  action,
  actor,
  targetEmail = null,
  targetName = null,
  details = {}
}) {
  try {
    await base44.entities.DocumentAuditLog.create({
      document_id: document.id,
      document_title: document.title,
      document_type: document.document_type,
      employee_email: document.employee_email,
      department: document.department || null,
      action,
      actor_email: actor.email,
      actor_name: actor.full_name || actor.email,
      target_email: targetEmail,
      target_name: targetName,
      details,
      user_agent: navigator.userAgent,
    });
  } catch (error) {
    console.error("Error logging document action:", error);
  }
}

// Actions prédéfinies
export const AUDIT_ACTIONS = {
  CREATED: "created",
  VIEWED: "viewed",
  DOWNLOADED: "downloaded",
  MODIFIED: "modified",
  SHARED: "shared",
  UNSHARED: "unshared",
  DELETED: "deleted",
  ARCHIVED: "archived",
  RESTORED: "restored",
  VERSION_ADDED: "version_added",
  TAGS_UPDATED: "tags_updated",
  APPROVAL_REQUESTED: "approval_requested",
  APPROVED: "approved",
  REJECTED: "rejected",
  SIGNATURE_REQUESTED: "signature_requested",
  SIGNED: "signed",
  SIGNATURE_DECLINED: "signature_declined",
};

export const ACTION_LABELS = {
  created: "Création",
  viewed: "Consultation",
  downloaded: "Téléchargement",
  modified: "Modification",
  shared: "Partage",
  unshared: "Fin de partage",
  deleted: "Suppression",
  archived: "Archivage",
  restored: "Restauration",
  version_added: "Nouvelle version",
  tags_updated: "Tags modifiés",
  approval_requested: "Demande d'approbation",
  approved: "Approuvé",
  rejected: "Rejeté",
  signature_requested: "Demande de signature",
  signed: "Signé",
  signature_declined: "Signature refusée",
};

export const ACTION_COLORS = {
  created: "bg-green-100 text-green-800",
  viewed: "bg-gray-100 text-gray-800",
  downloaded: "bg-blue-100 text-blue-800",
  modified: "bg-yellow-100 text-yellow-800",
  shared: "bg-purple-100 text-purple-800",
  unshared: "bg-purple-100 text-purple-800",
  deleted: "bg-red-100 text-red-800",
  archived: "bg-slate-100 text-slate-800",
  restored: "bg-green-100 text-green-800",
  version_added: "bg-blue-100 text-blue-800",
  tags_updated: "bg-indigo-100 text-indigo-800",
  approval_requested: "bg-orange-100 text-orange-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
  signature_requested: "bg-yellow-100 text-yellow-800",
  signed: "bg-green-100 text-green-800",
  signature_declined: "bg-red-100 text-red-800",
};