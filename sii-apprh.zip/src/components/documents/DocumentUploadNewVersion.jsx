import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Upload, CheckCircle, X, FileText } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DocumentUploadNewVersion({ document, currentVersion, onSuccess, onCancel }) {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileUrl, setFileUrl] = useState("");
  const [changeNotes, setChangeNotes] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    setUploading(true);
    setUploadProgress(0);

    try {
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);

      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setFileUrl(file_url);
    } catch (error) {
      console.error("Upload error:", error);
      alert("Échec du téléchargement du fichier");
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!fileUrl) {
      alert("Veuillez uploader un fichier");
      return;
    }

    try {
      const newVersionNumber = currentVersion + 1;

      // Créer la nouvelle version
      await base44.entities.DocumentVersion.create({
        document_id: document.id,
        version_number: newVersionNumber,
        file_url: fileUrl,
        uploaded_by: user.email,
        uploaded_by_name: user.full_name || user.email,
        upload_date: new Date().toISOString(),
        change_notes: changeNotes,
        file_size: selectedFile?.size || 0,
        is_current: true
      });

      // Marquer les anciennes versions comme non-courantes
      const oldVersions = await base44.entities.DocumentVersion.filter({ 
        document_id: document.id 
      });
      
      await Promise.all(
        oldVersions.map(v => 
          base44.entities.DocumentVersion.update(v.id, { is_current: false })
        )
      );

      // Mettre à jour le document principal
      await base44.entities.Document.update(document.id, {
        file_url: fileUrl,
        current_version: newVersionNumber,
        last_modified_date: new Date().toISOString(),
        last_modified_by: user.email
      });

      onSuccess();
    } catch (error) {
      console.error("Error creating new version:", error);
      alert("Erreur lors de la création de la nouvelle version");
    }
  };

  const getFileSize = (size) => {
    if (!size) return '';
    if (size < 1024) return size + ' B';
    if (size < 1024 * 1024) return (size / 1024).toFixed(2) + ' KB';
    return (size / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Nouvelle version - {document.title}
          </DialogTitle>
        </DialogHeader>

        <Alert className="bg-blue-50 border-blue-200">
          <FileText className="w-4 h-4 text-blue-600" />
          <AlertDescription className="text-blue-800 text-sm">
            Version actuelle : <strong>v{currentVersion}</strong>
            <br />
            Nouvelle version : <strong>v{currentVersion + 1}</strong>
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="file">Fichier de la nouvelle version *</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors">
              <Input
                id="file"
                type="file"
                onChange={handleFileUpload}
                className="hidden"
                disabled={uploading}
                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
              />
              
              {!fileUrl ? (
                <label htmlFor="file" className="cursor-pointer block">
                  <Upload className="w-12 h-12 mx-auto mb-3 text-slate-400" />
                  {uploading ? (
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600 font-medium">
                        Téléchargement en cours...
                      </p>
                      <Progress value={uploadProgress} className="w-full" />
                      <p className="text-xs text-slate-500">{uploadProgress}%</p>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm text-slate-600 font-medium mb-1">
                        Cliquez pour sélectionner un fichier
                      </p>
                      <p className="text-xs text-slate-500">
                        PDF, Word, Images (Max 10MB)
                      </p>
                    </>
                  )}
                </label>
              ) : (
                <div className="space-y-3">
                  <CheckCircle className="w-12 h-12 mx-auto text-green-600" />
                  <div>
                    <p className="text-sm text-green-600 font-medium mb-1">
                      ✓ Fichier téléchargé avec succès!
                    </p>
                    {selectedFile && (
                      <p className="text-xs text-slate-500">
                        {selectedFile.name} ({getFileSize(selectedFile.size)})
                      </p>
                    )}
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setFileUrl("");
                      setSelectedFile(null);
                      setUploadProgress(0);
                    }}
                    className="gap-2"
                  >
                    <X className="w-4 h-4" />
                    Changer de fichier
                  </Button>
                </div>
              )}
            </div>
          </div>

          {/* Change Notes */}
          <div className="space-y-2">
            <Label htmlFor="changeNotes">Notes sur les modifications *</Label>
            <Textarea
              id="changeNotes"
              value={changeNotes}
              onChange={(e) => setChangeNotes(e.target.value)}
              rows={4}
              placeholder="Décrivez les changements apportés dans cette version..."
              required
            />
            <p className="text-xs text-slate-500">
              Expliquez ce qui a changé par rapport à la version précédente
            </p>
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={uploading || !fileUrl || !changeNotes}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Créer la version {currentVersion + 1}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}