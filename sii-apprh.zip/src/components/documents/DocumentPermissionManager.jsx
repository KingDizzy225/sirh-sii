import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Shield, 
  Plus, 
  Trash2, 
  Edit, 
  User, 
  Building2, 
  Briefcase,
  FileText,
  Users,
  Lock,
  Eye,
  Download,
  Share2,
  CheckCircle,
  PenTool,
  Tag,
  Upload
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { useToast } from "@/components/ui/use-toast";
import { DOCUMENT_ROLES, PERMISSION_LABELS } from "./DocumentPermissionService";

const permissionIcons = {
  can_view: Eye,
  can_download: Download,
  can_edit: Edit,
  can_delete: Trash2,
  can_share: Share2,
  can_approve: CheckCircle,
  can_sign: PenTool,
  can_request_signature: PenTool,
  can_manage_versions: Upload,
  can_manage_tags: Tag
};

export default function DocumentPermissionManager({ employees, departments }) {
  const [showForm, setShowForm] = useState(false);
  const [editingRule, setEditingRule] = useState(null);
  const [activeTab, setActiveTab] = useState("all");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: permissions = [], isLoading } = useQuery({
    queryKey: ['documentPermissions'],
    queryFn: () => base44.entities.DocumentPermission.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.DocumentPermission.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documentPermissions'] });
      setShowForm(false);
      toast({ title: "Règle de permission créée ✅" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.DocumentPermission.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documentPermissions'] });
      setShowForm(false);
      setEditingRule(null);
      toast({ title: "Règle mise à jour ✅" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.DocumentPermission.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['documentPermissions'] });
      toast({ title: "Règle supprimée" });
    },
  });

  const filteredPermissions = activeTab === "all" 
    ? permissions 
    : permissions.filter(p => p.permission_type === activeTab);

  const positions = [...new Set(employees.map(e => e.position).filter(Boolean))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Shield className="w-6 h-6 text-purple-600" />
            Gestion des Permissions Documents
          </h2>
          <p className="text-slate-600">Définissez des règles d'accès granulaires</p>
        </div>
        <Button onClick={() => { setEditingRule(null); setShowForm(true); }} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Nouvelle règle
        </Button>
      </div>

      {/* Statistiques */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {Object.entries(DOCUMENT_ROLES).map(([key, role]) => {
          const count = permissions.filter(p => p.role === key).length;
          return (
            <Card key={key} className="border-none shadow-md">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-slate-600">{role.label}s</p>
                    <p className="text-2xl font-bold">{count}</p>
                  </div>
                  <Badge className={role.color}>{key}</Badge>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-white shadow-md">
          <TabsTrigger value="all">Toutes ({permissions.length})</TabsTrigger>
          <TabsTrigger value="global">Globales</TabsTrigger>
          <TabsTrigger value="document_type">Par type</TabsTrigger>
          <TabsTrigger value="department">Par département</TabsTrigger>
          <TabsTrigger value="position">Par poste</TabsTrigger>
          <TabsTrigger value="document">Par document</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Liste des règles */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
          </div>
        ) : filteredPermissions.length === 0 ? (
          <Card className="border-none shadow-lg">
            <CardContent className="p-12 text-center">
              <Shield className="w-16 h-16 mx-auto mb-4 text-slate-300" />
              <p className="text-slate-600">Aucune règle de permission</p>
            </CardContent>
          </Card>
        ) : (
          filteredPermissions.map(rule => (
            <PermissionRuleCard
              key={rule.id}
              rule={rule}
              onEdit={() => { setEditingRule(rule); setShowForm(true); }}
              onDelete={() => deleteMutation.mutate(rule.id)}
              onToggle={(active) => updateMutation.mutate({ id: rule.id, data: { is_active: active } })}
            />
          ))
        )}
      </div>

      {/* Formulaire */}
      {showForm && (
        <PermissionForm
          rule={editingRule}
          employees={employees}
          departments={departments}
          positions={positions}
          onSubmit={(data) => {
            if (editingRule) {
              updateMutation.mutate({ id: editingRule.id, data });
            } else {
              createMutation.mutate(data);
            }
          }}
          onClose={() => { setShowForm(false); setEditingRule(null); }}
          isSubmitting={createMutation.isPending || updateMutation.isPending}
        />
      )}
    </div>
  );
}

function PermissionRuleCard({ rule, onEdit, onDelete, onToggle }) {
  const roleInfo = DOCUMENT_ROLES[rule.role] || DOCUMENT_ROLES.viewer;

  const getScopeIcon = () => {
    switch (rule.permission_type) {
      case 'global': return <Lock className="w-4 h-4" />;
      case 'document_type': return <FileText className="w-4 h-4" />;
      case 'department': return <Building2 className="w-4 h-4" />;
      case 'position': return <Briefcase className="w-4 h-4" />;
      case 'document': return <FileText className="w-4 h-4" />;
      default: return <Shield className="w-4 h-4" />;
    }
  };

  const getScopeLabel = () => {
    switch (rule.permission_type) {
      case 'global': return "Tous les documents";
      case 'document_type': return `Type: ${rule.document_type}`;
      case 'department': return `Département: ${rule.department}`;
      case 'position': return `Poste: ${rule.position}`;
      case 'document': return `Document spécifique`;
      default: return rule.permission_type;
    }
  };

  const getTargetLabel = () => {
    switch (rule.target_type) {
      case 'user': return rule.target_email;
      case 'department': return `Département: ${rule.target_department}`;
      case 'position': return `Poste: ${rule.target_position}`;
      case 'all': return "Tous les utilisateurs";
      default: return rule.target_type;
    }
  };

  return (
    <Card className={`border-none shadow-lg ${!rule.is_active ? 'opacity-60' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Badge className={roleInfo.color}>{roleInfo.label}</Badge>
              <h4 className="font-semibold text-slate-900">{rule.name}</h4>
              {!rule.is_active && <Badge variant="outline" className="text-xs">Désactivée</Badge>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                {getScopeIcon()}
                <span>{getScopeLabel()}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                <span>{getTargetLabel()}</span>
              </div>
            </div>

            {/* Permissions actives */}
            <div className="flex flex-wrap gap-1 mt-3">
              {rule.permissions && Object.entries(rule.permissions)
                .filter(([_, v]) => v)
                .map(([key]) => {
                  const Icon = permissionIcons[key] || Shield;
                  return (
                    <Badge key={key} variant="outline" className="text-xs gap-1">
                      <Icon className="w-3 h-3" />
                      {PERMISSION_LABELS[key]}
                    </Badge>
                  );
                })}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => onToggle(!rule.is_active)}>
              {rule.is_active ? "Désactiver" : "Activer"}
            </Button>
            <Button variant="ghost" size="sm" onClick={onEdit}>
              <Edit className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-red-600" onClick={onDelete}>
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function PermissionForm({ rule, employees, departments, positions, onSubmit, onClose, isSubmitting }) {
  const [formData, setFormData] = useState(rule || {
    name: "",
    permission_type: "global",
    document_type: "",
    department: "",
    position: "",
    target_type: "all",
    target_email: "",
    target_department: "",
    target_position: "",
    role: "viewer",
    permissions: DOCUMENT_ROLES.viewer.permissions,
    is_active: true,
    priority: 0,
    notes: ""
  });

  const [useCustomPermissions, setUseCustomPermissions] = useState(false);

  const handleRoleChange = (role) => {
    setFormData({
      ...formData,
      role,
      permissions: DOCUMENT_ROLES[role]?.permissions || {}
    });
  };

  const handlePermissionToggle = (key) => {
    setFormData({
      ...formData,
      permissions: {
        ...formData.permissions,
        [key]: !formData.permissions[key]
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const documentTypes = ["Contrat", "Carte d'identité", "CV", "Certificat", "Attestation", "Fiche de paie", "Autre"];

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-purple-600" />
            {rule ? "Modifier la règle" : "Nouvelle règle de permission"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nom */}
          <div className="space-y-2">
            <Label>Nom de la règle *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Accès RH aux contrats"
              required
            />
          </div>

          {/* Scope */}
          <div className="p-4 bg-slate-50 rounded-lg space-y-4">
            <h4 className="font-semibold text-slate-900">Portée de la règle</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Type de permission</Label>
                <Select value={formData.permission_type} onValueChange={(v) => setFormData({ ...formData, permission_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="global">Tous les documents</SelectItem>
                    <SelectItem value="document_type">Par type de document</SelectItem>
                    <SelectItem value="department">Par département</SelectItem>
                    <SelectItem value="position">Par poste</SelectItem>
                    <SelectItem value="document">Document spécifique</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.permission_type === "document_type" && (
                <div className="space-y-2">
                  <Label>Type de document</Label>
                  <Select value={formData.document_type} onValueChange={(v) => setFormData({ ...formData, document_type: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent>
                      {documentTypes.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.permission_type === "department" && (
                <div className="space-y-2">
                  <Label>Département source</Label>
                  <Select value={formData.department} onValueChange={(v) => setFormData({ ...formData, department: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent>
                      {departments.map(d => <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.permission_type === "position" && (
                <div className="space-y-2">
                  <Label>Poste source</Label>
                  <Select value={formData.position} onValueChange={(v) => setFormData({ ...formData, position: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent>
                      {positions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </div>

          {/* Target */}
          <div className="p-4 bg-blue-50 rounded-lg space-y-4">
            <h4 className="font-semibold text-slate-900">Bénéficiaires</h4>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Attribuer à</Label>
                <Select value={formData.target_type} onValueChange={(v) => setFormData({ ...formData, target_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tous les utilisateurs</SelectItem>
                    <SelectItem value="user">Utilisateur spécifique</SelectItem>
                    <SelectItem value="department">Département</SelectItem>
                    <SelectItem value="position">Poste</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.target_type === "user" && (
                <div className="space-y-2">
                  <Label>Utilisateur</Label>
                  <Select value={formData.target_email} onValueChange={(v) => setFormData({ ...formData, target_email: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent className="max-h-60">
                      {employees.map(e => <SelectItem key={e.id} value={e.email}>{e.full_name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.target_type === "department" && (
                <div className="space-y-2">
                  <Label>Département cible</Label>
                  <Select value={formData.target_department} onValueChange={(v) => setFormData({ ...formData, target_department: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent>
                      {departments.map(d => <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {formData.target_type === "position" && (
                <div className="space-y-2">
                  <Label>Poste cible</Label>
                  <Select value={formData.target_position} onValueChange={(v) => setFormData({ ...formData, target_position: v })}>
                    <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                    <SelectContent>
                      {positions.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </div>

          {/* Role & Permissions */}
          <div className="p-4 bg-purple-50 rounded-lg space-y-4">
            <h4 className="font-semibold text-slate-900">Rôle et permissions</h4>
            
            <div className="space-y-2">
              <Label>Rôle</Label>
              <div className="grid grid-cols-5 gap-2">
                {Object.entries(DOCUMENT_ROLES).map(([key, role]) => (
                  <Button
                    key={key}
                    type="button"
                    variant={formData.role === key ? "default" : "outline"}
                    className={formData.role === key ? "bg-purple-600" : ""}
                    onClick={() => handleRoleChange(key)}
                  >
                    {role.label}
                  </Button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox 
                id="custom" 
                checked={useCustomPermissions}
                onCheckedChange={setUseCustomPermissions}
              />
              <Label htmlFor="custom" className="text-sm">Personnaliser les permissions</Label>
            </div>

            {useCustomPermissions && (
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(PERMISSION_LABELS).map(([key, label]) => {
                  const Icon = permissionIcons[key] || Shield;
                  return (
                    <div key={key} className="flex items-center gap-2 p-2 bg-white rounded">
                      <Checkbox
                        id={key}
                        checked={formData.permissions?.[key] || false}
                        onCheckedChange={() => handlePermissionToggle(key)}
                      />
                      <Icon className="w-4 h-4 text-slate-500" />
                      <Label htmlFor={key} className="text-sm">{label}</Label>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Priorité (0-100)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div className="space-y-2">
              <Label>Date d'expiration (optionnel)</Label>
              <Input
                type="date"
                value={formData.expires_at || ""}
                onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">Annuler</Button>
            <Button type="submit" disabled={isSubmitting} className="flex-1 bg-purple-600 hover:bg-purple-700">
              {isSubmitting ? "Enregistrement..." : (rule ? "Mettre à jour" : "Créer")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}