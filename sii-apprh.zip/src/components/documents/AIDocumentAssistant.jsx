import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Sparkles, 
  FileText, 
  Wand2, 
  FileSearch, 
  Lightbulb,
  Copy,
  Check,
  Loader2,
  RefreshCw
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function AIDocumentAssistant({ employee, onSelectTemplate, documentContent }) {
  const [activeTab, setActiveTab] = useState("suggest");
  const [prompt, setPrompt] = useState("");
  const [generatedContent, setGeneratedContent] = useState("");
  const [summary, setSummary] = useState("");
  const [suggestions, setSuggestions] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  // Suggérer des templates basés sur le contexte
  const suggestTemplates = async () => {
    if (!employee) return;
    setIsLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es un assistant RH expert. Analyse le profil de cet employé et suggère les 3 documents les plus pertinents à générer.

Profil employé:
- Nom: ${employee.full_name}
- Poste: ${employee.position}
- Département: ${employee.department}
- Date d'embauche: ${employee.hire_date}
- Type de contrat: ${employee.employment_type}
- Ancienneté: ${employee.hire_date ? Math.floor((new Date() - new Date(employee.hire_date)) / (1000 * 60 * 60 * 24 * 365)) : 0} ans

Templates disponibles:
1. employment_contract - Contrat de travail CDI
2. work_certificate - Attestation de travail
3. salary_certificate - Certificat de salaire
4. attendance_certificate - Attestation de présence
5. recommendation_letter - Lettre de recommandation
6. job_description - Fiche de poste
7. end_of_contract - Certificat de fin de contrat

Pour chaque suggestion, explique pourquoi ce document serait utile.`,
        response_json_schema: {
          type: "object",
          properties: {
            suggestions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  template_id: { type: "string" },
                  template_name: { type: "string" },
                  reason: { type: "string" },
                  priority: { type: "string", enum: ["high", "medium", "low"] }
                }
              }
            },
            context_note: { type: "string" }
          }
        }
      });
      setSuggestions(result);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible d'obtenir des suggestions", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  // Générer ou améliorer du contenu
  const generateContent = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Tu es un rédacteur RH professionnel. ${employee ? `
Contexte employé:
- Nom: ${employee.full_name}
- Poste: ${employee.position}
- Département: ${employee.department}
- Entreprise: SII
` : ''}

Demande de l'utilisateur: ${prompt}

Génère un contenu professionnel, formel et adapté au contexte RH français. 
Le texte doit être prêt à être utilisé dans un document officiel.
Utilise un ton professionnel mais humain.`,
      });
      setGeneratedContent(result);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de générer le contenu", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  // Résumer un document
  const summarizeDocument = async () => {
    if (!documentContent) {
      toast({ title: "Aucun contenu", description: "Sélectionnez d'abord un document à résumer" });
      return;
    }
    setIsLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Résume ce document RH de manière concise et structurée. Identifie les points clés, les dates importantes et les obligations mentionnées.

Document:
${documentContent}

Fournis un résumé clair avec:
1. Type de document
2. Points clés (3-5 bullet points)
3. Dates/échéances importantes
4. Actions requises (si applicable)`,
        response_json_schema: {
          type: "object",
          properties: {
            document_type: { type: "string" },
            key_points: { type: "array", items: { type: "string" } },
            important_dates: { type: "array", items: { type: "object", properties: { date: { type: "string" }, description: { type: "string" } } } },
            required_actions: { type: "array", items: { type: "string" } },
            summary: { type: "string" }
          }
        }
      });
      setSummary(result);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible de résumer le document", variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copié !" });
  };

  const priorityColors = {
    high: "bg-red-100 text-red-800",
    medium: "bg-yellow-100 text-yellow-800",
    low: "bg-green-100 text-green-800"
  };

  return (
    <Card className="border-none shadow-lg bg-gradient-to-br from-purple-50 to-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Assistant IA Documents
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="suggest" className="flex items-center gap-1">
              <Lightbulb className="w-4 h-4" />
              Suggérer
            </TabsTrigger>
            <TabsTrigger value="generate" className="flex items-center gap-1">
              <Wand2 className="w-4 h-4" />
              Rédiger
            </TabsTrigger>
            <TabsTrigger value="summarize" className="flex items-center gap-1">
              <FileSearch className="w-4 h-4" />
              Résumer
            </TabsTrigger>
          </TabsList>

          {/* Suggestions de templates */}
          <TabsContent value="suggest" className="space-y-4">
            <p className="text-sm text-slate-600">
              L'IA analyse le profil de l'employé pour suggérer les documents les plus pertinents.
            </p>
            
            <Button 
              onClick={suggestTemplates} 
              disabled={isLoading || !employee}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {isLoading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyse en cours...</>
              ) : (
                <><Sparkles className="w-4 h-4 mr-2" /> Obtenir des suggestions</>
              )}
            </Button>

            {suggestions && (
              <div className="space-y-3 mt-4">
                {suggestions.context_note && (
                  <p className="text-sm text-purple-700 bg-purple-100 p-3 rounded-lg">
                    💡 {suggestions.context_note}
                  </p>
                )}
                
                {suggestions.suggestions?.map((suggestion, idx) => (
                  <div 
                    key={idx}
                    className="p-4 bg-white rounded-lg border border-purple-200 hover:border-purple-400 cursor-pointer transition-colors"
                    onClick={() => onSelectTemplate?.(suggestion.template_id)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-purple-600" />
                        <span className="font-semibold">{suggestion.template_name}</span>
                      </div>
                      <Badge className={priorityColors[suggestion.priority]}>
                        {suggestion.priority === 'high' ? 'Recommandé' : suggestion.priority === 'medium' ? 'Utile' : 'Optionnel'}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600">{suggestion.reason}</p>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Génération de contenu */}
          <TabsContent value="generate" className="space-y-4">
            <p className="text-sm text-slate-600">
              Décrivez ce que vous souhaitez rédiger et l'IA générera un contenu professionnel.
            </p>
            
            <Textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ex: Rédige un paragraphe d'introduction pour une lettre de recommandation mettant en avant les compétences techniques..."
              rows={3}
              className="bg-white"
            />

            <Button 
              onClick={generateContent} 
              disabled={isLoading || !prompt.trim()}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {isLoading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Génération...</>
              ) : (
                <><Wand2 className="w-4 h-4 mr-2" /> Générer le contenu</>
              )}
            </Button>

            {generatedContent && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-purple-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-purple-700">Contenu généré</span>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={() => generateContent()}
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => copyToClipboard(generatedContent)}
                    >
                      {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-slate-700 whitespace-pre-wrap">{generatedContent}</p>
              </div>
            )}

            {/* Suggestions de prompts */}
            <div className="mt-4">
              <p className="text-xs text-slate-500 mb-2">Suggestions :</p>
              <div className="flex flex-wrap gap-2">
                {[
                  "Rédige une introduction pour une attestation de travail",
                  "Formule les points forts de l'employé",
                  "Écris une conclusion professionnelle"
                ].map((suggestion, idx) => (
                  <Badge 
                    key={idx}
                    variant="outline"
                    className="cursor-pointer hover:bg-purple-50"
                    onClick={() => setPrompt(suggestion)}
                  >
                    {suggestion}
                  </Badge>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Résumé de document */}
          <TabsContent value="summarize" className="space-y-4">
            <p className="text-sm text-slate-600">
              {documentContent 
                ? "Cliquez pour obtenir un résumé du document sélectionné."
                : "Générez d'abord un document pour pouvoir le résumer."}
            </p>

            <Button 
              onClick={summarizeDocument} 
              disabled={isLoading || !documentContent}
              className="w-full bg-purple-600 hover:bg-purple-700"
            >
              {isLoading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyse...</>
              ) : (
                <><FileSearch className="w-4 h-4 mr-2" /> Résumer le document</>
              )}
            </Button>

            {summary && (
              <div className="mt-4 space-y-4">
                <div className="p-4 bg-white rounded-lg border border-purple-200">
                  <Badge className="mb-3 bg-purple-600">{summary.document_type}</Badge>
                  
                  <div className="mb-4">
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">📌 Points clés</h4>
                    <ul className="space-y-1">
                      {summary.key_points?.map((point, idx) => (
                        <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                          <span className="text-purple-600">•</span>
                          {point}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {summary.important_dates?.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-slate-700 mb-2">📅 Dates importantes</h4>
                      <div className="space-y-1">
                        {summary.important_dates.map((item, idx) => (
                          <p key={idx} className="text-sm text-slate-600">
                            <span className="font-medium">{item.date}</span> - {item.description}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {summary.required_actions?.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-sm font-semibold text-slate-700 mb-2">✅ Actions requises</h4>
                      <ul className="space-y-1">
                        {summary.required_actions.map((action, idx) => (
                          <li key={idx} className="text-sm text-slate-600 flex items-start gap-2">
                            <span className="text-green-600">→</span>
                            {action}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="pt-3 border-t">
                    <p className="text-sm text-slate-700">{summary.summary}</p>
                  </div>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}