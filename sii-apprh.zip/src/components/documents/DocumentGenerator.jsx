import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Sparkles, FileText, Download, Eye, Calendar, Bot } from "lucide-react";
import { DOCUMENT_TEMPLATES, generateDocumentFromTemplate } from "./DocumentTemplates";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import AIDocumentAssistant from "./AIDocumentAssistant";

export default function DocumentGenerator({ employee, onClose, onGenerated }) {
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [generatedContent, setGeneratedContent] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [additionalData, setAdditionalData] = useState({
    company: "SII",
    startDate: "",
    endDate: "",
    reason: ""
  });
  const [manager, setManager] = useState(null);
  const { toast } = useToast();

  const handleAITemplateSelect = (templateId) => {
    setSelectedTemplate(templateId);
    setShowAIAssistant(false);
  };

  useEffect(() => {
    const loadManager = async () => {
      if (employee.manager_email) {
        const employees = await base44.entities.Employee.filter({ 
          email: employee.manager_email 
        });
        if (employees.length > 0) {
          setManager(employees[0]);
        }
      }
    };
    loadManager();
  }, [employee]);

  const handleGenerate = async () => {
    if (!selectedTemplate) return;

    setIsGenerating(true);
    try {
      const result = await generateDocumentFromTemplate(
        selectedTemplate,
        employee,
        {
          company: additionalData.company,
          manager,
          ...additionalData
        }
      );

      setGeneratedContent(result.content);

      toast({
        title: "Document généré ✨",
        description: "Le document a été généré avec succès",
        duration: 5000,
      });
    } catch (error) {
      console.error("Erreur génération:", error);
      toast({
        title: "Erreur",
        description: error.message || "Impossible de générer le document",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const template = DOCUMENT_TEMPLATES[selectedTemplate];
      
      // Créer un blob HTML (compatible Word)
      const blob = new Blob([generatedContent], { type: 'application/msword' });
      const file = new File([blob], `${template.name} - ${employee.full_name}.doc`, { type: 'application/msword' });

      // Upload le fichier
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Créer le document
      const user = await base44.auth.me();
      const doc = await base44.entities.Document.create({
        employee_id: employee.id,
        employee_name: employee.full_name,
        employee_email: employee.email,
        document_type: template.category,
        title: `${template.name} - ${employee.full_name}`,
        description: template.description,
        file_url: file_url,
        upload_date: new Date().toISOString().split('T')[0],
        uploaded_by: user.email,
        current_version: 1,
        last_modified_date: new Date().toISOString(),
        last_modified_by: user.email,
        status: "actif",
        tags: ["généré", template.name.toLowerCase()]
      });

      // Créer la version initiale
      await base44.entities.DocumentVersion.create({
        document_id: doc.id,
        version_number: 1,
        file_url: file_url,
        uploaded_by: user.email,
        uploaded_by_name: user.full_name || user.email,
        upload_date: new Date().toISOString(),
        change_notes: "Document généré automatiquement",
        is_current: true
      });

      toast({
        title: "Document enregistré ✅",
        description: "Le document Word a été sauvegardé avec succès",
        duration: 5000,
      });

      if (onGenerated) {
        onGenerated(doc);
      }

      onClose();
    } catch (error) {
      console.error("Erreur sauvegarde:", error);
      toast({
        title: "Erreur",
        description: "Impossible de sauvegarder le document",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDownload = () => {
    // Télécharger en format Word (.doc)
    const blob = new Blob([generatedContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${DOCUMENT_TEMPLATES[selectedTemplate].name} - ${employee.full_name}.doc`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const selectedTemplateData = selectedTemplate ? DOCUMENT_TEMPLATES[selectedTemplate] : null;
  const needsDateRange = selectedTemplate === 'attendance_certificate';
  const needsEndReason = selectedTemplate === 'end_of_contract';

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            Générateur de Documents Automatique
          </DialogTitle>
          <p className="text-sm text-slate-600 mt-1">
            Pour {employee.full_name} - {employee.position}
          </p>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration */}
          <div className="space-y-4">
            {/* AI Assistant Toggle */}
            <Button
              variant={showAIAssistant ? "default" : "outline"}
              onClick={() => setShowAIAssistant(!showAIAssistant)}
              className={showAIAssistant ? "w-full bg-purple-600 hover:bg-purple-700" : "w-full border-purple-300 text-purple-700 hover:bg-purple-50"}
            >
              <Bot className="w-4 h-4 mr-2" />
              {showAIAssistant ? "Masquer l'assistant IA" : "Utiliser l'assistant IA"}
            </Button>

            {showAIAssistant && (
              <AIDocumentAssistant 
                employee={employee}
                onSelectTemplate={handleAITemplateSelect}
                documentContent={generatedContent}
              />
            )}

            <Card className="border-purple-200 bg-purple-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold text-purple-900">Configuration</h3>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Type de document *</Label>
                    <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choisir un template" />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(DOCUMENT_TEMPLATES).map(([key, template]) => (
                          <SelectItem key={key} value={key}>
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4" />
                              {template.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedTemplateData && (
                    <div className="p-3 bg-white rounded-lg border border-purple-200">
                      <p className="text-sm font-medium text-purple-900 mb-1">
                        {selectedTemplateData.name}
                      </p>
                      <p className="text-xs text-purple-700">
                        {selectedTemplateData.description}
                      </p>
                      <Badge className="mt-2 bg-purple-600">
                        {selectedTemplateData.category}
                      </Badge>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label>Nom de l'entreprise</Label>
                    <Input
                      value={additionalData.company}
                      onChange={(e) => setAdditionalData({...additionalData, company: e.target.value})}
                    />
                  </div>

                  {needsDateRange && (
                    <>
                      <div className="space-y-2">
                        <Label>Date de début *</Label>
                        <Input
                          type="date"
                          value={additionalData.startDate}
                          onChange={(e) => setAdditionalData({...additionalData, startDate: e.target.value})}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Date de fin *</Label>
                        <Input
                          type="date"
                          value={additionalData.endDate}
                          onChange={(e) => setAdditionalData({...additionalData, endDate: e.target.value})}
                          required
                        />
                      </div>
                    </>
                  )}

                  {needsEndReason && (
                    <div className="space-y-2">
                      <Label>Motif de fin de contrat</Label>
                      <Input
                        value={additionalData.reason}
                        onChange={(e) => setAdditionalData({...additionalData, reason: e.target.value})}
                        placeholder="ex: Démission, Fin de CDD..."
                      />
                    </div>
                  )}

                  <Button
                    onClick={handleGenerate}
                    disabled={!selectedTemplate || isGenerating}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {isGenerating ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                        Génération...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Générer le document
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Infos employé */}
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold text-slate-900 mb-3">Informations de l'employé</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Nom:</span>
                    <span className="font-medium">{employee.full_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Poste:</span>
                    <span className="font-medium">{employee.position}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Département:</span>
                    <span className="font-medium">{employee.department}</span>
                  </div>
                  {employee.employee_id && (
                    <div className="flex justify-between">
                      <span className="text-slate-600">ID:</span>
                      <span className="font-medium">{employee.employee_id}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Aperçu */}
          <div className="space-y-4">
            <Card className="border-slate-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                    <Eye className="w-5 h-5" />
                    Aperçu du document
                  </h3>
                  {generatedContent && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownload}
                      className="text-blue-600 border-blue-200 hover:bg-blue-50"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger (.doc)
                    </Button>
                  )}
                </div>

                {!generatedContent ? (
                  <div className="text-center py-12 text-slate-400">
                    <FileText className="w-16 h-16 mx-auto mb-3 text-slate-300" />
                    <p className="text-sm">Sélectionnez un template et cliquez sur "Générer"</p>
                  </div>
                ) : (
                  <div className="bg-white border border-slate-200 rounded-lg max-h-[500px] overflow-y-auto">
                    <iframe 
                      srcDoc={generatedContent}
                      className="w-full h-[480px] border-0"
                      title="Aperçu du document"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
          {generatedContent && (
            <Button
              onClick={handleSave}
              disabled={isSaving}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSaving ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Enregistrement...
                </>
              ) : (
                <>
                  <FileText className="w-4 h-4 mr-2" />
                  Enregistrer dans les documents
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}