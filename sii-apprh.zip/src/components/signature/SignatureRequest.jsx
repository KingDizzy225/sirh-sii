import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  PenTool, 
  Plus, 
  X, 
  User, 
  FileText, 
  Calendar,
  AlertCircle,
  Send,
  Users
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { addDays, format } from "date-fns";
import { fr } from "date-fns/locale";

export default function SignatureRequest({ document, onClose, onRequestSent }) {
  const [user, setUser] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [signers, setSigners] = useState([]);
  const [message, setMessage] = useState("");
  const [deadline, setDeadline] = useState(format(addDays(new Date(), 7), 'yyyy-MM-dd'));
  const [sequentialSigning, setSequentialSigning] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadData = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);

      const allEmployees = await base44.entities.Employee.filter({ status: 'active' });
      setEmployees(allEmployees);

      // Pré-remplir avec l'employé concerné par le document
      if (document.employee_email) {
        setSigners([{
          email: document.employee_email,
          name: document.employee_name,
          role: 'employee'
        }]);
      }
    };
    loadData();
  }, []);

  const addSigner = () => {
    setSigners([...signers, { email: "", name: "", role: "employee" }]);
  };

  const removeSigner = (index) => {
    setSigners(signers.filter((_, i) => i !== index));
  };

  const updateSigner = (index, field, value) => {
    const updated = [...signers];
    updated[index][field] = value;
    
    if (field === 'email') {
      const emp = employees.find(e => e.email === value);
      if (emp) {
        updated[index].name = emp.full_name;
      }
    }
    
    setSigners(updated);
  };

  const handleSendRequest = async () => {
    if (signers.length === 0) {
      toast({
        title: "Erreur",
        description: "Ajoutez au moins un signataire",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    const invalidSigners = signers.filter(s => !s.email || !s.name);
    if (invalidSigners.length > 0) {
      toast({
        title: "Erreur",
        description: "Tous les signataires doivent avoir un email et un nom",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Créer les demandes de signature
      const signaturePromises = signers.map((signer, index) => 
        base44.entities.DocumentSignature.create({
          document_id: document.id,
          document_title: document.title,
          document_type: document.document_type,
          signer_email: signer.email,
          signer_name: signer.name,
          signer_role: signer.role,
          status: "pending",
          request_date: new Date().toISOString(),
          requested_by: user.email,
          requested_by_name: user.full_name || user.email,
          deadline: deadline,
          is_required: true,
          order: sequentialSigning ? index + 1 : 0
        })
      );

      await Promise.all(signaturePromises);

      // Mettre à jour le document
      await base44.entities.Document.update(document.id, {
        status: "en_attente_signature",
        tags: [...(document.tags || []), "signature_requise"]
      });

      // Envoyer notifications et emails
      for (const signer of signers) {
        // Notification in-app
        await base44.entities.Notification.create({
          user_email: signer.email,
          user_name: signer.name,
          notification_type: "system",
          title: "Document à signer ✍️",
          message: `Vous devez signer le document "${document.title}". Échéance: ${format(new Date(deadline), 'd MMMM yyyy', { locale: fr })}`,
          priority: "high",
          action_url: "/Documents",
          action_label: "Signer maintenant",
          related_id: document.id,
          related_type: "Document",
          sender_email: user.email,
          sender_name: user.full_name || user.email
        });

        // Email
        await base44.integrations.Core.SendEmail({
          to: signer.email,
          subject: `Signature requise: ${document.title}`,
          body: `
Bonjour ${signer.name},

Vous êtes invité(e) à signer le document suivant :

📄 Document : ${document.title}
📁 Type : ${document.document_type}
👤 Demandé par : ${user.full_name || user.email}
📅 Date limite : ${format(new Date(deadline), 'd MMMM yyyy', { locale: fr })}

${message ? `Message : ${message}\n\n` : ''}

${sequentialSigning ? '⚠️ Ce document nécessite des signatures séquentielles. Vous serez notifié(e) quand ce sera votre tour de signer.\n\n' : ''}

Veuillez vous connecter au portail RH pour signer le document de manière électronique.

Cordialement,
${user.full_name || user.email}
          `
        });
      }

      toast({
        title: "Demandes envoyées ✅",
        description: `${signers.length} personne(s) ont été notifiée(s)`,
        duration: 5000,
      });

      if (onRequestSent) {
        onRequestSent();
      }

      onClose();
    } catch (error) {
      console.error("Erreur envoi demandes signature:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer les demandes de signature",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenTool className="w-5 h-5 text-blue-600" />
            Demander des Signatures Électroniques
          </DialogTitle>
          <p className="text-sm text-slate-600 mt-1">
            Pour le document: {document.title}
          </p>
        </DialogHeader>

        <div className="space-y-6">
          {/* Document info */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <FileText className="w-8 h-8 text-blue-600" />
                <div>
                  <p className="font-semibold text-blue-900">{document.title}</p>
                  <p className="text-sm text-blue-700">{document.document_type}</p>
                  <p className="text-xs text-blue-600 mt-1">
                    Employé: {document.employee_name}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Signataires */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Signataires *</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addSigner}
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter un signataire
              </Button>
            </div>

            {signers.map((signer, index) => (
              <Card key={index} className="border-slate-200">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="space-y-2">
                        <Label className="text-xs">Email</Label>
                        <Select
                          value={signer.email}
                          onValueChange={(value) => updateSigner(index, 'email', value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionner" />
                          </SelectTrigger>
                          <SelectContent className="max-h-[300px]">
                            {employees.map(emp => (
                              <SelectItem key={emp.id} value={emp.email}>
                                {emp.full_name} - {emp.position}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Nom</Label>
                        <Input
                          value={signer.name}
                          onChange={(e) => updateSigner(index, 'name', e.target.value)}
                          placeholder="Nom complet"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label className="text-xs">Rôle</Label>
                        <Select
                          value={signer.role}
                          onValueChange={(value) => updateSigner(index, 'role', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="employee">Employé</SelectItem>
                            <SelectItem value="manager">Manager</SelectItem>
                            <SelectItem value="hr">RH</SelectItem>
                            <SelectItem value="director">Directeur</SelectItem>
                            <SelectItem value="witness">Témoin</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {signers.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSigner(index)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  {sequentialSigning && (
                    <div className="mt-2">
                      <Badge variant="outline" className="text-xs">
                        Ordre de signature: {index + 1}
                      </Badge>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Options */}
          <Card className="border-slate-200">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <Label>Date limite de signature</Label>
                <Input
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  min={format(new Date(), 'yyyy-MM-dd')}
                />
              </div>

              <div className="space-y-2">
                <Label>Message pour les signataires (optionnel)</Label>
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Ajoutez un message personnalisé..."
                  rows={3}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="sequential"
                  checked={sequentialSigning}
                  onCheckedChange={setSequentialSigning}
                />
                <Label htmlFor="sequential" className="cursor-pointer">
                  <div>
                    <p className="font-medium">Signature séquentielle</p>
                    <p className="text-xs text-slate-500">
                      Les signataires devront signer dans l'ordre défini
                    </p>
                  </div>
                </Label>
              </div>
            </CardContent>
          </Card>

          {/* Info */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-blue-900 mb-1">
                    À propos des signatures électroniques
                  </p>
                  <ul className="text-xs text-blue-700 space-y-1">
                    <li>• Chaque signataire recevra une notification et un email</li>
                    <li>• Les signatures sont horodatées et traçables (IP, navigateur, localisation)</li>
                    <li>• Un hash cryptographique garantit l'intégrité du document</li>
                    <li>• L'historique complet est conservé pour audit</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Annuler
          </Button>
          <Button
            onClick={handleSendRequest}
            disabled={isSubmitting || signers.length === 0}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Envoi...
              </>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" />
                Envoyer {signers.length} demande{signers.length > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}