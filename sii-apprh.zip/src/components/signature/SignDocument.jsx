import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { 
  PenTool, 
  FileText, 
  User, 
  Calendar, 
  Eye,
  XCircle,
  CheckCircle,
  AlertCircle,
  Download,
  Shield
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import SignatureCanvas from "./SignatureCanvas";
import { logDocumentAction, AUDIT_ACTIONS } from "../documents/DocumentAuditService";

export default function SignDocument({ signatureRequest, document, onClose, onSigned }) {
  const [user, setUser] = useState(null);
  const [showSignatureCanvas, setShowSignatureCanvas] = useState(false);
  const [showDeclineDialog, setShowDeclineDialog] = useState(false);
  const [declineReason, setDeclineReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const handleSignatureComplete = async (signatureData) => {
    setIsSubmitting(true);
    try {
      // Récupérer les infos du navigateur
      const userAgent = navigator.userAgent;
      const signedAt = new Date().toISOString();

      // Créer un hash pour audit trail
      const certificateHash = await generateCertificateHash({
        documentId: document.id,
        signerEmail: signatureRequest.signer_email,
        timestamp: signedAt,
        signatureData: signatureData.signature_data
      });

      // Mettre à jour la signature avec view_count
      await base44.entities.DocumentSignature.update(signatureRequest.id, {
        status: "signed",
        signature_data: signatureData.signature_data,
        signature_type: signatureData.signature_type,
        typed_name: signatureData.typed_name,
        signed_date: signedAt,
        user_agent: userAgent,
        certificate_hash: certificateHash,
        view_count: (signatureRequest.view_count || 0) + 1
      });

      // Audit log
      if (user) {
        await logDocumentAction({
          document,
          action: AUDIT_ACTIONS.SIGNED,
          actor: user,
          details: {
            signature_type: signatureData.signature_type,
            certificate_hash: certificateHash.substring(0, 16),
            signer_role: signatureRequest.signer_role
          }
        });
      }

      // Vérifier si toutes les signatures sont complètes
      const allSignatures = await base44.entities.DocumentSignature.filter({
        document_id: document.id
      });

      const allSigned = allSignatures.every(s => s.status === 'signed' || s.id === signatureRequest.id);
      const pendingCount = allSignatures.filter(s => s.status === 'pending' && s.id !== signatureRequest.id).length;

      if (allSigned || pendingCount === 0) {
        // Mettre à jour le document comme complètement signé
        await base44.entities.Document.update(document.id, {
          status: "signé",
          tags: [...new Set([...(document.tags || []).filter(t => t !== "signature_requise"), "signé"])],
          last_modified_date: signedAt
        });

        // Notifier le demandeur
        await base44.entities.Notification.create({
          user_email: signatureRequest.requested_by,
          user_name: signatureRequest.requested_by_name,
          notification_type: "signature_complete",
          title: "✅ Document entièrement signé",
          message: `Le document "${document.title}" a été signé par tous les signataires (${allSignatures.length}).`,
          priority: "high",
          action_url: "/Documents",
          action_label: "Voir le document",
          related_id: document.id,
          related_type: "Document"
        });

        // Email de confirmation
        await base44.integrations.Core.SendEmail({
          to: signatureRequest.requested_by,
          subject: `✅ Document signé: ${document.title}`,
          body: `
Le document "${document.title}" a été entièrement signé par tous les signataires.

📄 Document : ${document.title}
✅ Signataires : ${allSignatures.length}
📅 Dernière signature : ${format(new Date(signedAt), "d MMMM yyyy 'à' HH:mm", { locale: fr })}

Un certificat de signature électronique a été généré.
Connectez-vous au portail pour télécharger le document signé.

Cordialement,
Système RH
          `
        });
      } else {
        // Notifier le demandeur de la signature partielle
        await base44.entities.Notification.create({
          user_email: signatureRequest.requested_by,
          user_name: signatureRequest.requested_by_name,
          notification_type: "signature_partial",
          title: "✍️ Nouvelle signature reçue",
          message: `${signatureRequest.signer_name} a signé "${document.title}". ${pendingCount} signature(s) en attente.`,
          priority: "medium",
          action_url: "/Documents",
          related_id: document.id,
          related_type: "Document"
        });
      }

      toast({
        title: "Document signé ✍️",
        description: "Votre signature a été enregistrée avec succès",
        duration: 5000,
      });

      if (onSigned) {
        onSigned();
      }

      onClose();
    } catch (error) {
      console.error("Erreur signature:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer la signature",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDecline = async () => {
    if (!declineReason.trim()) {
      toast({
        title: "Raison requise",
        description: "Veuillez indiquer pourquoi vous refusez de signer",
        variant: "destructive",
        duration: 5000,
      });
      return;
    }

    setIsSubmitting(true);
    try {
      await base44.entities.DocumentSignature.update(signatureRequest.id, {
        status: "declined",
        decline_reason: declineReason,
        signed_date: new Date().toISOString()
      });

      // Audit log
      if (user) {
        await logDocumentAction({
          document,
          action: AUDIT_ACTIONS.SIGNATURE_DECLINED,
          actor: user,
          details: { reason: declineReason }
        });
      }

      // Notifier le demandeur
      await base44.entities.Notification.create({
        user_email: signatureRequest.requested_by,
        user_name: signatureRequest.requested_by_name,
        notification_type: "signature_declined",
        title: "❌ Signature refusée",
        message: `${signatureRequest.signer_name} a refusé de signer "${document.title}".`,
        priority: "high",
        action_url: "/Documents",
        related_id: document.id,
        related_type: "Document"
      });

      // Email
      await base44.integrations.Core.SendEmail({
        to: signatureRequest.requested_by,
        subject: `❌ Signature refusée: ${document.title}`,
        body: `
${signatureRequest.signer_name} a refusé de signer le document "${document.title}".

📄 Document : ${document.title}
👤 Signataire : ${signatureRequest.signer_name}
❌ Raison du refus : ${declineReason}

Veuillez vous connecter au portail pour prendre les actions nécessaires.

Cordialement,
Système RH
        `
      });

      toast({
        title: "Refus enregistré",
        description: "Le demandeur a été notifié de votre refus",
        duration: 5000,
      });

      onClose();
    } catch (error) {
      console.error("Erreur refus signature:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer le refus",
        variant: "destructive",
        duration: 5000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isPastDeadline = new Date() > new Date(signatureRequest.deadline);

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenTool className="w-5 h-5 text-blue-600" />
            Signer le Document
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Document Info */}
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <FileText className="w-12 h-12 text-blue-600" />
                <div className="flex-1">
                  <h3 className="font-bold text-blue-900 text-lg mb-1">{document.title}</h3>
                  <p className="text-sm text-blue-700 mb-2">{document.document_type}</p>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-600" />
                      <span className="text-blue-800">
                        Demandé par: {signatureRequest.requested_by_name}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-blue-600" />
                      <span className="text-blue-800">
                        Échéance: {format(new Date(signatureRequest.deadline), 'd MMMM yyyy', { locale: fr })}
                      </span>
                    </div>
                  </div>

                  {isPastDeadline && (
                    <Badge className="mt-2 bg-red-600">
                      Échéance dépassée
                    </Badge>
                  )}
                </div>

                <Button
                  variant="outline"
                  onClick={() => window.open(document.file_url, '_blank')}
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Voir le document
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Signature Role */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Badge className="bg-purple-600">
                  Vous signez en tant que: {signatureRequest.signer_role}
                </Badge>
                {signatureRequest.order > 0 && (
                  <Badge variant="outline">
                    Ordre de signature: {signatureRequest.order}
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Legal Notice */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-orange-900 mb-2">
                    Avertissement Légal
                  </p>
                  <ul className="text-xs text-orange-800 space-y-1">
                    <li>• En signant, vous confirmez avoir lu et compris le document</li>
                    <li>• Votre signature électronique a la même valeur juridique qu'une signature manuscrite</li>
                    <li>• Les informations suivantes seront enregistrées: date/heure, navigateur</li>
                    <li>• Cette signature ne peut pas être révoquée une fois confirmée</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* eIDAS Compliance */}
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-green-900 mb-1">
                    Signature conforme eIDAS
                  </p>
                  <p className="text-xs text-green-700">
                    Cette signature électronique est conforme au règlement européen eIDAS (UE 910/2014). 
                    Un certificat de signature horodaté sera généré pour garantir l'intégrité du document.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Signature Canvas */}
          {!showSignatureCanvas ? (
            <div className="flex gap-3">
              <Button
                onClick={() => setShowSignatureCanvas(true)}
                className="flex-1 bg-green-600 hover:bg-green-700 h-16 text-lg"
              >
                <PenTool className="w-5 h-5 mr-2" />
                Je signe ce document
              </Button>
              <Button
                onClick={() => setShowDeclineDialog(true)}
                variant="outline"
                className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50 h-16 text-lg"
              >
                <XCircle className="w-5 h-5 mr-2" />
                Refuser de signer
              </Button>
            </div>
          ) : (
            <div>
              <h3 className="font-semibold text-slate-900 mb-4">Apposez votre signature</h3>
              <SignatureCanvas 
                onSignatureComplete={handleSignatureComplete}
                signerName={signatureRequest.signer_name}
              />
            </div>
          )}

          {/* Decline Dialog */}
          {showDeclineDialog && (
            <Card className="border-red-200 bg-red-50 mt-4">
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-600" />
                  <h4 className="font-semibold text-red-900">Refuser la signature</h4>
                </div>
                
                <div className="space-y-2">
                  <Label>Raison du refus *</Label>
                  <Textarea
                    value={declineReason}
                    onChange={(e) => setDeclineReason(e.target.value)}
                    placeholder="Expliquez pourquoi vous refusez de signer..."
                    rows={3}
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowDeclineDialog(false);
                      setDeclineReason("");
                    }}
                    className="flex-1"
                  >
                    Annuler
                  </Button>
                  <Button
                    onClick={handleDecline}
                    disabled={isSubmitting || !declineReason.trim()}
                    className="flex-1 bg-red-600 hover:bg-red-700"
                  >
                    {isSubmitting ? "Envoi..." : "Confirmer le refus"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Fonction utilitaire pour générer un hash cryptographique
async function generateCertificateHash(data) {
  const str = JSON.stringify(data);
  const encoder = new TextEncoder();
  const dataBuffer = encoder.encode(str);
  
  const hashBuffer = await crypto.subtle.digest('SHA-256', dataBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  
  return hashHex;
}