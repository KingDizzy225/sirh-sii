import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  Calendar,
  Eye,
  Download,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Progress } from "@/components/ui/progress";

const statusIcons = {
  pending: Clock,
  signed: CheckCircle,
  declined: XCircle,
  expired: AlertCircle
};

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-300",
  signed: "bg-green-100 text-green-800 border-green-300",
  declined: "bg-red-100 text-red-800 border-red-300",
  expired: "bg-gray-100 text-gray-800 border-gray-300"
};

const statusLabels = {
  pending: "En attente",
  signed: "Signé ✅",
  declined: "Refusé",
  expired: "Expiré"
};

const roleLabels = {
  employee: "Employé",
  manager: "Manager",
  hr: "RH",
  director: "Directeur",
  witness: "Témoin"
};

export default function SignatureStatus({ document, onViewSignature }) {
  const { data: signatures = [], isLoading } = useQuery({
    queryKey: ['documentSignatures', document.id],
    queryFn: () => base44.entities.DocumentSignature.filter({ 
      document_id: document.id 
    }),
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  if (signatures.length === 0) {
    return null;
  }

  const totalSignatures = signatures.length;
  const signedCount = signatures.filter(s => s.status === 'signed').length;
  const pendingCount = signatures.filter(s => s.status === 'pending').length;
  const declinedCount = signatures.filter(s => s.status === 'declined').length;
  const progress = Math.round((signedCount / totalSignatures) * 100);

  const isFullySigned = signedCount === totalSignatures && totalSignatures > 0;
  const hasDeclined = declinedCount > 0;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-600" />
            Statut des Signatures
          </CardTitle>
          {isFullySigned && (
            <Badge className="bg-green-600 text-lg px-4 py-1">
              ✅ Entièrement signé
            </Badge>
          )}
          {hasDeclined && (
            <Badge className="bg-red-600 text-lg px-4 py-1">
              ❌ Signature refusée
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Bar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">
              Progression des signatures
            </span>
            <span className="text-sm font-bold text-blue-600">
              {signedCount}/{totalSignatures} ({progress}%)
            </span>
          </div>
          <Progress value={progress} className="h-3" />
          <div className="flex items-center justify-between mt-2 text-xs text-slate-600">
            <span>✅ {signedCount} signé{signedCount > 1 ? 's' : ''}</span>
            <span>⏳ {pendingCount} en attente</span>
            {declinedCount > 0 && (
              <span className="text-red-600">❌ {declinedCount} refusé{declinedCount > 1 ? 's' : ''}</span>
            )}
          </div>
        </div>

        {/* Liste des signatures */}
        <div className="space-y-3">
          {signatures
            .sort((a, b) => (a.order || 0) - (b.order || 0))
            .map((signature) => {
              const StatusIcon = statusIcons[signature.status] || Clock;
              const statusColor = statusColors[signature.status];

              return (
                <Card key={signature.id} className="border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          signature.status === 'signed' ? 'bg-green-100' :
                          signature.status === 'declined' ? 'bg-red-100' :
                          signature.status === 'expired' ? 'bg-gray-100' :
                          'bg-yellow-100'
                        }`}>
                          <StatusIcon className={`w-5 h-5 ${
                            signature.status === 'signed' ? 'text-green-600' :
                            signature.status === 'declined' ? 'text-red-600' :
                            signature.status === 'expired' ? 'text-gray-600' :
                            'text-yellow-600'
                          }`} />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-semibold text-slate-900">
                              {signature.signer_name}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {roleLabels[signature.signer_role]}
                            </Badge>
                            {signature.order > 0 && (
                              <Badge variant="outline" className="text-xs">
                                #{signature.order}
                              </Badge>
                            )}
                          </div>
                          
                          <p className="text-sm text-slate-600 mb-2">
                            {signature.signer_email}
                          </p>

                          <Badge className={`${statusColor} border`}>
                            {statusLabels[signature.status]}
                          </Badge>

                          {signature.status === 'signed' && signature.signed_date && (
                            <p className="text-xs text-slate-500 mt-2">
                              Signé le {format(new Date(signature.signed_date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                            </p>
                          )}

                          {signature.status === 'declined' && signature.decline_reason && (
                            <div className="mt-2 p-2 bg-red-50 rounded border border-red-200">
                              <p className="text-xs text-red-700">
                                <strong>Raison:</strong> {signature.decline_reason}
                              </p>
                            </div>
                          )}

                          {signature.status === 'pending' && (
                            <p className="text-xs text-slate-500 mt-2">
                              Demandé le {format(new Date(signature.request_date), "d MMMM yyyy", { locale: fr })}
                            </p>
                          )}
                        </div>
                      </div>

                      {signature.status === 'signed' && signature.signature_data && onViewSignature && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onViewSignature(signature)}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Voir
                        </Button>
                      )}
                    </div>

                    {/* Audit Trail */}
                    {signature.status === 'signed' && (
                      <div className="mt-3 pt-3 border-t border-slate-200">
                        <p className="text-xs font-medium text-slate-700 mb-2">
                          🔒 Piste d'audit
                        </p>
                        <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                          {signature.ip_address && (
                            <div>
                              <span className="text-slate-500">IP:</span> {signature.ip_address}
                            </div>
                          )}
                          {signature.certificate_hash && (
                            <div className="col-span-2">
                              <span className="text-slate-500">Hash:</span>{' '}
                              <code className="text-xs bg-slate-100 px-1 rounded">
                                {signature.certificate_hash.substring(0, 32)}...
                              </code>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
        </div>

        {/* Certificate Download (if fully signed) */}
        {isFullySigned && (
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  <div>
                    <p className="font-semibold text-green-900">Document entièrement signé</p>
                    <p className="text-xs text-green-700">
                      Toutes les signatures ont été collectées
                    </p>
                  </div>
                </div>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Download className="w-4 h-4 mr-2" />
                  Certificat de signature
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </CardContent>
    </Card>
  );
}