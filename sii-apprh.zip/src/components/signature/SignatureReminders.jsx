import { base44 } from "@/api/base44Client";
import { addDays, format } from "date-fns";
import { fr } from "date-fns/locale";

/**
 * Envoie des rappels automatiques pour les signatures en attente
 */
export async function sendSignatureReminders() {
  try {
    const pendingSignatures = await base44.entities.DocumentSignature.filter({
      status: 'pending'
    });

    const today = new Date();

    for (const signature of pendingSignatures) {
      const deadline = new Date(signature.deadline);
      const daysUntilDeadline = Math.ceil((deadline - today) / (1000 * 60 * 60 * 24));

      // Rappel 3 jours avant échéance
      if (daysUntilDeadline === 3 && signature.reminder_count < 1) {
        await sendReminder(signature, "Rappel: signature dans 3 jours");
        await base44.entities.DocumentSignature.update(signature.id, {
          reminder_sent: true,
          reminder_count: (signature.reminder_count || 0) + 1
        });
      }

      // Rappel 1 jour avant échéance
      if (daysUntilDeadline === 1 && signature.reminder_count < 2) {
        await sendReminder(signature, "⚠️ URGENT: signature demain");
        await base44.entities.DocumentSignature.update(signature.id, {
          reminder_sent: true,
          reminder_count: (signature.reminder_count || 0) + 1
        });
      }

      // Marquer comme expiré si passé la deadline
      if (daysUntilDeadline < 0) {
        await base44.entities.DocumentSignature.update(signature.id, {
          status: 'expired'
        });

        // Notifier le demandeur
        await base44.entities.Notification.create({
          user_email: signature.requested_by,
          user_name: signature.requested_by_name,
          notification_type: "system",
          title: "Signature expirée",
          message: `La demande de signature pour "${signature.document_title}" envoyée à ${signature.signer_name} a expiré.`,
          priority: "medium",
          related_id: signature.document_id,
          related_type: "Document"
        });
      }
    }

    return true;
  } catch (error) {
    console.error("Erreur envoi rappels signature:", error);
    return false;
  }
}

async function sendReminder(signature, subject) {
  try {
    // Notification in-app
    await base44.entities.Notification.create({
      user_email: signature.signer_email,
      user_name: signature.signer_name,
      notification_type: "deadline_reminder",
      title: subject,
      message: `Le document "${signature.document_title}" attend votre signature. Échéance: ${format(new Date(signature.deadline), 'd MMMM', { locale: fr })}`,
      priority: "high",
      action_url: "/MySignatures",
      action_label: "Signer maintenant",
      related_id: signature.document_id,
      related_type: "Document"
    });

    // Email
    await base44.integrations.Core.SendEmail({
      to: signature.signer_email,
      subject: subject,
      body: `
Bonjour ${signature.signer_name},

Rappel: Vous avez un document en attente de signature.

📄 Document: ${signature.document_title}
📁 Type: ${signature.document_type}
📅 Échéance: ${format(new Date(signature.deadline), 'd MMMM yyyy', { locale: fr })}
👤 Demandé par: ${signature.requested_by_name}

Veuillez vous connecter au portail RH pour signer le document.

Cordialement,
L'équipe RH
      `
    });

    return true;
  } catch (error) {
    console.error("Erreur envoi rappel:", error);
    return false;
  }
}

export default {
  sendSignatureReminders
};