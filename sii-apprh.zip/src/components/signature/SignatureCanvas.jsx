import React, { useRef, useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Pen, Type, Upload, RotateCcw, Check } from "lucide-react";

export default function SignatureCanvas({ onSignatureComplete, signerName = "" }) {
  const canvasRef = useRef(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signatureType, setSignatureType] = useState("drawn");
  const [typedName, setTypedName] = useState(signerName);
  const [uploadedSignature, setUploadedSignature] = useState(null);
  const [hasSignature, setHasSignature] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#1e40af';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }, []);

  const startDrawing = (e) => {
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    
    ctx.beginPath();
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setHasSignature(true);
  };

  const draw = (e) => {
    if (!isDrawing) return;
    
    e.preventDefault();
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const ctx = canvas.getContext('2d');
    
    const x = (e.clientX || e.touches?.[0]?.clientX) - rect.left;
    const y = (e.clientY || e.touches?.[0]?.clientY) - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
    setTypedName("");
    setUploadedSignature(null);
  };

  const generateTypedSignature = () => {
    if (!typedName.trim()) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.font = "48px 'Brush Script MT', cursive";
    ctx.fillStyle = '#1e40af';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(typedName, canvas.width / 2, canvas.height / 2);
    
    setHasSignature(true);
  };

  const handleFileUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const scale = Math.min(
          canvas.width / img.width,
          canvas.height / img.height
        );
        
        const x = (canvas.width - img.width * scale) / 2;
        const y = (canvas.height - img.height * scale) / 2;
        
        ctx.drawImage(img, x, y, img.width * scale, img.height * scale);
        setHasSignature(true);
        setUploadedSignature(event.target.result);
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };

  const handleConfirm = () => {
    const canvas = canvasRef.current;
    const signatureData = canvas.toDataURL('image/png');
    
    onSignatureComplete({
      signature_data: signatureData,
      signature_type: signatureType,
      typed_name: signatureType === 'typed' ? typedName : null
    });
  };

  return (
    <div className="space-y-4">
      <Tabs value={signatureType} onValueChange={(value) => {
        setSignatureType(value);
        clearCanvas();
      }}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="drawn" className="gap-2">
            <Pen className="w-4 h-4" />
            Dessiner
          </TabsTrigger>
          <TabsTrigger value="typed" className="gap-2">
            <Type className="w-4 h-4" />
            Taper
          </TabsTrigger>
          <TabsTrigger value="uploaded" className="gap-2">
            <Upload className="w-4 h-4" />
            Uploader
          </TabsTrigger>
        </TabsList>

        <TabsContent value="drawn" className="space-y-4">
          <Card className="border-2 border-blue-200">
            <CardContent className="p-4">
              <canvas
                ref={canvasRef}
                width={600}
                height={200}
                className="w-full border-2 border-dashed border-blue-300 rounded-lg cursor-crosshair bg-white"
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
              />
              <p className="text-xs text-slate-500 mt-2 text-center">
                Signez avec votre souris, trackpad ou doigt (écran tactile)
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="typed" className="space-y-4">
          <Card className="border-2 border-blue-200">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <Label>Tapez votre nom complet</Label>
                <Input
                  value={typedName}
                  onChange={(e) => setTypedName(e.target.value)}
                  placeholder="ex: Jean Dupont"
                  className="text-lg"
                />
              </div>
              
              <Button
                onClick={generateTypedSignature}
                disabled={!typedName.trim()}
                className="w-full"
                variant="outline"
              >
                Générer la signature
              </Button>

              <canvas
                ref={canvasRef}
                width={600}
                height={200}
                className="w-full border-2 border-dashed border-blue-300 rounded-lg bg-white"
              />
              
              <p className="text-xs text-slate-500 text-center">
                Votre nom sera affiché en style cursif
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="uploaded" className="space-y-4">
          <Card className="border-2 border-blue-200">
            <CardContent className="p-4 space-y-4">
              <div className="space-y-2">
                <Label>Uploader une image de signature</Label>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="cursor-pointer"
                />
                <p className="text-xs text-slate-500">
                  PNG, JPG, GIF (fond transparent recommandé)
                </p>
              </div>

              <canvas
                ref={canvasRef}
                width={600}
                height={200}
                className="w-full border-2 border-dashed border-blue-300 rounded-lg bg-white"
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={clearCanvas}
          className="flex-1"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Recommencer
        </Button>
        <Button
          onClick={handleConfirm}
          disabled={!hasSignature}
          className="flex-1 bg-green-600 hover:bg-green-700"
        >
          <Check className="w-4 h-4 mr-2" />
          Confirmer la signature
        </Button>
      </div>
    </div>
  );
}