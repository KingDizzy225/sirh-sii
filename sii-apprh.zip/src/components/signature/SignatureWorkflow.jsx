import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  PenTool, 
  Plus, 
  X, 
  Send, 
  Clock, 
  CheckCircle, 
  XCircle,
  AlertCircle,
  User,
  UserPlus,
  Mail,
  Calendar,
  Eye,
  RefreshCw,
  Bell,
  FileText,
  ExternalLink,
  Copy,
  Link
} from "lucide-react";
import { format, addDays, differenceInDays } from "date-fns";
import { fr } from "date-fns/locale";
import { useToast } from "@/components/ui/use-toast";
import { logDocumentAction, AUDIT_ACTIONS } from "../documents/DocumentAuditService";

const signerRoles = [
  { value: "employee", label: "Employé", icon: User },
  { value: "manager", label: "Manager", icon: User },
  { value: "hr", label: "RH", icon: User },
  { value: "director", label: "Directeur", icon: User },
  { value: "witness", label: "Témoin", icon: User },
  { value: "external", label: "Externe", icon: ExternalLink },
];

export default function SignatureWorkflow({ document, onClose, onRequestSent }) {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("request");
  const [signers, setSigners] = useState([]);
  const [message, setMessage] = useState("");
  const [deadline, setDeadline] = useState(format(addDays(new Date(), 7), 'yyyy-MM-dd'));
  const [sequentialSigning, setSequentialSigning] = useState(false);
  const [sendReminders, setSendReminders] = useState(true);
  const [reminderDays, setReminderDays] = useState(2);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.filter({ status: 'active' }),
  });

  const { data: existingSignatures = [] } = useQuery({
    queryKey: ['documentSignatures', document?.id],
    queryFn: () => base44.entities.DocumentSignature.filter({ document_id: document.id }),
    enabled: !!document?.id,
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  // Pré-remplir avec l'employé du document
  useEffect(() => {
    if (document?.employee_email && signers.length === 0) {
      setSigners([{
        type: "internal",
        email: document.employee_email,
        name: document.employee_name,
        role: "employee"
      }]);
    }
  }, [document]);

  const addInternalSigner = () => {
    setSigners([...signers, { type: "internal", email: "", name: "", role: "employee" }]);
  };

  const addExternalSigner = () => {
    setSigners([...signers, { type: "external", email: "", name: "", company: "", role: "external" }]);
  };

  const removeSigner = (index) => {
    setSigners(signers.filter((_, i) => i !== index));
  };

  const updateSigner = (index, field, value) => {
    const updated = [...signers];
    updated[index][field] = value;
    
    if (field === 'email' && updated[index].type === 'internal') {
      const emp = employees.find(e => e.email === value);
      if (emp) {
        updated[index].name = emp.full_name;
      }
    }
    
    setSigners(updated);
  };

  const generateExternalSigningLink = (signatureId) => {
    // Génère un lien unique pour signature externe
    const baseUrl = window.location.origin;
    const token = btoa(`${signatureId}-${Date.now()}`);
    return `${baseUrl}/sign/${token}`;
  };

  const handleSendRequest = async () => {
    if (signers.length === 0) {
      toast({ title: "Erreur", description: "Ajoutez au moins un signataire", variant: "destructive" });
      return;
    }

    const invalidSigners = signers.filter(s => !s.email || !s.name);
    if (invalidSigners.length > 0) {
      toast({ title: "Erreur", description: "Tous les signataires doivent avoir un email et un nom", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    try {
      const createdSignatures = [];

      for (let i = 0; i < signers.length; i++) {
        const signer = signers[i];
        
        const signatureRecord = await base44.entities.DocumentSignature.create({
          document_id: document.id,
          document_title: document.title,
          document_type: document.document_type,
          signer_email: signer.email,
          signer_name: signer.name,
          signer_role: signer.role,
          signer_company: signer.company || null,
          is_external: signer.type === "external",
          status: "pending",
          request_date: new Date().toISOString(),
          requested_by: user.email,
          requested_by_name: user.full_name || user.email,
          deadline: deadline,
          is_required: true,
          order: sequentialSigning ? i + 1 : 0,
          reminder_enabled: sendReminders,
          reminder_days_before: reminderDays,
          message: message,
          view_count: 0,
          last_viewed: null
        });

        createdSignatures.push(signatureRecord);

        // Notification pour signataires internes
        if (signer.type === "internal") {
          await base44.entities.Notification.create({
            user_email: signer.email,
            user_name: signer.name,
            notification_type: "signature_request",
            title: "📝 Document à signer",
            message: `Vous devez signer "${document.title}". Échéance: ${format(new Date(deadline), 'd MMMM yyyy', { locale: fr })}`,
            priority: "high",
            action_url: "/MySignatures",
            action_label: "Signer maintenant",
            related_id: document.id,
            related_type: "Document",
            sender_email: user.email,
            sender_name: user.full_name || user.email
          });
        }

        // Email pour tous les signataires
        const signingLink = signer.type === "external" 
          ? generateExternalSigningLink(signatureRecord.id)
          : `${window.location.origin}/MySignatures`;

        await base44.integrations.Core.SendEmail({
          to: signer.email,
          subject: `✍️ Signature requise: ${document.title}`,
          body: `
Bonjour ${signer.name},

Vous êtes invité(e) à signer électroniquement le document suivant :

📄 Document : ${document.title}
📁 Type : ${document.document_type}
👤 Demandé par : ${user.full_name || user.email}
📅 Date limite : ${format(new Date(deadline), 'd MMMM yyyy', { locale: fr })}

${message ? `💬 Message : ${message}\n\n` : ''}

${signer.type === "external" 
  ? `🔗 Cliquez sur le lien suivant pour signer le document :\n${signingLink}\n\nCe lien est personnel et sécurisé.`
  : `🔗 Connectez-vous au portail RH pour signer le document :\n${signingLink}`
}

${sequentialSigning ? '\n⚠️ Ce document nécessite des signatures séquentielles. Vous serez notifié(e) quand ce sera votre tour.\n' : ''}

---
Cette signature électronique a valeur légale conformément au règlement eIDAS.
Un certificat de signature sera généré après la finalisation.

Cordialement,
${user.full_name || user.email}
          `
        });
      }

      // Mettre à jour le document
      await base44.entities.Document.update(document.id, {
        status: "en_attente_signature",
        tags: [...new Set([...(document.tags || []), "signature_requise"])]
      });

      // Audit log
      if (user) {
        await logDocumentAction({
          document,
          action: AUDIT_ACTIONS.SIGNATURE_REQUESTED,
          actor: user,
          details: {
            signers_count: signers.length,
            sequential: sequentialSigning,
            deadline: deadline
          }
        });
      }

      toast({
        title: "Demandes envoyées ✅",
        description: `${signers.length} signataire(s) notifié(s)`,
      });

      onRequestSent?.();
      onClose();
    } catch (error) {
      console.error("Erreur envoi demandes signature:", error);
      toast({ title: "Erreur", description: "Impossible d'envoyer les demandes", variant: "destructive" });
    } finally {
      setIsSubmitting(false);
    }
  };

  const sendReminder = async (signature) => {
    try {
      await base44.integrations.Core.SendEmail({
        to: signature.signer_email,
        subject: `🔔 Rappel: Signature en attente - ${document.title}`,
        body: `
Bonjour ${signature.signer_name},

Ceci est un rappel pour la signature du document "${document.title}".

📅 Date limite : ${format(new Date(signature.deadline), 'd MMMM yyyy', { locale: fr })}
⏰ Jours restants : ${Math.max(0, differenceInDays(new Date(signature.deadline), new Date()))}

Merci de signer le document dès que possible.

Cordialement,
L'équipe RH
        `
      });

      await base44.entities.DocumentSignature.update(signature.id, {
        reminder_count: (signature.reminder_count || 0) + 1,
        reminder_sent: true
      });

      toast({ title: "Rappel envoyé ✅" });
      queryClient.invalidateQueries({ queryKey: ['documentSignatures'] });
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible d'envoyer le rappel", variant: "destructive" });
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenTool className="w-5 h-5 text-blue-600" />
            Workflow de Signature Électronique
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="request">Nouvelle demande</TabsTrigger>
            <TabsTrigger value="status">
              Suivi ({existingSignatures.length})
            </TabsTrigger>
          </TabsList>

          {/* Nouvelle demande */}
          <TabsContent value="request" className="space-y-6 mt-4">
            {/* Document info */}
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <FileText className="w-8 h-8 text-blue-600" />
                  <div>
                    <p className="font-semibold text-blue-900">{document.title}</p>
                    <p className="text-sm text-blue-700">{document.document_type}</p>
                    <p className="text-xs text-blue-600 mt-1">Employé: {document.employee_name}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Signataires */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-base font-semibold">Signataires *</Label>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" size="sm" onClick={addInternalSigner}>
                    <UserPlus className="w-4 h-4 mr-2" />
                    Interne
                  </Button>
                  <Button type="button" variant="outline" size="sm" onClick={addExternalSigner}>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Externe
                  </Button>
                </div>
              </div>

              {signers.map((signer, index) => (
                <Card key={index} className={`border ${signer.type === 'external' ? 'border-orange-200 bg-orange-50' : 'border-slate-200'}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-3">
                          <Badge variant={signer.type === 'external' ? 'default' : 'outline'} className={signer.type === 'external' ? 'bg-orange-600' : ''}>
                            {signer.type === 'external' ? 'Externe' : 'Interne'}
                          </Badge>
                          {sequentialSigning && <Badge variant="outline">Ordre: {index + 1}</Badge>}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          {signer.type === 'internal' ? (
                            <div className="space-y-2">
                              <Label className="text-xs">Employé</Label>
                              <Select value={signer.email} onValueChange={(v) => updateSigner(index, 'email', v)}>
                                <SelectTrigger><SelectValue placeholder="Sélectionner" /></SelectTrigger>
                                <SelectContent className="max-h-[300px]">
                                  {employees.map(emp => (
                                    <SelectItem key={emp.id} value={emp.email}>
                                      {emp.full_name} - {emp.position}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          ) : (
                            <>
                              <div className="space-y-2">
                                <Label className="text-xs">Email *</Label>
                                <Input
                                  type="email"
                                  value={signer.email}
                                  onChange={(e) => updateSigner(index, 'email', e.target.value)}
                                  placeholder="email@externe.com"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label className="text-xs">Nom *</Label>
                                <Input
                                  value={signer.name}
                                  onChange={(e) => updateSigner(index, 'name', e.target.value)}
                                  placeholder="Nom complet"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label className="text-xs">Entreprise</Label>
                                <Input
                                  value={signer.company || ""}
                                  onChange={(e) => updateSigner(index, 'company', e.target.value)}
                                  placeholder="Nom entreprise"
                                />
                              </div>
                            </>
                          )}

                          <div className="space-y-2">
                            <Label className="text-xs">Rôle</Label>
                            <Select value={signer.role} onValueChange={(v) => updateSigner(index, 'role', v)}>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {signerRoles.map(r => (
                                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>

                      <Button type="button" variant="ghost" size="icon" onClick={() => removeSigner(index)} className="text-red-600">
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {signers.length === 0 && (
                <Card className="border-dashed border-2 border-slate-300">
                  <CardContent className="p-8 text-center text-slate-500">
                    <PenTool className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p>Ajoutez des signataires internes ou externes</p>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Options */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Date limite</Label>
                    <Input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} min={format(new Date(), 'yyyy-MM-dd')} />
                  </div>
                  <div className="space-y-2">
                    <Label>Rappel automatique (jours avant échéance)</Label>
                    <Input type="number" min="1" max="7" value={reminderDays} onChange={(e) => setReminderDays(parseInt(e.target.value))} disabled={!sendReminders} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Message personnalisé</Label>
                  <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Message optionnel pour les signataires..." rows={2} />
                </div>

                <div className="flex flex-wrap gap-6">
                  <div className="flex items-center gap-2">
                    <Checkbox id="sequential" checked={sequentialSigning} onCheckedChange={setSequentialSigning} />
                    <Label htmlFor="sequential">Signature séquentielle</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox id="reminders" checked={sendReminders} onCheckedChange={setSendReminders} />
                    <Label htmlFor="reminders">Rappels automatiques</Label>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={onClose}>Annuler</Button>
              <Button onClick={handleSendRequest} disabled={isSubmitting || signers.length === 0} className="bg-blue-600 hover:bg-blue-700">
                {isSubmitting ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" /> Envoi...</> : <><Send className="w-4 h-4 mr-2" /> Envoyer</>}
              </Button>
            </div>
          </TabsContent>

          {/* Suivi des signatures */}
          <TabsContent value="status" className="space-y-4 mt-4">
            <SignatureStatusList 
              signatures={existingSignatures}
              onSendReminder={sendReminder}
            />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function SignatureStatusList({ signatures, onSendReminder }) {
  if (signatures.length === 0) {
    return (
      <Card className="border-none shadow-lg">
        <CardContent className="p-8 text-center text-slate-500">
          <PenTool className="w-12 h-12 mx-auto mb-3 text-slate-300" />
          <p>Aucune demande de signature en cours</p>
        </CardContent>
      </Card>
    );
  }

  const signedCount = signatures?.filter(s => s.status === 'signed').length || 0;
  const pendingCount = signatures?.filter(s => s.status === 'pending').length || 0;
  const declinedCount = signatures?.filter(s => s.status === 'declined').length || 0;
  const total = signatures?.length || 0;
  const progress = total > 0 ? Math.round((signedCount / total) * 100) : 0;

  const statusConfig = {
    pending: { icon: Clock, color: "text-yellow-600", bg: "bg-yellow-100", label: "En attente" },
    signed: { icon: CheckCircle, color: "text-green-600", bg: "bg-green-100", label: "Signé" },
    declined: { icon: XCircle, color: "text-red-600", bg: "bg-red-100", label: "Refusé" },
    viewed: { icon: Eye, color: "text-blue-600", bg: "bg-blue-100", label: "Consulté" },
  };

  return (
    <div className="space-y-4">
      {/* Progress */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Progression</span>
            <span className="text-sm font-bold text-blue-600">{signedCount}/{total} ({progress}%)</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-3">
            <div className="bg-green-600 h-3 rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex justify-between mt-2 text-xs text-slate-600">
            <span>✅ {signedCount} signé{signedCount > 1 ? 's' : ''}</span>
            <span>⏳ {pendingCount} en attente</span>
            {declinedCount > 0 && <span className="text-red-600">❌ {declinedCount} refusé{declinedCount > 1 ? 's' : ''}</span>}
          </div>
        </CardContent>
      </Card>

      {/* Liste */}
      {(signatures || []).sort((a, b) => (a.order || 0) - (b.order || 0)).map((sig) => {
        const config = statusConfig[sig.status] || statusConfig.pending;
        const StatusIcon = config.icon;
        const isPastDeadline = new Date() > new Date(sig.deadline);
        const daysLeft = differenceInDays(new Date(sig.deadline), new Date());

        return (
          <Card key={sig.id} className="border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-full ${config.bg} flex items-center justify-center`}>
                    <StatusIcon className={`w-5 h-5 ${config.color}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold">{sig.signer_name}</p>
                      {sig.is_external && <Badge className="bg-orange-600 text-xs">Externe</Badge>}
                      {sig.order > 0 && <Badge variant="outline" className="text-xs">#{sig.order}</Badge>}
                    </div>
                    <p className="text-sm text-slate-600">{sig.signer_email}</p>
                    <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
                      <span>Demandé le {format(new Date(sig.request_date), 'dd/MM/yyyy', { locale: fr })}</span>
                      {sig.view_count > 0 && <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {sig.view_count} vue{sig.view_count > 1 ? 's' : ''}</span>}
                    </div>
                    {sig.status === 'signed' && sig.signed_date && (
                      <p className="text-xs text-green-600 mt-1">
                        Signé le {format(new Date(sig.signed_date), "dd/MM/yyyy 'à' HH:mm", { locale: fr })}
                      </p>
                    )}
                    {sig.status === 'declined' && sig.decline_reason && (
                      <p className="text-xs text-red-600 mt-1 p-2 bg-red-50 rounded">
                        Raison: {sig.decline_reason}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  <Badge className={`${config.bg} ${config.color} border-0`}>{config.label}</Badge>
                  {sig.status === 'pending' && (
                    <>
                      {isPastDeadline ? (
                        <Badge className="bg-red-600">Échéance dépassée</Badge>
                      ) : daysLeft <= 3 ? (
                        <Badge className="bg-orange-600">{daysLeft}j restant{daysLeft > 1 ? 's' : ''}</Badge>
                      ) : null}
                      <Button size="sm" variant="outline" onClick={() => onSendReminder(sig)}>
                        <Bell className="w-3 h-3 mr-1" /> Rappel
                      </Button>
                    </>
                  )}
                </div>
              </div>

              {/* Audit info */}
              {sig.status === 'signed' && sig.certificate_hash && (
                <div className="mt-3 pt-3 border-t text-xs text-slate-500">
                  <span className="font-medium">Hash: </span>
                  <code className="bg-slate-100 px-1 rounded">{sig.certificate_hash.substring(0, 24)}...</code>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}