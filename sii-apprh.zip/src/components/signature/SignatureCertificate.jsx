import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Shield } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

/**
 * Génère et télécharge un certificat de signature
 */
export default function SignatureCertificate({ document, signatures }) {
  const generateCertificate = () => {
    const certificateContent = `
╔═══════════════════════════════════════════════════════════════╗
║           CERTIFICAT DE SIGNATURE ÉLECTRONIQUE                ║
╚═══════════════════════════════════════════════════════════════╝

Document: ${document.title}
Type: ${document.document_type}
Employé concerné: ${document.employee_name}

Date de création du document: ${format(new Date(document.created_date), 'd MMMM yyyy', { locale: fr })}
Date de certification: ${format(new Date(), "d MMMM yyyy 'à' HH:mm:ss", { locale: fr })}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SIGNATURES COLLECTÉES (${signatures.filter(s => s.status === 'signed').length}/${signatures.length}):

${signatures
  .filter(s => s.status === 'signed')
  .sort((a, b) => (a.order || 0) - (b.order || 0))
  .map((sig, index) => `
${index + 1}. ${sig.signer_name}
   Rôle: ${sig.signer_role}
   Email: ${sig.signer_email}
   Date de signature: ${format(new Date(sig.signed_date), "d MMMM yyyy 'à' HH:mm:ss", { locale: fr })}
   Type de signature: ${sig.signature_type}
   Adresse IP: ${sig.ip_address || 'N/A'}
   Hash de certification: ${sig.certificate_hash || 'N/A'}
   ${sig.order > 0 ? `Ordre de signature: #${sig.order}` : ''}
`).join('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VALIDATION ET CONFORMITÉ

✓ Toutes les signatures requises ont été collectées
✓ Chaque signature est horodatée et traçable
✓ Les hashs cryptographiques garantissent l'intégrité
✓ Piste d'audit complète disponible

Ce certificat atteste que le document "${document.title}" a été 
signé électroniquement par toutes les parties requises conformément 
aux réglementations en vigueur sur les signatures électroniques.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Hash du document: ${document.id}
Version du document: ${document.current_version || 1}

Ce certificat a été généré automatiquement par le système RH.
Il constitue une preuve juridiquement valable de la signature du document.

Pour toute question, contactez le service RH.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Généré le ${format(new Date(), "d MMMM yyyy 'à' HH:mm:ss", { locale: fr })}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`;

    // Télécharger le certificat
    const blob = new Blob([certificateContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Certificat_Signature_${document.title.replace(/[^a-zA-Z0-9]/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const allSigned = signatures.every(s => s.status === 'signed');

  if (!allSigned) return null;

  return (
    <Card className="border-green-200 bg-green-50">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-green-600" />
            <div>
              <p className="font-semibold text-green-900">Certificat de signature disponible</p>
              <p className="text-xs text-green-700">
                Téléchargez le certificat d'authenticité pour vos archives
              </p>
            </div>
          </div>
          <Button
            onClick={generateCertificate}
            className="bg-green-600 hover:bg-green-700"
          >
            <Download className="w-4 h-4 mr-2" />
            Télécharger le certificat
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}