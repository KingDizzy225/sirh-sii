import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";

export default function AttendanceForm({ employees, existingAttendance, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    date: format(new Date(), 'yyyy-MM-dd'),
    status: "present",
    clock_in: "",
    clock_out: "",
    notes: "",
  });

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      employee_email: email,
      employee_name: employee?.full_name || ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calculate hours worked if both clock times provided
    let hours_worked = 0;
    if (formData.clock_in && formData.clock_out) {
      const [inHour, inMin] = formData.clock_in.split(':').map(Number);
      const [outHour, outMin] = formData.clock_out.split(':').map(Number);
      hours_worked = (outHour + outMin / 60) - (inHour + inMin / 60);
    }

    onSubmit({
      ...formData,
      hours_worked
    });
  };

  const alreadyMarked = existingAttendance.some(a => a.employee_email === formData.employee_email);

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Mark Attendance</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="employee">Employee *</Label>
            <Select
              value={formData.employee_email}
              onValueChange={handleEmployeeChange}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select employee" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.email}>
                    {emp.full_name} - {emp.position}
                    {existingAttendance.some(a => a.employee_email === emp.email) && ' (marked)'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {alreadyMarked && (
              <p className="text-xs text-orange-600">This employee's attendance is already marked for today</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="date">Date *</Label>
            <Input
              id="date"
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({...formData, date: e.target.value})}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="status">Status *</Label>
            <Select
              value={formData.status}
              onValueChange={(value) => setFormData({...formData, status: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="present">Present</SelectItem>
                <SelectItem value="absent">Absent</SelectItem>
                <SelectItem value="late">Late</SelectItem>
                <SelectItem value="half_day">Half Day</SelectItem>
                <SelectItem value="on_leave">On Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="clock_in">Clock In</Label>
              <Input
                id="clock_in"
                type="time"
                value={formData.clock_in}
                onChange={(e) => setFormData({...formData, clock_in: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="clock_out">Clock Out</Label>
              <Input
                id="clock_out"
                type="time"
                value={formData.clock_out}
                onChange={(e) => setFormData({...formData, clock_out: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
              placeholder="Additional notes..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Saving...' : 'Mark Attendance'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}