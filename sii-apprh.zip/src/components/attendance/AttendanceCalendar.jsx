import React from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function AttendanceCalendar({ attendance, selectedDate }) {
  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getAttendanceForDay = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return attendance.filter(a => a.date === dateStr);
  };

  return (
    <div>
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-slate-900">
          {format(selectedDate, 'MMMM yyyy')}
        </h3>
      </div>

      <div className="grid grid-cols-7 gap-2">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center text-sm font-medium text-slate-600 py-2">
            {day}
          </div>
        ))}

        {daysInMonth.map(date => {
          const dayAttendance = getAttendanceForDay(date);
          const present = dayAttendance.filter(a => a.status === 'present').length;
          const total = dayAttendance.length;
          const rate = total > 0 ? Math.round((present / total) * 100) : 0;

          return (
            <div
              key={date.toString()}
              className={`aspect-square p-2 rounded-lg border ${
                isToday(date) 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-slate-200 hover:border-slate-300'
              } ${!isSameMonth(date, selectedDate) ? 'opacity-50' : ''}`}
            >
              <div className="text-sm font-medium text-slate-900 mb-1">
                {format(date, 'd')}
              </div>
              {total > 0 && (
                <div className="text-xs">
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${
                      rate >= 90 ? 'bg-green-50 text-green-700 border-green-200' :
                      rate >= 70 ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                      'bg-red-50 text-red-700 border-red-200'
                    }`}
                  >
                    {rate}%
                  </Badge>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}