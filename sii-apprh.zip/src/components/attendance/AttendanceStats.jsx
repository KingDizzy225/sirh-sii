import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, XCircle, Clock, Calendar } from "lucide-react";
import { format, startOfMonth } from "date-fns";

export default function AttendanceStats({ attendance, employees }) {
  const today = format(new Date(), 'yyyy-MM-dd');
  const monthStart = format(startOfMonth(new Date()), 'yyyy-MM-dd');

  const todayAttendance = attendance.filter(a => a.date === today);
  const present = todayAttendance.filter(a => a.status === 'present').length;
  const late = todayAttendance.filter(a => a.status === 'late').length;
  const absent = todayAttendance.filter(a => a.status === 'absent').length;

  const monthAttendance = attendance.filter(a => a.date >= monthStart);
  const monthPresent = monthAttendance.filter(a => a.status === 'present').length;
  const attendanceRate = monthAttendance.length > 0 
    ? Math.round((monthPresent / monthAttendance.length) * 100)
    : 0;

  const stats = [
    {
      title: "Present Today",
      value: present,
      icon: CheckCircle,
      color: "text-green-600",
      bg: "bg-green-50",
    },
    {
      title: "Late Today",
      value: late,
      icon: Clock,
      color: "text-orange-600",
      bg: "bg-orange-50",
    },
    {
      title: "Absent Today",
      value: absent,
      icon: XCircle,
      color: "text-red-600",
      bg: "bg-red-50",
    },
    {
      title: "Monthly Rate",
      value: `${attendanceRate}%`,
      icon: Calendar,
      color: "text-blue-600",
      bg: "bg-blue-50",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat) => (
        <Card key={stat.title} className="shadow-lg border-none">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">{stat.title}</p>
                <h3 className="text-3xl font-bold text-slate-900">{stat.value}</h3>
              </div>
              <div className={`p-3 rounded-xl ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}