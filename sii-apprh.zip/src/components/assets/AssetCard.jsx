import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Laptop, Smartphone, Monitor, Car, Package, User, Calendar } from "lucide-react";
import { format } from "date-fns";

const assetIcons = {
  laptop: Laptop,
  phone: Smartphone,
  tablet: Smartphone,
  monitor: Monitor,
  vehicle: Car,
  other: Package,
};

const statusColors = {
  available: "bg-green-100 text-green-800",
  assigned: "bg-blue-100 text-blue-800",
  maintenance: "bg-orange-100 text-orange-800",
  retired: "bg-gray-100 text-gray-800",
};

const statusLabels = {
  available: "Disponible",
  assigned: "Assigné",
  maintenance: "Maintenance",
  retired: "Retiré",
};

const conditionColors = {
  new: "bg-green-100 text-green-800",
  good: "bg-blue-100 text-blue-800",
  fair: "bg-yellow-100 text-yellow-800",
  poor: "bg-red-100 text-red-800",
};

export default function AssetCard({ asset, employees, onAssign, onUnassign }) {
  const [selectedEmployee, setSelectedEmployee] = useState("");
  const Icon = assetIcons[asset.asset_type] || Package;

  const handleAssign = () => {
    const employee = employees.find(e => e.email === selectedEmployee);
    if (employee) {
      onAssign(asset.id, employee.email, employee.full_name);
      setSelectedEmployee("");
    }
  };

  return (
    <Card className="shadow-lg border-none">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <Icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900">{asset.asset_name}</h3>
              <p className="text-sm text-slate-600">{asset.brand} {asset.model}</p>
            </div>
          </div>
        </div>

        <div className="flex gap-2 mb-4">
          <Badge className={statusColors[asset.status]}>
            {statusLabels[asset.status]}
          </Badge>
          <Badge className={conditionColors[asset.condition]}>
            {asset.condition}
          </Badge>
        </div>

        <div className="space-y-2 mb-4 text-sm text-slate-600">
          <div>
            <span className="font-medium">N° série:</span> {asset.serial_number}
          </div>
          {asset.purchase_date && (
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>Acheté le {format(new Date(asset.purchase_date), 'dd/MM/yyyy')}</span>
            </div>
          )}
          {asset.assigned_to_name && (
            <div className="flex items-center gap-2 text-blue-600 font-medium">
              <User className="w-4 h-4" />
              <span>Assigné à: {asset.assigned_to_name}</span>
            </div>
          )}
        </div>

        {asset.status === 'available' ? (
          <div className="space-y-2">
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger>
                <SelectValue placeholder="Assigner à un employé" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.email}>
                    {emp.full_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={handleAssign}
              disabled={!selectedEmployee}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              Assigner
            </Button>
          </div>
        ) : asset.status === 'assigned' ? (
          <Button
            onClick={() => onUnassign(asset.id)}
            variant="outline"
            className="w-full"
          >
            Désassigner
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}