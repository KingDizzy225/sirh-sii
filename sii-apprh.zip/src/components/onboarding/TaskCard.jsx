import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, User, AlertCircle, CheckCircle, Building2, Flag } from "lucide-react";
import { format, isPast, differenceInDays } from "date-fns";
import { fr } from "date-fns/locale";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  in_progress: "bg-blue-100 text-blue-800 border-blue-200",
  completed: "bg-green-100 text-green-800 border-green-200",
};

const statusLabels = {
  pending: "En attente",
  in_progress: "En cours",
  completed: "Terminée",
};

const priorityColors = {
  low: "bg-gray-100 text-gray-700",
  medium: "bg-blue-100 text-blue-700",
  high: "bg-orange-100 text-orange-700",
  critical: "bg-red-100 text-red-700",
};

const priorityLabels = {
  low: "Faible",
  medium: "Moyenne",
  high: "Haute",
  critical: "Critique",
};

const priorityIcons = {
  low: "🔵",
  medium: "🟡",
  high: "🟠",
  critical: "🔴",
};

export default function TaskCard({ task, onUpdateStatus }) {
  const dueDate = new Date(task.due_date);
  const isOverdue = isPast(dueDate) && task.status !== 'completed';
  const daysUntilDue = differenceInDays(dueDate, new Date());
  const isDueSoon = daysUntilDue >= 0 && daysUntilDue <= 3 && task.status !== 'completed';

  const handleStatusChange = (newStatus) => {
    onUpdateStatus(task.id, newStatus);
  };

  return (
    <Card className={`shadow-lg transition-all duration-300 hover:shadow-xl border-2 ${
      isOverdue ? 'border-red-300 bg-red-50/30' : 
      isDueSoon ? 'border-orange-300 bg-orange-50/30' :
      task.status === 'completed' ? 'border-green-300' : 
      'border-slate-200'
    }`}>
      <CardContent className="p-6">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Badge className={`${statusColors[task.status]} border font-medium`}>
                  {statusLabels[task.status]}
                </Badge>
                <Badge className={priorityColors[task.priority]} variant="outline">
                  <Flag className="w-3 h-3 mr-1" />
                  {priorityLabels[task.priority]}
                </Badge>
                {task.task_type && (
                  <Badge variant="outline" className={
                    task.task_type === 'onboarding' ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700'
                  }>
                    {task.task_type === 'onboarding' ? 'Intégration' : 'Départ'}
                  </Badge>
                )}
              </div>
              <h3 className="font-bold text-lg text-slate-900 leading-tight">
                {task.title}
              </h3>
            </div>
            <div className="flex-shrink-0">
              {task.status === 'completed' ? (
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              ) : isOverdue ? (
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center animate-pulse">
                  <AlertCircle className="w-6 h-6 text-red-600" />
                </div>
              ) : (
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg">
              {task.description}
            </p>
          )}

          {/* Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
            <div className="flex items-center gap-2 text-sm">
              <User className="w-4 h-4 text-slate-500 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-slate-500">Employé</p>
                <p className="font-medium text-slate-900 truncate">{task.employee_name}</p>
              </div>
            </div>

            {task.department && (
              <div className="flex items-center gap-2 text-sm">
                <Building2 className="w-4 h-4 text-slate-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Département</p>
                  <p className="font-medium text-slate-900 truncate">{task.department}</p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 text-sm">
              <Calendar className="w-4 h-4 text-slate-500 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs text-slate-500">Date d'échéance</p>
                <p className={`font-medium ${
                  isOverdue ? 'text-red-600 font-bold' : 
                  isDueSoon ? 'text-orange-600 font-bold' : 
                  'text-slate-900'
                }`}>
                  {format(dueDate, 'dd MMMM yyyy', { locale: fr })}
                </p>
              </div>
            </div>

            {task.assigned_to && (
              <div className="flex items-center gap-2 text-sm">
                <User className="w-4 h-4 text-slate-500 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Assigné à</p>
                  <p className="font-medium text-slate-900 truncate">{task.assigned_to}</p>
                </div>
              </div>
            )}
          </div>

          {/* Status Warning/Info */}
          {isOverdue && (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-700 font-medium">
                ⚠️ En retard de {Math.abs(daysUntilDue)} jour{Math.abs(daysUntilDue) > 1 ? 's' : ''}
              </p>
            </div>
          )}

          {isDueSoon && !isOverdue && (
            <div className="flex items-center gap-2 p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <Clock className="w-5 h-5 text-orange-600 flex-shrink-0" />
              <p className="text-sm text-orange-700 font-medium">
                ⏰ À réaliser dans {daysUntilDue} jour{daysUntilDue > 1 ? 's' : ''}
              </p>
            </div>
          )}

          {task.notes && (
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-xs text-blue-700 font-medium mb-1">📝 Notes</p>
              <p className="text-sm text-blue-900">{task.notes}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2 border-t border-slate-200">
            {task.status === 'pending' && (
              <Button
                onClick={() => handleStatusChange('in_progress')}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <PlayCircle className="w-4 h-4 mr-2" />
                Commencer
              </Button>
            )}

            {task.status === 'in_progress' && (
              <Button
                onClick={() => handleStatusChange('completed')}
                className="flex-1 bg-green-600 hover:bg-green-700"
                size="sm"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Marquer comme terminée
              </Button>
            )}

            {task.status === 'completed' && (
              <Button
                onClick={() => handleStatusChange('in_progress')}
                variant="outline"
                className="flex-1"
                size="sm"
              >
                Rouvrir
              </Button>
            )}

            {task.status !== 'pending' && task.status !== 'completed' && (
              <Button
                onClick={() => handleStatusChange('pending')}
                variant="outline"
                size="sm"
              >
                Remettre en attente
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function PlayCircle({ className }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  );
}