import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";

export default function InterviewForm({ candidates = [], jobPostings = [], onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    candidate_id: "",
    candidate_name: "",
    candidate_email: "",
    job_posting_id: "",
    job_title: "",
    interview_date: format(new Date(), 'yyyy-MM-dd'),
    interview_time: "10:00",
    duration_minutes: 60,
    interviewer_email: "",
    interviewer_name: "",
    interview_type: "in_person",
    location: "",
    video_link: "",
    status: "scheduled",
    notes: "",
  });

  // Filtrer les candidats éligibles (en présélection ou entretien)
  const eligibleCandidates = candidates.filter(c => 
    c.status === 'new' || c.status === 'screening' || c.status === 'interview'
  );

  const handleCandidateChange = (candidateId) => {
    const candidate = candidates.find(c => c.id === candidateId);
    if (candidate) {
      setFormData({
        ...formData,
        candidate_id: candidateId,
        candidate_name: candidate.full_name || "",
        candidate_email: candidate.email || "",
        job_posting_id: candidate.job_posting_id || "",
        job_title: candidate.job_title || "",
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validation de base
    if (!formData.candidate_id || !formData.interview_date || !formData.interviewer_name) {
      return;
    }

    onSubmit({
      ...formData,
      duration_minutes: parseInt(formData.duration_minutes) || 60,
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Planifier un entretien</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Sélection du candidat */}
          <div className="space-y-2">
            <Label htmlFor="candidate">Candidat *</Label>
            <Select
              value={formData.candidate_id}
              onValueChange={handleCandidateChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un candidat" />
              </SelectTrigger>
              <SelectContent>
                {eligibleCandidates.length === 0 ? (
                  <SelectItem value="none" disabled>Aucun candidat éligible</SelectItem>
                ) : (
                  eligibleCandidates.map(candidate => (
                    <SelectItem key={candidate.id} value={candidate.id}>
                      {candidate.full_name} - {candidate.job_title || "Poste non défini"}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Date */}
            <div className="space-y-2">
              <Label htmlFor="interview_date">Date *</Label>
              <Input
                id="interview_date"
                type="date"
                value={formData.interview_date}
                onChange={(e) => setFormData({...formData, interview_date: e.target.value})}
                required
              />
            </div>

            {/* Heure */}
            <div className="space-y-2">
              <Label htmlFor="interview_time">Heure *</Label>
              <Input
                id="interview_time"
                type="time"
                value={formData.interview_time}
                onChange={(e) => setFormData({...formData, interview_time: e.target.value})}
                required
              />
            </div>

            {/* Durée */}
            <div className="space-y-2">
              <Label htmlFor="duration_minutes">Durée (minutes)</Label>
              <Select
                value={String(formData.duration_minutes)}
                onValueChange={(value) => setFormData({...formData, duration_minutes: parseInt(value)})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="45">45 minutes</SelectItem>
                  <SelectItem value="60">1 heure</SelectItem>
                  <SelectItem value="90">1h30</SelectItem>
                  <SelectItem value="120">2 heures</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Type d'entretien */}
            <div className="space-y-2">
              <Label htmlFor="interview_type">Type d'entretien *</Label>
              <Select
                value={formData.interview_type}
                onValueChange={(value) => setFormData({...formData, interview_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="phone">Téléphonique</SelectItem>
                  <SelectItem value="video">Visioconférence</SelectItem>
                  <SelectItem value="in_person">En personne</SelectItem>
                  <SelectItem value="technical">Technique</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Nom de l'intervieweur */}
            <div className="space-y-2">
              <Label htmlFor="interviewer_name">Nom de l'intervieweur *</Label>
              <Input
                id="interviewer_name"
                value={formData.interviewer_name}
                onChange={(e) => setFormData({...formData, interviewer_name: e.target.value})}
                placeholder="Jean Dupont"
                required
              />
            </div>

            {/* Email de l'intervieweur */}
            <div className="space-y-2">
              <Label htmlFor="interviewer_email">Email de l'intervieweur</Label>
              <Input
                id="interviewer_email"
                type="email"
                value={formData.interviewer_email}
                onChange={(e) => setFormData({...formData, interviewer_email: e.target.value})}
                placeholder="jean.dupont@entreprise.com"
              />
            </div>
          </div>

          {/* Lieu / Lien */}
          <div className="space-y-2">
            <Label htmlFor="location">
              {formData.interview_type === 'video' ? 'Lien de visioconférence' : 'Lieu'}
            </Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => setFormData({...formData, location: e.target.value})}
              placeholder={formData.interview_type === 'video' ? 'https://meet.google.com/...' : 'Bureau 301, 3ème étage'}
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optionnel)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Notes additionnelles pour l'entretien..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.candidate_id}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSubmitting ? 'Création...' : 'Planifier l\'entretien'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}