import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  Star, User, Briefcase, Calendar, Clock, MapPin, 
  ChevronLeft, ChevronRight, Save, CheckCircle, 
  MessageSquare, Award, FileText
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";

export default function InterviewSession({ interview, candidate, jobPosting, onClose }) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const questions = jobPosting?.interview_questions || [];
  const totalQuestions = questions.length;

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [scores, setScores] = useState(candidate?.interview_scores || {});
  const [notes, setNotes] = useState({});
  const [globalNotes, setGlobalNotes] = useState(interview?.notes || "");
  const [globalRating, setGlobalRating] = useState(interview?.rating || 0);
  const [feedback, setFeedback] = useState(interview?.feedback || "");

  const updateInterviewMutation = useMutation({
    mutationFn: (data) => base44.entities.Interview.update(interview.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interviews'] });
    },
  });

  const updateCandidateMutation = useMutation({
    mutationFn: (data) => base44.entities.Candidate.update(candidate?.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
    },
  });

  // Vérifications de sécurité - après les hooks
  if (!interview || !candidate) {
    return null;
  }

  const calculateOverallScore = (currentScores) => {
    if (totalQuestions === 0) return 0;
    const answered = Object.keys(currentScores).length;
    if (answered === 0) return 0;
    const total = Object.values(currentScores).reduce((sum, s) => sum + s, 0);
    return Math.round((total / (totalQuestions * 5)) * 100);
  };

  const handleScoreChange = (questionIndex, score) => {
    const newScores = { ...scores, [questionIndex]: score };
    setScores(newScores);
  };

  const handleNoteChange = (questionIndex, note) => {
    setNotes({ ...notes, [questionIndex]: note });
  };

  const handleSave = async (complete = false) => {
    const overallScore = calculateOverallScore(scores);

    // Sauvegarder sur le candidat
    await updateCandidateMutation.mutateAsync({
      interview_scores: scores,
      overall_score: overallScore,
      rating: globalRating || candidate?.rating,
      notes: candidate?.notes 
        ? `${candidate.notes}\n\n--- Entretien du ${format(new Date(), 'dd/MM/yyyy')} ---\n${globalNotes}`
        : `--- Entretien du ${format(new Date(), 'dd/MM/yyyy')} ---\n${globalNotes}`,
    });

    // Sauvegarder sur l'entretien
    await updateInterviewMutation.mutateAsync({
      rating: globalRating,
      feedback,
      notes: globalNotes,
      status: complete ? 'completed' : interview.status,
    });

    toast({
      title: complete ? "Entretien terminé ✅" : "Évaluation sauvegardée",
      description: complete 
        ? `Score global: ${overallScore}%` 
        : "Vos notes ont été enregistrées",
    });

    if (complete) {
      onClose();
    }
  };

  const progress = totalQuestions > 0 
    ? Math.round((Object.keys(scores).length / totalQuestions) * 100)
    : 0;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-0">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b z-10 p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <span className="text-white font-bold text-xl">
                  {candidate?.full_name?.charAt(0) || '?'}
                </span>
              </div>
              <div>
                <DialogTitle className="text-xl">{candidate?.full_name}</DialogTitle>
                <p className="text-blue-600 font-medium">{jobPosting?.title || interview?.job_title}</p>
                <div className="flex items-center gap-3 mt-1 text-sm text-slate-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {format(new Date(interview.interview_date), 'dd MMMM yyyy', { locale: fr })}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {interview.interview_time}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <Badge className="bg-blue-100 text-blue-800 text-lg px-3 py-1">
                Score: {calculateOverallScore(scores)}%
              </Badge>
              {totalQuestions > 0 && (
                <p className="text-xs text-slate-500 mt-1">
                  {Object.keys(scores).length}/{totalQuestions} questions évaluées
                </p>
              )}
            </div>
          </div>
          
          {totalQuestions > 0 && (
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>

        <div className="p-6">
          {totalQuestions === 0 ? (
            /* Pas de questionnaire défini */
            <div className="space-y-6">
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <p className="text-orange-800">
                    Aucun questionnaire n'est défini pour ce poste. Vous pouvez tout de même noter l'entretien.
                  </p>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Award className="w-5 h-5 text-yellow-500" />
                      Évaluation globale
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setGlobalRating(star)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              star <= globalRating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="ml-3 text-lg font-semibold">
                        {globalRating > 0 ? `${globalRating}/5` : ''}
                      </span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <User className="w-5 h-5 text-blue-500" />
                      Infos candidat
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm space-y-1">
                    <p><span className="text-slate-500">Email:</span> {candidate?.email}</p>
                    <p><span className="text-slate-500">Téléphone:</span> {candidate?.phone || 'N/A'}</p>
                    <p><span className="text-slate-500">Expérience:</span> {candidate?.experience_years ? `${candidate.experience_years} ans` : 'N/A'}</p>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-2">
                <Label>Feedback de l'entretien</Label>
                <Textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  rows={4}
                  placeholder="Points forts, points d'amélioration, impression générale..."
                />
              </div>

              <div className="space-y-2">
                <Label>Notes complémentaires</Label>
                <Textarea
                  value={globalNotes}
                  onChange={(e) => setGlobalNotes(e.target.value)}
                  rows={3}
                  placeholder="Notes additionnelles..."
                />
              </div>
            </div>
          ) : (
            /* Questionnaire disponible */
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Liste des questions */}
              <div className="lg:col-span-1 space-y-2">
                <h3 className="font-semibold text-slate-700 mb-3">Questions ({totalQuestions})</h3>
                <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
                  {questions.map((question, index) => {
                    const isAnswered = scores[index] !== undefined;
                    const isActive = currentQuestionIndex === index;
                    
                    return (
                      <button
                        key={index}
                        onClick={() => setCurrentQuestionIndex(index)}
                        className={`w-full text-left p-3 rounded-lg border transition-all ${
                          isActive 
                            ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200' 
                            : isAnswered
                              ? 'border-green-300 bg-green-50'
                              : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-start gap-2">
                          <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                            isAnswered ? 'bg-green-500 text-white' : 'bg-slate-200 text-slate-600'
                          }`}>
                            {isAnswered ? <CheckCircle className="w-4 h-4" /> : index + 1}
                          </div>
                          <p className="text-sm text-slate-700 line-clamp-2">{question}</p>
                        </div>
                        {isAnswered && (
                          <div className="flex items-center gap-1 mt-2 ml-8">
                            {[1, 2, 3, 4, 5].map((s) => (
                              <Star
                                key={s}
                                className={`w-3 h-3 ${
                                  s <= scores[index] ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'
                                }`}
                              />
                            ))}
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Question active */}
              <div className="lg:col-span-2 space-y-6">
                <Card className="border-blue-200">
                  <CardHeader className="bg-blue-50 border-b border-blue-100">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">
                        Question {currentQuestionIndex + 1} / {totalQuestions}
                      </CardTitle>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
                          disabled={currentQuestionIndex === 0}
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentQuestionIndex(Math.min(totalQuestions - 1, currentQuestionIndex + 1))}
                          disabled={currentQuestionIndex === totalQuestions - 1}
                        >
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-lg text-slate-800 mb-6">
                      {questions[currentQuestionIndex]}
                    </p>

                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-semibold mb-3 block">Évaluation</Label>
                        <div className="flex items-center gap-3">
                          {[1, 2, 3, 4, 5].map((score) => (
                            <button
                              key={score}
                              type="button"
                              onClick={() => handleScoreChange(currentQuestionIndex, score)}
                              className="transition-transform hover:scale-110"
                            >
                              <Star
                                className={`w-10 h-10 ${
                                  score <= (scores[currentQuestionIndex] || 0)
                                    ? 'fill-yellow-400 text-yellow-400'
                                    : 'text-slate-300 hover:text-yellow-200'
                                }`}
                              />
                            </button>
                          ))}
                          <span className="ml-4 text-lg font-semibold text-slate-700">
                            {scores[currentQuestionIndex] ? `${scores[currentQuestionIndex]}/5` : 'Non évalué'}
                          </span>
                        </div>
                      </div>

                      <div>
                        <Label className="text-sm font-semibold mb-2 block">
                          Notes sur la réponse
                        </Label>
                        <Textarea
                          value={notes[currentQuestionIndex] || ""}
                          onChange={(e) => handleNoteChange(currentQuestionIndex, e.target.value)}
                          rows={3}
                          placeholder="Observations sur la réponse du candidat..."
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Évaluation globale */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Award className="w-5 h-5 text-yellow-500" />
                      Évaluation globale de l'entretien
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-3">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setGlobalRating(star)}
                          className="transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              star <= globalRating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="ml-3 font-semibold">
                        {globalRating > 0 ? `${globalRating}/5` : 'Non évalué'}
                      </span>
                    </div>

                    <div>
                      <Label className="text-sm mb-2 block">Feedback général</Label>
                      <Textarea
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        rows={3}
                        placeholder="Impression générale, recommandation..."
                      />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t p-4 flex justify-between items-center">
          <Button variant="outline" onClick={onClose}>
            Fermer
          </Button>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => handleSave(false)}
              disabled={updateInterviewMutation.isPending || updateCandidateMutation.isPending}
            >
              <Save className="w-4 h-4 mr-2" />
              Sauvegarder
            </Button>
            <Button 
              onClick={() => handleSave(true)}
              disabled={updateInterviewMutation.isPending || updateCandidateMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Terminer l'entretien
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}