import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { 
  Calendar, 
  Clock, 
  User, 
  MapPin, 
  Video, 
  Phone, 
  Mail, 
  CheckCircle, 
  XCircle,
  RotateCcw,
  Send,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const statusConfig = {
  scheduled: { label: "Planifié", color: "bg-blue-100 text-blue-800" },
  confirmed: { label: "Confirmé", color: "bg-green-100 text-green-800" },
  completed: { label: "Terminé", color: "bg-gray-100 text-gray-800" },
  cancelled: { label: "Annulé", color: "bg-red-100 text-red-800" },
  postponed: { label: "Reporté", color: "bg-orange-100 text-orange-800" },
  no_show: { label: "Absent", color: "bg-yellow-100 text-yellow-800" },
};

const typeLabels = {
  phone: "Téléphonique",
  video: "Visioconférence",
  in_person: "En personne",
  technical: "Technique",
};

const typeIcons = {
  phone: Phone,
  video: Video,
  in_person: MapPin,
  technical: User,
};

export default function InterviewDetailsModal({ interview, onClose, onUpdate }) {
  const [activeTab, setActiveTab] = useState("details");
  const [isSendingInvite, setIsSendingInvite] = useState(false);
  const [postponeData, setPostponeData] = useState({
    new_date: "",
    new_time: "",
    reason: ""
  });
  const [cancelReason, setCancelReason] = useState("");
  const { toast } = useToast();

  const TypeIcon = typeIcons[interview.interview_type] || Calendar;
  const status = statusConfig[interview.status] || statusConfig.scheduled;

  const sendInvitations = async () => {
    setIsSendingInvite(true);
    try {
      const interviewDetails = `
📅 Date: ${format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })}
⏰ Heure: ${interview.interview_time}
⏱️ Durée: ${interview.duration_minutes} minutes
📍 Type: ${typeLabels[interview.interview_type]}
${interview.location ? `📌 Lieu/Lien: ${interview.location}` : ''}
${interview.video_link ? `🎥 Lien visio: ${interview.video_link}` : ''}
      `.trim();

      // Email au candidat
      await base44.integrations.Core.SendEmail({
        to: interview.candidate_email,
        subject: `Invitation à un entretien - ${interview.job_title}`,
        body: `
Bonjour ${interview.candidate_name},

Nous avons le plaisir de vous inviter à un entretien pour le poste de ${interview.job_title}.

${interviewDetails}

Votre intervieweur sera: ${interview.interviewer_name}

Merci de confirmer votre disponibilité en répondant à cet email.

Cordialement,
L'équipe Recrutement
        `
      });

      // Email à l'intervieweur
      await base44.integrations.Core.SendEmail({
        to: interview.interviewer_email,
        subject: `Entretien planifié - ${interview.candidate_name} (${interview.job_title})`,
        body: `
Bonjour ${interview.interviewer_name},

Un entretien a été planifié avec le candidat suivant:

👤 Candidat: ${interview.candidate_name}
📧 Email: ${interview.candidate_email}
💼 Poste: ${interview.job_title}

${interviewDetails}

Cordialement,
L'équipe Recrutement
        `
      });

      // Mettre à jour le statut d'envoi
      await onUpdate({
        invitation_sent: true,
        invitation_sent_date: new Date().toISOString()
      });

      toast({
        title: "Invitations envoyées ✅",
        description: "Le candidat et l'intervieweur ont été notifiés par email",
      });
    } catch (error) {
      console.error("Erreur envoi invitations:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer les invitations",
        variant: "destructive",
      });
    } finally {
      setIsSendingInvite(false);
    }
  };

  const handleConfirm = async () => {
    await onUpdate({ status: "confirmed" });
    
    // Envoyer un email de confirmation
    await base44.integrations.Core.SendEmail({
      to: interview.candidate_email,
      subject: `Confirmation de votre entretien - ${interview.job_title}`,
      body: `
Bonjour ${interview.candidate_name},

Votre entretien pour le poste de ${interview.job_title} est confirmé.

📅 Date: ${format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })}
⏰ Heure: ${interview.interview_time}
${interview.location ? `📍 Lieu/Lien: ${interview.location}` : ''}

À bientôt !

L'équipe Recrutement
      `
    });

    toast({
      title: "Entretien confirmé",
      description: "Un email de confirmation a été envoyé au candidat",
    });
  };

  const handlePostpone = async () => {
    if (!postponeData.new_date || !postponeData.new_time) {
      toast({
        title: "Erreur",
        description: "Veuillez saisir la nouvelle date et heure",
        variant: "destructive",
      });
      return;
    }

    await onUpdate({
      status: "postponed",
      postponed_from: interview.interview_date,
      interview_date: postponeData.new_date,
      interview_time: postponeData.new_time,
      postpone_reason: postponeData.reason,
      invitation_sent: false
    });

    // Notifier par email
    await base44.integrations.Core.SendEmail({
      to: interview.candidate_email,
      subject: `Report de votre entretien - ${interview.job_title}`,
      body: `
Bonjour ${interview.candidate_name},

Votre entretien pour le poste de ${interview.job_title} a été reporté.

❌ Date initiale: ${format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })}
✅ Nouvelle date: ${format(new Date(postponeData.new_date), 'd MMMM yyyy', { locale: fr })} à ${postponeData.new_time}

${postponeData.reason ? `Raison: ${postponeData.reason}` : ''}

Nous vous prions de nous excuser pour ce désagrément.

Cordialement,
L'équipe Recrutement
      `
    });

    toast({
      title: "Entretien reporté",
      description: "Le candidat a été notifié du changement",
    });
    onClose();
  };

  const handleCancel = async () => {
    await onUpdate({
      status: "cancelled",
      cancellation_reason: cancelReason
    });

    // Notifier par email
    await base44.integrations.Core.SendEmail({
      to: interview.candidate_email,
      subject: `Annulation de votre entretien - ${interview.job_title}`,
      body: `
Bonjour ${interview.candidate_name},

Nous sommes au regret de vous informer que votre entretien pour le poste de ${interview.job_title} prévu le ${format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })} a été annulé.

${cancelReason ? `Raison: ${cancelReason}` : ''}

Nous vous contacterons prochainement pour la suite du processus.

Cordialement,
L'équipe Recrutement
      `
    });

    toast({
      title: "Entretien annulé",
      description: "Le candidat a été notifié de l'annulation",
    });
    onClose();
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl">Détails de l'entretien</DialogTitle>
            <Badge className={status.color}>{status.label}</Badge>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">Détails</TabsTrigger>
            <TabsTrigger value="actions">Actions</TabsTrigger>
            <TabsTrigger value="feedback">Feedback</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4 mt-4">
            {/* Informations candidat */}
            <div className="p-4 bg-slate-50 rounded-lg space-y-3">
              <h3 className="font-semibold text-slate-900">Candidat</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-slate-500" />
                  <span>{interview.candidate_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-slate-500" />
                  <a href={`mailto:${interview.candidate_email}`} className="text-blue-600 hover:underline">
                    {interview.candidate_email}
                  </a>
                </div>
              </div>
              <div className="text-sm text-blue-600 font-medium">{interview.job_title}</div>
            </div>

            {/* Informations entretien */}
            <div className="p-4 bg-blue-50 rounded-lg space-y-3">
              <h3 className="font-semibold text-blue-900">Entretien</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span>{format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-blue-600" />
                  <span>{interview.interview_time} ({interview.duration_minutes} min)</span>
                </div>
                <div className="flex items-center gap-2">
                  <TypeIcon className="w-4 h-4 text-blue-600" />
                  <span>{typeLabels[interview.interview_type]}</span>
                </div>
                {interview.location && (
                  <div className="flex items-center gap-2 col-span-2">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span className="truncate">{interview.location}</span>
                  </div>
                )}
                {interview.video_link && (
                  <div className="flex items-center gap-2 col-span-2">
                    <Video className="w-4 h-4 text-blue-600" />
                    <a href={interview.video_link} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline truncate">
                      {interview.video_link}
                    </a>
                  </div>
                )}
              </div>
            </div>

            {/* Intervieweur */}
            <div className="p-4 bg-green-50 rounded-lg space-y-3">
              <h3 className="font-semibold text-green-900">Intervieweur</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-green-600" />
                  <span>{interview.interviewer_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-green-600" />
                  <a href={`mailto:${interview.interviewer_email}`} className="text-green-600 hover:underline">
                    {interview.interviewer_email}
                  </a>
                </div>
              </div>
            </div>

            {/* Statut invitation */}
            <div className="flex items-center justify-between p-4 bg-slate-100 rounded-lg">
              <div>
                <p className="font-medium">Invitation</p>
                <p className="text-sm text-slate-600">
                  {interview.invitation_sent 
                    ? `Envoyée le ${format(new Date(interview.invitation_sent_date), 'd MMM yyyy HH:mm', { locale: fr })}`
                    : "Non envoyée"
                  }
                </p>
              </div>
              {!interview.invitation_sent && interview.status !== 'cancelled' && interview.status !== 'completed' && (
                <Button onClick={sendInvitations} disabled={isSendingInvite} className="bg-blue-600 hover:bg-blue-700">
                  <Send className="w-4 h-4 mr-2" />
                  {isSendingInvite ? "Envoi..." : "Envoyer les invitations"}
                </Button>
              )}
            </div>

            {/* Informations de report */}
            {interview.status === 'postponed' && interview.postponed_from && (
              <div className="p-4 bg-orange-50 rounded-lg">
                <div className="flex items-center gap-2 text-orange-800 mb-2">
                  <RotateCcw className="w-4 h-4" />
                  <span className="font-medium">Entretien reporté</span>
                </div>
                <p className="text-sm text-orange-700">
                  Date initiale: {format(new Date(interview.postponed_from), 'd MMMM yyyy', { locale: fr })}
                </p>
                {interview.postpone_reason && (
                  <p className="text-sm text-orange-700 mt-1">Raison: {interview.postpone_reason}</p>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="actions" className="space-y-4 mt-4">
            {interview.status !== 'cancelled' && interview.status !== 'completed' && (
              <>
                {/* Confirmer */}
                {interview.status === 'scheduled' && (
                  <div className="p-4 border border-green-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-green-800 flex items-center gap-2">
                          <CheckCircle className="w-5 h-5" />
                          Confirmer l'entretien
                        </h3>
                        <p className="text-sm text-green-600 mt-1">
                          Un email de confirmation sera envoyé au candidat
                        </p>
                      </div>
                      <Button onClick={handleConfirm} className="bg-green-600 hover:bg-green-700">
                        Confirmer
                      </Button>
                    </div>
                  </div>
                )}

                {/* Reporter */}
                <div className="p-4 border border-orange-200 rounded-lg space-y-3">
                  <h3 className="font-semibold text-orange-800 flex items-center gap-2">
                    <RotateCcw className="w-5 h-5" />
                    Reporter l'entretien
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>Nouvelle date</Label>
                      <Input
                        type="date"
                        value={postponeData.new_date}
                        onChange={(e) => setPostponeData({...postponeData, new_date: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Nouvelle heure</Label>
                      <Input
                        type="time"
                        value={postponeData.new_time}
                        onChange={(e) => setPostponeData({...postponeData, new_time: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Raison du report (optionnel)</Label>
                    <Input
                      value={postponeData.reason}
                      onChange={(e) => setPostponeData({...postponeData, reason: e.target.value})}
                      placeholder="Indisponibilité de l'intervieweur..."
                    />
                  </div>
                  <Button onClick={handlePostpone} variant="outline" className="w-full border-orange-300 text-orange-700 hover:bg-orange-50">
                    Reporter l'entretien
                  </Button>
                </div>

                {/* Annuler */}
                <div className="p-4 border border-red-200 rounded-lg space-y-3">
                  <h3 className="font-semibold text-red-800 flex items-center gap-2">
                    <XCircle className="w-5 h-5" />
                    Annuler l'entretien
                  </h3>
                  <div className="space-y-2">
                    <Label>Raison de l'annulation</Label>
                    <Textarea
                      value={cancelReason}
                      onChange={(e) => setCancelReason(e.target.value)}
                      placeholder="Poste pourvu, candidat désisté..."
                      rows={2}
                    />
                  </div>
                  <Button onClick={handleCancel} variant="outline" className="w-full border-red-300 text-red-700 hover:bg-red-50">
                    Annuler l'entretien
                  </Button>
                </div>

                {/* Marquer comme terminé */}
                {(interview.status === 'scheduled' || interview.status === 'confirmed') && (
                  <Button 
                    onClick={() => onUpdate({ status: 'completed' })}
                    className="w-full bg-slate-600 hover:bg-slate-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Marquer comme terminé
                  </Button>
                )}

                {/* Marquer comme absent */}
                {(interview.status === 'scheduled' || interview.status === 'confirmed') && (
                  <Button 
                    onClick={() => onUpdate({ status: 'no_show' })}
                    variant="outline"
                    className="w-full border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                  >
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Marquer comme absent (no-show)
                  </Button>
                )}
              </>
            )}

            {interview.status === 'cancelled' && (
              <div className="p-6 text-center text-red-600 bg-red-50 rounded-lg">
                <XCircle className="w-12 h-12 mx-auto mb-3" />
                <p className="font-medium">Cet entretien a été annulé</p>
                {interview.cancellation_reason && (
                  <p className="text-sm mt-2">Raison: {interview.cancellation_reason}</p>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="feedback" className="space-y-4 mt-4">
            {interview.status === 'completed' ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Notes de l'entretien</Label>
                  <Textarea
                    value={interview.notes || ""}
                    onChange={(e) => onUpdate({ notes: e.target.value })}
                    placeholder="Notes sur l'entretien..."
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Feedback</Label>
                  <Textarea
                    value={interview.feedback || ""}
                    onChange={(e) => onUpdate({ feedback: e.target.value })}
                    placeholder="Feedback détaillé sur le candidat..."
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Note globale (1-5)</Label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map(rating => (
                      <Button
                        key={rating}
                        variant={interview.rating === rating ? "default" : "outline"}
                        size="sm"
                        onClick={() => onUpdate({ rating })}
                        className={interview.rating === rating ? "bg-yellow-500 hover:bg-yellow-600" : ""}
                      >
                        {rating}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-6 text-center text-slate-500 bg-slate-50 rounded-lg">
                <p>Le feedback sera disponible une fois l'entretien terminé</p>
              </div>
            )}
          </TabsContent>
        </Tabs>

        <div className="flex justify-end pt-4 border-t">
          <Button variant="outline" onClick={onClose}>Fermer</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}