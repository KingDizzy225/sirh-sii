import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Send, Calendar, Clock, MapPin, User, FileText, 
  Upload, X, Paperclip, Bell, Mail, Loader2
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function InterviewInvitation({ interview, candidate, jobPosting, onClose, onSent }) {
  const [sendToCandidate, setSendToCandidate] = useState(true);
  const [sendToInterviewer, setSendToInterviewer] = useState(true);
  const [sendReminder, setSendReminder] = useState(true);
  const [reminderHours, setReminderHours] = useState("24");
  const [attachments, setAttachments] = useState([]);
  const [customMessage, setCustomMessage] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const { toast } = useToast();

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setIsUploading(true);
    try {
      const uploadedFiles = await Promise.all(
        files.map(async (file) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          return { name: file.name, url: file_url };
        })
      );
      setAttachments(prev => [...prev, ...uploadedFiles]);
    } catch (error) {
      toast({ title: "Erreur", description: "Impossible d'uploader les fichiers", variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  const removeAttachment = (index) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const generateEmailBody = (recipient) => {
    const dateStr = format(new Date(interview.interview_date), 'EEEE d MMMM yyyy', { locale: fr });
    const timeStr = interview.interview_time || "à confirmer";
    const duration = interview.duration_minutes || 60;
    const location = interview.location || interview.video_link || "À confirmer";

    const typeLabels = {
      phone: "téléphonique",
      video: "en visioconférence",
      in_person: "en présentiel",
      technical: "technique"
    };
    const interviewType = typeLabels[interview.interview_type] || "";

    if (recipient === 'candidate') {
      return `Bonjour ${candidate?.full_name || interview.candidate_name},

Nous avons le plaisir de vous convier à un entretien ${interviewType} pour le poste de ${jobPosting?.title || interview.job_title}.

📅 Date : ${dateStr}
🕐 Heure : ${timeStr}
⏱️ Durée prévue : ${duration} minutes
📍 Lieu : ${location}
👤 Intervieweur : ${interview.interviewer_name || "À confirmer"}

${customMessage ? `\n${customMessage}\n` : ''}
${attachments.length > 0 ? `\n📎 Documents joints :\n${attachments.map(a => `- ${a.name}: ${a.url}`).join('\n')}\n` : ''}
Merci de confirmer votre présence en répondant à cet email.

Nous vous souhaitons bonne préparation.

Cordialement,
L'équipe RH`;
    } else {
      return `Bonjour ${interview.interviewer_name},

Un entretien ${interviewType} est programmé avec le/la candidat(e) suivant(e) :

👤 Candidat : ${candidate?.full_name || interview.candidate_name}
📧 Email : ${candidate?.email || interview.candidate_email}
📞 Téléphone : ${candidate?.phone || "Non renseigné"}
💼 Poste : ${jobPosting?.title || interview.job_title}

📅 Date : ${dateStr}
🕐 Heure : ${timeStr}
⏱️ Durée prévue : ${duration} minutes
📍 Lieu : ${location}

${customMessage ? `\nNote : ${customMessage}\n` : ''}
${attachments.length > 0 ? `\n📎 Documents joints :\n${attachments.map(a => `- ${a.name}: ${a.url}`).join('\n')}\n` : ''}
Cordialement`;
    }
  };

  const handleSend = async () => {
    setIsSending(true);
    
    try {
      const emailPromises = [];

      // Email au candidat
      if (sendToCandidate && (candidate?.email || interview.candidate_email)) {
        emailPromises.push(
          base44.integrations.Core.SendEmail({
            to: candidate?.email || interview.candidate_email,
            subject: `Invitation entretien - ${jobPosting?.title || interview.job_title}`,
            body: generateEmailBody('candidate')
          })
        );
      }

      // Email à l'intervieweur
      if (sendToInterviewer && interview.interviewer_email) {
        emailPromises.push(
          base44.integrations.Core.SendEmail({
            to: interview.interviewer_email,
            subject: `Entretien programmé - ${candidate?.full_name || interview.candidate_name}`,
            body: generateEmailBody('interviewer')
          })
        );
      }

      await Promise.all(emailPromises);

      // Mettre à jour l'entretien
      await base44.entities.Interview.update(interview.id, {
        invitation_sent: true,
        invitation_sent_date: new Date().toISOString(),
        reminder_sent: false,
      });

      // Programmer le rappel (stocké dans les notes pour simplifier)
      if (sendReminder) {
        const reminderDate = new Date(interview.interview_date);
        reminderDate.setHours(reminderDate.getHours() - parseInt(reminderHours));
        
        await base44.entities.Interview.update(interview.id, {
          notes: `${interview.notes || ''}\n[Rappel programmé: ${reminderHours}h avant]`
        });
      }

      toast({
        title: "Invitations envoyées ✅",
        description: `${emailPromises.length} email(s) envoyé(s)`
      });

      onSent?.();
      onClose();
    } catch (error) {
      console.error("Erreur envoi:", error);
      toast({ title: "Erreur", description: "Impossible d'envoyer les invitations", variant: "destructive" });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-blue-600" />
            Envoyer les invitations
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Récapitulatif */}
          <Card className="bg-slate-50">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-blue-600" />
                  <span>{candidate?.full_name || interview.candidate_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-green-600" />
                  <span>{format(new Date(interview.interview_date), 'd MMMM yyyy', { locale: fr })}</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-purple-600" />
                  <span>{jobPosting?.title || interview.job_title}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-orange-600" />
                  <span>{interview.interview_time} ({interview.duration_minutes || 60} min)</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Destinataires */}
          <div className="space-y-3">
            <Label className="font-semibold">Destinataires</Label>
            
            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-slate-600" />
                <span>Candidat ({candidate?.email || interview.candidate_email})</span>
              </div>
              <Switch checked={sendToCandidate} onCheckedChange={setSendToCandidate} />
            </div>

            <div className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-slate-600" />
                <span>Intervieweur ({interview.interviewer_email || "Non défini"})</span>
              </div>
              <Switch 
                checked={sendToInterviewer} 
                onCheckedChange={setSendToInterviewer}
                disabled={!interview.interviewer_email}
              />
            </div>
          </div>

          {/* Rappel */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="font-semibold flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Rappel automatique
              </Label>
              <Switch checked={sendReminder} onCheckedChange={setSendReminder} />
            </div>
            
            {sendReminder && (
              <div className="flex items-center gap-2 ml-6">
                <Input
                  type="number"
                  value={reminderHours}
                  onChange={(e) => setReminderHours(e.target.value)}
                  className="w-20"
                  min="1"
                  max="72"
                />
                <span className="text-sm text-slate-600">heures avant l'entretien</span>
              </div>
            )}
          </div>

          {/* Pièces jointes */}
          <div className="space-y-3">
            <Label className="font-semibold flex items-center gap-2">
              <Paperclip className="w-4 h-4" />
              Pièces jointes
            </Label>
            
            <div className="flex flex-wrap gap-2">
              {attachments.map((file, index) => (
                <Badge key={index} variant="secondary" className="flex items-center gap-1 py-1">
                  <FileText className="w-3 h-3" />
                  {file.name}
                  <button onClick={() => removeAttachment(index)} className="ml-1 hover:text-red-600">
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>

            <div>
              <Input
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                id="attachment-upload"
                accept=".pdf,.doc,.docx,.xls,.xlsx"
              />
              <label htmlFor="attachment-upload">
                <Button type="button" variant="outline" size="sm" asChild disabled={isUploading}>
                  <span className="cursor-pointer">
                    {isUploading ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Upload className="w-4 h-4 mr-2" />
                    )}
                    Ajouter un document
                  </span>
                </Button>
              </label>
              <p className="text-xs text-slate-500 mt-1">
                Ex: Grille d'évaluation, fiche de poste, informations pratiques...
              </p>
            </div>
          </div>

          {/* Message personnalisé */}
          <div className="space-y-2">
            <Label className="font-semibold">Message personnalisé (optionnel)</Label>
            <Textarea
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              placeholder="Ajouter un message personnalisé à l'invitation..."
              rows={3}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={isSending}>
              Annuler
            </Button>
            <Button 
              onClick={handleSend}
              disabled={isSending || (!sendToCandidate && !sendToInterviewer)}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Envoi...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer les invitations
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}