import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mail, Phone, FileText, Star, Calendar, Award } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  new: "bg-blue-100 text-blue-800",
  screening: "bg-purple-100 text-purple-800",
  interview: "bg-orange-100 text-orange-800",
  offer: "bg-green-100 text-green-800",
  hired: "bg-emerald-100 text-emerald-800",
  rejected: "bg-red-100 text-red-800",
};

const statusLabels = {
  new: "Nouveau",
  screening: "Présélection",
  interview: "Entretien",
  offer: "Offre",
  hired: "Embauché",
  rejected: "Rejeté",
};

export default function CandidateCard({ candidate, onClick }) {
  const getApplicationDate = () => {
    try {
      const date = candidate.application_date || candidate.created_date;
      if (date) {
        return format(new Date(date), 'dd/MM/yyyy');
      }
      return 'N/A';
    } catch {
      return 'N/A';
    }
  };

  return (
    <Card 
      className="shadow-lg border-none cursor-pointer hover:shadow-xl transition-shadow"
      onClick={onClick}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <Badge className={statusColors[candidate.status] || statusColors.new}>
                {statusLabels[candidate.status] || candidate.status}
              </Badge>
              {candidate.rating && (
                <div className="flex items-center gap-1 text-yellow-500">
                  <Star className="w-4 h-4 fill-current" />
                  <span className="text-sm font-medium">{candidate.rating}/5</span>
                </div>
              )}
              {candidate.overall_score && (
                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  Score: {candidate.overall_score}%
                </Badge>
              )}
            </div>
            <h3 className="font-bold text-lg text-slate-900">{candidate.full_name}</h3>
            <p className="text-sm text-blue-600 font-medium">{candidate.job_title || "Poste non défini"}</p>
          </div>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Mail className="w-4 h-4" />
            <a 
              href={`mailto:${candidate.email}`} 
              className="hover:text-blue-600"
              onClick={(e) => e.stopPropagation()}
            >
              {candidate.email}
            </a>
          </div>

          {candidate.phone && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Phone className="w-4 h-4" />
              <span>{candidate.phone}</span>
            </div>
          )}

          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4" />
            <span>Candidature: {getApplicationDate()}</span>
          </div>

          {candidate.experience_years && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Award className="w-4 h-4" />
              <span>{candidate.experience_years} ans d'expérience</span>
            </div>
          )}
        </div>

        {(candidate.skills || []).length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-slate-600 mb-2">Compétences</p>
            <div className="flex flex-wrap gap-1">
              {(candidate.skills || []).slice(0, 3).map((skill, index) => (
                <Badge key={index} variant="outline" className="text-xs bg-blue-50">
                  {skill}
                </Badge>
              ))}
              {(candidate.skills || []).length > 3 && (
                <Badge variant="outline" className="text-xs">
                  +{(candidate.skills || []).length - 3}
                </Badge>
              )}
            </div>
          </div>
        )}

        {candidate.resume_url && (
          <Button
            variant="outline"
            size="sm"
            className="w-full"
            onClick={(e) => {
              e.stopPropagation();
              window.open(candidate.resume_url, '_blank');
            }}
          >
            <FileText className="w-4 h-4 mr-2" />
            Voir le CV
          </Button>
        )}
      </CardContent>
    </Card>
  );
}