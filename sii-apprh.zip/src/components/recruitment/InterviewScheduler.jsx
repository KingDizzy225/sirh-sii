import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Plus, Calendar, Clock, MapPin, Video, Phone, User, CalendarDays, List, CheckCircle, XCircle, RotateCcw, Play, Send } from "lucide-react";
import { format, isAfter, isBefore } from "date-fns";
import { fr } from "date-fns/locale";
import InterviewForm from "./InterviewForm";
import InterviewSession from "./InterviewSession";
import InterviewCalendar from "./InterviewCalendar";
import InterviewInvitation from "./InterviewInvitation";
import { useToast } from "@/components/ui/use-toast";

const statusConfig = {
  scheduled: { label: "Planifié", color: "bg-blue-100 text-blue-800", icon: Calendar },
  confirmed: { label: "Confirmé", color: "bg-green-100 text-green-800", icon: CheckCircle },
  completed: { label: "Terminé", color: "bg-gray-100 text-gray-800", icon: CheckCircle },
  cancelled: { label: "Annulé", color: "bg-red-100 text-red-800", icon: XCircle },
  postponed: { label: "Reporté", color: "bg-orange-100 text-orange-800", icon: RotateCcw },
  no_show: { label: "Absent", color: "bg-yellow-100 text-yellow-800", icon: XCircle },
};

const typeConfig = {
  phone: { label: "Téléphone", icon: Phone },
  video: { label: "Vidéo", icon: Video },
  in_person: { label: "Présentiel", icon: MapPin },
  technical: { label: "Technique", icon: User },
};

export default function InterviewScheduler({ candidates = [], jobPostings = [], interviews = [] }) {
  const [showForm, setShowForm] = useState(false);
  const [viewMode, setViewMode] = useState("calendar");
  const [activeSession, setActiveSession] = useState(null);
  const [invitationInterview, setInvitationInterview] = useState(null);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const startInterviewSession = (interview) => {
    const candidate = candidates.find(c => c.id === interview.candidate_id);
    const jobPosting = jobPostings.find(j => j.id === interview.job_posting_id);
    setActiveSession({ interview, candidate, jobPosting });
  };

  const openInvitation = (interview) => {
    const candidate = candidates.find(c => c.id === interview.candidate_id);
    const jobPosting = jobPostings.find(j => j.id === interview.job_posting_id);
    setInvitationInterview({ interview, candidate, jobPosting });
  };

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Interview.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interviews'] });
      setShowForm(false);
      toast({ title: "Entretien créé", description: "L'entretien a été planifié avec succès" });
    },
    onError: (error) => {
      toast({ title: "Erreur", description: "Impossible de créer l'entretien", variant: "destructive" });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Interview.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interviews'] });
      toast({ title: "Entretien mis à jour" });
    },
  });

  const today = new Date();
  
  const upcomingInterviews = interviews.filter(i => 
    (i.status === 'scheduled' || i.status === 'confirmed') && 
    isAfter(new Date(i.interview_date), new Date(today.setHours(0,0,0,0)))
  ).sort((a, b) => new Date(a.interview_date) - new Date(b.interview_date));

  const pastInterviews = interviews.filter(i => 
    i.status === 'completed' || 
    (i.status !== 'cancelled' && isBefore(new Date(i.interview_date), new Date()))
  ).sort((a, b) => new Date(b.interview_date) - new Date(a.interview_date));

  const cancelledInterviews = interviews.filter(i => i.status === 'cancelled');

  const handleStatusChange = (interviewId, newStatus) => {
    updateMutation.mutate({ id: interviewId, data: { status: newStatus } });
  };

  const renderInterviewCard = (interview) => {
    const status = statusConfig[interview.status] || statusConfig.scheduled;
    const type = typeConfig[interview.interview_type] || typeConfig.in_person;
    const StatusIcon = status.icon;
    const TypeIcon = type.icon;

    return (
      <Card key={interview.id} className="border-none shadow-lg hover:shadow-xl transition-shadow">
        <CardHeader className="border-b border-slate-100 pb-4">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <Badge className={status.color}>
                  <StatusIcon className="w-3 h-3 mr-1" />
                  {status.label}
                </Badge>
                <Badge variant="outline" className="flex items-center gap-1">
                  <TypeIcon className="w-3 h-3" />
                  {type.label}
                </Badge>
              </div>
              <CardTitle className="text-lg">{interview.candidate_name}</CardTitle>
              <p className="text-sm text-blue-600 font-medium">{interview.job_title}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-3">
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Calendar className="w-4 h-4 text-blue-600" />
            <span className="font-medium">
              {format(new Date(interview.interview_date), 'EEEE d MMMM yyyy', { locale: fr })}
            </span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <Clock className="w-4 h-4 text-green-600" />
            <span>{interview.interview_time || "Heure non définie"} ({interview.duration_minutes || 60} min)</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-700">
            <User className="w-4 h-4 text-purple-600" />
            <span>{interview.interviewer_name || "Non assigné"}</span>
          </div>
          {interview.location && (
            <div className="flex items-center gap-2 text-sm text-slate-700">
              <MapPin className="w-4 h-4 text-orange-600" />
              <span className="truncate">{interview.location}</span>
            </div>
          )}
          
          {(interview.status === 'scheduled' || interview.status === 'confirmed') && (
            <div className="flex flex-col gap-2 pt-3 border-t">
              <Button
                size="sm"
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={() => startInterviewSession(interview)}
              >
                <Play className="w-4 h-4 mr-1" />
                Démarrer l'entretien
              </Button>
              <div className="flex gap-2">
                {!interview.invitation_sent && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => openInvitation(interview)}
                  >
                    <Send className="w-4 h-4 mr-1" />
                    Inviter
                  </Button>
                )}
                {interview.status === 'scheduled' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1"
                    onClick={() => handleStatusChange(interview.id, 'confirmed')}
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Confirmer
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="text-red-600 hover:bg-red-50"
                  onClick={() => handleStatusChange(interview.id, 'cancelled')}
                >
                  <XCircle className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Entretiens</h2>
          <p className="text-slate-600">{upcomingInterviews.length} entretien(s) à venir</p>
        </div>
        <div className="flex gap-2">
          <Tabs value={viewMode} onValueChange={setViewMode}>
            <TabsList>
              <TabsTrigger value="calendar"><CalendarDays className="w-4 h-4 mr-1" /> Calendrier</TabsTrigger>
              <TabsTrigger value="list"><List className="w-4 h-4 mr-1" /> Liste</TabsTrigger>
            </TabsList>
          </Tabs>
          <Button onClick={() => setShowForm(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Planifier
          </Button>
        </div>
      </div>

      {viewMode === "calendar" ? (
        <InterviewCalendar
          interviews={interviews}
          candidates={candidates}
          onSchedule={() => setShowForm(true)}
          onInterviewClick={(interview) => {
            const candidate = candidates.find(c => c.id === interview.candidate_id);
            const jobPosting = jobPostings.find(j => j.id === interview.job_posting_id);
            setActiveSession({ interview, candidate, jobPosting });
          }}
        />
      ) : (
      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="bg-white shadow">
          <TabsTrigger value="upcoming">
            À venir ({upcomingInterviews.length})
          </TabsTrigger>
          <TabsTrigger value="past">
            Passés ({pastInterviews.length})
          </TabsTrigger>
          <TabsTrigger value="cancelled">
            Annulés ({cancelledInterviews.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="mt-6">
          {upcomingInterviews.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p className="text-slate-500">Aucun entretien à venir</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {upcomingInterviews.map(renderInterviewCard)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="past" className="mt-6">
          {pastInterviews.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p className="text-slate-500">Aucun entretien passé</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {pastInterviews.slice(0, 10).map((interview) => {
                const status = statusConfig[interview.status] || statusConfig.completed;
                return (
                  <Card key={interview.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center">
                            <span className="text-sm font-semibold text-slate-700">
                              {interview.candidate_name?.charAt(0) || '?'}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-slate-900">{interview.candidate_name}</p>
                            <p className="text-sm text-slate-600">{interview.job_title}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={status.color}>{status.label}</Badge>
                          <p className="text-xs text-slate-500 mt-1">
                            {format(new Date(interview.interview_date), 'dd/MM/yyyy', { locale: fr })}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="cancelled" className="mt-6">
          {cancelledInterviews.length === 0 ? (
            <Card className="border-none shadow-lg">
              <CardContent className="p-12 text-center">
                <XCircle className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p className="text-slate-500">Aucun entretien annulé</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {cancelledInterviews.map((interview) => (
                <Card key={interview.id} className="opacity-60">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-slate-900 line-through">{interview.candidate_name}</p>
                        <p className="text-sm text-slate-600">{interview.job_title}</p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-red-100 text-red-800">Annulé</Badge>
                        <p className="text-xs text-slate-500 mt-1">
                          {format(new Date(interview.interview_date), 'dd/MM/yyyy', { locale: fr })}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      )}

      {showForm && (
        <InterviewForm
          candidates={candidates}
          jobPostings={jobPostings}
          onSubmit={(data) => createMutation.mutate(data)}
          onCancel={() => setShowForm(false)}
          isSubmitting={createMutation.isPending}
        />
      )}

      {activeSession && (
        <InterviewSession
          interview={activeSession.interview}
          candidate={activeSession.candidate}
          jobPosting={activeSession.jobPosting}
          onClose={() => setActiveSession(null)}
        />
      )}

      {invitationInterview && (
        <InterviewInvitation
          interview={invitationInterview.interview}
          candidate={invitationInterview.candidate}
          jobPosting={invitationInterview.jobPosting}
          onClose={() => setInvitationInterview(null)}
          onSent={() => {
            queryClient.invalidateQueries({ queryKey: ['interviews'] });
            setInvitationInterview(null);
          }}
        />
      )}
    </div>
  );
}