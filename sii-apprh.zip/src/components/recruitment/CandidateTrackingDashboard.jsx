import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, Filter, Mail, Calendar, Clock, User, 
  ChevronDown, ChevronUp, Users, Briefcase, 
  ArrowRight, CheckCircle, XCircle, AlertCircle
} from "lucide-react";
import { format, formatDistanceToNow, isAfter, subDays } from "date-fns";
import { fr } from "date-fns/locale";
import BulkEmailModal from "./BulkEmailModal";

const statusConfig = {
  new: { label: "Nouveau", color: "bg-blue-100 text-blue-800", nextStep: "Présélection" },
  screening: { label: "Présélection", color: "bg-purple-100 text-purple-800", nextStep: "Entretien" },
  interview: { label: "Entretien", color: "bg-orange-100 text-orange-800", nextStep: "Offre" },
  offer: { label: "Offre", color: "bg-green-100 text-green-800", nextStep: "Embauche" },
  hired: { label: "Embauché", color: "bg-emerald-100 text-emerald-800", nextStep: null },
  rejected: { label: "Rejeté", color: "bg-red-100 text-red-800", nextStep: null },
};

export default function CandidateTrackingDashboard({ candidates = [], jobPostings = [], interviews = [] }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterJob, setFilterJob] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterActivity, setFilterActivity] = useState("all");
  const [sortField, setSortField] = useState("updated_date");
  const [sortOrder, setSortOrder] = useState("desc");
  const [selectedCandidates, setSelectedCandidates] = useState([]);
  const [showBulkEmail, setShowBulkEmail] = useState(false);
  const [expandedRows, setExpandedRows] = useState([]);

  // Enrichir les candidats avec les données d'entretiens
  const enrichedCandidates = useMemo(() => {
    return candidates.map(candidate => {
      const candidateInterviews = interviews.filter(i => i.candidate_id === candidate.id);
      const upcomingInterview = candidateInterviews
        .filter(i => i.status === 'scheduled' || i.status === 'confirmed')
        .sort((a, b) => new Date(a.interview_date) - new Date(b.interview_date))[0];
      const lastInterview = candidateInterviews
        .filter(i => i.status === 'completed')
        .sort((a, b) => new Date(b.interview_date) - new Date(a.interview_date))[0];

      const lastActivity = candidate.updated_date || candidate.created_date;
      const daysSinceActivity = lastActivity 
        ? Math.floor((new Date() - new Date(lastActivity)) / (1000 * 60 * 60 * 24))
        : 999;

      return {
        ...candidate,
        upcomingInterview,
        lastInterview,
        lastActivity,
        daysSinceActivity,
        interviewCount: candidateInterviews.length,
      };
    });
  }, [candidates, interviews]);

  // Filtrer et trier
  const filteredCandidates = useMemo(() => {
    let result = enrichedCandidates;

    // Recherche
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(c => 
        c.full_name?.toLowerCase().includes(term) ||
        c.email?.toLowerCase().includes(term) ||
        c.job_title?.toLowerCase().includes(term)
      );
    }

    // Filtre par poste
    if (filterJob !== "all") {
      result = result.filter(c => c.job_posting_id === filterJob);
    }

    // Filtre par statut
    if (filterStatus !== "all") {
      result = result.filter(c => c.status === filterStatus);
    }

    // Filtre par activité
    if (filterActivity !== "all") {
      const days = parseInt(filterActivity);
      result = result.filter(c => c.daysSinceActivity <= days);
    }

    // Tri
    result.sort((a, b) => {
      let aVal, bVal;
      switch (sortField) {
        case "name":
          aVal = a.full_name || "";
          bVal = b.full_name || "";
          break;
        case "status":
          aVal = a.status || "";
          bVal = b.status || "";
          break;
        case "updated_date":
        default:
          aVal = new Date(a.lastActivity || 0);
          bVal = new Date(b.lastActivity || 0);
      }
      if (sortOrder === "asc") {
        return aVal > bVal ? 1 : -1;
      }
      return aVal < bVal ? 1 : -1;
    });

    return result;
  }, [enrichedCandidates, searchTerm, filterJob, filterStatus, filterActivity, sortField, sortOrder]);

  // Stats
  const stats = useMemo(() => ({
    total: filteredCandidates.length,
    new: filteredCandidates.filter(c => c.status === 'new').length,
    screening: filteredCandidates.filter(c => c.status === 'screening').length,
    interview: filteredCandidates.filter(c => c.status === 'interview').length,
    offer: filteredCandidates.filter(c => c.status === 'offer').length,
    inactive: filteredCandidates.filter(c => c.daysSinceActivity > 7).length,
  }), [filteredCandidates]);

  const toggleSelectAll = () => {
    if (selectedCandidates.length === filteredCandidates.length) {
      setSelectedCandidates([]);
    } else {
      setSelectedCandidates(filteredCandidates.map(c => c.id));
    }
  };

  const toggleSelect = (id) => {
    setSelectedCandidates(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleExpand = (id) => {
    setExpandedRows(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
  };

  const getSelectedCandidatesData = () => {
    return filteredCandidates.filter(c => selectedCandidates.includes(c.id));
  };

  const SortIcon = ({ field }) => {
    if (sortField !== field) return null;
    return sortOrder === "asc" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card className="border-none shadow bg-white">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-slate-900">{stats.total}</p>
            <p className="text-xs text-slate-600">Total</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow bg-blue-50">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-blue-700">{stats.new}</p>
            <p className="text-xs text-blue-600">Nouveaux</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow bg-purple-50">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-purple-700">{stats.screening}</p>
            <p className="text-xs text-purple-600">Présélection</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow bg-orange-50">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-orange-700">{stats.interview}</p>
            <p className="text-xs text-orange-600">Entretien</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow bg-green-50">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-green-700">{stats.offer}</p>
            <p className="text-xs text-green-600">Offre</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow bg-red-50">
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-red-700">{stats.inactive}</p>
            <p className="text-xs text-red-600">Inactifs 7j+</p>
          </CardContent>
        </Card>
      </div>

      {/* Filtres et Actions */}
      <Card className="border-none shadow-lg">
        <CardContent className="p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="Rechercher un candidat..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={filterJob} onValueChange={setFilterJob}>
              <SelectTrigger className="w-full lg:w-48">
                <Briefcase className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Poste" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les postes</SelectItem>
                {jobPostings.map(job => (
                  <SelectItem key={job.id} value={job.id}>{job.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full lg:w-48">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                {Object.entries(statusConfig).map(([key, config]) => (
                  <SelectItem key={key} value={key}>{config.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterActivity} onValueChange={setFilterActivity}>
              <SelectTrigger className="w-full lg:w-48">
                <Clock className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Activité" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Toute période</SelectItem>
                <SelectItem value="1">Dernières 24h</SelectItem>
                <SelectItem value="7">7 derniers jours</SelectItem>
                <SelectItem value="30">30 derniers jours</SelectItem>
                <SelectItem value="90">90 derniers jours</SelectItem>
              </SelectContent>
            </Select>

            {selectedCandidates.length > 0 && (
              <Button 
                onClick={() => setShowBulkEmail(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Mail className="w-4 h-4 mr-2" />
                Email ({selectedCandidates.length})
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tableau */}
      <Card className="border-none shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b">
              <tr>
                <th className="p-4 w-12">
                  <Checkbox
                    checked={selectedCandidates.length === filteredCandidates.length && filteredCandidates.length > 0}
                    onCheckedChange={toggleSelectAll}
                  />
                </th>
                <th 
                  className="p-4 text-left text-sm font-semibold text-slate-700 cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort("name")}
                >
                  <div className="flex items-center gap-1">
                    Candidat <SortIcon field="name" />
                  </div>
                </th>
                <th className="p-4 text-left text-sm font-semibold text-slate-700">Poste</th>
                <th 
                  className="p-4 text-left text-sm font-semibold text-slate-700 cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort("status")}
                >
                  <div className="flex items-center gap-1">
                    Statut <SortIcon field="status" />
                  </div>
                </th>
                <th 
                  className="p-4 text-left text-sm font-semibold text-slate-700 cursor-pointer hover:bg-slate-100"
                  onClick={() => handleSort("updated_date")}
                >
                  <div className="flex items-center gap-1">
                    Dernière activité <SortIcon field="updated_date" />
                  </div>
                </th>
                <th className="p-4 text-left text-sm font-semibold text-slate-700">Prochaine étape</th>
                <th className="p-4 w-12"></th>
              </tr>
            </thead>
            <tbody>
              {filteredCandidates.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-500">
                    <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p>Aucun candidat trouvé</p>
                  </td>
                </tr>
              ) : (
                filteredCandidates.map(candidate => {
                  const status = statusConfig[candidate.status] || statusConfig.new;
                  const isExpanded = expandedRows.includes(candidate.id);
                  const isInactive = candidate.daysSinceActivity > 7;

                  return (
                    <React.Fragment key={candidate.id}>
                      <tr className={`border-b hover:bg-slate-50 ${isInactive ? 'bg-red-50/30' : ''}`}>
                        <td className="p-4">
                          <Checkbox
                            checked={selectedCandidates.includes(candidate.id)}
                            onCheckedChange={() => toggleSelect(candidate.id)}
                          />
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                              <span className="text-white font-semibold text-sm">
                                {candidate.full_name?.charAt(0) || '?'}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-slate-900">{candidate.full_name}</p>
                              <p className="text-xs text-slate-500">{candidate.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="text-sm text-slate-700">{candidate.job_title || "Non défini"}</p>
                        </td>
                        <td className="p-4">
                          <Badge className={status.color}>{status.label}</Badge>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {isInactive && <AlertCircle className="w-4 h-4 text-red-500" />}
                            <span className={`text-sm ${isInactive ? 'text-red-600 font-medium' : 'text-slate-600'}`}>
                              {candidate.lastActivity 
                                ? formatDistanceToNow(new Date(candidate.lastActivity), { addSuffix: true, locale: fr })
                                : 'Jamais'
                              }
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          {candidate.upcomingInterview ? (
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-blue-600" />
                              <span className="text-sm text-blue-600 font-medium">
                                Entretien {format(new Date(candidate.upcomingInterview.interview_date), 'dd/MM')}
                              </span>
                            </div>
                          ) : status.nextStep ? (
                            <div className="flex items-center gap-1 text-sm text-slate-500">
                              <ArrowRight className="w-4 h-4" />
                              {status.nextStep}
                            </div>
                          ) : (
                            <span className="text-sm text-slate-400">-</span>
                          )}
                        </td>
                        <td className="p-4">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => toggleExpand(candidate.id)}
                          >
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </Button>
                        </td>
                      </tr>
                      {isExpanded && (
                        <tr className="bg-slate-50">
                          <td colSpan={7} className="p-4">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <div>
                                <p className="text-xs font-semibold text-slate-500 mb-2">INFORMATIONS</p>
                                <div className="space-y-1 text-sm">
                                  <p><span className="text-slate-500">Téléphone:</span> {candidate.phone || 'N/A'}</p>
                                  <p><span className="text-slate-500">Expérience:</span> {candidate.experience_years ? `${candidate.experience_years} ans` : 'N/A'}</p>
                                  <p><span className="text-slate-500">Source:</span> {candidate.source || 'N/A'}</p>
                                </div>
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-slate-500 mb-2">ENTRETIENS ({candidate.interviewCount})</p>
                                {candidate.lastInterview ? (
                                  <p className="text-sm">
                                    Dernier: {format(new Date(candidate.lastInterview.interview_date), 'dd/MM/yyyy', { locale: fr })}
                                    {candidate.lastInterview.rating && ` - Note: ${candidate.lastInterview.rating}/5`}
                                  </p>
                                ) : (
                                  <p className="text-sm text-slate-400">Aucun entretien passé</p>
                                )}
                              </div>
                              <div>
                                <p className="text-xs font-semibold text-slate-500 mb-2">NOTES</p>
                                <p className="text-sm text-slate-600">
                                  {candidate.notes || 'Aucune note'}
                                </p>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Modal Email Groupé */}
      {showBulkEmail && (
        <BulkEmailModal
          candidates={getSelectedCandidatesData()}
          onClose={() => setShowBulkEmail(false)}
          onSent={() => {
            setShowBulkEmail(false);
            setSelectedCandidates([]);
          }}
        />
      )}
    </div>
  );
}