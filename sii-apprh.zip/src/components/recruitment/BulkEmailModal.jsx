import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Send, Users, AlertCircle, CheckCircle, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

const emailTemplates = [
  {
    id: "interview_invite",
    name: "Invitation entretien",
    subject: "Invitation à un entretien - {job_title}",
    body: `Bonjour {candidate_name},

Nous avons le plaisir de vous informer que votre candidature pour le poste de {job_title} a retenu notre attention.

Nous souhaiterions vous rencontrer pour un entretien. Merci de nous confirmer vos disponibilités pour les prochains jours.

Cordialement,
L'équipe RH`
  },
  {
    id: "status_update",
    name: "Mise à jour candidature",
    subject: "Mise à jour de votre candidature - {job_title}",
    body: `Bonjour {candidate_name},

Nous souhaitons vous tenir informé(e) de l'avancement de votre candidature pour le poste de {job_title}.

Votre dossier est actuellement en cours d'examen par notre équipe. Nous reviendrons vers vous très prochainement.

Cordialement,
L'équipe RH`
  },
  {
    id: "reminder",
    name: "Relance",
    subject: "Rappel - Candidature {job_title}",
    body: `Bonjour {candidate_name},

Nous vous recontactons concernant votre candidature pour le poste de {job_title}.

Pourriez-vous nous confirmer que vous êtes toujours intéressé(e) par cette opportunité ?

Cordialement,
L'équipe RH`
  },
  {
    id: "rejection",
    name: "Refus",
    subject: "Réponse à votre candidature - {job_title}",
    body: `Bonjour {candidate_name},

Nous vous remercions de l'intérêt que vous avez porté à notre entreprise et au poste de {job_title}.

Après étude approfondie de votre candidature, nous avons le regret de vous informer que nous ne sommes pas en mesure de donner suite à votre candidature pour ce poste.

Nous conservons votre CV dans notre vivier de talents et ne manquerons pas de vous recontacter si une opportunité correspondant à votre profil se présente.

Nous vous souhaitons bonne continuation dans vos recherches.

Cordialement,
L'équipe RH`
  },
  {
    id: "custom",
    name: "Personnalisé",
    subject: "",
    body: ""
  }
];

export default function BulkEmailModal({ candidates = [], onClose, onSent }) {
  const [selectedTemplate, setSelectedTemplate] = useState("custom");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [sendingProgress, setSendingProgress] = useState({ sent: 0, failed: 0, total: candidates.length });
  const [excludedCandidates, setExcludedCandidates] = useState([]);

  const { toast } = useToast();

  const handleTemplateChange = (templateId) => {
    setSelectedTemplate(templateId);
    const template = emailTemplates.find(t => t.id === templateId);
    if (template) {
      setSubject(template.subject);
      setBody(template.body);
    }
  };

  const excludeCandidate = (id) => {
    setExcludedCandidates(prev => [...prev, id]);
  };

  const activeCandidates = candidates.filter(c => !excludedCandidates.includes(c.id));

  const personalizeContent = (content, candidate) => {
    return content
      .replace(/{candidate_name}/g, candidate.full_name || 'Candidat')
      .replace(/{job_title}/g, candidate.job_title || 'le poste')
      .replace(/{email}/g, candidate.email || '');
  };

  const handleSend = async () => {
    if (!subject || !body) {
      toast({ title: "Erreur", description: "Veuillez remplir le sujet et le contenu", variant: "destructive" });
      return;
    }

    if (activeCandidates.length === 0) {
      toast({ title: "Erreur", description: "Aucun candidat sélectionné", variant: "destructive" });
      return;
    }

    setIsSending(true);
    setSendingProgress({ sent: 0, failed: 0, total: activeCandidates.length });

    let sent = 0;
    let failed = 0;

    for (const candidate of activeCandidates) {
      try {
        const personalizedSubject = personalizeContent(subject, candidate);
        const personalizedBody = personalizeContent(body, candidate);

        await base44.integrations.Core.SendEmail({
          to: candidate.email,
          subject: personalizedSubject,
          body: personalizedBody,
        });

        sent++;
      } catch (error) {
        console.error(`Erreur envoi à ${candidate.email}:`, error);
        failed++;
      }

      setSendingProgress({ sent, failed, total: activeCandidates.length });
    }

    setIsSending(false);

    if (failed === 0) {
      toast({ 
        title: "Emails envoyés ✅", 
        description: `${sent} email(s) envoyé(s) avec succès` 
      });
      onSent();
    } else {
      toast({ 
        title: "Envoi terminé", 
        description: `${sent} envoyé(s), ${failed} échec(s)`,
        variant: failed > 0 ? "destructive" : "default"
      });
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-blue-600" />
            Email groupé ({activeCandidates.length} destinataires)
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Destinataires */}
          <div>
            <Label className="text-sm font-semibold mb-2 block">Destinataires</Label>
            <Card className="border-slate-200">
              <CardContent className="p-3">
                <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto">
                  {candidates.map(candidate => {
                    const isExcluded = excludedCandidates.includes(candidate.id);
                    return (
                      <Badge 
                        key={candidate.id}
                        variant={isExcluded ? "secondary" : "outline"}
                        className={`flex items-center gap-1 ${isExcluded ? 'opacity-50 line-through' : ''}`}
                      >
                        {candidate.full_name}
                        {!isExcluded && (
                          <button 
                            onClick={() => excludeCandidate(candidate.id)}
                            className="ml-1 hover:text-red-600"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </Badge>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Templates */}
          <div>
            <Label className="text-sm font-semibold mb-2 block">Modèle d'email</Label>
            <div className="flex flex-wrap gap-2">
              {emailTemplates.map(template => (
                <Button
                  key={template.id}
                  type="button"
                  variant={selectedTemplate === template.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleTemplateChange(template.id)}
                  className={selectedTemplate === template.id ? "bg-blue-600" : ""}
                >
                  {template.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Sujet */}
          <div>
            <Label htmlFor="subject" className="text-sm font-semibold mb-2 block">
              Sujet
            </Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Sujet de l'email..."
            />
            <p className="text-xs text-slate-500 mt-1">
              Variables: {"{candidate_name}"}, {"{job_title}"}
            </p>
          </div>

          {/* Corps */}
          <div>
            <Label htmlFor="body" className="text-sm font-semibold mb-2 block">
              Contenu
            </Label>
            <Textarea
              id="body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Contenu de l'email..."
              rows={10}
            />
          </div>

          {/* Aperçu */}
          {activeCandidates.length > 0 && subject && body && (
            <div>
              <Label className="text-sm font-semibold mb-2 block">Aperçu (1er destinataire)</Label>
              <Card className="border-slate-200 bg-slate-50">
                <CardContent className="p-4">
                  <p className="font-semibold text-slate-900 mb-2">
                    {personalizeContent(subject, activeCandidates[0])}
                  </p>
                  <p className="text-sm text-slate-700 whitespace-pre-wrap">
                    {personalizeContent(body, activeCandidates[0])}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Progression */}
          {isSending && (
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-blue-900">
                      Envoi en cours... {sendingProgress.sent + sendingProgress.failed}/{sendingProgress.total}
                    </p>
                    <div className="h-2 bg-blue-200 rounded-full mt-2 overflow-hidden">
                      <div 
                        className="h-full bg-blue-600 transition-all"
                        style={{ width: `${((sendingProgress.sent + sendingProgress.failed) / sendingProgress.total) * 100}%` }}
                      />
                    </div>
                    <div className="flex gap-4 mt-2 text-xs">
                      <span className="text-green-600">✓ {sendingProgress.sent} envoyé(s)</span>
                      {sendingProgress.failed > 0 && (
                        <span className="text-red-600">✗ {sendingProgress.failed} échec(s)</span>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose} disabled={isSending}>
              Annuler
            </Button>
            <Button 
              onClick={handleSend}
              disabled={isSending || !subject || !body || activeCandidates.length === 0}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isSending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Envoi...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer à {activeCandidates.length} candidat(s)
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}