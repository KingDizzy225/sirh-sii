import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Sparkles, X, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";

export default function JobPostingForm({ job, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState(job || {
    title: "",
    department: "",
    location: "",
    employment_type: "full_time",
    description: "",
    requirements: "",
    salary_range: "",
    posted_date: format(new Date(), 'yyyy-MM-dd'),
    closing_date: "",
    status: "draft",
    hiring_manager: "",
    interview_questions: [],
    is_high_turnover: false,
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [newQuestion, setNewQuestion] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const generateQuestions = async () => {
    setIsGenerating(true);
    try {
      const prompt = `Tu es un expert RH spécialisé dans le recrutement. Génère 8 questions d'entretien pertinentes et professionnelles pour le poste suivant :

Titre du poste : ${formData.title}
Département : ${formData.department}
Description : ${formData.description}
Exigences : ${formData.requirements}

Les questions doivent couvrir :
- Compétences techniques requises
- Compétences comportementales
- Expérience professionnelle
- Motivation et objectifs de carrière
- Résolution de problèmes et gestion du stress
${formData.is_high_turnover ? '- Engagement à long terme et stabilité (poste à fort turnover)' : ''}

Génère des questions ouvertes qui permettent d'évaluer en profondeur le candidat.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            questions: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      if (response.questions && response.questions.length > 0) {
        setFormData({...formData, interview_questions: response.questions});
      }
    } catch (error) {
      console.error("Erreur lors de la génération des questions:", error);
      alert("Erreur lors de la génération des questions. Veuillez réessayer.");
    }
    setIsGenerating(false);
  };

  const addQuestion = () => {
    if (newQuestion.trim()) {
      setFormData({
        ...formData,
        interview_questions: [...formData.interview_questions, newQuestion.trim()]
      });
      setNewQuestion("");
    }
  };

  const removeQuestion = (index) => {
    setFormData({
      ...formData,
      interview_questions: formData.interview_questions.filter((_, i) => i !== index)
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{job ? 'Modifier l\'offre' : 'Nouvelle offre d\'emploi'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="title">Titre du poste *</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Département *</Label>
              <Input
                id="department"
                value={formData.department}
                onChange={(e) => setFormData({...formData, department: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Lieu</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="employment_type">Type d'emploi *</Label>
              <Select
                value={formData.employment_type}
                onValueChange={(value) => setFormData({...formData, employment_type: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full_time">Temps plein</SelectItem>
                  <SelectItem value="part_time">Temps partiel</SelectItem>
                  <SelectItem value="contract">Contrat</SelectItem>
                  <SelectItem value="intern">Stage</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="salary_range">Fourchette de salaire</Label>
              <Input
                id="salary_range"
                value={formData.salary_range}
                onChange={(e) => setFormData({...formData, salary_range: e.target.value})}
                placeholder="ex: 40 000 - 50 000 €"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Description du poste *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                rows={4}
                required
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="requirements">Exigences et qualifications</Label>
              <Textarea
                id="requirements"
                value={formData.requirements}
                onChange={(e) => setFormData({...formData, requirements: e.target.value})}
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="posted_date">Date de publication</Label>
              <Input
                id="posted_date"
                type="date"
                value={formData.posted_date}
                onChange={(e) => setFormData({...formData, posted_date: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="closing_date">Date de clôture</Label>
              <Input
                id="closing_date"
                type="date"
                value={formData.closing_date}
                onChange={(e) => setFormData({...formData, closing_date: e.target.value})}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Statut</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({...formData, status: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Brouillon</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="closed">Fermée</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="hiring_manager">Responsable du recrutement</Label>
              <Input
                id="hiring_manager"
                type="email"
                value={formData.hiring_manager}
                onChange={(e) => setFormData({...formData, hiring_manager: e.target.value})}
                placeholder="email@example.com"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is_high_turnover"
                  checked={formData.is_high_turnover}
                  onCheckedChange={(checked) => setFormData({...formData, is_high_turnover: checked})}
                />
                <Label htmlFor="is_high_turnover" className="font-normal">
                  Poste à fort taux de rotation (ex: Chargé de clientèle, Responsable d'agence)
                </Label>
              </div>
            </div>
          </div>

          {/* Section Questions d'entretien */}
          <div className="border-t pt-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Questions d'entretien</h3>
                <p className="text-sm text-slate-600">Générez des questions personnalisées avec l'IA ou ajoutez-les manuellement</p>
              </div>
              <Button
                type="button"
                onClick={generateQuestions}
                disabled={isGenerating || !formData.title || !formData.description}
                variant="outline"
                className="bg-gradient-to-r from-purple-500 to-blue-500 text-white hover:from-purple-600 hover:to-blue-600"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Génération...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Générer avec l'IA
                  </>
                )}
              </Button>
            </div>

            {formData.interview_questions.length > 0 && (
              <div className="space-y-2">
                {formData.interview_questions.map((question, index) => (
                  <div key={index} className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <Badge variant="outline" className="mt-1 flex-shrink-0">
                      Q{index + 1}
                    </Badge>
                    <p className="text-sm text-slate-700 flex-1">{question}</p>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeQuestion(index)}
                      className="flex-shrink-0 h-8 w-8"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <Input
                placeholder="Ajouter une question manuellement..."
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addQuestion();
                  }
                }}
              />
              <Button type="button" onClick={addQuestion} variant="outline">
                Ajouter
              </Button>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Enregistrement...' : job ? 'Mettre à jour' : 'Créer l\'offre'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}