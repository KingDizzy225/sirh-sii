import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { 
  Filter, Search, X, Calendar as CalendarIcon, 
  Star, Briefcase, MapPin, Clock, RotateCcw
} from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const statusOptions = [
  { value: "new", label: "Nouveau" },
  { value: "screening", label: "Présélection" },
  { value: "interview", label: "Entretien" },
  { value: "offer", label: "Offre" },
  { value: "hired", label: "Embauché" },
  { value: "rejected", label: "Rejeté" },
];

const sourceOptions = [
  { value: "linkedin", label: "LinkedIn" },
  { value: "indeed", label: "Indeed" },
  { value: "website", label: "Site carrière" },
  { value: "referral", label: "Cooptation" },
  { value: "agency", label: "Cabinet" },
  { value: "other", label: "Autre" },
];

export default function CandidateAdvancedFilters({ 
  jobPostings = [], 
  onFilterChange, 
  initialFilters = {} 
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [filters, setFilters] = useState({
    search: "",
    jobPostingId: "",
    statuses: [],
    sources: [],
    minScore: 0,
    maxScore: 100,
    minExperience: 0,
    maxExperience: 20,
    minRating: 0,
    dateFrom: null,
    dateTo: null,
    skills: [],
    hasResume: false,
    hasInterview: false,
    ...initialFilters
  });
  const [skillInput, setSkillInput] = useState("");

  const updateFilter = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilterChange?.(newFilters);
  };

  const toggleStatus = (status) => {
    const current = filters.statuses || [];
    const updated = current.includes(status)
      ? current.filter(s => s !== status)
      : [...current, status];
    updateFilter('statuses', updated);
  };

  const toggleSource = (source) => {
    const current = filters.sources || [];
    const updated = current.includes(source)
      ? current.filter(s => s !== source)
      : [...current, source];
    updateFilter('sources', updated);
  };

  const addSkill = () => {
    const skills = filters.skills || [];
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      updateFilter('skills', [...skills, skillInput.trim()]);
      setSkillInput("");
    }
  };

  const removeSkill = (skill) => {
    const skills = filters.skills || [];
    updateFilter('skills', skills.filter(s => s !== skill));
  };

  const resetFilters = () => {
    const resetState = {
      search: "",
      jobPostingId: "",
      statuses: [],
      sources: [],
      minScore: 0,
      maxScore: 100,
      minExperience: 0,
      maxExperience: 20,
      minRating: 0,
      dateFrom: null,
      dateTo: null,
      skills: [],
      hasResume: false,
      hasInterview: false,
    };
    setFilters(resetState);
    onFilterChange?.(resetState);
  };

  const activeFiltersCount = [
    filters.search,
    filters.jobPostingId,
    (filters.statuses || []).length > 0,
    (filters.sources || []).length > 0,
    filters.minScore > 0,
    filters.maxScore < 100,
    filters.minExperience > 0,
    filters.maxExperience < 20,
    filters.minRating > 0,
    filters.dateFrom,
    filters.dateTo,
    (filters.skills || []).length > 0,
    filters.hasResume,
    filters.hasInterview,
  ].filter(Boolean).length;

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Filter className="w-5 h-5 text-blue-600" />
            Filtres de recherche
            {activeFiltersCount > 0 && (
              <Badge className="bg-blue-600">{activeFiltersCount}</Badge>
            )}
          </CardTitle>
          <div className="flex gap-2">
            {activeFiltersCount > 0 && (
              <Button variant="ghost" size="sm" onClick={resetFilters}>
                <RotateCcw className="w-4 h-4 mr-1" />
                Réinitialiser
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'Réduire' : 'Plus de filtres'}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Recherche principale */}
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              placeholder="Rechercher par nom, email, compétences..."
              value={filters.search}
              onChange={(e) => updateFilter('search', e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filters.jobPostingId} onValueChange={(v) => updateFilter('jobPostingId', v)}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Tous les postes" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Tous les postes</SelectItem>
              {jobPostings.map(job => (
                <SelectItem key={job.id} value={job.id}>{job.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Statuts */}
        <div className="space-y-2">
          <Label className="text-sm font-medium">Statut</Label>
          <div className="flex flex-wrap gap-2">
            {statusOptions.map(status => (
              <Badge
                key={status.value}
                variant={(filters.statuses || []).includes(status.value) ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => toggleStatus(status.value)}
              >
                {status.label}
              </Badge>
            ))}
          </div>
        </div>

        {isExpanded && (
          <>
            {/* Sources */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Source</Label>
              <div className="flex flex-wrap gap-2">
                {sourceOptions.map(source => (
                  <Badge
                    key={source.value}
                    variant={(filters.sources || []).includes(source.value) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleSource(source.value)}
                  >
                    {source.label}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Score et expérience */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <Star className="w-4 h-4 text-yellow-500" />
                  Score minimum: {filters.minScore}%
                </Label>
                <Slider
                  value={[filters.minScore]}
                  onValueChange={(v) => updateFilter('minScore', v[0])}
                  max={100}
                  step={5}
                />
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <Briefcase className="w-4 h-4 text-blue-500" />
                  Expérience: {filters.minExperience} - {filters.maxExperience} ans
                </Label>
                <Slider
                  value={[filters.minExperience, filters.maxExperience]}
                  onValueChange={(v) => {
                    updateFilter('minExperience', v[0]);
                    updateFilter('maxExperience', v[1]);
                  }}
                  max={20}
                  step={1}
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Date de candidature (du)</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start">
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      {filters.dateFrom 
                        ? format(filters.dateFrom, 'dd/MM/yyyy', { locale: fr })
                        : 'Sélectionner'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={filters.dateFrom}
                      onSelect={(d) => updateFilter('dateFrom', d)}
                      locale={fr}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Date de candidature (au)</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start">
                      <CalendarIcon className="w-4 h-4 mr-2" />
                      {filters.dateTo 
                        ? format(filters.dateTo, 'dd/MM/yyyy', { locale: fr })
                        : 'Sélectionner'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={filters.dateTo}
                      onSelect={(d) => updateFilter('dateTo', d)}
                      locale={fr}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Compétences */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">Compétences requises</Label>
              <div className="flex gap-2">
                <Input
                  value={skillInput}
                  onChange={(e) => setSkillInput(e.target.value)}
                  placeholder="Ajouter une compétence..."
                  onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                />
                <Button variant="outline" onClick={addSkill}>Ajouter</Button>
              </div>
              {(filters.skills || []).length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {(filters.skills || []).map(skill => (
                    <Badge key={skill} variant="secondary" className="flex items-center gap-1">
                      {skill}
                      <X 
                        className="w-3 h-3 cursor-pointer hover:text-red-600" 
                        onClick={() => removeSkill(skill)}
                      />
                    </Badge>
                  ))}
                </div>
              )}
            </div>

            {/* Options supplémentaires */}
            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <Checkbox
                  id="hasResume"
                  checked={filters.hasResume}
                  onCheckedChange={(v) => updateFilter('hasResume', v)}
                />
                <Label htmlFor="hasResume" className="text-sm cursor-pointer">
                  CV uploadé
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="hasInterview"
                  checked={filters.hasInterview}
                  onCheckedChange={(v) => updateFilter('hasInterview', v)}
                />
                <Label htmlFor="hasInterview" className="text-sm cursor-pointer">
                  Entretien programmé
                </Label>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}