import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronLeft, ChevronRight, Calendar, Clock, User, 
  Video, Phone, MapPin, Plus, GripVertical
} from "lucide-react";
import { 
  format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, 
  addDays, addMonths, subMonths, isSameMonth, isSameDay, isToday,
  parseISO
} from "date-fns";
import { fr } from "date-fns/locale";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";

const statusColors = {
  scheduled: "bg-blue-500",
  confirmed: "bg-green-500",
  completed: "bg-gray-400",
  cancelled: "bg-red-400",
  postponed: "bg-orange-400",
};

const typeIcons = {
  phone: Phone,
  video: Video,
  in_person: MapPin,
  technical: User,
};

export default function InterviewCalendar({ interviews = [], candidates = [], onSchedule, onInterviewClick }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [viewMode, setViewMode] = useState("month"); // month, week

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async ({ id, data, interview }) => {
      await base44.entities.Interview.update(id, data);
      
      // Envoyer notifications si la date change
      if (data.interview_date && data.interview_date !== interview.interview_date) {
        await sendRescheduleNotifications(interview, data.interview_date);
      }
      
      return { id, data };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interviews'] });
      toast({ title: "Entretien reprogrammé", description: "Les participants ont été notifiés" });
    },
  });

  const sendRescheduleNotifications = async (interview, newDate) => {
    const formattedDate = format(new Date(newDate), 'EEEE d MMMM yyyy', { locale: fr });
    
    // Notifier le candidat
    if (interview.candidate_email) {
      await base44.integrations.Core.SendEmail({
        to: interview.candidate_email,
        subject: `Report d'entretien - ${interview.job_title}`,
        body: `Bonjour ${interview.candidate_name},\n\nVotre entretien pour le poste de ${interview.job_title} a été reprogrammé au ${formattedDate} à ${interview.interview_time}.\n\nCordialement,\nL'équipe RH`
      });
    }

    // Notifier l'intervieweur
    if (interview.interviewer_email) {
      await base44.integrations.Core.SendEmail({
        to: interview.interviewer_email,
        subject: `Report d'entretien - ${interview.candidate_name}`,
        body: `Bonjour,\n\nL'entretien avec ${interview.candidate_name} pour le poste de ${interview.job_title} a été reprogrammé au ${formattedDate} à ${interview.interview_time}.\n\nCordialement`
      });
    }
  };

  // Générer les jours du calendrier
  const calendarDays = useMemo(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(monthStart);
    const startDate = startOfWeek(monthStart, { weekStartsOn: 1 });
    const endDate = endOfWeek(monthEnd, { weekStartsOn: 1 });

    const days = [];
    let day = startDate;

    while (day <= endDate) {
      days.push(day);
      day = addDays(day, 1);
    }

    return days;
  }, [currentMonth]);

  // Grouper les entretiens par date
  const interviewsByDate = useMemo(() => {
    const grouped = {};
    interviews.forEach(interview => {
      if (!interview.interview_date) return;
      const dateKey = format(new Date(interview.interview_date), 'yyyy-MM-dd');
      if (!grouped[dateKey]) grouped[dateKey] = [];
      grouped[dateKey].push(interview);
    });
    // Trier par heure
    Object.keys(grouped).forEach(key => {
      grouped[key].sort((a, b) => (a.interview_time || '').localeCompare(b.interview_time || ''));
    });
    return grouped;
  }, [interviews]);

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const interviewId = result.draggableId;
    const newDate = result.destination.droppableId;
    const interview = interviews.find(i => i.id === interviewId);

    if (interview && newDate !== format(new Date(interview.interview_date), 'yyyy-MM-dd')) {
      updateMutation.mutate({
        id: interviewId,
        data: { interview_date: newDate },
        interview
      });
    }
  };

  const navigateMonth = (direction) => {
    setCurrentMonth(direction === 'next' ? addMonths(currentMonth, 1) : subMonths(currentMonth, 1));
  };

  const weekDays = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Calendrier des entretiens
            </CardTitle>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => navigateMonth('prev')}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <span className="font-semibold min-w-[150px] text-center">
                {format(currentMonth, 'MMMM yyyy', { locale: fr })}
              </span>
              <Button variant="outline" size="sm" onClick={() => navigateMonth('next')}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setCurrentMonth(new Date())}>
              Aujourd'hui
            </Button>
            {onSchedule && (
              <Button size="sm" onClick={onSchedule} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-1" />
                Planifier
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <DragDropContext onDragEnd={handleDragEnd}>
          {/* En-têtes des jours */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {weekDays.map(day => (
              <div key={day} className="text-center text-sm font-semibold text-slate-600 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Grille du calendrier */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day, index) => {
              const dateKey = format(day, 'yyyy-MM-dd');
              const dayInterviews = interviewsByDate[dateKey] || [];
              const isCurrentMonth = isSameMonth(day, currentMonth);
              const isCurrentDay = isToday(day);

              return (
                <Droppable key={dateKey} droppableId={dateKey}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className={`min-h-[120px] border rounded-lg p-1 transition-colors ${
                        snapshot.isDraggingOver ? 'bg-blue-50 border-blue-300' : 'border-slate-200'
                      } ${!isCurrentMonth ? 'bg-slate-50 opacity-50' : 'bg-white'}`}
                    >
                      <div className={`text-right text-sm font-medium p-1 ${
                        isCurrentDay 
                          ? 'bg-blue-600 text-white rounded-full w-7 h-7 flex items-center justify-center ml-auto' 
                          : 'text-slate-600'
                      }`}>
                        {format(day, 'd')}
                      </div>
                      
                      <div className="space-y-1 mt-1">
                        {dayInterviews.slice(0, 3).map((interview, idx) => {
                          const TypeIcon = typeIcons[interview.interview_type] || User;
                          
                          return (
                            <Draggable 
                              key={interview.id} 
                              draggableId={interview.id} 
                              index={idx}
                              isDragDisabled={interview.status === 'completed' || interview.status === 'cancelled'}
                            >
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  onClick={() => onInterviewClick?.(interview)}
                                  className={`text-xs p-1.5 rounded cursor-pointer transition-all ${
                                    snapshot.isDragging ? 'shadow-lg ring-2 ring-blue-400' : ''
                                  } ${statusColors[interview.status]} text-white`}
                                >
                                  <div className="flex items-center gap-1">
                                    <GripVertical className="w-3 h-3 opacity-50" />
                                    <TypeIcon className="w-3 h-3" />
                                    <span className="truncate flex-1">{interview.candidate_name}</span>
                                  </div>
                                  <div className="text-[10px] opacity-80 ml-4">
                                    {interview.interview_time}
                                  </div>
                                </div>
                              )}
                            </Draggable>
                          );
                        })}
                        {dayInterviews.length > 3 && (
                          <div className="text-xs text-center text-blue-600 font-medium">
                            +{dayInterviews.length - 3} autres
                          </div>
                        )}
                      </div>
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              );
            })}
          </div>
        </DragDropContext>

        {/* Légende */}
        <div className="flex items-center gap-4 mt-4 pt-4 border-t flex-wrap">
          <span className="text-sm text-slate-600">Légende:</span>
          {Object.entries({ scheduled: 'Planifié', confirmed: 'Confirmé', completed: 'Terminé', cancelled: 'Annulé' }).map(([key, label]) => (
            <div key={key} className="flex items-center gap-1">
              <div className={`w-3 h-3 rounded ${statusColors[key]}`} />
              <span className="text-xs text-slate-600">{label}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}