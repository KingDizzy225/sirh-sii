import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X, Upload } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";

export default function CandidateForm({ jobPostings = [], onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    job_posting_id: "",
    job_title: "",
    resume_url: "",
    cover_letter: "",
    experience_years: "",
    skills: [],
    salary_expectation: "",
    availability: "",
    source: "",
    notes: "",
    status: "new",
    application_date: format(new Date(), 'yyyy-MM-dd'),
  });

  const [newSkill, setNewSkill] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  const handleJobChange = (jobId) => {
    const job = jobPostings.find(j => j.id === jobId);
    setFormData({
      ...formData,
      job_posting_id: jobId,
      job_title: job?.title || "",
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, resume_url: file_url });
    } catch (error) {
      console.error("Erreur upload:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      setFormData({
        ...formData,
        skills: [...formData.skills, newSkill.trim()]
      });
      setNewSkill("");
    }
  };

  const removeSkill = (skillToRemove) => {
    setFormData({
      ...formData,
      skills: formData.skills.filter(s => s !== skillToRemove)
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.full_name || !formData.email) {
      return;
    }

    onSubmit({
      ...formData,
      experience_years: formData.experience_years ? parseInt(formData.experience_years) : null,
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Ajouter une candidature</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Nom complet */}
            <div className="space-y-2">
              <Label htmlFor="full_name">Nom complet *</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                placeholder="Jean Dupont"
                required
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                placeholder="jean.dupont@email.com"
                required
              />
            </div>

            {/* Téléphone */}
            <div className="space-y-2">
              <Label htmlFor="phone">Téléphone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="+33 6 12 34 56 78"
              />
            </div>

            {/* Poste */}
            <div className="space-y-2">
              <Label htmlFor="job">Poste</Label>
              <Select
                value={formData.job_posting_id}
                onValueChange={handleJobChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un poste" />
                </SelectTrigger>
                <SelectContent>
                  {jobPostings.length === 0 ? (
                    <SelectItem value="none" disabled>Aucun poste disponible</SelectItem>
                  ) : (
                    jobPostings.map(job => (
                      <SelectItem key={job.id} value={job.id}>
                        {job.title}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            {/* Expérience */}
            <div className="space-y-2">
              <Label htmlFor="experience_years">Années d'expérience</Label>
              <Input
                id="experience_years"
                type="number"
                min="0"
                value={formData.experience_years}
                onChange={(e) => setFormData({...formData, experience_years: e.target.value})}
                placeholder="5"
              />
            </div>

            {/* Prétentions salariales */}
            <div className="space-y-2">
              <Label htmlFor="salary_expectation">Prétentions salariales</Label>
              <Input
                id="salary_expectation"
                value={formData.salary_expectation}
                onChange={(e) => setFormData({...formData, salary_expectation: e.target.value})}
                placeholder="45 000 - 55 000 €"
              />
            </div>

            {/* Disponibilité */}
            <div className="space-y-2">
              <Label htmlFor="availability">Disponibilité</Label>
              <Input
                id="availability"
                value={formData.availability}
                onChange={(e) => setFormData({...formData, availability: e.target.value})}
                placeholder="Immédiate / 1 mois..."
              />
            </div>

            {/* Source */}
            <div className="space-y-2">
              <Label htmlFor="source">Source</Label>
              <Select
                value={formData.source}
                onValueChange={(value) => setFormData({...formData, source: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Source de la candidature" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="indeed">Indeed</SelectItem>
                  <SelectItem value="website">Site web</SelectItem>
                  <SelectItem value="referral">Cooptation</SelectItem>
                  <SelectItem value="spontaneous">Candidature spontanée</SelectItem>
                  <SelectItem value="other">Autre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* CV */}
          <div className="space-y-2">
            <Label>CV</Label>
            <div className="flex items-center gap-4">
              <Input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileUpload}
                className="hidden"
                id="resume-upload"
              />
              <label
                htmlFor="resume-upload"
                className="flex items-center gap-2 px-4 py-2 border border-dashed border-slate-300 rounded-lg cursor-pointer hover:bg-slate-50 transition-colors"
              >
                <Upload className="w-4 h-4" />
                <span className="text-sm">
                  {isUploading ? "Téléchargement..." : "Télécharger un CV"}
                </span>
              </label>
              {formData.resume_url && (
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  CV téléchargé ✓
                </Badge>
              )}
            </div>
          </div>

          {/* Compétences */}
          <div className="space-y-2">
            <Label>Compétences</Label>
            <div className="flex gap-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Ajouter une compétence"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
              />
              <Button type="button" variant="outline" onClick={addSkill}>
                Ajouter
              </Button>
            </div>
            {formData.skills.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Lettre de motivation */}
          <div className="space-y-2">
            <Label htmlFor="cover_letter">Lettre de motivation</Label>
            <Textarea
              id="cover_letter"
              value={formData.cover_letter}
              onChange={(e) => setFormData({...formData, cover_letter: e.target.value})}
              placeholder="Lettre de motivation du candidat..."
              rows={4}
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes internes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              placeholder="Notes sur le candidat..."
              rows={2}
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting || !formData.full_name || !formData.email}
              className="bg-green-600 hover:bg-green-700"
            >
              {isSubmitting ? 'Création...' : 'Ajouter le candidat'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}