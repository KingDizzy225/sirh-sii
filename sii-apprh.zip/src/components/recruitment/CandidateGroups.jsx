import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { 
  Users, Plus, Mail, Trash2, Edit2, Send, 
  UserPlus, FolderPlus, Loader2, X
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useToast } from "@/components/ui/use-toast";

export default function CandidateGroups({ candidates = [], groups = [], onGroupsChange }) {
  const [localGroups, setLocalGroups] = useState(groups);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [newGroupName, setNewGroupName] = useState("");
  const [newGroupDescription, setNewGroupDescription] = useState("");
  const [selectedCandidates, setSelectedCandidates] = useState([]);
  const [emailSubject, setEmailSubject] = useState("");
  const [emailBody, setEmailBody] = useState("");
  const [isSending, setIsSending] = useState(false);

  const { toast } = useToast();

  const createGroup = () => {
    if (!newGroupName.trim()) return;

    const newGroup = {
      id: Date.now().toString(),
      name: newGroupName.trim(),
      description: newGroupDescription.trim(),
      candidateIds: selectedCandidates,
      createdAt: new Date().toISOString(),
    };

    const updatedGroups = [...localGroups, newGroup];
    setLocalGroups(updatedGroups);
    onGroupsChange?.(updatedGroups);

    setNewGroupName("");
    setNewGroupDescription("");
    setSelectedCandidates([]);
    setShowCreateModal(false);

    toast({ title: "Groupe créé", description: `${selectedCandidates.length} candidat(s) ajouté(s)` });
  };

  const deleteGroup = (groupId) => {
    const updatedGroups = localGroups.filter(g => g.id !== groupId);
    setLocalGroups(updatedGroups);
    onGroupsChange?.(updatedGroups);
    toast({ title: "Groupe supprimé" });
  };

  const toggleCandidateSelection = (candidateId) => {
    setSelectedCandidates(prev =>
      prev.includes(candidateId)
        ? prev.filter(id => id !== candidateId)
        : [...prev, candidateId]
    );
  };

  const selectAll = () => {
    setSelectedCandidates(candidates.map(c => c.id));
  };

  const deselectAll = () => {
    setSelectedCandidates([]);
  };

  const openEmailModal = (group) => {
    setSelectedGroup(group);
    setShowEmailModal(true);
  };

  const sendBulkEmail = async () => {
    if (!selectedGroup || !emailSubject || !emailBody) return;

    setIsSending(true);
    const groupCandidates = candidates.filter(c => selectedGroup.candidateIds.includes(c.id));
    let sentCount = 0;

    try {
      for (const candidate of groupCandidates) {
        if (candidate.email) {
          const personalizedBody = emailBody
            .replace(/\{nom\}/g, candidate.full_name)
            .replace(/\{poste\}/g, candidate.job_title || "")
            .replace(/\{email\}/g, candidate.email);

          await base44.integrations.Core.SendEmail({
            to: candidate.email,
            subject: emailSubject,
            body: personalizedBody
          });
          sentCount++;
        }
      }

      toast({
        title: "Emails envoyés ✅",
        description: `${sentCount} email(s) envoyé(s) au groupe "${selectedGroup.name}"`
      });

      setShowEmailModal(false);
      setEmailSubject("");
      setEmailBody("");
    } catch (error) {
      toast({ title: "Erreur", description: "Certains emails n'ont pas pu être envoyés", variant: "destructive" });
    } finally {
      setIsSending(false);
    }
  };

  const getGroupCandidatesCount = (group) => {
    if (!group || !group.candidateIds) return 0;
    return candidates.filter(c => group.candidateIds.includes(c.id)).length;
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          Groupes de candidats
        </h3>
        <Button onClick={() => setShowCreateModal(true)} size="sm" className="bg-blue-600 hover:bg-blue-700">
          <FolderPlus className="w-4 h-4 mr-1" />
          Créer un groupe
        </Button>
      </div>

      {/* Liste des groupes */}
      {localGroups.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-8 text-center">
            <Users className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p className="text-slate-500">Aucun groupe créé</p>
            <p className="text-sm text-slate-400 mt-1">
              Créez des groupes pour organiser vos candidats
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {localGroups.map(group => {
            const count = getGroupCandidatesCount(group);
            return (
              <Card key={group.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-base">{group.name}</CardTitle>
                      {group.description && (
                        <p className="text-xs text-slate-500 mt-1">{group.description}</p>
                      )}
                    </div>
                    <Badge variant="secondary">{count} candidat(s)</Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openEmailModal(group)}
                      disabled={count === 0}
                    >
                      <Mail className="w-4 h-4 mr-1" />
                      Envoyer email
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-red-600 hover:bg-red-50"
                      onClick={() => deleteGroup(group.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Modal création groupe */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderPlus className="w-5 h-5 text-blue-600" />
              Créer un groupe de candidats
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Nom du groupe *</Label>
                <Input
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Ex: Candidats tech senior"
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input
                  value={newGroupDescription}
                  onChange={(e) => setNewGroupDescription(e.target.value)}
                  placeholder="Ex: Campagne recrutement Q1"
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Sélectionner les candidats ({selectedCandidates.length})</Label>
                <div className="flex gap-2">
                  <Button variant="ghost" size="sm" onClick={selectAll}>Tout sélectionner</Button>
                  <Button variant="ghost" size="sm" onClick={deselectAll}>Désélectionner</Button>
                </div>
              </div>
              
              <div className="border rounded-lg max-h-[300px] overflow-y-auto">
                {candidates.map(candidate => (
                  <div
                    key={candidate.id}
                    className={`flex items-center gap-3 p-3 border-b last:border-b-0 hover:bg-slate-50 cursor-pointer ${
                      selectedCandidates.includes(candidate.id) ? 'bg-blue-50' : ''
                    }`}
                    onClick={() => toggleCandidateSelection(candidate.id)}
                  >
                    <Checkbox checked={selectedCandidates.includes(candidate.id)} />
                    <div className="flex-1">
                      <p className="font-medium text-sm">{candidate.full_name}</p>
                      <p className="text-xs text-slate-500">{candidate.email} • {candidate.job_title}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {candidate.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setShowCreateModal(false)}>
                Annuler
              </Button>
              <Button
                onClick={createGroup}
                disabled={!newGroupName.trim() || selectedCandidates.length === 0}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Créer le groupe ({selectedCandidates.length})
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal envoi email */}
      <Dialog open={showEmailModal} onOpenChange={setShowEmailModal}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-600" />
              Email au groupe "{selectedGroup?.name}"
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="bg-blue-50 p-3 rounded-lg text-sm">
              <p className="text-blue-700">
                📧 {getGroupCandidatesCount(selectedGroup || {})} destinataire(s)
              </p>
              <p className="text-blue-600 text-xs mt-1">
                Variables disponibles: {'{nom}'}, {'{poste}'}, {'{email}'}
              </p>
            </div>

            <div className="space-y-2">
              <Label>Objet *</Label>
              <Input
                value={emailSubject}
                onChange={(e) => setEmailSubject(e.target.value)}
                placeholder="Ex: Opportunité chez notre entreprise"
              />
            </div>

            <div className="space-y-2">
              <Label>Message *</Label>
              <Textarea
                value={emailBody}
                onChange={(e) => setEmailBody(e.target.value)}
                rows={8}
                placeholder={`Bonjour {nom},\n\nNous avons le plaisir de vous contacter concernant le poste de {poste}...\n\nCordialement`}
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setShowEmailModal(false)} disabled={isSending}>
                Annuler
              </Button>
              <Button
                onClick={sendBulkEmail}
                disabled={isSending || !emailSubject || !emailBody}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isSending ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                Envoyer
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}