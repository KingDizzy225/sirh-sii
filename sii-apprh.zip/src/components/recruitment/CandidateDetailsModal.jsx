import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, Calendar, FileText, Star, Award, Clock, User, BarChart3 } from "lucide-react";
import { format } from "date-fns";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";
import CandidateRatingSystem from "./CandidateRatingSystem";

const statusColors = {
  new: "bg-blue-100 text-blue-800",
  screening: "bg-purple-100 text-purple-800",
  interview: "bg-orange-100 text-orange-800",
  offer: "bg-green-100 text-green-800",
  hired: "bg-emerald-100 text-emerald-800",
  rejected: "bg-red-100 text-red-800",
};

const statusLabels = {
  new: "Nouveau",
  screening: "Présélection",
  interview: "Entretien",
  offer: "Offre",
  hired: "Embauché",
  rejected: "Rejeté",
};

export default function CandidateDetailsModal({ candidate, onClose }) {
  const [activeTab, setActiveTab] = useState("info");
  const [notes, setNotes] = useState(candidate.notes || "");
  const [rating, setRating] = useState(candidate.rating || 0);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Candidate.update(candidate.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({ title: "Candidat mis à jour" });
    },
  });

  const handleSave = () => {
    updateMutation.mutate({ notes, rating });
  };

  const handleStatusChange = (newStatus) => {
    updateMutation.mutate({ status: newStatus });
  };

  const getApplicationDate = () => {
    try {
      const date = candidate.application_date || candidate.created_date;
      if (date) {
        return format(new Date(date), 'dd/MM/yyyy');
      }
      return 'N/A';
    } catch {
      return 'N/A';
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-2xl">{candidate.full_name}</DialogTitle>
              <p className="text-blue-600 font-medium mt-1">{candidate.job_title || "Poste non défini"}</p>
            </div>
            <Badge className={statusColors[candidate.status] || statusColors.new}>
              {statusLabels[candidate.status] || candidate.status}
            </Badge>
          </div>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="info">Informations</TabsTrigger>
            <TabsTrigger value="evaluation">Évaluation</TabsTrigger>
            <TabsTrigger value="actions">Actions</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-blue-600" />
                    <div>
                      <p className="text-xs text-slate-500">Email</p>
                      <p className="text-sm font-medium">{candidate.email}</p>
                    </div>
                  </div>
                  {candidate.phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-green-600" />
                      <div>
                        <p className="text-xs text-slate-500">Téléphone</p>
                        <p className="text-sm font-medium">{candidate.phone}</p>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-purple-600" />
                    <div>
                      <p className="text-xs text-slate-500">Candidature</p>
                      <p className="text-sm font-medium">{getApplicationDate()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4 space-y-3">
                  {candidate.experience_years && (
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-orange-600" />
                      <div>
                        <p className="text-xs text-slate-500">Expérience</p>
                        <p className="text-sm font-medium">{candidate.experience_years} ans</p>
                      </div>
                    </div>
                  )}
                  {candidate.salary_expectation && (
                    <div className="flex items-center gap-2">
                      <span className="text-lg">💰</span>
                      <div>
                        <p className="text-xs text-slate-500">Prétentions salariales</p>
                        <p className="text-sm font-medium">{candidate.salary_expectation}</p>
                      </div>
                    </div>
                  )}
                  {candidate.availability && (
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="text-xs text-slate-500">Disponibilité</p>
                        <p className="text-sm font-medium">{candidate.availability}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {candidate.skills && candidate.skills.length > 0 && (
              <div>
                <Label>Compétences</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {candidate.skills.map((skill, index) => (
                    <Badge key={index} variant="outline" className="bg-blue-50">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {candidate.cover_letter && (
              <div>
                <Label>Lettre de motivation</Label>
                <p className="text-sm text-slate-700 mt-2 p-3 bg-slate-50 rounded-lg whitespace-pre-wrap">
                  {candidate.cover_letter}
                </p>
              </div>
            )}

            <div className="space-y-2">
              <Label>Notes internes</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={4}
                placeholder="Ajouter des notes sur ce candidat..."
              />
            </div>

            <div className="space-y-2">
              <Label>Évaluation globale</Label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="transition-transform hover:scale-110"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-slate-300'
                      }`}
                    />
                  </button>
                ))}
                <span className="ml-2 text-sm text-slate-600">
                  {rating > 0 ? `${rating}/5` : 'Non évalué'}
                </span>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4">
              <Button variant="outline" onClick={onClose}>
                Fermer
              </Button>
              <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
                Enregistrer
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="evaluation" className="mt-4">
            <CandidateRatingSystem 
              candidate={candidate} 
              onUpdate={() => queryClient.invalidateQueries({ queryKey: ['candidates'] })}
            />
          </TabsContent>

          <TabsContent value="actions" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-3">
              {candidate.status !== 'screening' && candidate.status !== 'hired' && candidate.status !== 'rejected' && (
                <Button
                  onClick={() => handleStatusChange('screening')}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Présélectionner
                </Button>
              )}
              {candidate.status === 'screening' && (
                <Button
                  onClick={() => handleStatusChange('interview')}
                  className="bg-orange-600 hover:bg-orange-700"
                >
                  Convoquer en entretien
                </Button>
              )}
              {candidate.status === 'interview' && (
                <Button
                  onClick={() => handleStatusChange('offer')}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Faire une offre
                </Button>
              )}
              {candidate.status === 'offer' && (
                <Button
                  onClick={() => handleStatusChange('hired')}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Embaucher
                </Button>
              )}
              {candidate.status !== 'rejected' && candidate.status !== 'hired' && (
                <Button
                  variant="outline"
                  onClick={() => handleStatusChange('rejected')}
                  className="border-red-300 text-red-600 hover:bg-red-50"
                >
                  Rejeter
                </Button>
              )}
            </div>

            {candidate.status === 'hired' && (
              <div className="p-4 bg-emerald-50 rounded-lg text-center">
                <p className="text-emerald-800 font-medium">Ce candidat a été embauché !</p>
              </div>
            )}

            {candidate.status === 'rejected' && (
              <div className="p-4 bg-red-50 rounded-lg text-center">
                <p className="text-red-800 font-medium">Cette candidature a été rejetée</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleStatusChange('new')}
                  className="mt-2"
                >
                  Réactiver la candidature
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="documents" className="space-y-4 mt-4">
            {candidate.resume_url ? (
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="w-8 h-8 text-blue-600" />
                      <div>
                        <p className="font-medium">CV</p>
                        <p className="text-xs text-slate-500">Document du candidat</p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => window.open(candidate.resume_url, '_blank')}
                    >
                      Voir le CV
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="text-center py-12 text-slate-500">
                <FileText className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                <p>Aucun CV téléchargé</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}