import { base44 } from "@/api/base44Client";
import { format, addDays } from "date-fns";
import { generateWorkflow, generateOnboardingDocuments, scheduleMeetings } from "../workflow/WorkflowAutomation";

/**
 * Convertit un candidat embauché en employé et déclenche le workflow d'onboarding
 * @param {Object} candidate - Le candidat embauché
 * @param {Object} jobPosting - L'offre d'emploi associée (optionnel)
 * @param {Object} additionalData - Données supplémentaires pour l'employé
 * @returns {Promise<Object>} - L'employé créé
 */
export async function convertCandidateToEmployee(candidate, jobPosting = null, additionalData = {}) {
  try {
    // Vérifier si l'employé existe déjà
    const existingEmployees = await base44.entities.Employee.filter({
      email: candidate.email
    });

    if (existingEmployees.length > 0) {
      console.log("⚠️ L'employé existe déjà:", candidate.email);
      return { employee: existingEmployees[0], alreadyExists: true };
    }

    // Générer un ID employé unique
    const employeeId = await generateEmployeeId();

    // Date d'embauche (aujourd'hui par défaut ou date spécifiée)
    const hireDate = additionalData.hire_date || format(new Date(), 'yyyy-MM-dd');

    // Calculer la date de fin de période d'essai (3 mois par défaut)
    const probationEndDate = format(addDays(new Date(hireDate), 90), 'yyyy-MM-dd');

    // Créer l'employé
    const employeeData = {
      employee_id: employeeId,
      full_name: candidate.full_name,
      email: candidate.email,
      phone: candidate.phone || '',
      department: jobPosting?.department || additionalData.department || '',
      position: candidate.job_title || jobPosting?.title || additionalData.position || '',
      employment_type: jobPosting?.employment_type || additionalData.employment_type || 'full_time',
      hire_date: hireDate,
      probation_end_date: probationEndDate,
      status: 'active',
      skills: candidate.skills || [],
      work_location: jobPosting?.location || additionalData.work_location || '',
      manager_email: jobPosting?.hiring_manager || additionalData.manager_email || '',
      salary: additionalData.salary || null,
      notes: `Converti depuis candidature le ${format(new Date(), 'dd/MM/yyyy')}. Source: ${candidate.source || 'Candidature directe'}`,
      ...additionalData
    };

    const employee = await base44.entities.Employee.create(employeeData);
    console.log("✅ Employé créé:", employee.id);

    // Mettre à jour le département si nécessaire
    if (employeeData.department) {
      await updateDepartmentCount(employeeData.department);
    }

    // Déclencher le workflow d'onboarding
    try {
      const workflow = await generateWorkflow(employee, 'onboarding', hireDate);
      console.log("✅ Workflow d'onboarding créé:", workflow?.id);
    } catch (workflowError) {
      console.warn("⚠️ Erreur création workflow (peut-être pas de template):", workflowError);
      // Créer les tâches d'onboarding par défaut si pas de template
      await createDefaultOnboardingTasks(employee, hireDate);
    }

    // Générer les documents d'intégration
    try {
      await generateOnboardingDocuments(employee);
    } catch (docError) {
      console.warn("⚠️ Erreur génération documents:", docError);
    }

    // Planifier les réunions d'intégration
    try {
      await scheduleMeetings(employee, 'onboarding');
    } catch (meetingError) {
      console.warn("⚠️ Erreur planification réunions:", meetingError);
    }

    // Créer les notifications
    await createHiringNotifications(employee, candidate);

    // Mettre à jour le candidat avec la référence de l'employé
    await base44.entities.Candidate.update(candidate.id, {
      notes: `${candidate.notes || ''}\n\n[${format(new Date(), 'dd/MM/yyyy')}] Converti en employé (ID: ${employeeId})`
    });

    return { employee, alreadyExists: false };
  } catch (error) {
    console.error("❌ Erreur lors de la conversion du candidat:", error);
    throw error;
  }
}

/**
 * Génère un ID employé unique
 */
async function generateEmployeeId() {
  const year = new Date().getFullYear();
  const employees = await base44.entities.Employee.list();
  const currentYearEmployees = employees.filter(e => 
    e.employee_id?.startsWith(`EMP-${year}`)
  );
  const nextNumber = (currentYearEmployees.length + 1).toString().padStart(4, '0');
  return `EMP-${year}-${nextNumber}`;
}

/**
 * Met à jour le compteur d'employés du département
 */
async function updateDepartmentCount(departmentName) {
  try {
    const departments = await base44.entities.Department.filter({ name: departmentName });
    if (departments.length > 0) {
      const dept = departments[0];
      await base44.entities.Department.update(dept.id, {
        employee_count: (dept.employee_count || 0) + 1
      });
    }
  } catch (error) {
    console.warn("⚠️ Erreur mise à jour département:", error);
  }
}

/**
 * Crée les tâches d'onboarding par défaut si aucun template n'existe
 */
async function createDefaultOnboardingTasks(employee, startDate) {
  const defaultTasks = [
    { title: "Préparer le poste de travail", department: "IT", days_offset: -1, priority: "high" },
    { title: "Créer les accès informatiques", department: "IT", days_offset: -1, priority: "high" },
    { title: "Préparer le contrat de travail", department: "RH", days_offset: -2, priority: "critical" },
    { title: "Session d'accueil et présentation", department: "RH", days_offset: 0, priority: "high" },
    { title: "Formation sécurité", department: "RH", days_offset: 0, priority: "medium" },
    { title: "Tour des locaux", department: "RH", days_offset: 0, priority: "medium" },
    { title: "Présentation de l'équipe", department: "Manager", days_offset: 0, priority: "medium" },
    { title: "Première réunion avec le manager", department: "Manager", days_offset: 0, priority: "high" },
    { title: "Formation aux outils", department: "IT", days_offset: 1, priority: "medium" },
    { title: "Point de suivi - Semaine 1", department: "Manager", days_offset: 7, priority: "medium" },
    { title: "Évaluation fin période d'essai", department: "RH", days_offset: 90, priority: "high" },
  ];

  for (const task of defaultTasks) {
    const dueDate = format(addDays(new Date(startDate), task.days_offset), 'yyyy-MM-dd');
    
    try {
      await base44.entities.OnboardingTask.create({
        employee_email: employee.email,
        employee_name: employee.full_name,
        task_type: 'onboarding',
        title: task.title,
        description: `Tâche d'intégration pour ${employee.full_name}`,
        department: task.department,
        due_date: dueDate,
        status: 'pending',
        priority: task.priority,
      });
    } catch (error) {
      console.warn("⚠️ Erreur création tâche:", task.title, error);
    }
  }

  console.log(`✅ ${defaultTasks.length} tâches d'onboarding créées par défaut`);
}

/**
 * Crée les notifications pour l'embauche
 */
async function createHiringNotifications(employee, candidate) {
  try {
    // Notification pour les RH
    await base44.entities.Notification.create({
      type: 'new_employee',
      title: "Nouvel employé embauché 🎉",
      message: `${employee.full_name} a été embauché(e) au poste de ${employee.position} dans le département ${employee.department || 'non défini'}.`,
      priority: 'high',
      is_read: false,
      related_entity: 'Employee',
      related_entity_id: employee.id,
    });

    // Notification pour le manager si défini
    if (employee.manager_email) {
      await base44.entities.Notification.create({
        user_email: employee.manager_email,
        type: 'new_team_member',
        title: "Nouveau membre dans votre équipe",
        message: `${employee.full_name} rejoint votre équipe le ${format(new Date(employee.hire_date), 'dd/MM/yyyy')}.`,
        priority: 'high',
        is_read: false,
        related_entity: 'Employee',
        related_entity_id: employee.id,
      });
    }

    // Email de bienvenue au nouvel employé
    try {
      await base44.integrations.Core.SendEmail({
        to: employee.email,
        subject: `Bienvenue chez SII - ${employee.position}`,
        body: `
Bonjour ${employee.full_name},

Nous sommes ravis de vous accueillir au sein de notre équipe !

Votre prise de poste est prévue le ${format(new Date(employee.hire_date), 'dd/MM/yyyy')}.

Poste : ${employee.position}
Département : ${employee.department || 'À définir'}

Votre processus d'intégration a été lancé et vous recevrez bientôt plus d'informations sur les étapes à suivre.

À très bientôt,
L'équipe RH
        `.trim()
      });
    } catch (emailError) {
      console.warn("⚠️ Erreur envoi email de bienvenue:", emailError);
    }

  } catch (error) {
    console.warn("⚠️ Erreur création notifications:", error);
  }
}

/**
 * Hook pour utiliser la conversion candidat -> employé
 */
export function useCandidateToEmployee() {
  const convertToEmployee = async (candidate, jobPosting, additionalData = {}) => {
    return await convertCandidateToEmployee(candidate, jobPosting, additionalData);
  };

  return { convertToEmployee };
}

export default {
  convertCandidateToEmployee,
  useCandidateToEmployee
};