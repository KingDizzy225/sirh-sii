import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Star, Save, Brain, MessageSquare, Users, Briefcase, 
  Zap, Target, ThumbsUp, ThumbsDown, Loader2
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";

const ratingCategories = [
  { id: "technical_skills", label: "Compétences techniques", icon: Brain, color: "text-blue-600" },
  { id: "communication", label: "Communication", icon: MessageSquare, color: "text-green-600" },
  { id: "teamwork", label: "Travail d'équipe", icon: Users, color: "text-purple-600" },
  { id: "experience", label: "Expérience pertinente", icon: Briefcase, color: "text-orange-600" },
  { id: "motivation", label: "Motivation", icon: Zap, color: "text-yellow-600" },
  { id: "culture_fit", label: "Adéquation culturelle", icon: Target, color: "text-pink-600" },
];

export default function CandidateRatingSystem({ candidate, onUpdate }) {
  const [ratings, setRatings] = useState(candidate?.detailed_ratings || {});
  const [strengths, setStrengths] = useState(candidate?.strengths || "");
  const [weaknesses, setWeaknesses] = useState(candidate?.weaknesses || "");
  const [recommendation, setRecommendation] = useState(candidate?.recommendation || "");
  const [isSaving, setIsSaving] = useState(false);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Candidate.update(candidate.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      toast({ title: "Évaluation sauvegardée" });
      onUpdate?.();
    },
  });

  const handleRatingChange = (categoryId, value) => {
    setRatings(prev => ({ ...prev, [categoryId]: value[0] }));
  };

  const calculateOverallScore = () => {
    const values = Object.values(ratings);
    if (values.length === 0) return 0;
    return Math.round(values.reduce((a, b) => a + b, 0) / values.length);
  };

  const handleSave = async () => {
    setIsSaving(true);
    const overallScore = calculateOverallScore();
    
    await updateMutation.mutateAsync({
      detailed_ratings: ratings,
      strengths,
      weaknesses,
      recommendation,
      overall_score: overallScore,
      rating: Math.round(overallScore / 20), // Convertir en /5
    });
    
    setIsSaving(false);
  };

  const overallScore = calculateOverallScore();

  return (
    <div className="space-y-6">
      {/* Score global */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-none">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 mb-1">Score global</p>
              <div className="flex items-center gap-3">
                <span className="text-4xl font-bold text-blue-700">{overallScore}%</span>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star
                      key={star}
                      className={`w-5 h-5 ${
                        star <= Math.round(overallScore / 20)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-slate-300'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            <div className="w-24 h-24 relative">
              <svg className="w-full h-full transform -rotate-90">
                <circle
                  cx="48" cy="48" r="40"
                  stroke="#e2e8f0" strokeWidth="8" fill="none"
                />
                <circle
                  cx="48" cy="48" r="40"
                  stroke="#3b82f6" strokeWidth="8" fill="none"
                  strokeDasharray={`${overallScore * 2.51} 251`}
                  strokeLinecap="round"
                />
              </svg>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Catégories de notation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Évaluation détaillée</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {ratingCategories.map(category => {
            const Icon = category.icon;
            const value = ratings[category.id] || 0;
            
            return (
              <div key={category.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center gap-2">
                    <Icon className={`w-4 h-4 ${category.color}`} />
                    {category.label}
                  </Label>
                  <Badge variant={value >= 70 ? "default" : value >= 40 ? "secondary" : "outline"}>
                    {value}%
                  </Badge>
                </div>
                <Slider
                  value={[value]}
                  onValueChange={(v) => handleRatingChange(category.id, v)}
                  max={100}
                  step={5}
                  className="py-2"
                />
                <Progress value={value} className="h-2" />
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* Points forts et faibles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-green-700">
              <ThumbsUp className="w-4 h-4" />
              Points forts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={strengths}
              onChange={(e) => setStrengths(e.target.value)}
              placeholder="Listez les points forts du candidat..."
              rows={4}
              className="border-green-200 focus:border-green-400"
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2 text-orange-700">
              <ThumbsDown className="w-4 h-4" />
              Points à améliorer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={weaknesses}
              onChange={(e) => setWeaknesses(e.target.value)}
              placeholder="Listez les axes d'amélioration..."
              rows={4}
              className="border-orange-200 focus:border-orange-400"
            />
          </CardContent>
        </Card>
      </div>

      {/* Recommandation */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Recommandation finale</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={recommendation}
            onChange={(e) => setRecommendation(e.target.value)}
            placeholder="Votre recommandation pour ce candidat (embauche, autre poste, refus...)..."
            rows={3}
          />
        </CardContent>
      </Card>

      {/* Bouton sauvegarder */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={isSaving} className="bg-blue-600 hover:bg-blue-700">
          {isSaving ? (
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          Sauvegarder l'évaluation
        </Button>
      </div>
    </div>
  );
}