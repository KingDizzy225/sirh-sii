import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Mail, Star, Settings, Plus, Trash2, GripVertical, 
  Check, X, Bell, ChevronDown, ChevronUp, Eye, EyeOff, UserPlus
} from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";
import CandidateDetailsModal from "./CandidateDetailsModal";
import { convertCandidateToEmployee } from "./CandidateToEmployeeService";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const defaultStages = [
  { id: 'new', label: 'Nouveaux', color: 'bg-blue-500', textColor: 'text-blue-700', bgLight: 'bg-blue-50', visible: true },
  { id: 'screening', label: 'Présélection', color: 'bg-purple-500', textColor: 'text-purple-700', bgLight: 'bg-purple-50', visible: true },
  { id: 'interview', label: 'Entretien', color: 'bg-orange-500', textColor: 'text-orange-700', bgLight: 'bg-orange-50', visible: true },
  { id: 'offer', label: 'Offre', color: 'bg-green-500', textColor: 'text-green-700', bgLight: 'bg-green-50', visible: true },
  { id: 'hired', label: 'Embauché', color: 'bg-emerald-500', textColor: 'text-emerald-700', bgLight: 'bg-emerald-50', visible: true },
  { id: 'rejected', label: 'Rejeté', color: 'bg-red-500', textColor: 'text-red-700', bgLight: 'bg-red-50', visible: true },
];

const colorOptions = [
  { color: 'bg-blue-500', textColor: 'text-blue-700', bgLight: 'bg-blue-50', label: 'Bleu' },
  { color: 'bg-purple-500', textColor: 'text-purple-700', bgLight: 'bg-purple-50', label: 'Violet' },
  { color: 'bg-orange-500', textColor: 'text-orange-700', bgLight: 'bg-orange-50', label: 'Orange' },
  { color: 'bg-green-500', textColor: 'text-green-700', bgLight: 'bg-green-50', label: 'Vert' },
  { color: 'bg-emerald-500', textColor: 'text-emerald-700', bgLight: 'bg-emerald-50', label: 'Émeraude' },
  { color: 'bg-red-500', textColor: 'text-red-700', bgLight: 'bg-red-50', label: 'Rouge' },
  { color: 'bg-pink-500', textColor: 'text-pink-700', bgLight: 'bg-pink-50', label: 'Rose' },
  { color: 'bg-indigo-500', textColor: 'text-indigo-700', bgLight: 'bg-indigo-50', label: 'Indigo' },
  { color: 'bg-teal-500', textColor: 'text-teal-700', bgLight: 'bg-teal-50', label: 'Sarcelle' },
  { color: 'bg-yellow-500', textColor: 'text-yellow-700', bgLight: 'bg-yellow-50', label: 'Jaune' },
];

export default function RecruitmentPipeline({ candidates = [], jobPostings = [], onCandidateUpdate }) {
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [stages, setStages] = useState(() => {
    const saved = localStorage.getItem('recruitment_pipeline_stages');
    return saved ? JSON.parse(saved) : defaultStages;
  });
  const [collapsedStages, setCollapsedStages] = useState({});
  const [editingStage, setEditingStage] = useState(null);
  const [newStageName, setNewStageName] = useState("");

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Sauvegarder les étapes dans le localStorage
  useEffect(() => {
    localStorage.setItem('recruitment_pipeline_stages', JSON.stringify(stages));
  }, [stages]);

  const updateMutation = useMutation({
    mutationFn: async ({ id, data, previousStatus }) => {
      await base44.entities.Candidate.update(id, data);
      return { id, data, previousStatus };
    },
    onSuccess: async ({ id, data, previousStatus }) => {
      queryClient.invalidateQueries({ queryKey: ['candidates'] });
      
      const candidate = candidates.find(c => c.id === id);
      const newStage = stages.find(s => s.id === data.status);
      const oldStage = stages.find(s => s.id === previousStatus);
      
      // Notification de changement de statut
      if (candidate && newStage && oldStage && newStage.id !== oldStage.id) {
        toast({
          title: `📋 Statut mis à jour`,
          description: `${candidate.full_name} : ${oldStage.label} → ${newStage.label}`,
        });

        // Envoyer une notification pour les changements importants
        if (['interview', 'offer', 'hired', 'rejected'].includes(data.status)) {
          try {
            await sendStatusNotification(candidate, data.status, newStage.label);
          } catch (e) {
            console.error("Erreur notification:", e);
          }
        }

        // SI LE CANDIDAT EST EMBAUCHÉ -> Convertir en employé et déclencher workflows
        if (data.status === 'hired' && candidate) {
          try {
            toast({
              title: "🔄 Création du profil employé...",
              description: `Conversion de ${candidate.full_name} en employé`,
            });

            // Récupérer l'offre d'emploi associée
            let jobPosting = null;
            if (candidate.job_posting_id) {
              try {
                const jobPostings = await base44.entities.JobPosting.filter({ id: candidate.job_posting_id });
                jobPosting = jobPostings[0] || null;
              } catch (e) {
                console.warn("Offre d'emploi non trouvée");
              }
            }

            const result = await convertCandidateToEmployee(candidate, jobPosting);

            if (result.alreadyExists) {
              toast({
                title: "ℹ️ Employé existant",
                description: `${candidate.full_name} existe déjà dans la liste du personnel.`,
              });
            } else {
              toast({
                title: "✅ Employé créé !",
                description: `${candidate.full_name} a été ajouté au personnel. Workflow d'onboarding déclenché.`,
              });
              
              // Invalider le cache des employés
              queryClient.invalidateQueries({ queryKey: ['employees'] });
            }
          } catch (e) {
            console.error("Erreur conversion candidat->employé:", e);
            toast({
              title: "⚠️ Erreur",
              description: "Impossible de créer le profil employé. Veuillez réessayer.",
              variant: "destructive",
            });
          }
        }
      }
    },
  });

  const sendStatusNotification = async (candidate, newStatus, stageLabel) => {
    // Créer une notification interne
    try {
      await base44.entities.Notification.create({
        type: 'candidate_status_change',
        title: `Candidat passé à "${stageLabel}"`,
        message: `${candidate.full_name} pour le poste ${candidate.job_title || 'non défini'} est maintenant en statut "${stageLabel}"`,
        priority: newStatus === 'hired' ? 'high' : 'medium',
        is_read: false,
        related_entity: 'Candidate',
        related_entity_id: candidate.id,
      });
    } catch (e) {
      // L'entité Notification n'existe peut-être pas
    }
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const { source, destination, draggableId, type } = result;

    // Réorganisation des colonnes
    if (type === 'COLUMN') {
      const newStages = Array.from(stages);
      const [removed] = newStages.splice(source.index, 1);
      newStages.splice(destination.index, 0, removed);
      setStages(newStages);
      return;
    }

    // Déplacement de candidat
    const candidateId = draggableId;
    const newStatus = destination.droppableId;
    const previousStatus = source.droppableId;

    if (newStatus === previousStatus) return;

    if (onCandidateUpdate) {
      onCandidateUpdate(candidateId, { status: newStatus });
    } else {
      updateMutation.mutate({ id: candidateId, data: { status: newStatus }, previousStatus });
    }
  };

  const getCandidatesByStage = (stageId) => {
    return candidates.filter(c => c.status === stageId);
  };

  const toggleStageCollapse = (stageId) => {
    setCollapsedStages(prev => ({
      ...prev,
      [stageId]: !prev[stageId]
    }));
  };

  const toggleStageVisibility = (stageId) => {
    setStages(prev => prev.map(s => 
      s.id === stageId ? { ...s, visible: !s.visible } : s
    ));
  };

  const updateStageLabel = (stageId, newLabel) => {
    setStages(prev => prev.map(s => 
      s.id === stageId ? { ...s, label: newLabel } : s
    ));
    setEditingStage(null);
  };

  const updateStageColor = (stageId, colorOption) => {
    setStages(prev => prev.map(s => 
      s.id === stageId ? { ...s, ...colorOption } : s
    ));
  };

  const addCustomStage = () => {
    if (!newStageName.trim()) return;
    
    const newId = `custom_${Date.now()}`;
    const newStage = {
      id: newId,
      label: newStageName.trim(),
      color: 'bg-gray-500',
      textColor: 'text-gray-700',
      bgLight: 'bg-gray-50',
      visible: true,
      isCustom: true,
    };
    
    // Insérer avant 'hired' et 'rejected'
    const insertIndex = stages.findIndex(s => s.id === 'hired');
    const newStages = [...stages];
    newStages.splice(insertIndex > -1 ? insertIndex : stages.length, 0, newStage);
    setStages(newStages);
    setNewStageName("");
    
    toast({ title: "Étape ajoutée", description: `L'étape "${newStageName}" a été créée` });
  };

  const removeCustomStage = (stageId) => {
    const stage = stages.find(s => s.id === stageId);
    if (!stage?.isCustom) return;
    
    // Déplacer les candidats vers 'new'
    const candidatesInStage = getCandidatesByStage(stageId);
    candidatesInStage.forEach(c => {
      if (onCandidateUpdate) {
        onCandidateUpdate(c.id, { status: 'new' });
      } else {
        updateMutation.mutate({ id: c.id, data: { status: 'new' }, previousStatus: stageId });
      }
    });
    
    setStages(prev => prev.filter(s => s.id !== stageId));
    toast({ title: "Étape supprimée" });
  };

  const resetToDefault = () => {
    setStages(defaultStages);
    localStorage.removeItem('recruitment_pipeline_stages');
    toast({ title: "Pipeline réinitialisé" });
  };

  const visibleStages = stages.filter(s => s.visible);
  const totalCandidates = candidates.length;

  return (
    <>
      {/* Header avec stats et paramètres */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Pipeline de recrutement</h2>
          <p className="text-sm text-slate-600">
            {totalCandidates} candidat(s) • {visibleStages.length} étapes affichées
          </p>
        </div>
        <Button variant="outline" onClick={() => setShowSettings(true)}>
          <Settings className="w-4 h-4 mr-2" />
          Personnaliser
        </Button>
      </div>

      {/* Pipeline */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="pipeline-columns" direction="horizontal" type="COLUMN">
          {(provided) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className="flex gap-4 overflow-x-auto pb-4"
              style={{ minHeight: '500px' }}
            >
              {visibleStages.map((stage, columnIndex) => {
                const stageCandidates = getCandidatesByStage(stage.id);
                const isCollapsed = collapsedStages[stage.id];
                
                return (
                  <Draggable key={stage.id} draggableId={`column-${stage.id}`} index={columnIndex}>
                    {(columnProvided, columnSnapshot) => (
                      <div
                        ref={columnProvided.innerRef}
                        {...columnProvided.draggableProps}
                        className={`flex-shrink-0 w-72 ${columnSnapshot.isDragging ? 'opacity-80' : ''}`}
                      >
                        <Droppable droppableId={stage.id} type="CANDIDATE">
                          {(provided, snapshot) => (
                            <Card 
                              className={`border-none shadow-lg h-full ${snapshot.isDraggingOver ? `ring-2 ring-blue-400 ${stage.bgLight}` : ''}`}
                            >
                              <CardHeader 
                                {...columnProvided.dragHandleProps}
                                className={`pb-3 cursor-grab active:cursor-grabbing ${stage.bgLight} rounded-t-lg`}
                              >
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className={`w-3 h-3 rounded-full ${stage.color}`} />
                                    <CardTitle className={`text-base ${stage.textColor}`}>
                                      {stage.label}
                                    </CardTitle>
                                  </div>
                                  <div className="flex items-center gap-1">
                                    <Badge variant="secondary" className={stage.bgLight}>
                                      {stageCandidates.length}
                                    </Badge>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="h-6 w-6 p-0"
                                      onClick={() => toggleStageCollapse(stage.id)}
                                    >
                                      {isCollapsed ? (
                                        <ChevronDown className="w-4 h-4" />
                                      ) : (
                                        <ChevronUp className="w-4 h-4" />
                                      )}
                                    </Button>
                                  </div>
                                </div>
                              </CardHeader>
                              
                              {!isCollapsed && (
                                <CardContent
                                  ref={provided.innerRef}
                                  {...provided.droppableProps}
                                  className="space-y-3 min-h-[350px] max-h-[500px] overflow-y-auto"
                                >
                                  {stageCandidates.map((candidate, index) => (
                                    <Draggable
                                      key={candidate.id}
                                      draggableId={candidate.id}
                                      index={index}
                                    >
                                      {(provided, snapshot) => (
                                        <div
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          {...provided.dragHandleProps}
                                          className={`p-4 bg-white rounded-lg border border-slate-200 cursor-grab active:cursor-grabbing hover:shadow-md transition-all ${
                                            snapshot.isDragging ? 'shadow-lg ring-2 ring-blue-400 rotate-2' : ''
                                          }`}
                                          onClick={() => setSelectedCandidate(candidate)}
                                        >
                                          <div className="flex items-start gap-3">
                                            <div className={`w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0`}>
                                              <span className="text-white font-semibold text-sm">
                                                {candidate.full_name?.charAt(0) || 'C'}
                                              </span>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                              <h4 className="font-semibold text-slate-900 truncate">
                                                {candidate.full_name}
                                              </h4>
                                              <p className="text-xs text-blue-600 truncate">
                                                {candidate.job_title || "Poste non défini"}
                                              </p>
                                              {candidate.rating && (
                                                <div className="flex items-center gap-1 mt-1">
                                                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                                  <span className="text-xs font-medium text-slate-700">
                                                    {candidate.rating}/5
                                                  </span>
                                                </div>
                                              )}
                                              {candidate.overall_score && (
                                                <div className="mt-2">
                                                  <div className="flex items-center justify-between text-xs text-slate-600 mb-1">
                                                    <span>Score</span>
                                                    <span className="font-semibold">{candidate.overall_score}%</span>
                                                  </div>
                                                  <div className="h-1.5 bg-slate-200 rounded-full overflow-hidden">
                                                    <div 
                                                      className={`h-full ${stage.color} rounded-full transition-all`}
                                                      style={{ width: `${candidate.overall_score}%` }}
                                                    />
                                                  </div>
                                                </div>
                                              )}
                                            </div>
                                          </div>
                                          <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
                                            <Mail className="w-3 h-3" />
                                            <span className="truncate">{candidate.email}</span>
                                          </div>
                                        </div>
                                      )}
                                    </Draggable>
                                  ))}
                                  {provided.placeholder}
                                  {stageCandidates.length === 0 && (
                                    <div className="text-center py-8 text-slate-400 text-sm border-2 border-dashed border-slate-200 rounded-lg">
                                      <GripVertical className="w-6 h-6 mx-auto mb-2 opacity-50" />
                                      Glissez un candidat ici
                                    </div>
                                  )}
                                </CardContent>
                              )}
                            </Card>
                          )}
                        </Droppable>
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {/* Modal de personnalisation */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-blue-600" />
              Personnaliser le pipeline
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Ajouter une étape */}
            <div className="p-4 bg-slate-50 rounded-lg">
              <h3 className="font-semibold text-slate-900 mb-3">Ajouter une étape personnalisée</h3>
              <div className="flex gap-2">
                <Input
                  placeholder="Nom de l'étape..."
                  value={newStageName}
                  onChange={(e) => setNewStageName(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addCustomStage()}
                />
                <Button onClick={addCustomStage} disabled={!newStageName.trim()}>
                  <Plus className="w-4 h-4 mr-1" />
                  Ajouter
                </Button>
              </div>
            </div>

            {/* Liste des étapes */}
            <div className="space-y-2">
              <h3 className="font-semibold text-slate-900">Étapes du pipeline</h3>
              <p className="text-sm text-slate-500 mb-3">
                Réorganisez, renommez ou masquez les étapes
              </p>
              
              {stages.map((stage, index) => (
                <div 
                  key={stage.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border ${stage.visible ? 'bg-white' : 'bg-slate-100 opacity-60'}`}
                >
                  <GripVertical className="w-4 h-4 text-slate-400" />
                  
                  <div className={`w-4 h-4 rounded-full ${stage.color}`} />
                  
                  {editingStage === stage.id ? (
                    <Input
                      value={stage.label}
                      onChange={(e) => setStages(prev => prev.map(s => 
                        s.id === stage.id ? { ...s, label: e.target.value } : s
                      ))}
                      onBlur={() => setEditingStage(null)}
                      onKeyPress={(e) => e.key === 'Enter' && setEditingStage(null)}
                      className="flex-1 h-8"
                      autoFocus
                    />
                  ) : (
                    <span 
                      className="flex-1 font-medium cursor-pointer hover:text-blue-600"
                      onClick={() => setEditingStage(stage.id)}
                    >
                      {stage.label}
                    </span>
                  )}

                  <Badge variant="outline" className="text-xs">
                    {getCandidatesByStage(stage.id).length}
                  </Badge>

                  {/* Sélecteur de couleur */}
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <div className={`w-4 h-4 rounded-full ${stage.color}`} />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-2">
                      <div className="grid grid-cols-5 gap-1">
                        {colorOptions.map((opt) => (
                          <button
                            key={opt.color}
                            onClick={() => updateStageColor(stage.id, opt)}
                            className={`w-6 h-6 rounded-full ${opt.color} hover:ring-2 ring-offset-1 ring-blue-400 transition-all`}
                          />
                        ))}
                      </div>
                    </PopoverContent>
                  </Popover>

                  {/* Visibilité */}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={() => toggleStageVisibility(stage.id)}
                  >
                    {stage.visible ? (
                      <Eye className="w-4 h-4 text-slate-600" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-slate-400" />
                    )}
                  </Button>

                  {/* Supprimer (seulement pour les étapes personnalisées) */}
                  {stage.isCustom && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 w-8 p-0 text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => removeCustomStage(stage.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex justify-between pt-4 border-t">
              <Button variant="outline" onClick={resetToDefault}>
                Réinitialiser par défaut
              </Button>
              <Button onClick={() => setShowSettings(false)} className="bg-blue-600 hover:bg-blue-700">
                <Check className="w-4 h-4 mr-1" />
                Terminé
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {selectedCandidate && (
        <CandidateDetailsModal
          candidate={selectedCandidate}
          onClose={() => setSelectedCandidate(null)}
        />
      )}
    </>
  );
}