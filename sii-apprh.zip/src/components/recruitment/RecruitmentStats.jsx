import React, { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Clock, TrendingUp, Award, Calendar, CheckCircle, ArrowRight, Briefcase, User } from "lucide-react";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, FunnelChart, Funnel, LabelList,
  Legend, AreaChart, Area, ComposedChart
} from "recharts";
import { differenceInDays, startOfMonth, endOfMonth, eachMonthOfInterval, startOfYear, endOfYear, isSameMonth, format } from "date-fns";
import { fr } from "date-fns/locale";

const COLORS = ['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981', '#22c55e', '#ef4444'];
const PIPELINE_COLORS = {
  new: '#3b82f6',
  screening: '#8b5cf6',
  interview: '#f59e0b',
  offer: '#10b981',
  hired: '#22c55e',
  rejected: '#ef4444',
};

export default function RecruitmentStats({ candidates = [], jobPostings = [], interviews = [] }) {
  // Assurer que les tableaux sont toujours définis
  const safeCandidates = candidates || [];
  const safeJobPostings = jobPostings || [];
  const safeInterviews = interviews || [];
  const [selectedJob, setSelectedJob] = useState("all");
  const [timeRange, setTimeRange] = useState("year");

  // Filtrer les candidats par poste si sélectionné
  const filteredCandidates = useMemo(() => {
    if (selectedJob === "all") return safeCandidates;
    return safeCandidates.filter(c => c.job_posting_id === selectedJob);
  }, [safeCandidates, selectedJob]);

  // Statistiques globales
  const totalCandidates = filteredCandidates.length;
  const hiredCandidates = filteredCandidates.filter(c => c.status === 'hired').length;
  const rejectedCandidates = filteredCandidates.filter(c => c.status === 'rejected').length;
  const activeCandidates = totalCandidates - hiredCandidates - rejectedCandidates;

  const conversionRate = totalCandidates > 0 
    ? Math.round((hiredCandidates / totalCandidates) * 100) 
    : 0;

  // Temps moyen de recrutement
  const hiredWithDates = filteredCandidates.filter(c => 
    c.status === 'hired' && c.application_date && c.updated_date
  );
  const avgRecruitmentTime = hiredWithDates.length > 0
    ? Math.round(
        hiredWithDates.reduce((sum, c) => 
          sum + differenceInDays(new Date(c.updated_date), new Date(c.application_date)), 0
        ) / hiredWithDates.length
      )
    : 0;

  // 1. TAUX DE CONVERSION PAR ÉTAPE DU PIPELINE (Funnel)
  const pipelineConversion = useMemo(() => {
    const stages = ['new', 'screening', 'interview', 'offer', 'hired'];
    const stageLabels = {
      new: 'Nouveaux',
      screening: 'Présélection',
      interview: 'Entretien',
      offer: 'Offre',
      hired: 'Embauchés'
    };

    // Compter les candidats qui ont atteint ou dépassé chaque étape
    const stageCounts = stages.map(stage => {
      const stageIndex = stages.indexOf(stage);
      // Candidats actuellement à cette étape ou qui l'ont dépassée
      const count = filteredCandidates.filter(c => {
        const candidateStageIndex = stages.indexOf(c.status);
        // Inclure aussi les rejetés qui étaient à cette étape ou après
        if (c.status === 'rejected') {
          // On estime qu'ils étaient au moins à 'new'
          return stageIndex === 0;
        }
        return candidateStageIndex >= stageIndex;
      }).length;
      
      return count;
    });

    // Pour un funnel plus réaliste, on utilise le nombre de candidats par étape actuelle
    const currentStageCounts = stages.map(stage => 
      filteredCandidates.filter(c => c.status === stage).length
    );

    // Calculer le funnel cumulatif (combien ont passé chaque étape)
    let cumulativeCount = totalCandidates;
    
    return stages.map((stage, index) => {
      const currentCount = currentStageCounts[index];
      const passedCount = stages.slice(index).reduce((sum, s) => 
        sum + filteredCandidates.filter(c => c.status === s).length, 0
      );
      
      const conversionFromPrevious = index === 0 
        ? 100 
        : (stageCounts[index - 1] > 0 
            ? Math.round((passedCount / totalCandidates) * 100) 
            : 0);

      return {
        stage: stageLabels[stage],
        stageId: stage,
        count: passedCount,
        current: currentCount,
        conversionRate: totalCandidates > 0 ? Math.round((passedCount / totalCandidates) * 100) : 0,
        fill: PIPELINE_COLORS[stage],
      };
    });
  }, [filteredCandidates, totalCandidates]);

  // 2. DISTRIBUTION DES CANDIDATURES PAR POSTE
  const candidatesByJob = useMemo(() => {
    return safeJobPostings.map(job => {
      const jobCandidates = safeCandidates.filter(c => c.job_posting_id === job.id);
      const hired = jobCandidates.filter(c => c.status === 'hired').length;
      const inProgress = jobCandidates.filter(c => !['hired', 'rejected'].includes(c.status)).length;
      const rejected = jobCandidates.filter(c => c.status === 'rejected').length;
      
      return {
        id: job.id,
        name: job.title.length > 15 ? job.title.substring(0, 15) + '...' : job.title,
        fullName: job.title,
        total: jobCandidates.length,
        hired,
        inProgress,
        rejected,
        conversionRate: jobCandidates.length > 0 ? Math.round((hired / jobCandidates.length) * 100) : 0,
      };
    }).sort((a, b) => b.total - a.total);
  }, [safeCandidates, safeJobPostings]);

  // 3. PERFORMANCE DES RECRUTEURS
  const recruiterPerformance = useMemo(() => {
    // Grouper les entretiens par interviewer
    const interviewerStats = {};
    
    safeInterviews.forEach(interview => {
      const email = interview.interviewer_email;
      const name = interview.interviewer_name || email?.split('@')[0] || 'Inconnu';
      
      if (!email) return;
      
      if (!interviewerStats[email]) {
        interviewerStats[email] = {
          name,
          email,
          totalInterviews: 0,
          completedInterviews: 0,
          hiredCandidates: 0,
          avgRating: 0,
          ratings: [],
        };
      }
      
      interviewerStats[email].totalInterviews++;
      
      if (interview.status === 'completed') {
        interviewerStats[email].completedInterviews++;
        if (interview.rating) {
          interviewerStats[email].ratings.push(interview.rating);
        }
      }
    });

    // Calculer les embauches par recruteur
    safeCandidates.filter(c => c.status === 'hired').forEach(candidate => {
      const candidateInterviews = safeInterviews.filter(i => i.candidate_id === candidate.id);
      candidateInterviews.forEach(interview => {
        if (interviewerStats[interview.interviewer_email]) {
          interviewerStats[interview.interviewer_email].hiredCandidates++;
        }
      });
    });

    // Calculer les moyennes
    return Object.values(interviewerStats).map(recruiter => ({
      ...recruiter,
      avgRating: recruiter.ratings.length > 0 
        ? Math.round((recruiter.ratings.reduce((a, b) => a + b, 0) / recruiter.ratings.length) * 10) / 10
        : 0,
      successRate: recruiter.totalInterviews > 0 
        ? Math.round((recruiter.hiredCandidates / recruiter.totalInterviews) * 100)
        : 0,
    })).sort((a, b) => b.totalInterviews - a.totalInterviews);
  }, [safeInterviews, safeCandidates]);

  // 4. TEMPS MOYEN DE RECRUTEMENT PAR POSTE
  const recruitmentTimeByJob = useMemo(() => {
    return safeJobPostings.map(job => {
      const jobHired = safeCandidates.filter(c => 
        c.job_posting_id === job.id && 
        c.status === 'hired' && 
        c.application_date && 
        c.updated_date
      );
      
      const avgTime = jobHired.length > 0
        ? Math.round(
            jobHired.reduce((sum, c) => 
              sum + differenceInDays(new Date(c.updated_date), new Date(c.application_date)), 0
            ) / jobHired.length
          )
        : 0;
      
      // Temps par étape (estimation basée sur les candidats actuels)
      const jobCandidates = safeCandidates.filter(c => c.job_posting_id === job.id);
      
      return {
        id: job.id,
        name: job.title.length > 15 ? job.title.substring(0, 15) + '...' : job.title,
        fullName: job.title,
        avgDays: avgTime,
        hiredCount: jobHired.length,
        totalCandidates: jobCandidates.length,
      };
    }).filter(j => j.hiredCount > 0 || j.totalCandidates > 0)
      .sort((a, b) => b.avgDays - a.avgDays);
  }, [safeCandidates, safeJobPostings]);

  // Distribution par statut (pour le pie chart)
  const statusDistribution = [
    { name: 'Nouveaux', value: filteredCandidates.filter(c => c.status === 'new').length, fill: PIPELINE_COLORS.new },
    { name: 'Présélection', value: filteredCandidates.filter(c => c.status === 'screening').length, fill: PIPELINE_COLORS.screening },
    { name: 'Entretien', value: filteredCandidates.filter(c => c.status === 'interview').length, fill: PIPELINE_COLORS.interview },
    { name: 'Offre', value: filteredCandidates.filter(c => c.status === 'offer').length, fill: PIPELINE_COLORS.offer },
    { name: 'Embauchés', value: hiredCandidates, fill: PIPELINE_COLORS.hired },
    { name: 'Rejetés', value: rejectedCandidates, fill: PIPELINE_COLORS.rejected },
  ];

  // Tendances mensuelles
  const currentYear = new Date().getFullYear();
  const yearStart = startOfYear(new Date());
  const yearEnd = endOfYear(new Date());
  const months = eachMonthOfInterval({ start: yearStart, end: yearEnd });

  const monthlyTrends = months.map(month => {
    const monthCandidates = safeCandidates.filter(c => 
      isSameMonth(new Date(c.application_date || c.created_date), month)
    );
    const monthHired = safeCandidates.filter(c => 
      c.status === 'hired' && c.updated_date && isSameMonth(new Date(c.updated_date), month)
    );
    const monthInterviews = safeInterviews.filter(i =>
      isSameMonth(new Date(i.interview_date), month)
    );
    
    return {
      month: format(month, 'MMM', { locale: fr }),
      candidatures: monthCandidates.length,
      embauches: monthHired.length,
      entretiens: monthInterviews.length,
    };
  });

  // Entretiens ce mois
  const monthStart = startOfMonth(new Date());
  const monthEnd = endOfMonth(new Date());
  const monthInterviewsCount = safeInterviews.filter(i => {
    const date = new Date(i.interview_date);
    return date >= monthStart && date <= monthEnd;
  }).length;

  // Custom tooltip pour les graphiques
  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 rounded-lg shadow-lg border">
          <p className="font-semibold text-slate-900">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Filtres */}
      <div className="flex flex-wrap gap-4">
        <Select value={selectedJob} onValueChange={setSelectedJob}>
          <SelectTrigger className="w-[200px]">
            <Briefcase className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Tous les postes" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les postes</SelectItem>
            {safeJobPostings.map(job => (
              <SelectItem key={job.id} value={job.id}>{job.title}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Statistiques principales */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Total candidats</p>
                <p className="text-3xl font-bold text-slate-900">{totalCandidates}</p>
                <p className="text-xs text-slate-500 mt-1">{activeCandidates} en cours</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Taux de conversion</p>
                <p className="text-3xl font-bold text-green-600">{conversionRate}%</p>
                <p className="text-xs text-slate-500 mt-1">{hiredCandidates} embauchés</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Temps moyen</p>
                <p className="text-3xl font-bold text-purple-600">{avgRecruitmentTime}j</p>
                <p className="text-xs text-slate-500 mt-1">pour recruter</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                <Clock className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">Entretiens ce mois</p>
                <p className="text-3xl font-bold text-orange-600">{monthInterviewsCount}</p>
                <p className="text-xs text-slate-500 mt-1">planifiés</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Onglets pour les graphiques détaillés */}
      <Tabs defaultValue="pipeline" className="w-full">
        <TabsList className="bg-white shadow mb-4">
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="jobs">Par poste</TabsTrigger>
          <TabsTrigger value="recruiters">Recruteurs</TabsTrigger>
          <TabsTrigger value="time">Temps</TabsTrigger>
          <TabsTrigger value="trends">Tendances</TabsTrigger>
        </TabsList>

        {/* 1. TAUX DE CONVERSION PAR ÉTAPE */}
        <TabsContent value="pipeline">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  Taux de conversion par étape
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pipelineConversion.map((stage, index) => (
                    <div key={stage.stageId} className="relative">
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: stage.fill }}
                          />
                          <span className="font-medium text-slate-700">{stage.stage}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <Badge variant="outline">{stage.count} candidats</Badge>
                          <span className="font-bold" style={{ color: stage.fill }}>
                            {stage.conversionRate}%
                          </span>
                        </div>
                      </div>
                      <div className="h-8 bg-slate-100 rounded-lg overflow-hidden">
                        <div 
                          className="h-full rounded-lg transition-all duration-500 flex items-center justify-end pr-2"
                          style={{ 
                            width: `${stage.conversionRate}%`, 
                            backgroundColor: stage.fill,
                            minWidth: stage.count > 0 ? '40px' : '0'
                          }}
                        >
                          {stage.count > 0 && (
                            <span className="text-white text-xs font-semibold">
                              {stage.count}
                            </span>
                          )}
                        </div>
                      </div>
                      {index < pipelineConversion.length - 1 && (
                        <div className="flex justify-center my-1">
                          <ArrowRight className="w-4 h-4 text-slate-300 rotate-90" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Distribution des candidats</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={statusDistribution.filter(s => s.value > 0)}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={100}
                      paddingAngle={2}
                      dataKey="value"
                    >
                      {statusDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* 2. DISTRIBUTION PAR POSTE */}
        <TabsContent value="jobs">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-purple-600" />
                  Candidatures par poste
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={350}>
                  <BarChart data={candidatesByJob.slice(0, 8)} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="inProgress" stackId="a" fill="#3b82f6" name="En cours" />
                    <Bar dataKey="hired" stackId="a" fill="#22c55e" name="Embauchés" />
                    <Bar dataKey="rejected" stackId="a" fill="#ef4444" name="Rejetés" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Taux de conversion par poste</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[350px] overflow-y-auto">
                  {candidatesByJob.map(job => (
                    <div key={job.id} className="p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-slate-800 truncate flex-1" title={job.fullName}>
                          {job.fullName}
                        </span>
                        <Badge className={job.conversionRate >= 20 ? 'bg-green-600' : job.conversionRate >= 10 ? 'bg-yellow-600' : 'bg-red-600'}>
                          {job.conversionRate}%
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-slate-600">
                        <span>{job.total} candidats</span>
                        <span className="text-green-600">{job.hired} embauchés</span>
                        <span className="text-blue-600">{job.inProgress} en cours</span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full mt-2 overflow-hidden">
                        <div 
                          className="h-full bg-green-500 rounded-full"
                          style={{ width: `${job.conversionRate}%` }}
                        />
                      </div>
                    </div>
                  ))}
                  {candidatesByJob.length === 0 && (
                    <p className="text-center text-slate-500 py-8">Aucune donnée disponible</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* 3. PERFORMANCE DES RECRUTEURS */}
        <TabsContent value="recruiters">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5 text-indigo-600" />
                  Performance des recruteurs
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recruiterPerformance.length > 0 ? (
                  <ResponsiveContainer width="100%" height={350}>
                    <BarChart data={recruiterPerformance.slice(0, 6)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend />
                      <Bar dataKey="totalInterviews" fill="#8b5cf6" name="Entretiens" />
                      <Bar dataKey="hiredCandidates" fill="#22c55e" name="Embauches" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-center py-12 text-slate-500">
                    <User className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>Aucune donnée de recruteur disponible</p>
                    <p className="text-sm">Les statistiques apparaîtront après les premiers entretiens</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Classement des recruteurs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-[350px] overflow-y-auto">
                  {recruiterPerformance.map((recruiter, index) => (
                    <div key={recruiter.email} className="flex items-center gap-4 p-3 bg-slate-50 rounded-lg">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                        index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-slate-400' : index === 2 ? 'bg-amber-600' : 'bg-slate-300'
                      }`}>
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-slate-900">{recruiter.name}</p>
                        <div className="flex gap-3 text-xs text-slate-600">
                          <span>{recruiter.totalInterviews} entretiens</span>
                          <span className="text-green-600">{recruiter.hiredCandidates} embauches</span>
                          {recruiter.avgRating > 0 && (
                            <span className="text-yellow-600">⭐ {recruiter.avgRating}/5</span>
                          )}
                        </div>
                      </div>
                      <Badge variant="outline" className={recruiter.successRate >= 30 ? 'bg-green-50 text-green-700' : ''}>
                        {recruiter.successRate}% succès
                      </Badge>
                    </div>
                  ))}
                  {recruiterPerformance.length === 0 && (
                    <p className="text-center text-slate-500 py-8">Aucun recruteur avec des entretiens</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* 4. TEMPS DE RECRUTEMENT */}
        <TabsContent value="time">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-orange-600" />
                  Temps moyen de recrutement par poste
                </CardTitle>
              </CardHeader>
              <CardContent>
                {recruitmentTimeByJob.filter(j => j.avgDays > 0).length > 0 ? (
                  <ResponsiveContainer width="100%" height={350}>
                    <BarChart data={recruitmentTimeByJob.filter(j => j.avgDays > 0).slice(0, 8)} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" unit=" j" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip 
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload;
                            return (
                              <div className="bg-white p-3 rounded-lg shadow-lg border">
                                <p className="font-semibold">{data.fullName}</p>
                                <p className="text-orange-600">{data.avgDays} jours en moyenne</p>
                                <p className="text-sm text-slate-600">{data.hiredCount} embauches</p>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="avgDays" fill="#f59e0b" name="Jours" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-center py-12 text-slate-500">
                    <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>Pas assez de données</p>
                    <p className="text-sm">Les statistiques apparaîtront après les premières embauches</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader>
                <CardTitle>Analyse du temps</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-orange-900">Temps moyen global</span>
                      <span className="text-2xl font-bold text-orange-600">{avgRecruitmentTime} jours</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {recruitmentTimeByJob.filter(j => j.avgDays > 0).slice(0, 5).map(job => (
                      <div key={job.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                        <span className="font-medium text-slate-800 truncate flex-1" title={job.fullName}>
                          {job.name}
                        </span>
                        <div className="flex items-center gap-2">
                          <Badge 
                            variant="outline" 
                            className={job.avgDays <= 30 ? 'bg-green-50 text-green-700' : job.avgDays <= 60 ? 'bg-yellow-50 text-yellow-700' : 'bg-red-50 text-red-700'}
                          >
                            {job.avgDays}j
                          </Badge>
                          <span className="text-xs text-slate-500">({job.hiredCount} embauches)</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {avgRecruitmentTime > 45 && (
                    <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <p className="text-sm text-yellow-800">
                        ⚠️ Le temps moyen de {avgRecruitmentTime} jours est supérieur à la moyenne recommandée (45 jours).
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* 5. TENDANCES */}
        <TabsContent value="trends">
          <Card className="border-none shadow-lg">
            <CardHeader>
              <CardTitle>Tendances {currentYear}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ComposedChart data={monthlyTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="candidatures" 
                    fill="#3b82f6" 
                    fillOpacity={0.2}
                    stroke="#3b82f6"
                    strokeWidth={2}
                    name="Candidatures"
                  />
                  <Bar dataKey="entretiens" fill="#8b5cf6" name="Entretiens" />
                  <Line 
                    type="monotone" 
                    dataKey="embauches" 
                    stroke="#22c55e" 
                    strokeWidth={3}
                    dot={{ fill: '#22c55e', r: 4 }}
                    name="Embauches"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Insights */}
      <Card className="border-none shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-purple-600" />
            Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {conversionRate < 10 && totalCandidates > 10 && (
            <p className="text-sm text-slate-700 p-2 bg-white/50 rounded">
              ⚠️ Votre taux de conversion ({conversionRate}%) est faible. Revoyez vos critères de sélection ou le processus d'entretien.
            </p>
          )}
          
          {avgRecruitmentTime > 45 && (
            <p className="text-sm text-slate-700 p-2 bg-white/50 rounded">
              ⏰ Le temps moyen de recrutement ({avgRecruitmentTime} jours) est élevé. Optimisez votre processus pour réduire les délais.
            </p>
          )}

          {safeCandidates.filter(c => c.status === 'new').length > 10 && (
            <p className="text-sm text-slate-700 p-2 bg-white/50 rounded">
              📊 Vous avez {safeCandidates.filter(c => c.status === 'new').length} nouveaux candidats en attente. Priorisez leur présélection.
            </p>
          )}

          {conversionRate >= 15 && totalCandidates > 20 && (
            <p className="text-sm text-slate-700 p-2 bg-white/50 rounded">
              ✅ Excellent taux de conversion ! Votre processus de recrutement est efficace.
            </p>
          )}

          {recruiterPerformance.length > 0 && recruiterPerformance[0].successRate >= 30 && (
            <p className="text-sm text-slate-700 p-2 bg-white/50 rounded">
              🏆 {recruiterPerformance[0].name} est votre meilleur recruteur avec un taux de succès de {recruiterPerformance[0].successRate}%.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}