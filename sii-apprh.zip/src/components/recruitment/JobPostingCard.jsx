import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Users, Calendar, Edit, ClipboardList, AlertCircle } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  draft: "bg-gray-100 text-gray-800",
  active: "bg-green-100 text-green-800",
  closed: "bg-red-100 text-red-800",
};

const statusLabels = {
  draft: "Brouillon",
  active: "Active",
  closed: "Fermée",
};

const typeLabels = {
  full_time: "Temps plein",
  part_time: "Temps partiel",
  contract: "Contrat",
  intern: "Stage",
};

export default function JobPostingCard({ job, candidates, onEdit }) {
  const hasQuestions = job.interview_questions && job.interview_questions.length > 0;

  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <Badge className={statusColors[job.status]}>
                {statusLabels[job.status]}
              </Badge>
              <Badge variant="outline">{typeLabels[job.employment_type]}</Badge>
              {job.is_high_turnover && (
                <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Fort turnover
                </Badge>
              )}
              {hasQuestions && (
                <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                  <ClipboardList className="w-3 h-3 mr-1" />
                  {job.interview_questions.length} questions
                </Badge>
              )}
            </div>
            <CardTitle className="text-xl">{job.title}</CardTitle>
            <p className="text-sm text-slate-600 mt-1">{job.department}</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onEdit}>
            <Edit className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-center gap-4 text-sm text-slate-600">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>{job.location || 'Non spécifié'}</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            <span>{candidates.length} candidats</span>
          </div>
        </div>

        <p className="text-sm text-slate-700 line-clamp-3">{job.description}</p>

        {job.salary_range && (
          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
            <p className="text-sm font-medium text-green-800">
              Salaire: {job.salary_range}
            </p>
          </div>
        )}

        {hasQuestions && (
          <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
            <div className="flex items-center gap-2 mb-2">
              <ClipboardList className="w-4 h-4 text-purple-600" />
              <p className="text-sm font-medium text-purple-800">
                Questionnaire d'entretien prêt
              </p>
            </div>
            <p className="text-xs text-purple-700">
              {job.interview_questions.length} questions préparées pour cet entretien
            </p>
          </div>
        )}

        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Calendar className="w-3 h-3" />
          <span>Publié le {format(new Date(job.posted_date || job.created_date), 'dd/MM/yyyy')}</span>
        </div>
      </CardContent>
    </Card>
  );
}