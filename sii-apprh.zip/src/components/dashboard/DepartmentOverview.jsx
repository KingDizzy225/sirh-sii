
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function DepartmentOverview({ departments, employees }) {
  const departmentData = departments.map(dept => {
    const deptEmployees = employees.filter(e => e.department === dept.name && e.status === 'active');
    return {
      ...dept,
      count: deptEmployees.length
    };
  }).sort((a, b) => b.count - a.count).slice(0, 5);

  const colors = [
    "from-blue-500 to-blue-600",
    "from-green-500 to-green-600",
    "from-purple-500 to-purple-600",
    "from-orange-500 to-orange-600",
    "from-pink-500 to-pink-600",
  ];

  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">Départements</CardTitle>
          <Link to={createPageUrl("Departments")} className="text-sm text-blue-600 hover:text-blue-700 font-medium">
            Voir tout
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {departmentData.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Building2 className="w-12 h-12 mx-auto mb-3 text-slate-300" />
            <p>Aucun département pour le moment</p>
          </div>
        ) : (
          <div className="space-y-4">
            {departmentData.map((dept, index) => (
              <div key={dept.id} className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[index % colors.length]} flex items-center justify-center shadow-md`}>
                  <Building2 className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-slate-900">{dept.name}</p>
                  <div className="flex items-center gap-1 text-sm text-slate-600">
                    <Users className="w-3 h-3" />
                    <span>{dept.count} employés</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
