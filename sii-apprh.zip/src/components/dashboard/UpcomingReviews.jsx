
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Award, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function UpcomingReviews() {
  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">Actions rapides</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3">
          <Link
            to={createPageUrl("Employees")}
            className="block p-4 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 transition-all duration-200 border border-blue-200"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-600 flex items-center justify-center">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Ajouter un employé</p>
                <p className="text-xs text-slate-600">Intégrer un nouveau membre</p>
              </div>
            </div>
          </Link>

          <Link
            to={createPageUrl("LeaveManagement")}
            className="block p-4 rounded-xl bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 transition-all duration-200 border border-green-200"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-600 flex items-center justify-center">
                <Calendar className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Revoir les congés</p>
                <p className="text-xs text-slate-600">Approuver les demandes</p>
              </div>
            </div>
          </Link>

          <Link
            to={createPageUrl("Performance")}
            className="block p-4 rounded-xl bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 transition-all duration-200 border border-purple-200"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-600 flex items-center justify-center">
                <Award className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-semibold text-slate-900">Évaluation de performance</p>
                <p className="text-xs text-slate-600">Évaluer la performance</p>
              </div>
            </div>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
