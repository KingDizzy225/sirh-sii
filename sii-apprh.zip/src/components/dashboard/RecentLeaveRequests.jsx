
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, User } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const statusColors = {
  pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
  approved: "bg-green-100 text-green-800 border-green-200",
  rejected: "bg-red-100 text-red-800 border-red-200",
};

const statusLabels = {
  pending: "en attente",
  approved: "approuvé",
  rejected: "rejeté",
};

export default function RecentLeaveRequests({ requests }) {
  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-900">Demandes de congé récentes</CardTitle>
          <Link to={createPageUrl("LeaveManagement")} className="text-sm text-blue-600 hover:text-blue-700 font-medium">
            Voir tout
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-slate-100">
          {requests.length === 0 ? (
            <div className="p-8 text-center text-slate-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p>Aucune demande de congé pour le moment</p>
            </div>
          ) : (
            requests.map((request) => (
              <div key={request.id} className="p-4 hover:bg-slate-50 transition-colors">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-slate-900">{request.employee_name}</p>
                      <p className="text-sm text-slate-600 capitalize">{request.leave_type.replace('_', ' ')}</p>
                      <p className="text-xs text-slate-500 mt-1">
                        {format(new Date(request.start_date), 'dd MMM')} - {format(new Date(request.end_date), 'dd MMM yyyy')}
                      </p>
                    </div>
                  </div>
                  <Badge className={`${statusColors[request.status]} border`}>
                    {statusLabels[request.status]}
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
