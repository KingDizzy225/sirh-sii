
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format, subDays } from "date-fns";
import { fr } from 'date-fns/locale'; // Import the French locale

export default function AttendanceChart({ attendance }) {
  // Get last 7 days of attendance data
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayAttendance = attendance.filter(a => a.date === dateStr);
    
    return {
      // Use French locale for day names
      date: format(date, 'EEE', { locale: fr }), 
      present: dayAttendance.filter(a => a.status === 'present').length,
      late: dayAttendance.filter(a => a.status === 'late').length,
      absent: dayAttendance.filter(a => a.status === 'absent').length,
    };
  });

  return (
    <Card className="shadow-lg border-none">
      <CardHeader className="border-b border-slate-100">
        {/* Translated Card Title */}
        <CardTitle className="text-xl font-bold text-slate-900">Présence hebdomadaire</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={last7Days}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="date" stroke="#64748b" />
            <YAxis stroke="#64748b" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e2e8f0',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
              }} 
            />
            <Bar dataKey="present" fill="#10b981" radius={[8, 8, 0, 0]} />
            <Bar dataKey="late" fill="#f59e0b" radius={[8, 8, 0, 0]} />
            <Bar dataKey="absent" fill="#ef4444" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            {/* Translated legend text */}
            <span className="text-sm text-slate-600">Présent</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500" />
            {/* Translated legend text */}
            <span className="text-sm text-slate-600">En retard</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            {/* Translated legend text */}
            <span className="text-sm text-slate-600">Absent</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
