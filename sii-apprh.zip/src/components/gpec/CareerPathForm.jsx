import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, X } from "lucide-react";

export default function CareerPathForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    current_position: "",
    current_department: "",
    target_position: "",
    target_department: "",
    career_aspiration: "",
    estimated_timeline: "1-2 ans",
    readiness_level: "developing",
    required_skills: [],
    current_skills: [],
    skill_gaps: [],
    development_actions: [],
    mentor_email: "",
    mentor_name: "",
    status: "draft",
    progress_percentage: 0,
    notes: ""
  });

  const [newSkill, setNewSkill] = useState("");
  const [newAction, setNewAction] = useState({ action: "", type: "training", deadline: "" });

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    if (employee) {
      setFormData({
        ...formData,
        employee_email: email,
        employee_name: employee.full_name,
        current_position: employee.position,
        current_department: employee.department
      });
    }
  };

  const addSkill = (type) => {
    if (newSkill.trim()) {
      setFormData({
        ...formData,
        [type]: [...formData[type], newSkill.trim()]
      });
      setNewSkill("");
    }
  };

  const removeSkill = (type, index) => {
    setFormData({
      ...formData,
      [type]: formData[type].filter((_, i) => i !== index)
    });
  };

  const addAction = () => {
    if (newAction.action.trim()) {
      setFormData({
        ...formData,
        development_actions: [...formData.development_actions, { ...newAction, status: "planned" }]
      });
      setNewAction({ action: "", type: "training", deadline: "" });
    }
  };

  const removeAction = (index) => {
    setFormData({
      ...formData,
      development_actions: formData.development_actions.filter((_, i) => i !== index)
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calculer les skill gaps automatiquement
    const gaps = formData.required_skills.filter(
      skill => !formData.current_skills.includes(skill)
    );
    
    onSubmit({
      ...formData,
      skill_gaps: gaps
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Plan de développement de carrière</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employé */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Informations employé</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="employee">Employé *</Label>
                <Select
                  value={formData.employee_email}
                  onValueChange={handleEmployeeChange}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un employé" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.email}>
                        {emp.full_name} - {emp.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Poste actuel</Label>
                <Input value={formData.current_position} disabled />
              </div>

              <div className="space-y-2">
                <Label>Département actuel</Label>
                <Input value={formData.current_department} disabled />
              </div>
            </div>
          </div>

          {/* Objectif de carrière */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Objectif de carrière</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="target_position">Poste cible *</Label>
                <Input
                  id="target_position"
                  value={formData.target_position}
                  onChange={(e) => setFormData({...formData, target_position: e.target.value})}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="target_department">Département cible</Label>
                <Input
                  id="target_department"
                  value={formData.target_department}
                  onChange={(e) => setFormData({...formData, target_department: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="estimated_timeline">Délai estimé</Label>
                <Select
                  value={formData.estimated_timeline}
                  onValueChange={(value) => setFormData({...formData, estimated_timeline: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="6 mois - 1 an">6 mois - 1 an</SelectItem>
                    <SelectItem value="1-2 ans">1-2 ans</SelectItem>
                    <SelectItem value="3-5 ans">3-5 ans</SelectItem>
                    <SelectItem value="5+ ans">5+ ans</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="readiness_level">Niveau de préparation</Label>
                <Select
                  value={formData.readiness_level}
                  onValueChange={(value) => setFormData({...formData, readiness_level: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="not_ready">Pas encore prêt</SelectItem>
                    <SelectItem value="developing">En développement</SelectItem>
                    <SelectItem value="ready_soon">Bientôt prêt</SelectItem>
                    <SelectItem value="ready_now">Prêt maintenant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="career_aspiration">Aspirations de carrière</Label>
              <Textarea
                id="career_aspiration"
                value={formData.career_aspiration}
                onChange={(e) => setFormData({...formData, career_aspiration: e.target.value})}
                rows={3}
                placeholder="Décrivez les aspirations professionnelles de l'employé..."
              />
            </div>
          </div>

          {/* Compétences requises */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Compétences pour le poste cible</h3>
            <div className="space-y-2">
              <Label>Compétences requises</Label>
              <div className="flex gap-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Ajouter une compétence requise"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill('required_skills'))}
                />
                <Button type="button" onClick={() => addSkill('required_skills')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.required_skills.map((skill, index) => (
                  <Badge key={index} variant="outline" className="gap-2 bg-blue-50">
                    {skill}
                    <button type="button" onClick={() => removeSkill('required_skills', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Compétences actuelles</Label>
              <div className="flex gap-2">
                <Input
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  placeholder="Ajouter une compétence actuelle"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill('current_skills'))}
                />
                <Button type="button" onClick={() => addSkill('current_skills')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.current_skills.map((skill, index) => (
                  <Badge key={index} variant="outline" className="gap-2 bg-green-50">
                    {skill}
                    <button type="button" onClick={() => removeSkill('current_skills', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Actions de développement */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Actions de développement</h3>
            <div className="space-y-2">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <Input
                  placeholder="Action à réaliser"
                  value={newAction.action}
                  onChange={(e) => setNewAction({...newAction, action: e.target.value})}
                />
                <Select
                  value={newAction.type}
                  onValueChange={(value) => setNewAction({...newAction, type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="training">Formation</SelectItem>
                    <SelectItem value="mentoring">Mentorat</SelectItem>
                    <SelectItem value="project">Projet</SelectItem>
                    <SelectItem value="certification">Certification</SelectItem>
                    <SelectItem value="other">Autre</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Input
                    type="date"
                    value={newAction.deadline}
                    onChange={(e) => setNewAction({...newAction, deadline: e.target.value})}
                  />
                  <Button type="button" onClick={addAction}>
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2 mt-3">
                {formData.development_actions.map((action, index) => (
                  <div key={index} className="p-3 bg-slate-50 rounded-lg flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-slate-900">{action.action}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">{action.type}</Badge>
                        {action.deadline && (
                          <span className="text-xs text-slate-600">Échéance: {action.deadline}</span>
                        )}
                      </div>
                    </div>
                    <button type="button" onClick={() => removeAction(index)}>
                      <X className="w-4 h-4 text-slate-400 hover:text-red-600" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Mentor */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Accompagnement</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="mentor">Mentor</Label>
                <Select
                  value={formData.mentor_email}
                  onValueChange={(email) => {
                    const mentor = employees.find(e => e.email === email);
                    setFormData({
                      ...formData,
                      mentor_email: email,
                      mentor_name: mentor?.full_name || ""
                    });
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner un mentor (optionnel)" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.filter(e => e.email !== formData.employee_email).map(emp => (
                      <SelectItem key={emp.id} value={emp.email}>
                        {emp.full_name} - {emp.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Création...' : 'Créer le plan de carrière'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}