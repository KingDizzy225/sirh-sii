import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, X, AlertTriangle } from "lucide-react";

export default function SuccessionPlanForm({ employees, departments, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    position_title: "",
    department: "",
    current_holder_email: "",
    current_holder_name: "",
    is_critical_position: false,
    risk_level: "medium",
    retirement_date: "",
    successors: [],
    required_competencies: [],
    required_experience_years: 0,
    emergency_backup: { employee_email: "", employee_name: "" },
    development_plan: "",
    status: "active",
    notes: ""
  });

  const [newCompetency, setNewCompetency] = useState("");
  const [newSuccessor, setNewSuccessor] = useState({
    employee_email: "",
    employee_name: "",
    readiness: "needs_development",
    priority: 1,
    strengths: "",
    development_needs: ""
  });

  const handleCurrentHolderChange = (email) => {
    const employee = employees.find(e => e.email === email);
    if (employee) {
      setFormData({
        ...formData,
        current_holder_email: email,
        current_holder_name: employee.full_name,
        position_title: employee.position,
        department: employee.department
      });
    }
  };

  const addCompetency = () => {
    if (newCompetency.trim()) {
      setFormData({
        ...formData,
        required_competencies: [...formData.required_competencies, newCompetency.trim()]
      });
      setNewCompetency("");
    }
  };

  const removeCompetency = (index) => {
    setFormData({
      ...formData,
      required_competencies: formData.required_competencies.filter((_, i) => i !== index)
    });
  };

  const addSuccessor = () => {
    if (newSuccessor.employee_email) {
      setFormData({
        ...formData,
        successors: [...formData.successors, newSuccessor],
        internal_candidates_count: formData.successors.length + 1
      });
      setNewSuccessor({
        employee_email: "",
        employee_name: "",
        readiness: "needs_development",
        priority: formData.successors.length + 2,
        strengths: "",
        development_needs: ""
      });
    }
  };

  const removeSuccessor = (index) => {
    setFormData({
      ...formData,
      successors: formData.successors.filter((_, i) => i !== index),
      internal_candidates_count: formData.successors.length - 1
    });
  };

  const handleSuccessorEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    if (employee) {
      setNewSuccessor({
        ...newSuccessor,
        employee_email: email,
        employee_name: employee.full_name
      });
    }
  };

  const handleEmergencyBackupChange = (email) => {
    const employee = employees.find(e => e.email === email);
    if (employee) {
      setFormData({
        ...formData,
        emergency_backup: {
          employee_email: email,
          employee_name: employee.full_name
        }
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Plan de succession
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Poste */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Poste concerné</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="current_holder">Titulaire actuel</Label>
                <Select
                  value={formData.current_holder_email}
                  onValueChange={handleCurrentHolderChange}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner l'employé" />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map(emp => (
                      <SelectItem key={emp.id} value={emp.email}>
                        {emp.full_name} - {emp.position}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="position_title">Titre du poste *</Label>
                <Input
                  id="position_title"
                  value={formData.position_title}
                  onChange={(e) => setFormData({...formData, position_title: e.target.value})}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Département *</Label>
                <Select
                  value={formData.department}
                  onValueChange={(value) => setFormData({...formData, department: value})}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionner" />
                  </SelectTrigger>
                  <SelectContent>
                    {departments.map(dept => (
                      <SelectItem key={dept.id} value={dept.name}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="risk_level">Niveau de risque</Label>
                <Select
                  value={formData.risk_level}
                  onValueChange={(value) => setFormData({...formData, risk_level: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Faible</SelectItem>
                    <SelectItem value="medium">Moyen</SelectItem>
                    <SelectItem value="high">Élevé</SelectItem>
                    <SelectItem value="critical">Critique</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="retirement_date">Date de départ prévu</Label>
                <Input
                  id="retirement_date"
                  type="date"
                  value={formData.retirement_date}
                  onChange={(e) => setFormData({...formData, retirement_date: e.target.value})}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="required_experience_years">Années d'expérience requises</Label>
                <Input
                  id="required_experience_years"
                  type="number"
                  value={formData.required_experience_years}
                  onChange={(e) => setFormData({...formData, required_experience_years: parseInt(e.target.value)})}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_critical"
                checked={formData.is_critical_position}
                onCheckedChange={(checked) => setFormData({...formData, is_critical_position: checked})}
              />
              <Label htmlFor="is_critical" className="cursor-pointer">
                Poste critique pour l'organisation
              </Label>
            </div>
          </div>

          {/* Compétences requises */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Compétences clés requises</h3>
            <div className="flex gap-2">
              <Input
                value={newCompetency}
                onChange={(e) => setNewCompetency(e.target.value)}
                placeholder="Ajouter une compétence"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCompetency())}
              />
              <Button type="button" onClick={addCompetency}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.required_competencies.map((comp, index) => (
                <Badge key={index} variant="outline" className="gap-2">
                  {comp}
                  <button type="button" onClick={() => removeCompetency(index)}>
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Successeurs */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Successeurs potentiels</h3>
            
            {/* Formulaire nouveau successeur */}
            <div className="p-4 bg-slate-50 rounded-lg space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>Employé</Label>
                  <Select
                    value={newSuccessor.employee_email}
                    onValueChange={handleSuccessorEmployeeChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionner" />
                    </SelectTrigger>
                    <SelectContent>
                      {employees.filter(e => 
                        e.email !== formData.current_holder_email &&
                        !formData.successors.some(s => s.employee_email === e.email)
                      ).map(emp => (
                        <SelectItem key={emp.id} value={emp.email}>
                          {emp.full_name} - {emp.position}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Niveau de préparation</Label>
                  <Select
                    value={newSuccessor.readiness}
                    onValueChange={(value) => setNewSuccessor({...newSuccessor, readiness: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ready_now">Prêt maintenant</SelectItem>
                      <SelectItem value="ready_1_2_years">Prêt dans 1-2 ans</SelectItem>
                      <SelectItem value="ready_3_5_years">Prêt dans 3-5 ans</SelectItem>
                      <SelectItem value="needs_development">Nécessite développement</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label>Points forts</Label>
                  <Textarea
                    value={newSuccessor.strengths}
                    onChange={(e) => setNewSuccessor({...newSuccessor, strengths: e.target.value})}
                    rows={2}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label>Besoins de développement</Label>
                  <Textarea
                    value={newSuccessor.development_needs}
                    onChange={(e) => setNewSuccessor({...newSuccessor, development_needs: e.target.value})}
                    rows={2}
                  />
                </div>
              </div>

              <Button type="button" onClick={addSuccessor} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Ajouter ce successeur
              </Button>
            </div>

            {/* Liste des successeurs */}
            <div className="space-y-2">
              {formData.successors.map((successor, index) => (
                <div key={index} className="p-4 bg-white border-2 border-slate-200 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">Priorité {successor.priority}</Badge>
                        <Badge className={
                          successor.readiness === 'ready_now' ? 'bg-green-100 text-green-800' :
                          successor.readiness === 'ready_1_2_years' ? 'bg-blue-100 text-blue-800' :
                          successor.readiness === 'ready_3_5_years' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-orange-100 text-orange-800'
                        }>
                          {successor.readiness === 'ready_now' ? 'Prêt maintenant' :
                           successor.readiness === 'ready_1_2_years' ? '1-2 ans' :
                           successor.readiness === 'ready_3_5_years' ? '3-5 ans' :
                           'Développement nécessaire'}
                        </Badge>
                      </div>
                      <p className="font-semibold">{successor.employee_name}</p>
                      {successor.strengths && (
                        <p className="text-sm text-slate-600 mt-1">
                          <strong>Points forts:</strong> {successor.strengths}
                        </p>
                      )}
                    </div>
                    <button type="button" onClick={() => removeSuccessor(index)}>
                      <X className="w-4 h-4 text-slate-400 hover:text-red-600" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Backup d'urgence */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Remplaçant d'urgence</h3>
            <div className="space-y-2">
              <Label>Personne pouvant assurer l'intérim en cas d'urgence</Label>
              <Select
                value={formData.emergency_backup.employee_email}
                onValueChange={handleEmergencyBackupChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner (optionnel)" />
                </SelectTrigger>
                <SelectContent>
                  {employees.filter(e => e.email !== formData.current_holder_email).map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Plan de développement */}
          <div className="space-y-2">
            <Label htmlFor="development_plan">Plan de développement pour les successeurs</Label>
            <Textarea
              id="development_plan"
              value={formData.development_plan}
              onChange={(e) => setFormData({...formData, development_plan: e.target.value})}
              rows={4}
              placeholder="Décrivez les actions à mettre en place pour préparer les successeurs..."
            />
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={2}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Création...' : 'Créer le plan de succession'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}