import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Plus, X } from "lucide-react";

export default function TalentPoolForm({ employees, onSubmit, onCancel, isSubmitting }) {
  const [formData, setFormData] = useState({
    employee_email: "",
    employee_name: "",
    current_position: "",
    department: "",
    talent_category: "solid_performer",
    performance_rating: 3,
    potential_rating: 3,
    nine_box_position: "medium_performance_medium_potential",
    retention_risk: "low",
    mobility_readiness: "ready_2_years",
    key_strengths: [],
    development_areas: [],
    career_aspirations: "",
    recommended_actions: [],
    critical_skills: [],
    languages: [],
    international_mobility: false,
    notes: ""
  });

  const [newItem, setNewItem] = useState("");

  const handleEmployeeChange = (email) => {
    const employee = employees.find(e => e.email === email);
    if (employee) {
      setFormData({
        ...formData,
        employee_email: email,
        employee_name: employee.full_name,
        current_position: employee.position,
        department: employee.department
      });
    }
  };

  // Calculer automatiquement la position dans la 9-box
  const calculateNineBoxPosition = (performance, potential) => {
    const perfLevel = performance <= 2.5 ? 'low' : performance <= 3.5 ? 'medium' : 'high';
    const potLevel = potential <= 2.5 ? 'low' : potential <= 3.5 ? 'medium' : 'high';
    return `${perfLevel}_performance_${potLevel}_potential`;
  };

  const handleRatingChange = (type, value) => {
    const newData = { ...formData, [type]: value };
    if (type === 'performance_rating' || type === 'potential_rating') {
      newData.nine_box_position = calculateNineBoxPosition(
        type === 'performance_rating' ? value : formData.performance_rating,
        type === 'potential_rating' ? value : formData.potential_rating
      );
    }
    setFormData(newData);
  };

  const addToArray = (field) => {
    if (newItem.trim()) {
      setFormData({
        ...formData,
        [field]: [...formData[field], newItem.trim()]
      });
      setNewItem("");
    }
  };

  const removeFromArray = (field, index) => {
    setFormData({
      ...formData,
      [field]: formData[field].filter((_, i) => i !== index)
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Ajouter un talent au vivier</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Employé */}
          <div className="space-y-4">
            <h3 className="font-semibold text-slate-900">Informations employé</h3>
            <div className="space-y-2">
              <Label htmlFor="employee">Employé *</Label>
              <Select
                value={formData.employee_email}
                onValueChange={handleEmployeeChange}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner un employé" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.id} value={emp.email}>
                      {emp.full_name} - {emp.position}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Évaluations */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Évaluation</h3>
            
            <div className="space-y-2">
              <Label>Catégorie de talent *</Label>
              <Select
                value={formData.talent_category}
                onValueChange={(value) => setFormData({...formData, talent_category: value})}
                required
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high_potential">🌟 Haut Potentiel</SelectItem>
                  <SelectItem value="high_performer">⚡ Haute Performance</SelectItem>
                  <SelectItem value="key_talent">🔑 Talent Clé</SelectItem>
                  <SelectItem value="emerging_talent">🌱 Talent Émergent</SelectItem>
                  <SelectItem value="solid_performer">✅ Performeur Solide</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Performance (1-5) *</Label>
                  <Badge variant="outline" className="text-lg">{formData.performance_rating}</Badge>
                </div>
                <Slider
                  value={[formData.performance_rating]}
                  onValueChange={([value]) => handleRatingChange('performance_rating', value)}
                  min={1}
                  max={5}
                  step={0.5}
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Potentiel (1-5) *</Label>
                  <Badge variant="outline" className="text-lg">{formData.potential_rating}</Badge>
                </div>
                <Slider
                  value={[formData.potential_rating]}
                  onValueChange={([value]) => handleRatingChange('potential_rating', value)}
                  min={1}
                  max={5}
                  step={0.5}
                  className="w-full"
                />
              </div>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="text-sm font-medium text-blue-900 mb-1">Position 9-Box Grid</p>
              <p className="text-xs text-blue-700">
                {formData.nine_box_position.replace(/_/g, ' ').replace(/performance|potential/g, '')}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Risque de départ</Label>
                <Select
                  value={formData.retention_risk}
                  onValueChange={(value) => setFormData({...formData, retention_risk: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">🟢 Faible</SelectItem>
                    <SelectItem value="medium">🟡 Moyen</SelectItem>
                    <SelectItem value="high">🟠 Élevé</SelectItem>
                    <SelectItem value="critical">🔴 Critique</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Prêt pour une mobilité</Label>
                <Select
                  value={formData.mobility_readiness}
                  onValueChange={(value) => setFormData({...formData, mobility_readiness: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="not_ready">Pas prêt</SelectItem>
                    <SelectItem value="ready_1_year">Prêt dans 1 an</SelectItem>
                    <SelectItem value="ready_2_years">Prêt dans 2 ans</SelectItem>
                    <SelectItem value="ready_now">Prêt maintenant</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Points forts et développement */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Forces et développement</h3>
            
            <div className="space-y-2">
              <Label>Points forts clés</Label>
              <div className="flex gap-2">
                <Input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  placeholder="Ajouter un point fort"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addToArray('key_strengths'))}
                />
                <Button type="button" onClick={() => addToArray('key_strengths')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.key_strengths.map((item, index) => (
                  <Badge key={index} variant="outline" className="gap-2 bg-green-50">
                    ✅ {item}
                    <button type="button" onClick={() => removeFromArray('key_strengths', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Domaines de développement</Label>
              <div className="flex gap-2">
                <Input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  placeholder="Ajouter un domaine"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addToArray('development_areas'))}
                />
                <Button type="button" onClick={() => addToArray('development_areas')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.development_areas.map((item, index) => (
                  <Badge key={index} variant="outline" className="gap-2 bg-orange-50">
                    📈 {item}
                    <button type="button" onClick={() => removeFromArray('development_areas', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="career_aspirations">Aspirations de carrière</Label>
              <Textarea
                id="career_aspirations"
                value={formData.career_aspirations}
                onChange={(e) => setFormData({...formData, career_aspirations: e.target.value})}
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Actions recommandées</Label>
              <div className="flex gap-2">
                <Input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  placeholder="Ajouter une action"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addToArray('recommended_actions'))}
                />
                <Button type="button" onClick={() => addToArray('recommended_actions')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.recommended_actions.map((item, index) => (
                  <Badge key={index} variant="outline" className="gap-2 bg-blue-50">
                    💡 {item}
                    <button type="button" onClick={() => removeFromArray('recommended_actions', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Compétences et langues */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="font-semibold text-slate-900">Compétences et mobilité</h3>
            
            <div className="space-y-2">
              <Label>Compétences critiques</Label>
              <div className="flex gap-2">
                <Input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  placeholder="Ajouter une compétence"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addToArray('critical_skills'))}
                />
                <Button type="button" onClick={() => addToArray('critical_skills')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.critical_skills.map((item, index) => (
                  <Badge key={index} variant="outline" className="gap-2">
                    {item}
                    <button type="button" onClick={() => removeFromArray('critical_skills', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Langues</Label>
              <div className="flex gap-2">
                <Input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  placeholder="Ajouter une langue"
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addToArray('languages'))}
                />
                <Button type="button" onClick={() => addToArray('languages')}>
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {formData.languages.map((item, index) => (
                  <Badge key={index} variant="outline" className="gap-2">
                    🌐 {item}
                    <button type="button" onClick={() => removeFromArray('languages', index)}>
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="international_mobility"
                checked={formData.international_mobility}
                onCheckedChange={(checked) => setFormData({...formData, international_mobility: checked})}
              />
              <Label htmlFor="international_mobility" className="cursor-pointer">
                Ouvert à une mobilité internationale
              </Label>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Notes confidentielles</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting} className="bg-blue-600 hover:bg-blue-700">
              {isSubmitting ? 'Ajout...' : 'Ajouter au vivier de talents'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}