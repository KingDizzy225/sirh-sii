import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, MessageSquare } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

export default function ContinuousFeedbackList({ feedbacks, currentUser, onAcknowledge, onRespond }) {
  const [expandedId, setExpandedId] = useState(null);
  const [response, setResponse] = useState("");

  const handleRespond = (feedbackId) => {
    onRespond(feedbackId, response);
    setResponse("");
    setExpandedId(null);
  };

  const typeColors = {
    appreciation: "bg-green-100 text-green-800",
    constructive: "bg-blue-100 text-blue-800",
    request: "bg-purple-100 text-purple-800",
    observation: "bg-yellow-100 text-yellow-800"
  };

  const typeLabels = {
    appreciation: "✨ Appréciation",
    constructive: "🔧 Constructif",
    request: "🙏 Demande",
    observation: "👀 Observation"
  };

  const categoryLabels = {
    technical: "💻 Technique",
    communication: "💬 Communication",
    teamwork: "👥 Équipe",
    leadership: "⭐ Leadership",
    attitude: "😊 Attitude",
    productivity: "📈 Productivité",
    other: "📋 Autre"
  };

  return (
    <div className="space-y-4">
      {feedbacks.map(feedback => {
        const isReceiver = feedback.receiver_email === currentUser?.email;
        const isGiver = feedback.giver_email === currentUser?.email;
        const showGiver = !feedback.is_anonymous || isGiver;

        return (
          <Card key={feedback.id} className="border-none shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={typeColors[feedback.feedback_type]}>
                      {typeLabels[feedback.feedback_type]}
                    </Badge>
                    <Badge variant="outline">
                      {categoryLabels[feedback.category]}
                    </Badge>
                    {feedback.is_anonymous && (
                      <Badge variant="outline" className="bg-gray-100">
                        🔒 Anonyme
                      </Badge>
                    )}
                    {feedback.status === "acknowledged" && (
                      <Badge className="bg-green-600">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Lu
                      </Badge>
                    )}
                  </div>
                  
                  <div className="text-sm text-slate-600 mb-1">
                    {showGiver ? (
                      <>De: <strong>{feedback.giver_name}</strong></>
                    ) : (
                      <>De: <strong>Anonyme</strong></>
                    )}
                    {" → "}
                    À: <strong>{feedback.receiver_name}</strong>
                  </div>

                  <p className="text-xs text-slate-500">
                    {format(new Date(feedback.created_date), "d MMMM yyyy 'à' HH:mm", { locale: fr })}
                  </p>
                </div>

                <Badge className={
                  feedback.impact_level === 'high' ? 'bg-red-600' :
                  feedback.impact_level === 'medium' ? 'bg-yellow-600' :
                  'bg-green-600'
                }>
                  {feedback.impact_level === 'high' ? '🔴 Impact élevé' :
                   feedback.impact_level === 'medium' ? '🟡 Impact moyen' :
                   '🟢 Impact faible'}
                </Badge>
              </div>

              {feedback.context && (
                <div className="mb-3 p-3 bg-slate-50 rounded-lg">
                  <p className="text-xs font-medium text-slate-700 mb-1">📍 Contexte:</p>
                  <p className="text-sm text-slate-800">{feedback.context}</p>
                </div>
              )}

              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 mb-3">
                <p className="text-sm text-blue-900 whitespace-pre-wrap">{feedback.content}</p>
              </div>

              {feedback.ai_tags && feedback.ai_tags.length > 0 && (
                <div className="mb-3 flex flex-wrap gap-1">
                  <span className="text-xs text-slate-600">Tags IA:</span>
                  {feedback.ai_tags.map((tag, i) => (
                    <Badge key={i} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {feedback.response && (
                <div className="p-3 bg-green-50 rounded-lg border border-green-200 mb-3">
                  <p className="text-xs font-medium text-green-700 mb-1">💬 Réponse:</p>
                  <p className="text-sm text-green-900">{feedback.response}</p>
                </div>
              )}

              {isReceiver && feedback.status !== "acknowledged" && (
                <div className="flex gap-2 mt-3">
                  <Button
                    size="sm"
                    onClick={() => onAcknowledge(feedback.id)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Marquer comme lu
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setExpandedId(expandedId === feedback.id ? null : feedback.id)}
                  >
                    <MessageSquare className="w-4 h-4 mr-2" />
                    Répondre
                  </Button>
                </div>
              )}

              {expandedId === feedback.id && (
                <div className="mt-3 space-y-2">
                  <Textarea
                    value={response}
                    onChange={(e) => setResponse(e.target.value)}
                    placeholder="Votre réponse..."
                    rows={3}
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleRespond(feedback.id)}
                      disabled={!response}
                    >
                      Envoyer la réponse
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setExpandedId(null);
                        setResponse("");
                      }}
                    >
                      Annuler
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}

      {feedbacks.length === 0 && (
        <Card className="border-none shadow-lg">
          <CardContent className="p-12 text-center text-slate-500">
            <MessageSquare className="w-16 h-16 mx-auto mb-4 text-slate-300" />
            <p className="text-lg font-medium mb-2">Aucun feedback</p>
            <p className="text-sm">Les feedbacks apparaîtront ici</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}