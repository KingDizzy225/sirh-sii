import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { base44 } from "@/api/base44Client";

export default function ContinuousFeedbackForm({ onSubmit, onCancel, isSubmitting, employees = [] }) {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    receiver_email: "",
    receiver_name: "",
    feedback_type: "appreciation",
    category: "other",
    content: "",
    context: "",
    is_anonymous: false,
    visibility: "private",
    impact_level: "medium"
  });

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const data = {
      ...formData,
      giver_email: user.email,
      giver_name: user.full_name || user.email,
      status: "sent"
    };

    onSubmit(data);
  };

  const handleEmployeeSelect = (email) => {
    const employee = employees.find(e => e.email === email);
    setFormData({
      ...formData,
      receiver_email: email,
      receiver_name: employee?.full_name || email
    });
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Donner un feedback</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>À qui ? *</Label>
            <Select value={formData.receiver_email} onValueChange={handleEmployeeSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un collègue" />
              </SelectTrigger>
              <SelectContent>
                {employees
                  .filter(e => user && e.email !== user.email)
                  .map(e => (
                    <SelectItem key={e.id} value={e.email}>
                      {e.full_name} - {e.position}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Type de feedback *</Label>
              <Select value={formData.feedback_type} onValueChange={(value) => setFormData({...formData, feedback_type: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="appreciation">✨ Appréciation</SelectItem>
                  <SelectItem value="constructive">🔧 Constructif</SelectItem>
                  <SelectItem value="request">🙏 Demande</SelectItem>
                  <SelectItem value="observation">👀 Observation</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Catégorie *</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical">💻 Technique</SelectItem>
                  <SelectItem value="communication">💬 Communication</SelectItem>
                  <SelectItem value="teamwork">👥 Travail d'équipe</SelectItem>
                  <SelectItem value="leadership">⭐ Leadership</SelectItem>
                  <SelectItem value="attitude">😊 Attitude</SelectItem>
                  <SelectItem value="productivity">📈 Productivité</SelectItem>
                  <SelectItem value="other">📋 Autre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>Contexte / Situation</Label>
            <Input
              value={formData.context}
              onChange={(e) => setFormData({...formData, context: e.target.value})}
              placeholder="Quand et où cela s'est-il produit ?"
            />
          </div>

          <div>
            <Label>Votre feedback *</Label>
            <Textarea
              value={formData.content}
              onChange={(e) => setFormData({...formData, content: e.target.value})}
              placeholder="Décrivez votre feedback de manière constructive..."
              rows={6}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Impact</Label>
              <Select value={formData.impact_level} onValueChange={(value) => setFormData({...formData, impact_level: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">🟢 Faible</SelectItem>
                  <SelectItem value="medium">🟡 Moyen</SelectItem>
                  <SelectItem value="high">🔴 Élevé</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Visibilité</Label>
              <Select value={formData.visibility} onValueChange={(value) => setFormData({...formData, visibility: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="private">🔒 Privé (vous + destinataire + RH)</SelectItem>
                  <SelectItem value="manager">👤 Manager inclus</SelectItem>
                  <SelectItem value="team">👥 Équipe</SelectItem>
                  <SelectItem value="public">🌐 Public</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2 p-3 bg-amber-50 rounded-lg border border-amber-200">
            <Switch
              checked={formData.is_anonymous}
              onCheckedChange={(checked) => setFormData({...formData, is_anonymous: checked})}
            />
            <Label className="cursor-pointer">
              Feedback anonyme (votre identité ne sera pas révélée)
            </Label>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={onCancel}>
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting || !formData.receiver_email || !formData.content}>
              {isSubmitting ? "Envoi..." : "Envoyer le feedback"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}