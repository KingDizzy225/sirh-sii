import React, { useState, useEffect, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Search,
  User,
  Briefcase,
  FileText,
  Calendar,
  GraduationCap,
  Building2,
  UserCheck,
  Award,
  Clock,
  TrendingUp,
  Filter,
  X,
  ChevronRight,
  History,
  Sparkles
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

const SEARCH_CATEGORIES = {
  all: { label: "Tout", icon: Search },
  employees: { label: "Employés", icon: User },
  candidates: { label: "Candidats", icon: UserCheck },
  jobs: { label: "Postes", icon: Briefcase },
  documents: { label: "Documents", icon: FileText },
  trainings: { label: "Formations", icon: GraduationCap },
  departments: { label: "Départements", icon: Building2 },
  reviews: { label: "Évaluations", icon: Award },
  leaves: { label: "Congés", icon: Calendar },
};

export default function GlobalSearch({ isOpen, onClose, userRole }) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState([]);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    department: "all",
    status: "all",
    dateRange: "all",
  });

  const navigate = useNavigate();
  const searchInputRef = useRef(null);

  // Debounce search query
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load recent searches from localStorage
  useEffect(() => {
    const stored = localStorage.getItem("recentSearches");
    if (stored) {
      setRecentSearches(JSON.parse(stored));
    }
  }, []);

  // Focus input when dialog opens
  useEffect(() => {
    if (isOpen && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Save search to recent searches
  const saveRecentSearch = useCallback((query, category) => {
    if (!query.trim()) return;
    
    const newSearch = {
      query,
      category,
      timestamp: new Date().toISOString(),
    };
    
    const updated = [newSearch, ...recentSearches.filter(s => s.query !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem("recentSearches", JSON.stringify(updated));
  }, [recentSearches]);

  // Fetch all searchable data
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'employees'),
  });

  const { data: candidates = [] } = useQuery({
    queryKey: ['candidates'],
    queryFn: () => base44.entities.Candidate.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'candidates'),
  });

  const { data: jobPostings = [] } = useQuery({
    queryKey: ['jobPostings'],
    queryFn: () => base44.entities.JobPosting.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'jobs'),
  });

  const { data: documents = [] } = useQuery({
    queryKey: ['documents'],
    queryFn: () => base44.entities.Document.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'documents'),
  });

  const { data: trainings = [] } = useQuery({
    queryKey: ['trainings'],
    queryFn: () => base44.entities.Training.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'trainings'),
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments'],
    queryFn: () => base44.entities.Department.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'departments'),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews'],
    queryFn: () => base44.entities.PerformanceReview.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'reviews') && userRole !== 'employee',
  });

  const { data: leaves = [] } = useQuery({
    queryKey: ['leaves'],
    queryFn: () => base44.entities.LeaveRequest.list(),
    enabled: isOpen && (activeCategory === 'all' || activeCategory === 'leaves'),
  });

  // Search scoring algorithm
  const calculateScore = (item, query, searchFields) => {
    if (!query) return 0;
    
    let score = 0;
    const lowerQuery = query.toLowerCase();
    const queryWords = lowerQuery.split(' ').filter(w => w.length > 0);

    searchFields.forEach(({ field, weight = 1, exact = false }) => {
      const value = field.split('.').reduce((obj, key) => obj?.[key], item);
      if (!value) return;
      
      const lowerValue = String(value).toLowerCase();
      
      // Exact match bonus
      if (lowerValue === lowerQuery) {
        score += 100 * weight;
      }
      
      // Starts with query bonus
      if (lowerValue.startsWith(lowerQuery)) {
        score += 50 * weight;
      }
      
      // Contains query
      if (lowerValue.includes(lowerQuery)) {
        score += 25 * weight;
      }
      
      // Word matches
      queryWords.forEach(word => {
        if (lowerValue.includes(word)) {
          score += 10 * weight;
        }
      });
    });

    return score;
  };

  // Search employees
  const searchEmployees = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return employees
      .map(emp => ({
        ...emp,
        type: 'employee',
        score: calculateScore(emp, debouncedQuery, [
          { field: 'full_name', weight: 3 },
          { field: 'email', weight: 2 },
          { field: 'position', weight: 2 },
          { field: 'department', weight: 1.5 },
          { field: 'employee_id', weight: 2 },
        ])
      }))
      .filter(emp => {
        if (emp.score === 0) return false;
        if (filters.department !== 'all' && emp.department !== filters.department) return false;
        if (filters.status !== 'all' && emp.status !== filters.status) return false;
        return true;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [employees, debouncedQuery, filters]);

  // Search candidates
  const searchCandidates = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return candidates
      .map(cand => ({
        ...cand,
        type: 'candidate',
        score: calculateScore(cand, debouncedQuery, [
          { field: 'full_name', weight: 3 },
          { field: 'email', weight: 2 },
          { field: 'job_title', weight: 2 },
          { field: 'phone', weight: 1 },
        ])
      }))
      .filter(cand => {
        if (cand.score === 0) return false;
        if (filters.status !== 'all' && cand.status !== filters.status) return false;
        return true;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [candidates, debouncedQuery, filters]);

  // Search job postings
  const searchJobs = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return jobPostings
      .map(job => ({
        ...job,
        type: 'job',
        score: calculateScore(job, debouncedQuery, [
          { field: 'title', weight: 3 },
          { field: 'department', weight: 2 },
          { field: 'location', weight: 1.5 },
          { field: 'description', weight: 1 },
        ])
      }))
      .filter(job => {
        if (job.score === 0) return false;
        if (filters.department !== 'all' && job.department !== filters.department) return false;
        if (filters.status !== 'all' && job.status !== filters.status) return false;
        return true;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [jobPostings, debouncedQuery, filters]);

  // Search documents
  const searchDocuments = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return documents
      .map(doc => ({
        ...doc,
        type: 'document',
        score: calculateScore(doc, debouncedQuery, [
          { field: 'title', weight: 3 },
          { field: 'employee_name', weight: 2 },
          { field: 'document_type', weight: 2 },
          { field: 'description', weight: 1 },
        ])
      }))
      .filter(doc => doc.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [documents, debouncedQuery]);

  // Search trainings
  const searchTrainings = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return trainings
      .map(training => ({
        ...training,
        type: 'training',
        score: calculateScore(training, debouncedQuery, [
          { field: 'title', weight: 3 },
          { field: 'category', weight: 2 },
          { field: 'instructor', weight: 1.5 },
          { field: 'description', weight: 1 },
        ])
      }))
      .filter(training => {
        if (training.score === 0) return false;
        if (filters.status !== 'all' && training.status !== filters.status) return false;
        return true;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [trainings, debouncedQuery, filters]);

  // Search departments
  const searchDepartments = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return departments
      .map(dept => ({
        ...dept,
        type: 'department',
        score: calculateScore(dept, debouncedQuery, [
          { field: 'name', weight: 3 },
          { field: 'description', weight: 1 },
          { field: 'manager_email', weight: 1 },
        ])
      }))
      .filter(dept => dept.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [departments, debouncedQuery]);

  // Search reviews
  const searchReviews = useCallback(() => {
    if (!debouncedQuery || userRole === 'employee') return [];
    
    return reviews
      .map(review => ({
        ...review,
        type: 'review',
        score: calculateScore(review, debouncedQuery, [
          { field: 'employee_name', weight: 3 },
          { field: 'review_period', weight: 2 },
          { field: 'reviewer_email', weight: 1 },
        ])
      }))
      .filter(review => review.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [reviews, debouncedQuery, userRole]);

  // Search leaves
  const searchLeaves = useCallback(() => {
    if (!debouncedQuery) return [];
    
    return leaves
      .map(leave => ({
        ...leave,
        type: 'leave',
        score: calculateScore(leave, debouncedQuery, [
          { field: 'employee_name', weight: 3 },
          { field: 'leave_type', weight: 2 },
        ])
      }))
      .filter(leave => {
        if (leave.score === 0) return false;
        if (filters.status !== 'all' && leave.status !== filters.status) return false;
        return true;
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }, [leaves, debouncedQuery, filters]);

  // Aggregate all results
  const allResults = {
    employees: searchEmployees(),
    candidates: searchCandidates(),
    jobs: searchJobs(),
    documents: searchDocuments(),
    trainings: searchTrainings(),
    departments: searchDepartments(),
    reviews: searchReviews(),
    leaves: searchLeaves(),
  };

  const totalResults = Object.values(allResults).reduce((sum, arr) => sum + arr.length, 0);

  const currentResults = activeCategory === 'all' 
    ? Object.entries(allResults)
        .filter(([_, items]) => items.length > 0)
        .flatMap(([category, items]) => items)
        .sort((a, b) => b.score - a.score)
        .slice(0, 20)
    : allResults[activeCategory] || [];

  // Handle result click
  const handleResultClick = (result) => {
    saveRecentSearch(searchQuery, activeCategory);
    
    const navigationMap = {
      employee: () => navigate(createPageUrl("Employees")),
      candidate: () => navigate(createPageUrl("Recruitment")),
      job: () => navigate(createPageUrl("Recruitment")),
      document: () => navigate(createPageUrl("Documents")),
      training: () => navigate(createPageUrl("TrainingManagement")),
      department: () => navigate(createPageUrl("Departments")),
      review: () => navigate(createPageUrl("Performance")),
      leave: () => navigate(createPageUrl("LeaveManagement")),
    };

    const navFunction = navigationMap[result.type];
    if (navFunction) {
      navFunction();
      onClose();
    }
  };

  // Clear filters
  const clearFilters = () => {
    setFilters({
      department: "all",
      status: "all",
      dateRange: "all",
    });
  };

  const hasActiveFilters = filters.department !== 'all' || filters.status !== 'all' || filters.dateRange !== 'all';

  // Get unique departments for filter
  const allDepartments = [...new Set([
    ...employees.map(e => e.department),
    ...jobPostings.map(j => j.department),
  ])].filter(Boolean).sort();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden p-0">
        <div className="flex flex-col h-full">
          {/* Search Header */}
          <div className="p-4 border-b sticky top-0 bg-white z-10">
            <div className="flex items-center gap-3 mb-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input
                  ref={searchInputRef}
                  placeholder="Rechercher employés, candidats, documents..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 h-12 text-lg"
                />
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowFilters(!showFilters)}
                className={hasActiveFilters ? 'border-blue-500 text-blue-600' : ''}
              >
                <Filter className="w-5 h-5" />
              </Button>
            </div>

            {/* Filters Panel */}
            {showFilters && (
              <div className="p-3 bg-slate-50 rounded-lg space-y-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-slate-700">Filtres avancés</p>
                  {hasActiveFilters && (
                    <Button variant="ghost" size="sm" onClick={clearFilters}>
                      <X className="w-4 h-4 mr-1" />
                      Effacer
                    </Button>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-xs text-slate-600 mb-1 block">Département</label>
                    <select
                      value={filters.department}
                      onChange={(e) => setFilters({...filters, department: e.target.value})}
                      className="w-full px-3 py-2 rounded-md border border-slate-200 text-sm"
                    >
                      <option value="all">Tous</option>
                      {allDepartments.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 mb-1 block">Statut</label>
                    <select
                      value={filters.status}
                      onChange={(e) => setFilters({...filters, status: e.target.value})}
                      className="w-full px-3 py-2 rounded-md border border-slate-200 text-sm"
                    >
                      <option value="all">Tous</option>
                      <option value="active">Actif</option>
                      <option value="pending">En attente</option>
                      <option value="completed">Terminé</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-slate-600 mb-1 block">Période</label>
                    <select
                      value={filters.dateRange}
                      onChange={(e) => setFilters({...filters, dateRange: e.target.value})}
                      className="w-full px-3 py-2 rounded-md border border-slate-200 text-sm"
                    >
                      <option value="all">Toutes</option>
                      <option value="today">Aujourd'hui</option>
                      <option value="week">Cette semaine</option>
                      <option value="month">Ce mois</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Category Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 pt-3">
              {Object.entries(SEARCH_CATEGORIES).map(([key, { label, icon: Icon }]) => (
                <Button
                  key={key}
                  variant={activeCategory === key ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveCategory(key)}
                  className="flex items-center gap-2 whitespace-nowrap"
                >
                  <Icon className="w-4 h-4" />
                  {label}
                  {key !== 'all' && allResults[key]?.length > 0 && (
                    <Badge variant="secondary" className="ml-1">
                      {allResults[key].length}
                    </Badge>
                  )}
                </Button>
              ))}
            </div>
          </div>

          {/* Results */}
          <div className="flex-1 overflow-y-auto p-4">
            {!debouncedQuery && recentSearches.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-3">
                  <History className="w-4 h-4 text-slate-500" />
                  <h3 className="font-semibold text-slate-700">Recherches récentes</h3>
                </div>
                <div className="space-y-2">
                  {recentSearches.map((recent, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setSearchQuery(recent.query);
                        setActiveCategory(recent.category);
                      }}
                      className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors text-left"
                    >
                      <div className="flex items-center gap-3">
                        <Clock className="w-4 h-4 text-slate-400" />
                        <span className="text-sm">{recent.query}</span>
                        <Badge variant="outline" className="text-xs">
                          {SEARCH_CATEGORIES[recent.category]?.label}
                        </Badge>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-400" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {debouncedQuery && (
              <>
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm text-slate-600">
                    {totalResults} résultat{totalResults > 1 ? 's' : ''} trouvé{totalResults > 1 ? 's' : ''}
                  </p>
                  {totalResults > 0 && (
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Sparkles className="w-4 h-4" />
                      <span>Triés par pertinence</span>
                    </div>
                  )}
                </div>

                {totalResults === 0 ? (
                  <div className="text-center py-12">
                    <Search className="w-16 h-16 mx-auto mb-4 text-slate-300" />
                    <p className="text-slate-600 font-medium mb-2">Aucun résultat trouvé</p>
                    <p className="text-sm text-slate-500">
                      Essayez d'autres mots-clés ou ajustez vos filtres
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {currentResults.map((result, idx) => (
                      <ResultCard
                        key={`${result.type}-${result.id}-${idx}`}
                        result={result}
                        onClick={() => handleResultClick(result)}
                      />
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Result Card Component
function ResultCard({ result, onClick }) {
  const getIcon = () => {
    const iconMap = {
      employee: User,
      candidate: UserCheck,
      job: Briefcase,
      document: FileText,
      training: GraduationCap,
      department: Building2,
      review: Award,
      leave: Calendar,
    };
    const Icon = iconMap[result.type] || Search;
    return <Icon className="w-5 h-5" />;
  };

  const getTitle = () => {
    switch (result.type) {
      case 'employee':
        return result.full_name;
      case 'candidate':
        return result.full_name;
      case 'job':
        return result.title;
      case 'document':
        return result.title;
      case 'training':
        return result.title;
      case 'department':
        return result.name;
      case 'review':
        return `Évaluation de ${result.employee_name}`;
      case 'leave':
        return `Congé de ${result.employee_name}`;
      default:
        return 'Résultat';
    }
  };

  const getSubtitle = () => {
    switch (result.type) {
      case 'employee':
        return `${result.position} • ${result.department}`;
      case 'candidate':
        return `${result.job_title} • ${result.status}`;
      case 'job':
        return `${result.department} • ${result.location}`;
      case 'document':
        return `${result.document_type} • ${result.employee_name}`;
      case 'training':
        return `${result.category} • ${result.duration_hours}h`;
      case 'department':
        return `${result.employee_count} employés`;
      case 'review':
        return `${result.review_period} • Note: ${result.overall_rating}/5`;
      case 'leave':
        return `${result.leave_type} • ${result.days_count} jour(s)`;
      default:
        return '';
    }
  };

  const getStatusColor = () => {
    const status = result.status?.toLowerCase();
    if (status === 'active' || status === 'completed' || status === 'approved') return 'bg-green-100 text-green-800';
    if (status === 'pending') return 'bg-yellow-100 text-yellow-800';
    if (status === 'rejected' || status === 'terminated') return 'bg-red-100 text-red-800';
    return 'bg-slate-100 text-slate-800';
  };

  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-4 p-4 rounded-lg border border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-all text-left group"
    >
      <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 group-hover:bg-blue-200 transition-colors flex-shrink-0">
        {getIcon()}
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <h4 className="font-semibold text-slate-900 truncate">{getTitle()}</h4>
          {result.score > 50 && (
            <Badge className="bg-purple-100 text-purple-700 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              Pertinent
            </Badge>
          )}
        </div>
        <p className="text-sm text-slate-600 truncate">{getSubtitle()}</p>
      </div>

      {result.status && (
        <Badge className={getStatusColor()}>
          {result.status}
        </Badge>
      )}

      <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors flex-shrink-0" />
    </button>
  );
}